/* test-option.c -- 
 * Created: Wed Dec 29 05:37:25 1999 by faith@acm.org
 * Copyright 1999, 2000, 2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-option.c,v 1.5 2003-06-14 12:14:33 faith Exp $
 *
 */

#define OBJECTTYPE     ur_option_t
#define OBJECTCREATE   ur_option_create
#define OBJECTDESTROY  ur_option_destroy

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    int            c;
    ur_list_t       list;
    ur_option_t     opt;
    ur_option_list_t optlist[] = {
	{ "arg", 'a', UR_OPTION_ARG  },
	{ NULL,  'b', UR_OPTION_ARG  },
	{ "c",   'c', UR_OPTION_NONE },
	{ "l",   'l', UR_OPTION_LIST },
	{ NULL, 0, 0 },
    };
    
    test("L", "-a foo");
    opt = ur_option_create(optlist);
    ur_option_parse_string(opt, "-a foo");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);
    end(opt);
    
    test("L", "-a  foo");
    opt = ur_option_create(optlist);
    ur_option_parse_string(opt, "  -a  foo");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);
    end(opt);
    
    test("L", "-a ' foo'");
    opt = ur_option_create(optlist);
    ur_option_parse_string(opt, "-a ' foo'");
    c = ur_option_get(opt);
    if (c != 'a')                             fail("a");
    if (strcmp(ur_option_string(opt), " foo")) fail("foo");
    ok(0);
    
    test("L", "-afoo");
    ur_option_parse_string(opt, "-a foo");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);

    test("L", "--arg foo");
    ur_option_parse_string(opt, "--arg foo");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "--argfoo");
    ur_option_parse_string(opt, "--argfoo");
    c = ur_option_get(opt);
    if (c != '?')                            fail("a");
    if (ur_option_string(opt))                fail("arg");
    ok(0);
    
    test("L", "-afoo -bbar");
    ur_option_parse_string(opt, "-afoo -bbar");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    c = ur_option_get(opt);
    if (c != 'b')                            fail("b");
    if (strcmp(ur_option_string(opt), "bar")) fail("bar");
    ok(0);
    
    test("L", "-cafoo");
    ur_option_parse_string(opt, "-cafoo");
    c = ur_option_get(opt);
    if (c != 'c')                            fail("c");
    if (ur_option_string(opt))                fail("arg");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "-c  -afoo");
    ur_option_parse_string(opt, "-c  -afoo");
    c = ur_option_get(opt);
    if (c != 'c')                            fail("c");
    if (ur_option_string(opt))                fail("arg");
    c = ur_option_get(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(ur_option_string(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "-c x -afoo");
    ur_option_parse_string(opt, "-c x -afoo");
    c = ur_option_get(opt);
    if (c != 'c')                            fail("c");
    if (ur_option_string(opt))                fail("arg");
    c = ur_option_get(opt);
    if (c != EOF)                            fail("eof");
    list = ur_option_other(opt);
    if (ur_list_depth(list) != 2)             fail("depth");
    if (strcmp(ur_list_pop(list), "x"))       fail("x");
    if (strcmp(ur_list_pop(list), "-afoo"))   fail("-afoo");
    ur_list_destroy(list);
    ok(0);
    
    test("L", "-c -- -afoo");
    ur_option_parse_string(opt, "-c -- -afoo");
    c = ur_option_get(opt);
    if (c != 'c')                            fail("c");
    if (ur_option_string(opt))                fail("arg");
    c = ur_option_get(opt);
    if (c != EOF)                            fail("eof");
    list = ur_option_other(opt);
    if (ur_list_depth(list) != 1)             fail("depth");
    if (strcmp(ur_list_pop(list), "-afoo"))   fail("-afoo");
    ur_list_destroy(list);
    ok(0);
    
    test("L", "-c - -afoo");
    ur_option_parse_string(opt, "-c - -afoo");
    c = ur_option_get(opt);
    if (c != 'c')                            fail("c");
    if (ur_option_string(opt))                fail("arg");
    c = ur_option_get(opt);
    if (c != EOF)                            fail("eof");
    list = ur_option_other(opt);
    if (ur_list_depth(list) != 2)             fail("depth");
    if (strcmp(ur_list_pop(list), "-"))       fail("-");
    if (strcmp(ur_list_pop(list), "-afoo"))   fail("-afoo");
    ur_list_destroy(list);
    ok(0);

    test("L", "-l a,b,c - -afoo");
    ur_option_parse_string(opt, "-l a,b,c - -afoo");
    c = ur_option_get(opt);
    if (c != 'l')                              fail("l");
    if (strcmp(ur_option_string(opt), "a,b,c")) fail("string");
    list = ur_option_list(opt, NULL);
    if (!list)                                 fail("list");
    if (ur_list_depth(list) != 3)               fail("depth");
    if (strcmp(ur_list_nth(list, 1), "a"))      fail("a");
    if (strcmp(ur_list_nth(list, 2), "b"))      fail("b");
    if (strcmp(ur_list_nth(list, 3), "c"))      fail("c");
    if (ur_list_nth(list, 4))                   fail("too many");
    if (strcmp(ur_option_string(opt),"a,b,c"))  fail("arg");
    c = ur_option_get(opt);
    if (c != EOF)                              fail("eof");
    ur_list_destroy(list);
    list = ur_option_other(opt);
    if (ur_list_depth(list) != 2)               fail("depth");
    if (strcmp(ur_list_pop(list), "-"))         fail("-");
    if (strcmp(ur_list_pop(list), "-afoo"))     fail("-afoo");
    ur_list_destroy(list);
    ok(0);

    test("L", "ur_option_in_range");
    if (!ur_option_in_range(NULL, 1))            fail("1 not in NULL");
    if (!ur_option_in_range("1", 1))             fail("1 not in 1");
    if (!ur_option_in_range("1-2", 1))           fail("1 not in 1-2");
    if (!ur_option_in_range("1,", 1))            fail("1 not in 1,");
    if (!ur_option_in_range("1,,", 1))           fail("1 not in 1,,");
    if (!ur_option_in_range(",1", 1))            fail("1 not in ,1");
    if (!ur_option_in_range(",,1", 1))           fail("1 not in ,,1");
    if (!ur_option_in_range("1,2", 1))           fail("1 not in 1,2");
    if (!ur_option_in_range("1;2", 1))           fail("1 not in 1;2");
    if (!ur_option_in_range("2,1", 1))           fail("1 not in 2,1");
    if (!ur_option_in_range("2;1", 1))           fail("1 not in 2;1");
    if (!ur_option_in_range("2,1,3", 1))         fail("1 not in 2,1,3");
    if (!ur_option_in_range("0-3", 1))           fail("1 not in 0-3");
    if (!ur_option_in_range("4,0-3", 1))         fail("1 not in 4,0-3");
    if (!ur_option_in_range("0-3,4", 1))         fail("1 not in 0-3,4");
    if (!ur_option_in_range("3-0,4", 1))         fail("1 not in 3-0,4");
    if (!ur_option_in_range("1-", 1))            fail("1 not in 1-");
    if (!ur_option_in_range("-1", 1))            fail("1 not in -1");
    if (!ur_option_in_range("3-", 1))            fail("1 not in 3-");
    if (!ur_option_in_range("-3", 1))            fail("1 not in -3");
    if (!ur_option_in_range("7,1-", 1))          fail("1 not in 7,1-");
    if (!ur_option_in_range("7,-1", 1))          fail("1 not in 7,-1");
    if (!ur_option_in_range("7,3-", 1))          fail("1 not in 7,3-");
    if (!ur_option_in_range("7,-3", 1))          fail("1 not in 7,-3");
    if (!ur_option_in_range("1-,8", 1))          fail("1 not in 1-,8");
    if (!ur_option_in_range("-1,8", 1))          fail("1 not in -1,8");
    if (!ur_option_in_range("3-,8", 1))          fail("1 not in 3-,8");
    if (!ur_option_in_range("-3,8", 1))          fail("1 not in -3,8");
                                /* The -4 becomes unsigned, which may be
                                 * unexpected ... */
    if (!ur_option_in_range("--4,6", 5))         fail("5 not in --4,6");
    if (!ur_option_in_range("0--4,6", 5))        fail("5 not in 0--4,6");
    
    if (ur_option_in_range("0-3", 5))            fail("5 in 0-3");
    if (ur_option_in_range("", 5))               fail("5 in \"\"");
    if (ur_option_in_range("0-3;6", 5))          fail("5 in 0-3;6");
    if (ur_option_in_range("0-", 5))             fail("5 in 0-");
    if (ur_option_in_range("4,6", 5))            fail("5 in 4,6");
    if (ur_option_in_range("-4,6", 5))           fail("5 in -4,6");
    if (ur_option_in_range(",,,", 5))            fail("5 in ,,,");
    if (ur_option_in_range("a,b,e", 5))          fail("5 in a,b,e");
    ok(0);
    
    end(opt);
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
