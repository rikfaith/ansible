/* urmpplayer.c -- 
 * Created: Sun Nov 30 12:14:17 2008 by faith@acm.org
 * Revised: Sat Jan  3 14:52:15 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpplayer.h"
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

static int                  urmp_player_infd  = -1;
static int                  urmp_player_outfd = -1;
static volatile int         urmp_player_pid   = 0;
static ur_proc_t            urmp_player;
static urmp_player_status_t urmp_player_status;

static volatile int         urmp_player_in_handler;
static volatile int         urmp_player_in_worker;

uint64_t urmp_player_loadfile(const char *filename)
{
	ur_msg_t msg;
	uint64_t generation;
	
	msg = ur_msg_send(urmp_player, URMP_MSG_PLAY_FILE,
			  (void *)filename, strlen(filename)+1, 0);
	ur_msg_wait(msg, &generation, sizeof(generation), 0);
	return generation;
}

uint64_t urmp_player_set_volume(int volume)
{
	uint8_t  buf[2];
	ur_msg_t msg;
	uint64_t generation;

	if (volume < 0) volume = 0;
	if (volume > 100) volume = 100;
	buf[0] = volume / 256;
	buf[1] = volume - buf[0] * 256;
	msg = ur_msg_send(urmp_player, URMP_MSG_SET_VOLUME, buf, 2, 0);
	ur_msg_wait(msg, &generation, sizeof(generation), 0);
	return generation;
}

uint64_t urmp_player_set_position(int position)
{
	uint8_t  buf[2];
	ur_msg_t msg;
	uint64_t generation;

	buf[0] = position / 256;
	buf[1] = position - buf[0] * 256;
	msg = ur_msg_send(urmp_player, URMP_MSG_SET_POSITION, buf, 2, 0);
	ur_msg_wait(msg, &generation, sizeof(generation), 0);
	return generation;
}

uint64_t urmp_player_pause(void)
{
	ur_msg_t msg;
	uint64_t generation;

	ur_trace(URMP_TRACE_PLAYER, __func__, "\n");
	msg = ur_msg_send(urmp_player, URMP_MSG_PAUSE, NULL, 0, 0);
	ur_msg_wait(msg, &generation, sizeof(generation), 0);
	return generation;
}

uint64_t urmp_player_stop(void)
{
	ur_msg_t msg;
	uint64_t generation;

	ur_trace(URMP_TRACE_PLAYER, __func__, "\n");
	msg = ur_msg_send(urmp_player, URMP_MSG_STOP, NULL, 0, 0);
	ur_msg_wait(msg, &generation, sizeof(generation), 0);
	return generation;
}

uint64_t urmp_player_get_status(urmp_player_status_t *status)
{
	ur_msg_t msg;

	memset(status, 0, sizeof(*status));
	msg = ur_msg_send(urmp_player, URMP_MSG_GET_STATUS, NULL, 0, 0);
	ur_msg_wait(msg, status, sizeof(*status), 0);
#if 0
	printf("GOT %f %f %d playing=%d paused=%d\n",
	       status->volume,
	       status->time_pos,
	       status->percent_pos,
	       status->playing,
	       status->paused);
#endif
	return status->generation;
}

static bool urmp_player_input_available(int fd)
{
	fd_set readfds;
	struct timeval timeout;

	if (fd < 0) return false;
	FD_ZERO(&readfds);
	FD_SET(fd, &readfds);
	timeout.tv_sec = 0;
	timeout.tv_usec = 0;
	
	if (select(fd+1, &readfds, NULL, NULL, &timeout) > 0) {
		ur_trace(URMP_TRACE_PLAYERINT, __func__,
			 "fd=%d available\n", fd);
		return true;
	}
	ur_trace(URMP_TRACE_PLAYERINT, __func__, "fd=%d NOT available\n", fd);
	return false;
}

static void urmp_player_request_status(int fd)
{
	char buf[] = "get_property volume\n"
		     "get_property time_pos\n"
		     "get_property percent_pos\n";

	if (fd < 0) return;

	write(fd, buf, strlen(buf));
}

static void urmp_player_slave_parse(const char *buf)
{
	const char *pt;
	bool       update = false;

	ur_trace(URMP_TRACE_SLAVE, __func__, "%s\n", buf);

	if ((pt = strstr(buf, "ANS_volume="))) {
		pt = strchr(pt, '=');
		urmp_player_status.volume      = strtod(pt+1, NULL);
		update                         = true;
	}
	if ((pt = strstr(buf, "ANS_time_pos="))) {
		pt = strchr(pt, '=');
		urmp_player_status.time_pos    = strtod(pt+1, NULL);
		update                         = true;
	}
	if ((pt = strstr(buf, "ANS_percent_pos="))) {
		pt = strchr(pt, '=');
		urmp_player_status.percent_pos = strtol(pt+1, NULL, 10);
		update                         = true;
	}
	if ((pt = strstr(buf, "EOF code"))) {
		ur_trace(URMP_TRACE_SLAVE, __func__,
			 "playing=%d => false\n", urmp_player_status.playing);
		urmp_player_status.playing = false;
	} else if (update && !urmp_player_status.playing) {
		ur_trace(URMP_TRACE_SLAVE, __func__,
			 "playing=%d => true\n", urmp_player_status.playing);
		urmp_player_status.playing = true;
	}
	++urmp_player_status.generation;

	ur_trace(URMP_TRACE_SLAVE, __func__,
		 "%f %f %d playing=%d paused=%d\n",
		 urmp_player_status.volume,
		 urmp_player_status.time_pos,
		 urmp_player_status.percent_pos,
		 urmp_player_status.playing,
		 urmp_player_status.paused);
}

static char urmp_player_handler_buf[4096];

static void urmp_player_slave_read(int fd)
{
	int  retcode;
	int  save;

	if (fd < 0) return;
	while (urmp_player_input_available(fd)) {
		memset(urmp_player_handler_buf, 0,
		       sizeof(urmp_player_handler_buf));
		
		errno = 0;
		retcode = read(fd,
			       urmp_player_handler_buf,
			       sizeof(urmp_player_handler_buf)-1);
		save = errno;
		if (!retcode) {
			ur_trace(URMP_TRACE_PLAYERINT, __func__,
				 "read(%d)=%d EOF\n", fd, retcode);
			return;
		} else if (retcode < 0) {
			ur_trace(URMP_TRACE_PLAYERINT, __func__,
				 "read(%d)=%d failed: %s\n",
				 fd, retcode, strerror(save));
			return;
		}
		urmp_player_slave_parse(urmp_player_handler_buf);
	}
}

static void urmp_player_handler(int sig)
{
	int status;

	ur_trace(URMP_TRACE_PLAYERINT, __func__,
		 "sig(%d)=%s urmp_player_pid=%d pgrp=%d in_worker=%d\n",
		 sig, ur_signal_name(sig), urmp_player_pid, getpgid(getpid()),
		 urmp_player_in_worker);

	switch (sig) {
	case SIGUSR1: return;	/* For debugging purposes */
	case SIGIO: urmp_player_slave_read(urmp_player_outfd); break;
	case SIGCHLD:
		if (!urmp_player_pid) return;
		waitpid(urmp_player_pid, &status, 0);
		ur_trace(URMP_TRACE_PLAYER, __func__,
			 "child pid=%d exited, status=%d\n",
			 urmp_player_pid, status);
		urmp_player_pid = 0;
		close(urmp_player_infd);
		urmp_player_infd = -1;
		close(urmp_player_outfd);
		urmp_player_outfd = -1;
		alarm(0);
		return;
	case SIGALRM:
		if (urmp_player_in_worker) {
			ur_trace(URMP_TRACE_PLAYERINT, __func__,
				 "urmp_player_in_worker=%d\n",
				 urmp_player_in_worker);
			break;
		}
		if (urmp_player_in_handler++) {
			ur_internal(__func__, "Not reentrant!\n");
		}
		if (!urmp_player_status.paused) {
			urmp_player_request_status(urmp_player_infd);
		}
		if (urmp_player_pid && !urmp_player_in_worker) {
			if (urmp_player_status.paused
			    || !urmp_player_status.playing) {

				++urmp_player_status.generation;
			}
			alarm(1);
		}
		urmp_player_in_handler = 0;
		break;
	default:
		if (!urmp_player_pid) {
			ur_trace(URMP_TRACE_PLAYERINT, __func__,
				 "terminating, pid=%d\n", getpid());
			exit(0);
		}

		ur_trace(URMP_TRACE_PLAYERINT, __func__,
			 "killing pid=%d\n", urmp_player_pid);
		if (kill(urmp_player_pid, SIGKILL)) {
			int save = errno;
			ur_trace(URMP_TRACE_PLAYERINT, __func__,
				 "kill(%d) failed: %s\n",
				 urmp_player_pid, strerror(save));
		}
	}
}

static void urmp_player_init(void)
{
	int              sig[] = { SIGHUP, SIGINT, SIGQUIT, SIGILL,
				   SIGBUS, SIGFPE, SIGSEGV, SIGTERM,
				   SIGIO,  SIGCHLD, SIGUSR1, SIGALRM };
	size_t           i;
	struct sigaction a;

	ur_trace(URMP_TRACE_PLAYER, __func__, "\n");

	for (i = 0; i < sizeof(sig)/sizeof(sig[0]); i++) {
		memset(&a, 0, sizeof(a));
		a.sa_handler = urmp_player_handler;
		sigemptyset(&a.sa_mask);
		sigaddset(&a.sa_mask, sig[i]);
		sigaction(sig[i], &a, NULL);
	}
}

static void urmp_player_slave_init(void)
{
	ur_trace(URMP_TRACE_PLAYER, __func__,
		 "urmp_player_pid=%d\n", urmp_player_pid);

	if (!urmp_player_pid) {
		int retcode;
		int save;
		int flags;

		urmp_player_pid = ur_pr_open("mplayer -idle -slave -quiet"
					     " -nolirc -nojoystick"
					     " -nomouseinput -vo nul"
					     " -cache 64"
					     " -msglevel all=2:global=6",
					     UR_PR_CREATE_STDIN
					     |UR_PR_CREATE_STDOUT,
					     &urmp_player_infd,
					     &urmp_player_outfd,
					     NULL);
		ur_trace(URMP_TRACE_PLAYER, __func__,
			 "urmp_player_pid=%d urmp_player_infd=%d"
			 " urmp_player_outfd=%d\n",
			 urmp_player_pid, urmp_player_infd, urmp_player_outfd);

		fcntl(urmp_player_outfd, F_SETOWN, getpid());

		flags = fcntl(urmp_player_outfd, F_GETFL);
		save = 0;
		retcode = fcntl(urmp_player_outfd, F_SETFL, flags|O_ASYNC);
		save = errno;
		ur_trace(URMP_TRACE_PLAYER, __func__,
			 "F_SETFL: fd=%d flags=0x%x retcode=%d errno=%d\n",
			 urmp_player_outfd, flags, retcode, save);
	}
}

static void urmp_player_escapify(char *d, const char *s, int length)
{
	int i;

	for (i = 0; i < length; i++, s++) {
		switch (*s) {
		case ' ':  *d++ = '\\'; *d++ = ' ';  break;
		case '\'': *d++ = '\\'; *d++ = '\''; break;
		case '"':  *d++ = '\\'; *d++ = '"';  break;
		default:   *d++ = *s;                break;
		}
	}
	*d = '\0';
}

static int urmp_player_worker(ur_msg_t msg, int type, void *buf,
			      int length, void *arg _unused)
{
	char *escaped;
	char *message = NULL;
	int  len = 256;
	int  value = 0;

	if (length >= 2) value = ((unsigned char *)buf)[0]*256
				 + ((unsigned char *)buf)[1];

	ur_trace(URMP_TRACE_PLAYER, __func__, "type=%d\n", type);

	urmp_player_init();
	urmp_player_slave_init();

	ur_trace(URMP_TRACE_PLAYER, __func__,
		 "urmp_player_infd=%d\n", urmp_player_infd);

	if (type == URMP_MSG_GET_STATUS) {
		ur_msg_reply(msg, &urmp_player_status,
			     sizeof(urmp_player_status), 0);
		return 0;
	}

	if (urmp_player_in_worker++) {
		ur_internal(__func__, "Not reentrant!\n");
	}
	alarm(0);
	while (urmp_player_in_handler) {
		ur_trace(URMP_TRACE_PLAYER, __func__,
			 "urmp_player_in_handler=%d\n",
			 urmp_player_in_handler);
		alarm(0);
	}

	switch (type) {
	case URMP_MSG_PLAY_FILE:
		escaped = alloca(length * 2 + 16);
		urmp_player_escapify(escaped, buf, length);
		len = strlen(escaped) + 128;;
		message = alloca(len);
		snprintf(message, len-1,
			 "loadfile %s\nmute 0\n", escaped);
		urmp_player_status.playing = true;
		urmp_player_status.paused  = false;
		break;
	case URMP_MSG_SET_VOLUME:
		if (value < 0) value = 0;
		if (value > 100) value = 100;
		message = alloca(len);
		snprintf(message, len-1, "volume %d 1\nmute 0\n", value);
		break;
	case URMP_MSG_SET_POSITION:
		if (value < 0) value = 0;
		if (value > 100) value = 100;
		message = alloca(len);
		if (urmp_player_status.paused) {
			snprintf(message, len-1,
				 "mute 1\nseek %d 1\nmute 0\n", value);
		} else {
			snprintf(message, len-1,
				 "mute 1\npause\nseek %d 1\nmute 0\n", value);
		}
		if (urmp_player_status.playing)
			urmp_player_status.paused = false;
		break;
	case URMP_MSG_PAUSE:
		message = alloca(len);
		snprintf(message, len-1, "pause\n");
		urmp_player_status.paused = !urmp_player_status.paused;
		break;
	case URMP_MSG_STOP:
		message = alloca(len);
		snprintf(message, len-1, "quit\n");
		urmp_player_status.playing = false;
		urmp_player_status.paused  = false;
		break;
	default:
		ur_fatal(__func__, "Message type %d unexpected\n", type);
		break;
	}
	if (!message) ur_internal(__func__, "No message\n");

	ur_trace(URMP_TRACE_SLAVE, __func__,
		 "Command: %s", message);
	write(urmp_player_infd, message, strlen(message));
	ur_msg_reply(msg, &urmp_player_status.generation,
		     sizeof(urmp_player_status.generation), 0);

	urmp_player_in_worker = 0;
	raise(SIGALRM);
	return 0;
}

static int urmp_player_worker_cleanup(int pid, int status, int err,
				      void *arg __attribute__((unused)))
{
	if (status > 0) {
		printf("%s: %s pid=%d status=%d errno=%d: %s\n",
		       __func__, ur_signal_name(status), pid, status, err,
		       strerror(err));
	} else {
		printf("%s: %d pid=%d errno=%d: %s\n",
		       __func__, status, pid, err, strerror(err));
	}
	fflush(stdout);
	return 0;
}

void urmp_player_start(void)
{
	urmp_player = ur_proc_create(urmp_player_worker, NULL,
				     urmp_player_worker_cleanup, NULL,
				     NULL, NULL);
}
