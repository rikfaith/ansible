/* urmp.h -- 
 * Created: Tue Mar 18 13:19:44 2008 by faith@acm.org
 * Revised: Sun Apr 26 19:29:00 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMP_H_
#define _URMP_H_

#define _POSIX_C_SOURCE 200112L
#define _BSD_SOURCE
#define _XOPEN_SOURCE
#define _XOPEN_SOURCE_EXTENDED
#include "config.h"
#include "ur.h"
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#ifndef USE_GTK
#define USE_GTK 0
#endif

#if defined(__GNUC__) && !defined(__LCLINT__)
#define _unused __attribute__((unused))
#else
#define _unused
#endif

#define URMP_ENV_DEFAULT_CONFIG "URMP_DEFAULT_CONFIG"

#define URMP_DEFAULT_CONFIG "~/.urmp"
#define URMP_DEFAULT_DB     "db"
#define URMP_DEFAULT_RC     "config"

#define URMP_DEFAULT_WIDTH  800
#define URMP_DEFAULT_HEIGHT 600

#define URMP_PROC_COUNT 5
#define URMP_MAX_PATHLEN 4096

#define URMP_MAX_ID3_BUFLEN (16*1024)

#define URMP_TRACE_CONFIG    0x00000001UL
#define URMP_TRACE_BUILD     0x00000002UL
#define URMP_TRACE_PROC      0x00000004UL
#define URMP_TRACE_MSG       0x00000008UL
#define URMP_TRACE_STACK     0x00000010UL
#define URMP_TRACE_WORKER    0x00000020UL
#define URMP_TRACE_ID3ERR    0x00000040UL
#define URMP_TRACE_PLAYER    0x00000080UL
#define URMP_TRACE_PLAYERINT 0x00000100UL
#define URMP_TRACE_SLAVE     0x00000200UL
#define URMP_TRACE_SWITCH    0x00000400UL
#define URMP_TRACE_RANDOM    0x00000800UL
#define URMP_TRACE_EVENTS    0x00001000UL
#define URMP_TRACE_SEARCH    0x00002000UL
#define URMP_TRACE_PLAYLIST  0x00004000UL

/* For urmp_db_worker */
#define URMP_MSG_GET_INFO     1

/* For urmp_player_worker */
#define URMP_MSG_PLAY_FILE    2
#define URMP_MSG_SET_VOLUME   3
#define URMP_MSG_SET_POSITION 4
#define URMP_MSG_GET_STATUS   5
#define URMP_MSG_PAUSE        6
#define URMP_MSG_CONTINUE     7
#define URMP_MSG_STOP         8

extern int urmp_max_pathlen;

extern void urmp_gui(int *argc, const char ***argv);
extern void urmp_gui_trailer(void);

extern void urmp_player_start(void);

extern void urmp_read_db(void);
extern void urmp_write_db(void);
extern void urmp_process_new_entry(ur_id3_t id3);

extern ur_sl_t    urmp_db;

#endif
