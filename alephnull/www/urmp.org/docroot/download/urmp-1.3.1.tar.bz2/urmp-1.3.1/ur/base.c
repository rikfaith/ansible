/* base.c -- 
 * Created: Sun Aug 13 09:19:26 2000 by faith@dict.org
 * Copyright 2000, 2002, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: base.c,v 1.2 2002-12-23 17:05:00 faith Exp $
 *
 * The base 26 routines use the 26 lowercase letters of the alphabet for
 * encoding.  This probably doesn't conform to any standard.
 * 
 * The base 64 routines use the 64-character subset of International
 * Alphabet IA5 discussed in RFC 1421 (printeable encoding) and RFC 1522
 * (base64 MIME):
 *
 * Value Encoding  Value Encoding  Value Encoding  Value Encoding
 *     0 A            17 R            34 i            51 z
 *     1 B            18 S            35 j            52 0
 *     2 C            19 T            36 k            53 1
 *     3 D            20 U            37 l            54 2
 *     4 E            21 V            38 m            55 3
 *     5 F            22 W            39 n            56 4
 *     6 G            23 X            40 o            57 5
 *     7 H            24 Y            41 p            58 6
 *     8 I            25 Z            42 q            59 7
 *     9 J            26 a            43 r            60 8
 *    10 K            27 b            44 s            61 9
 *    11 L            28 c            45 t            62 +
 *    12 M            29 d            46 u            63 /
 *    13 N            30 e            47 v
 *    14 O            31 f            48 w         (pad) =
 *    15 P            32 g            49 x
 *    16 Q            33 h            50 y
 *
 * The base 85 routines use the 85-character subset of ASCII discussed in
 * RFC 1924:
 *
 *     0 0            25 P            50 o            75 >
 *     1 1            26 Q            51 p            76 ?
 *     2 2            27 R            52 q            77 @
 *     3 3            28 S            53 r            78 ^
 *     4 4            29 T            54 s            79 _
 *     5 5            30 U            55 t            80 `
 *     6 6            31 V            56 u            81 {
 *     7 7            32 W            57 v            82 |
 *     8 8            33 X            58 w            83 }
 *     9 9            34 Y            59 x            84 ~
 *    10 A            35 Z            60 y
 *    11 B            36 a            61 z
 *    12 C            37 b            62 !
 *    13 D            38 c            63 #
 *    14 E            39 d            64 $
 *    15 F            40 e            65 %
 *    16 G            41 f            66 &
 *    17 H            42 g            67 (
 *    18 I            43 h            68 )
 *    19 J            44 i            69 *
 *    20 K            45 j            70 +
 *    21 L            46 k            71 -
 *    22 M            47 l            72 ;
 *    23 N            48 m            73 <
 *    24 O            49 n            74 =
 */

#include "urP.h"

static unsigned char b26_list[] = "abcdefghijklmnopqrstuvwxyz";

static unsigned char b64_list[] =
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static unsigned char b85_list[] =
"0123456789ABCDEFGHIJKLMNO"
"PQRSTUVWXYZabcdefghijklmn"
"opqrstuvwxyz!#$%&()*+-;<="
">?@^_`{|}~";

#define XX 100

static int b26_index[256] = {
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX, 0, 1, 2,  3, 4, 5, 6,  7, 8, 9,10, 11,12,13,14,
    15,16,17,18, 19,20,21,22, 23,24,25,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
};

static int b64_index[256] = {
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,62, XX,XX,XX,63,
    52,53,54,55, 56,57,58,59, 60,61,XX,XX, XX,XX,XX,XX,
    XX, 0, 1, 2,  3, 4, 5, 6,  7, 8, 9,10, 11,12,13,14,
    15,16,17,18, 19,20,21,22, 23,24,25,XX, XX,XX,XX,XX,
    XX,26,27,28, 29,30,31,32, 33,34,35,36, 37,38,39,40,
    41,42,43,44, 45,46,47,48, 49,50,51,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
};

static int b85_index[256] = {
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,	/*   0 */
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,	/*  16 */
    XX,62,XX,63, 64,65,66,XX, 67,68,69,70, XX,71,XX,XX,	/*  32 */
     0, 1, 2, 3,  4, 5, 6, 7,  8, 9,XX,72, 73,74,75,76,	/*  48 */
    77,10,11,12, 13,14,15,16, 17,18,19,20, 21,22,23,24,	/*  64 */
    25,26,27,28, 29,30,31,32, 33,34,35,XX, XX,XX,78,79, /*  80 */
    80,36,37,38, 39,40,41,42, 43,44,45,46, 47,48,49,50,	/*  96 */
    51,52,53,54, 55,56,57,58, 59,60,61,81, 82,83,84,XX,	/* 112 */
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
};

#define MAKE_DECODE(base)                               \
unsigned long ur_base##base##_decode(const char *val)   \
{                                                       \
    unsigned long       v = 0;                          \
    const unsigned char *pt;                            \
    int                 tmp;                            \
                                                        \
    for (pt = (const unsigned char *)val; *pt; pt++) {  \
	if ((tmp = b##base##_index[*pt]) == XX)         \
	    ur_internal( __FUNCTION__,                  \
			 "Illegal character in base"    \
                         #base " value: `%c' (%d)\n",   \
			 *pt, *pt);                     \
	v = v * base + tmp;                             \
    }                                                   \
    return v;                                           \
}

#define MAKE_ENCODE(base,zero,len)                      \
const char *ur_base##base##_encode(unsigned long val)   \
{                                                       \
   static char          result[len];                    \
   static unsigned long previous = 0;                   \
   static int           i = 0;                          \
                                                        \
   if (!val) return zero;                               \
   if (previous != val) {                               \
       previous = val;                                  \
       for (i = len-2; i >= 0 && val; i--) {            \
	   result[i] = b##base##_list[val % base];      \
	   val = val / base;                            \
       }                                                \
       result[len-1] = 0;                               \
   }                                                    \
                                                        \
   return result + i + 1;                               \
}

MAKE_DECODE(26)
MAKE_DECODE(64)
MAKE_DECODE(85)

MAKE_ENCODE(26,"a",8)
MAKE_ENCODE(85,"0",6)

const char *ur_base64_encode(unsigned long val)
{
    static char result[7];
    int         i;

    result[0] = b64_list[(val & 0xc0000000) >> 30];
    result[1] = b64_list[(val & 0x3f000000) >> 24];
    result[2] = b64_list[(val & 0x00fc0000) >> 18];
    result[3] = b64_list[(val & 0x0003f000) >> 12];
    result[4] = b64_list[(val & 0x00000fc0) >>  6];
    result[5] = b64_list[(val & 0x0000003f)      ];
    result[6] = 0;
    
    for (i = 0; i < 5; i++) if (result[i] != b64_list[0]) return result + i;
    return result + 5;
}

