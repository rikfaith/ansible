/* atom.c -- 
 * Created: Mon Jul  5 13:31:02 1999 by faith@dict.org
 * Copyright 1999, 2000, 2001, 2002, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: atom.c,v 1.11 2003-06-14 12:14:33 faith Exp $
 * 
 */

#include "urP.h"

static ur_arena_t _ur_pool;
static ur_block_t _ur_block;
static ur_hash_t  _ur_hash;

typedef struct ur_atom_key_s {
    const unsigned char *key;
    int                 length;
} *ur_atom_key_t;

static unsigned long _ur_atom_hash(const void *key)
{
    ur_atom_key_t         k   = (ur_atom_key_t)key;
    const unsigned char *pt = k->key;
    unsigned long       h   = 0;
    int                 i;

    for (i = 0; i < k->length; i++)
	h = (h << 1) + (unsigned long)*pt++; /* FIXME */

    return h;
}

static int _ur_atom_compare(const void *key1, const void *key2)
{
    ur_atom_key_t         k1    = (ur_atom_key_t)key1;
    ur_atom_key_t         k2    = (ur_atom_key_t)key2;
    const unsigned char *p1   = k1->key;
    const unsigned char *p2   = k2->key;
    int                 i;

    if (k1->length > k2->length) return -1;
    if (k2->length > k1->length) return +1;

    for (i = 0; i < k1->length; i++, p1++, p2++) {
	if (*p1 > *p2) return -1;
	if (*p1 < *p2) return +1;
    }
    
    return 0;
}

static void _ur_atom_init(void)
{
    if (_ur_pool)  ur_internal(__FUNCTION__, "Pool already exists\n");
    if (_ur_block) ur_internal(__FUNCTION__, "Block already exists\n");
    if (_ur_hash)  ur_internal(__FUNCTION__, "Hash table already exists\n");
    _ur_pool  = ur_arena_create(1);
    _ur_block = ur_block_create(sizeof(struct ur_atom_key_s));
    _ur_hash  = ur_hash_create(_ur_atom_hash, _ur_atom_compare);
}

static const void *_ur_atom_new(const void *datum, int len, int terminate)
{
    struct ur_atom_key_s lookup_key;
    ur_atom_key_t        insert_key;
    const char         *atom;
    unsigned char      *buf;
    
    if (!_ur_pool || !_ur_hash || !_ur_block) _ur_atom_init();
    terminate = !!terminate;

				/* Make null terminated datum -- FIXME! */
    buf = ur_alloc(len + 1);
    memcpy(buf, datum, len);
    buf[len] = '\0';

				/* Already in table? */

    lookup_key.key    = buf;
    lookup_key.length = len + terminate;
    if ((atom = ur_hash_lookup(_ur_hash, &lookup_key))) {
	ur_free(buf);
	return atom;
    }

				/* Not in table */
    insert_key                  = ur_block_alloc(_ur_block);
    insert_key->length          = len + terminate;
    insert_key->key             = ur_arena_alloc(_ur_pool,
						insert_key->length);
    memcpy((char *)insert_key->key, buf, len);
    if (terminate) ((char *)insert_key->key)[len] = '\0';
    ur_hash_insert(_ur_hash, insert_key, insert_key->key);
    ur_free(buf);
    return insert_key->key;
}

const void *ur_atom_new(const void *datum, int len)
{
    return datum ? _ur_atom_new(datum, len, 0) : NULL;
}

const char *ur_atom_string(const char *datum)
{
    return datum ? _ur_atom_new(datum, strlen(datum) + 1, 0) : NULL;
}

const char *ur_atom_string_n(const char *datum, int len)
{
    return datum ? _ur_atom_new(datum, len, 1) : NULL;
}

void ur_atom_destroy(void)
{
    if (_ur_pool) ur_arena_destroy(_ur_pool);
    _ur_pool = NULL;
    if (_ur_block) ur_block_destroy(_ur_block);
    _ur_block = NULL;
    if (_ur_hash) ur_hash_destroy(_ur_hash);
    _ur_hash = NULL;
}

