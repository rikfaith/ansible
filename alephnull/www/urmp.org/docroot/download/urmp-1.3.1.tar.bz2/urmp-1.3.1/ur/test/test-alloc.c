/* alloc.c -- 
 * Created: Mon Oct 13 16:56:23 2008 by faith@acm.org
 * Revised: Mon Oct 13 17:26:42 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "standard.h"
#include "ur.h"

#define PAIRS 8192
#define ITER  1000

static void *mem[PAIRS];

static unsigned long long time_malloc(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;

	gettimeofday(&start, NULL);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = malloc(size);
		}
		for (j = 0; j < PAIRS; j++) {
			free(mem[j]);
		}
	}
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_ur_alloc(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;

	gettimeofday(&start, NULL);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_alloc(size);
		}
		for (j = 0; j < PAIRS; j++) {
			ur_free(mem[j]);
		}
	}
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_block(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;
	ur_block_t block;

	gettimeofday(&start, NULL);
	block = ur_block_create(size);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_block_alloc(block);
		}
		for (j = 0; j < PAIRS; j++) {
			ur_block_free(block, mem[j]);
		}
	}
	ur_block_destroy(block);
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_arena(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;
	ur_arena_t arena;

	gettimeofday(&start, NULL);
	arena = ur_arena_create(0);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_arena_alloc(arena, size);
		}
		ur_arena_clear(arena);
	}
	ur_arena_destroy(arena);
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}


int main(void)
{
	unsigned long long m;
	
	m = time_block(32);
	printf("block(32)      = %10llu iter/sec\n", m);
	m = time_block(256);
	printf("block(256)     = %10llu iter/sec\n", m);
	m = time_block(1024);
	printf("block(1024)    = %10llu iter/sec\n", m);

	m = time_arena(32);
	printf("arena(32)      = %10llu iter/sec\n", m);
	m = time_arena(256);
	printf("arena(256)     = %10llu iter/sec\n", m);
	m = time_arena(1024);
	printf("arena(1024)    = %10llu iter/sec\n", m);

	m = time_ur_alloc(32);
	printf("ur_alloc(32)   = %10llu iter/sec\n", m);
	m = time_ur_alloc(256);
	printf("ur_alloc(256)  = %10llu iter/sec\n", m);
	m = time_ur_alloc(1024);
	printf("ur_alloc(1024) = %10llu iter/sec\n", m);

	m = time_malloc(32);
	printf("malloc(32)     = %10llu iter/sec\n", m);
	m = time_malloc(256);
	printf("malloc(256)    = %10llu iter/sec\n", m);
	m = time_malloc(1024);
	printf("malloc(1024)   = %10llu iter/sec\n", m);
	
	return 0;
}
