/* skiplist.c -- 
 * Created: Mon Jul  5 13:23:07 1999 by faith@dict.org
 * Copyright 1999, 2000, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: skiplist.c,v 1.5 2000-08-20 13:16:19 faith Exp $
 * 
 */

#include "urP.h"

typedef struct ur_sl_element_s {
    const void                 *key;
    const void                 *datum;
    int                        levels;
    struct ur_sl_element_s *forward[1];
} *ur_sl_element_t;

struct ur_sl_s {
    unsigned long          magic;
    int                    level;
    unsigned int           size; /* number of data */
    ur_sl_element_t        head;
    ur_sl_compare_t        compare;
    ur_random_t            prng;
    unsigned long          level_count[UR_SKIPLIST_MAXLEVEL + 1];
};

CHECK_FUNCTION(_ur_sl_check, ur_sl_t, UR_SKIPLIST_MAGIC)

static int _ur_sl_compare(const void *key1, const void *key2)
{
    return strcmp(key1, key2);
}

static ur_sl_element_t _ur_sl_element_create(ur_sl_t list,
						     int max_level,
						     const void *key,
						     const void *datum)
{
    ur_sl_element_t e;
    
    if (max_level > UR_SKIPLIST_MAXLEVEL)
	ur_internal(__FUNCTION__, "level %d > %d\n",
		    max_level, UR_SKIPLIST_MAXLEVEL);

    e          = ur_allocz(sizeof(*e) + (max_level * sizeof(e->forward[0])));
    e->key     = key;
    e->datum   = datum;
    e->levels  = max_level + 1;
    ++list->level_count[max_level];
    return e;
}

ur_sl_t ur_sl_create(ur_sl_compare_t compare)
{
    ur_sl_t list = ur_allocz(sizeof(*list));

    list->magic   = UR_SKIPLIST_MAGIC;
    list->level   = 0;
    list->size    = 0;
    list->head    = _ur_sl_element_create(list,
					  UR_SKIPLIST_MAXLEVEL,
					  NULL,
					  NULL);
    list->compare = compare ? compare : _ur_sl_compare;
    list->prng    = ur_random_create(UR_RANDOM_STD, UR_RANDOM_UNIFORM);

    return list;
}

unsigned long ur_sl_destroy(ur_sl_t list)
{
    ur_sl_element_t e;
    ur_sl_element_t next;
    unsigned long       ret;

    _ur_sl_check(list);
    for (e = list->head; e; e = next) {
	next = e->forward[0];
	ur_free(e);
    }
    ret = list->magic = ~UR_SKIPLIST_MAGIC;
    ur_random_destroy(list->prng);
    ur_free(list);
    return ret;
}

static ur_sl_element_t _ur_sl_locate(ur_sl_t list,
					      const void *key,
					      ur_sl_element_t *update)
{
    int                 i;
    ur_sl_element_t e, pt, prev = NULL;

    for (i = list->level, e = list->head; i >= 0; i--) {
	while ((pt = e->forward[i])
	       && pt != prev && list->compare(pt->key, key) < 0)
	    e = pt;
	prev = pt;
	if (update) update[i] = e;
    }
    return e->forward[0];
}

void *ur_sl_lookup(ur_sl_t list, const void *key)
{
    ur_sl_element_t e;
    
    _ur_sl_check(list);
    e = _ur_sl_locate(list, key, NULL);
    if (e && !list->compare(e->key, key))
	return (void *)e->datum; /* Discard const */
    return NULL;
}

int ur_sl_insert(ur_sl_t list, const void *key, const void *datum)
{
    ur_sl_element_t update[UR_SKIPLIST_MAXLEVEL+1];
    ur_sl_element_t e;
    int                 level = 0;
    int                 i;
    
    _ur_sl_check(list);
    e = _ur_sl_locate(list, key, &update[0]);
    if (e && !list->compare(e->key, key)) return 1; /* FIXME */

    while (level < UR_SKIPLIST_MAXLEVEL && (ur_random(list->prng) & 0x01))
	++level;
    
    if (level > list->level) {
	level         = ++list->level;
	update[level] = list->head;
    }

    e = _ur_sl_element_create(list, level, key, datum);

    for (i = level; i >= 0; i--) {
	e->forward[i]         = update[i]->forward[i];
	update[i]->forward[i] = e;
    }

    ++list->size;
    return 0;
}

int ur_sl_delete(ur_sl_t list, const void *key)
{
    ur_sl_element_t update[UR_SKIPLIST_MAXLEVEL+1];
    ur_sl_element_t e;
    int                 i;
    
    _ur_sl_check(list);
    e = _ur_sl_locate(list, key, &update[0]);
    if (!e || list->compare(e->key, key)) return 1;

    for (i = 0; i <= list->level; i++)
	if (update[i]->forward[i] == e) update[i]->forward[i] = e->forward[i];

    ur_free(e);
    --list->size;
    return 0;
}

int ur_sl_print_stats(ur_sl_t list, FILE *str, int flags)
{
    int i;

    if (flags) {
	for (i = 0; i <= UR_SKIPLIST_MAXLEVEL; i++)
	    fprintf(str, "%5d", i);
	fprintf(str, "\n");
    }
    for (i = 0; i <= list->level; i++)
	fprintf(str, "%5lu", list->level_count[i]);
    fprintf(str, "\n");
    return 0;
}

void ur_sl_iterator_init(ur_sl_t list, ur_iterator_t *iter)
{
    _ur_sl_check(list);
    iter->a = list;
    iter->b = list->head->forward[0];
}

int ur_sl_iterator_next(ur_iterator_t *iter)
{
    ur_sl_t list = iter->a;

    _ur_sl_check(list);
    if (!iter->b) return 0;
    iter->b = ((ur_sl_element_t)iter->b)->forward[0];
    return iter->b != NULL;
}

void *ur_sl_iterator_key(ur_iterator_t *iter)
{
    ur_sl_t list = iter->a;

    _ur_sl_check(list);
    if (!iter->b) return NULL;
    return (void *)((ur_sl_element_t)iter->b)->key;	/* Discard const */
}

void *ur_sl_iterator_datum(ur_iterator_t *iter)
{
    ur_sl_t list = iter->a;

    _ur_sl_check(list);
    if (!iter->b) return NULL;
    return (void *)((ur_sl_element_t)iter->b)->datum; /* Discard const */
}

unsigned int ur_sl_items(ur_sl_t list)
{
	_ur_sl_check(list);
	return list->size;
}
