/* trigram.c -- 
 * Created: Fri Jun 13 08:47:01 2003 by faith@dict.org
 * Copyright 2003, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: trigram.c,v 1.2 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "urP.h"
#include <math.h>

#define UR_TRIGRAM_BITS             (256*256*256)
#define UR_TRIGRAM_ELEMENTS         (UR_TRIGRAM_BITS/32)
#define UR_TRIGRAM_BITS_PER_ELEMENT (32)

struct ur_trigram_s {
    unsigned long magic;
    unsigned long mask[UR_TRIGRAM_ELEMENTS];
    unsigned long total;
    unsigned long unique;
};

CHECK_FUNCTION(_ur_trigram_check, ur_trigram_t, UR_TRIGRAM_MAGIC)

static inline int ur_trigram_test(ur_trigram_t tg, unsigned long value)
{
    int element = value / UR_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * UR_TRIGRAM_BITS_PER_ELEMENT;
    return tg->mask[element] & (1 << bit);
}

static inline void ur_trigram_set(ur_trigram_t tg, unsigned long value)
{
    int element = value / UR_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * UR_TRIGRAM_BITS_PER_ELEMENT;
    tg->mask[element] |= (1 << bit);
}

#if 0
static inline void ur_trigram_clear(ur_trigram_t tg, unsigned long value)
{
    int element = value / UR_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * UR_TRIGRAM_BITS_PER_ELEMENT;
    tg->mask[element] &= ~(1 << bit);
}
#endif

ur_trigram_t ur_trigram_create(void)
{
    ur_trigram_t tg = ur_allocz(sizeof(*tg));

    tg->magic = UR_TRIGRAM_MAGIC;
    return tg;
}

unsigned long ur_trigram_destroy(ur_trigram_t tg)
{
    unsigned long ret;
    
    _ur_trigram_check(tg);
    ret = tg->magic = ~UR_TRIGRAM_MAGIC;
    ur_free(tg);
    return ret;
}

int ur_trigram_put(ur_trigram_t tg, const char *filename)
{
    FILE             *str;

    _ur_trigram_check(tg);
    if (!(str = fopen(filename, "w"))) return -1;

    fprintf(str, "0x%08lx %d %d %d %lu %lu\n",
            tg->magic, UR_TRIGRAM_BITS, UR_TRIGRAM_ELEMENTS,
            UR_TRIGRAM_BITS_PER_ELEMENT, tg->total, tg->unique);
    (void)fwrite(tg->mask, sizeof(tg->mask),  1, str);
    fclose(str);
    return 0;
}

ur_trigram_t ur_trigram_get(const char *filename)
{
    unsigned long  magic;
    unsigned long  bits, elements, bpe;
    FILE           *str;
    ur_trigram_t    tg;
    
    if (!(str = fopen(filename, "r"))) return NULL;
    tg = ur_trigram_create();
    fscanf(str, "0x%08lx %lu %lu %lu %lu %lu\n",
	   &magic, &bits, &elements, &bpe, &tg->total, &tg->unique);
    if (tg->magic   != magic
        || bits     != UR_TRIGRAM_BITS
        || elements != UR_TRIGRAM_ELEMENTS
        || bpe      != UR_TRIGRAM_BITS_PER_ELEMENT) {
        ur_trigram_destroy(tg);
        return NULL;
    }
    fread(tg->mask, sizeof(tg->mask), 1, str);
    return tg;
}

void ur_trigram_add(ur_trigram_t tg, const void *buf, int len)
{
    int                 i;
    const unsigned char *pt;
    unsigned long       tgram;

    _ur_trigram_check(tg);
    if (!len) len = strlen(buf);

    for (i = 0, pt = buf; pt && *pt && i < len - 3; ++pt, ++i) {
        tgram = pt[0] * 256 * 256 + pt[1] * 256 + pt[2];
        if (ur_trigram_test(tg, tgram)) ++tg->unique;
        ur_trigram_set(tg, tgram);
        ++tg->total;
    }
}

static inline int ur_trigram_print_byte(unsigned char byte, FILE *stream)
{
    if (byte >= ' ' && byte <= 127) {
        fprintf(stream, "%c", byte);
        return 1;
    }
    fprintf(stream, "0x%02x", byte);
    return 4;
}

void ur_trigram_print(ur_trigram_t tg, FILE *stream)
{
    int              i, j, k;
    int              count = 0;
    int              len;

    if (!stream) stream = stdout;
    _ur_trigram_check(tg);
    for (i = 0; i < 256; i++)
        for (j = 0; j < 256; j++)
            for (k = 0; k < 256; k++) {
                unsigned long tgram = i * 256 * 256 + j * 256 + k;
                if (ur_trigram_test(tg, tgram)) {
                    len  = ur_trigram_print_byte(i, stream);
                    len += ur_trigram_print_byte(j, stream);
                    len += ur_trigram_print_byte(k, stream);
                    if (count && !(count % 7))
                        fprintf(stream, "\n");
                    else
                        fprintf(stream, "%*.*s", 12-len, 12-len, " ");
                    ++count;
                }
            }
}

static inline int ur_trigram_bit_count(unsigned long x)
{
    x = (x >> 1  & 0x55555555) + (x & 0x55555555);
    x = ((x >> 2) & 0x33333333) + (x & 0x33333333);
    x = ((x >> 4) + x) & 0x0f0f0f0f;
    x = ((x >> 8) + x);
    return (x + (x >> 16)) & 0xff;
}

unsigned long ur_trigram_matches(ur_trigram_t a, ur_trigram_t b)
{
    unsigned long matches = 0;
    int           i;

    for (i = 0; i < UR_TRIGRAM_ELEMENTS; i++)
        matches += ur_trigram_bit_count(a->mask[i] & b->mask[i]);
    return matches;
}

static double _ur_trigram_matches(ur_trigram_t a, ur_trigram_t b)
{
    int              matches = 0;
    int              total;
    int              i;

    for (i = 0; i < UR_TRIGRAM_ELEMENTS; i++)
        matches += ur_trigram_bit_count(a->mask[i] & b->mask[i]);

    total = a->unique + b->unique;
    return (double)matches / (double)(total - matches);
}

static double _ur_trigram_cosine(ur_trigram_t a, ur_trigram_t b)
{
    double           num  = 0;
    double           sum0 = 0;
    double           sum1 = 0;
    
    int              i;

    for (i = 0; i < UR_TRIGRAM_ELEMENTS; i++) {
        double f = (double)ur_trigram_bit_count(a->mask[i])/a->total;
        int same = a->mask[i] & b->mask[i];
        sum0    += f * f;
        if (same)
            num += f * (double)ur_trigram_bit_count(same)/b->total;
    }

    for (i = 0; i < UR_TRIGRAM_ELEMENTS; i++) {
        double f = (double)ur_trigram_bit_count(b->mask[i])/b->total;
        sum1    += f * f;
    }
    
    return num / (sqrt(sum0) * sqrt(sum1));
}

double ur_trigram_compare(ur_trigram_t a, ur_trigram_t b, ur_trigram_alg_t alg)
{
    _ur_trigram_check(a);
    _ur_trigram_check(b);
    switch (alg) {
    case UR_TRIGRAM_MATCHES: return _ur_trigram_matches(a, b);
    case UR_TRIGRAM_COSINE:  return _ur_trigram_cosine(a, b);
    }
    return 0;
}

void ur_trigram_subtract(ur_trigram_t a, ur_trigram_t b)
{
    int i;
    int before, after;
    
    _ur_trigram_check(a);
    _ur_trigram_check(b);

    for (i = 0; i < UR_TRIGRAM_ELEMENTS; i++) {
        before     = ur_trigram_bit_count(a->mask[i]);
        a->mask[i] = a->mask[i] & ~b->mask[i];
        after      = ur_trigram_bit_count(a->mask[i]);
        a->total  -= before - after;
        a->unique -= before - after;
    }
}
