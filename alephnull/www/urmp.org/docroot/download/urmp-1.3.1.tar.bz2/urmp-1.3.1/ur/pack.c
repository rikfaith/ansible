/* pack.c -- 
 * Created: Mon Oct 13 20:32:14 2008 by faith@acm.org
 * Revised: Tue Oct 14 17:15:27 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urP.h"

char *ur_pack_int(char *buf, int *len, int value)
{
	union {
		uint32_t i;
		char     c[4];
	} u;
	
	if (!buf || !len || *len < 4) return NULL;

	u.i = value;
	buf[0] = u.c[0];
	buf[1] = u.c[1];
	buf[2] = u.c[2];
	buf[3] = u.c[3];
	ur_trace(UR_TRACE_PACK, __func__, "len=%d buf=%p value=%d\n", *len, buf, value);
	*len -= 4;
	return buf += 4;
}

char *ur_pack_string(char *buf, int *len, const char *value)
{
	int  slen;

	if (!buf || !len || *len <= 0) return NULL;

	if (!value) value = "";
	slen = strlen(value);
	if (*len <= slen) return NULL;
	strcpy(buf, value);
	ur_trace(UR_TRACE_PACK, __func__, "slen=%d len=%d buf=%p value=%s\n",
		 slen, *len, buf, value);
	*len -= slen + 1;
	return buf += slen + 1;
}

char *ur_unpack_int(char *buf, int *len, int *value)
{
	union {
		uint32_t i;
		char     c[4];
	} u;

	if (!buf || !len || *len < 4) return NULL;

	u.c[0] = buf[0];
	u.c[1] = buf[1];
	u.c[2] = buf[2];
	u.c[3] = buf[3];
	*value = u.i;
	ur_trace(UR_TRACE_PACK, __func__, "len=%d buf=%p value=%d\n", *len, buf, *value);

	*len -= 4;
	return buf += 4;
}

char *ur_unpack_string(char *buf, int *len, const char **value)
{
	int slen;
	char *pt;

	if (!buf || !len || *len <= 0) return NULL;

	for (pt = buf, slen = 0; *pt && slen < *len; ++pt, ++slen)
		;
	ur_trace(UR_TRACE_PACK, __func__, "slen=%d len=%d buf=%p value=%s\n",
		 slen, *len, buf, buf);

	if (slen > *len) return NULL;
	*value = ur_atom_string_n(buf, slen);
	*len -= slen + 1;
	return buf += slen + 1;
}
