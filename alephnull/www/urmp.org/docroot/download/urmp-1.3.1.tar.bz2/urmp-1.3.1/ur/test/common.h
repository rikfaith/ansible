/* common.h -- 
 * Created: Sun Aug 13 10:18:00 2000 by faith@dict.org
 * Copyright 2000, 2003, 2004, 2008 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: common.h,v 1.3 2004-02-09 02:36:27 faith Exp $
 *
 * Must define the following before including this file:
 *
 * For everything:
 * OBJECTTYPE
 * OBJECTCREATE or OBJECTCREATE2
 * OBJECTINSERT
 *
 * For associative objects (sorted lists/trees, hash tables):
 * OBJECTLOOKUP
 * OBJECTITERATE
 * OBJECTPRINTSTATS
 * OBJECTDELETE
 * OBJECTSORTED (only if iteration should be in sorted order)
 *
 * For stack-like objects (stacks, lists):
 * OBJECTPUSH
 * OBJECTPOP
 * OBJECTDEPTH
 * OBJECTLAST
 * OBJECTAPPEND
 * OBJECTTOP
 * OBJECTBOT
 * OBJECTPICK
 * OBJECTSWAP
 * OBJECTDUP
 */

#ifndef OBJECTPRINTSTATS
#define OBJECTPRINTSTATS(a,b,c)
#endif

static void test(const char *type, const char *message)
{
    int i;

    printf("%s %s:", type, message);
    for (i = strlen(message)+strlen(type)+2; i < 40; i++) printf(" ");
}

static void  __attribute__((noreturn)) fail(const char *message)
{
    if (message)
	printf("FAILED [%s]\n", message);
    else
	printf("FAILED\n");
    exit(EXIT_FAILURE);
}

static void ok(const char *message)
{
    if (message)
	printf("OK [%s]\n", message);
    else
	printf("OK\n");
}

#ifdef OBJECTINFO
static void info(const char *message)
{
    printf("### INFO %s\n", message);
}
#endif

#ifdef OBJECTTYPE

#if   defined(OBJECTCREATE)
#         define OBJCREATE OBJECTCREATE(NULL)
#elif defined(OBJECTCREATE2)
#         define OBJCREATE OBJECTCREATE2(NULL,NULL)
#elif defined(OBJECTCREATE0)
#         define OBJCREATE OBJECTCREATE0(0)
#elif defined(OBJECTCREATE64)
#         define OBJCREATE OBJECTCREATE64(64)
#elif defined(OBJECTCREATEV)
#         define OBJCREATE OBJECTCREATEV()
#else
#         define OBJCREATE OBJECTCREATER(UR_RANDOM_STD, UR_RANDOM_UNIFORM)
#endif

static void end(OBJECTTYPE s)
{
    OBJECTDESTROY(s);
}

static int testcreate(void) {
    OBJECTTYPE    s;
    char          buf[2048];
    unsigned long magic0;
    unsigned long magic1;

    test("O", "Creation");
    s = OBJCREATE;
    if (s) ok(0); else fail(0);

    test("O", "Destroy");
    magic0 = *(unsigned long *)s;
    magic1 = OBJECTDESTROY(s);
    sprintf(buf, "0x%08lx 0x%08lx", magic0, magic1 & 0xffffffffLU);
    if (magic0 != ~magic1) fail(buf);
    ok(buf);

    return EXIT_SUCCESS;
}
#endif

#if defined(OBJECTINSERT) && defined(OBJECTLOOKUP) && defined(OBJECTDELETE)

static int compr(const void *a, const void *b)
{
    return strcmp(*(char **)a, *(char **)b);
}

static void try(int count)
{
    char         buf[1024];
    int          i;
    int          j;
    char         **array;
    char         **array2;
    OBJECTTYPE   s;
    ur_random_t   prng;
    const char   *datum;
#ifdef OBJECTITERATE
    ur_iterator_t iter;
    const char   *key;
#endif
    
    array  = ur_alloc(count * sizeof(*array));
    array2 = ur_alloc(count * sizeof(*array2));
    prng   = ur_random_create(UR_RANDOM_ALT0, UR_RANDOM_UNIFORM);

    for (i = 0; i < count; i++) {
	int len = ur_random_range(prng, 1, 1000);


	if (count <=10) len %= 20;
	if (!len) len = 1;

	array[i]  = ur_alloc((len + 1) * sizeof(*array[0]));
	array2[i] = ur_alloc((len + 1) * sizeof(*array2[0]));
      redo:
	for (j = 0; j < len; j++) {
	    array[i][j] = array2[i][j] = ' ' + ur_random_range(prng, 0, 0x5f);
	    if (array[i][j] < ' ' || array[i][j] >= 127)
		array[i][j] = array2[i][j] = 'a';
	}
	array[i][len] = array2[i][len] = '\0';
	for (j = 0; j < i; j++) {
	    if (!strcmp(array[j], array[i])) {
		printf("Duplicate %s\n", array[i]);
		goto redo;
	    }
	}
    }
				/* Sort list to test iteration */
    qsort(&array2[0], count, sizeof(array2[0]), compr);

    if (count <= 10) {
	for (i = 0; i < count; i++) {
	    sprintf(buf, "Data point %d (len = %zd, %zd)",
		    i, strlen(array[i]), strlen(array2[i]));
	    test("C", buf);
	    sprintf(buf, " %-10.10s   %-10.10s ", array[i], array2[i]);
	    ok(buf);
	}
    }

    sprintf(buf, "Count = %d", count);
    test("C", buf);

    s = OBJCREATE;
    for (i = 0; i < count; i++) {
	if (OBJECTINSERT(s, array[i], array[i])) {
	    sprintf(buf, "Adding item %d \"%s\"", i, array[i]);
	    fail(buf);
	}
    }
    
    for (i = 0; i < count; i++) {
	datum = OBJECTLOOKUP(s, array[i]);
	if (!datum) fail("NULL 0");
	if (strcmp(datum, array[i])) {
	    sprintf(buf, "\"%s\" instead of \"%s\"", datum, array[i]);
	    fail(buf);
	}
				/* Lookup twice to test reorganization (for
                                   hash tables). */
	datum = OBJECTLOOKUP(s, array[i]);
	if (!datum) fail("NULL 1");
	if (strcmp(datum, array[i])) {
	    sprintf(buf, "\"%s\" instead of \"%s\"", datum, array[i]);
	    fail(buf);
	}
    }

#ifdef OBJECTITERATE
#ifdef OBJECTSORTED
    i = 0;
    OBJECTITERATE(s, iter, key, datum) {
	if (strcmp(key, array2[i]) || strcmp(datum, array2[i])) {
	    sprintf(buf, "%d %s", i, key);
	    fail(buf);
	}
	i++;
    }
    if (i != count) {
	sprintf(buf, "%d iterations", i);
	fail(buf);
    }
#else
    for (i = 0; i < count; i++) array2[i] = NULL;
    i = 0;
    OBJECTITERATE(s, iter, key, datum)
	array2[i++] = (void *)key; /* Discard const */
    if (i != count) {
	sprintf(buf, "no iteration %d", i);
	fail(buf);
    }
    qsort(&array[0], count, sizeof(array[0]), compr);
    qsort(&array2[0], count, sizeof(array2[0]), compr);
    for (i = 0; i < count; i++) if (strcmp(array[i], array2[i])) {
	sprintf(buf, "%d \"%s\" \"%s\"", i, array[i], array2[i]);
	fail(buf);
    }
#endif
#endif

    for (i = 0; i < count; i++) {
	datum = OBJECTLOOKUP(s, array2[i]);
	if (!datum) fail("NULL 2");
	if (strcmp(datum, array2[i])) {
	    sprintf(buf, "\"%s\" instead of \"%s\"", datum, array2[i]);
	    fail(buf);
	}
    }

    
    ok(0);
    OBJECTPRINTSTATS(s, stdout, 1);
    
    for (i = 0; i < count; i++) {
	if (i == count / 2) {	/* lookup after delete */
	    for (j = i; j < count; j++) {
		datum = OBJECTLOOKUP(s, array[j]);
		if (!datum) fail("NULL 0");
		if (strcmp(datum, array[j])) {
		    sprintf(buf, "\"%s\" instead of \"%s\"", datum, array[j]);
		    fail(buf);
		}
	    }
	    OBJECTPRINTSTATS(s, stdout, 0);
	}
	if (OBJECTDELETE(s, array[i])) fail(array[i]);
    }

    for (i = 0; i < count; i++) ur_free(array[i]);
    ur_free(array);
    ur_random_destroy(prng);

    OBJECTPRINTSTATS(s, stdout, 0);
    end(s);
}

static int testcontainer(void)
{
    OBJECTTYPE    s;
    const char    *key[]   = { "a",  "b",
			       "aa", "ab" };
    const char    *datum[] = { "foo", "bar",
			       "baz", "bat" };
    const char    *ret;
#ifdef OBJECTITERATE
    ur_iterator_t  iter;
    const char    *retk;
    int           i;
#endif


    				/* Test with small numbers of datapoints */
    test("C", "Lookup 1");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0])) fail(key[0]);
    ok(0);
    end(s);

    test("C", "Lookup 2");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    OBJECTINSERT(s, key[1], datum[1]);
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0])) fail(key[0]);
    ret = OBJECTLOOKUP(s, key[1]);
    if (!ret || strcmp(ret, datum[1])) fail(key[1]);
    ok(0);
    end(s);

    test("C", "Lookup 2r");
    s = OBJCREATE;
    OBJECTINSERT(s, key[1], datum[1]);
    OBJECTINSERT(s, key[0], datum[0]);
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0])) fail(key[0]);
    ret = OBJECTLOOKUP(s, key[1]);
    if (!ret || strcmp(ret, datum[1])) fail(key[1]);
    ok(0);
    end(s);
    
    test("C", "Lookup 2l");
    s = OBJCREATE;
    OBJECTINSERT(s, key[2], datum[2]);
    OBJECTINSERT(s, key[3], datum[3]);
    ret = OBJECTLOOKUP(s, key[2]);
    if (!ret || strcmp(ret, datum[2])) fail(key[2]);
    ret = OBJECTLOOKUP(s, key[3]);
    if (!ret || strcmp(ret, datum[3])) fail(key[3]);
    ok(0);
    end(s);
    
    test("C", "Lookup 2m");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[2]);
    OBJECTINSERT(s, key[3], datum[3]);
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[2])) fail(key[2]);
    ret = OBJECTLOOKUP(s, key[3]);
    if (!ret || strcmp(ret, datum[3])) fail(key[3]);
    ok(0);
    end(s);

#ifdef OBJECTITERATE
				/* Test iteration */
    test("C", "Iterate 1");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[0]))                   fail(key[0]);
	if (strcmp(ret, datum[0]))                  fail(datum[0]);
	i++;
    }
    if (!i)                                         fail("no iter");
    OBJECTDELETE(s, key[0]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[i]))                   fail(key[i]);
	if (strcmp(ret, datum[i]))                  fail(datum[i]);
	i++;
    }
    if (i)                                          fail("iter");
    ok(0);
    end(s);

    test("C", "Iterate 2 (unsorted)");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    OBJECTINSERT(s, key[1], datum[1]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[0])
            && strcmp(retk, key[1]))                fail(retk);
	if (strcmp(ret, datum[0])
            && strcmp(ret, datum[1]))               fail(ret);
	i++;
    }
    if (!i)                                         fail("no iter");
    OBJECTDELETE(s, key[0]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[1]))                   fail(key[1]);
	if (strcmp(ret, datum[1]))                  fail(datum[1]);
	i++;
    }
    if (!i)                                         fail("no iter (2)");
    OBJECTDELETE(s, key[1]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	i++;
    }
    if (i)                                          fail("iter");
    ok(0);
    end(s);

#ifdef OBJECTSORTED
    test("C", "Iterate 2");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    OBJECTINSERT(s, key[1], datum[1]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[i]))                   fail(key[i]);
	if (strcmp(ret, datum[i]))                  fail(datum[i]);
	i++;
    }
    if (!i)                                         fail("no iter");
    ok(0);
    end(s);
    
    test("C", "Iterate 2r");
    s = OBJCREATE;
    OBJECTINSERT(s, key[1], datum[1]);
    OBJECTINSERT(s, key[0], datum[0]);
    i = 0;
    OBJECTITERATE(s, iter, retk, ret) {
	if (strcmp(retk, key[i]))                   fail(key[i]);
	if (strcmp(ret, datum[i]))                  fail(datum[i]);
	i++;
    }
    if (!i)                                         fail("no iter");
    ok(0);
    end(s);
#endif
#endif
    
    				/* Test deletion */
    test("C", "Deletion");
    s = OBJCREATE;
    OBJECTINSERT(s, key[0], datum[0]);
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0])) fail("first lookup");
    if (OBJECTDELETE(s, key[0]))       fail("first delete");
    if (OBJECTLOOKUP(s, key[0]))       fail("second lookup");
    if (!OBJECTDELETE(s, key[0]))      fail("second delete");
    ok(0);
    end(s);

				/* Test reinsertion */
    test("C", "Reinsertion");
    s = OBJCREATE;
    if (OBJECTINSERT(s, key[0], datum[0])) fail("first insert");
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0]))     fail("first lookup");
    if (OBJECTDELETE(s, key[0]))           fail("first delete");
    if (OBJECTINSERT(s, key[0], datum[0])) fail("second insert");
    ret = OBJECTLOOKUP(s, key[0]);
    if (!ret || strcmp(ret, datum[0]))     fail("second lookup");
    if (OBJECTDELETE(s, key[0]))           fail("second delete");
    if (!OBJECTDELETE(s, key[0]))          fail("third delete");
    ok(0);
    end(s);

    try(10);
    try(100);
    try(1000);

    return EXIT_SUCCESS;
}

static int timecontainer(void)
{
    OBJECTTYPE    s;
    ur_timer_t     t;
    ur_timeval_t   tv;
    int           iters, useconds;
    char          **array;
    ur_random_t    prng;
    const int     count = 10000;
    int           i, j, k;
    char          buf[2048];

    array  = ur_alloc(count * sizeof(*array));
    prng   = ur_random_create(UR_RANDOM_ALT0, UR_RANDOM_UNIFORM);
    
    for (i = 0; i < count; i++) {
	int len = ur_random_range(prng, 1, 1000);

	if (count <=10) len %= 20;
	if (!len) len = 1;

	array[i]  = ur_alloc((len + 1) * sizeof(*array[0]));
      redo:
	for (j = 0; j < len; j++) {
	    array[i][j] = ' ' + ur_random_range(prng, 0, 0x5f);
	    if (array[i][j] < ' ' || array[i][j] >= 127)
		array[i][j] = 'a';
	}
	array[i][len] = '\0';
	for (j = 0; j < i; j++) {
	    if (!strcmp(array[j], array[i])) goto redo;
	}
    }

    test("T", "Time setup (ins/del 100)");
    if (!(t = ur_timer_create(0))) fail("timer");
    if (!(s = OBJCREATE))         fail("object");
    for (iters = 100, useconds = 0; useconds < 300000;) {
	iters *= 2;
	ur_timer_start(t);
	for (k = 0; k < iters; k++) {
	    for (i = 0; i < 100; i++) OBJECTINSERT(s, array[i], array[i]);
	    for (i = 0; i < 100; i++) OBJECTDELETE(s, array[i]);
	}
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Time (ins/del 100)");
    if (!(s = OBJCREATE))         fail("object");
    ur_timer_start(t);
    for (k = 0; k < iters; k++) {
	for (i = 0; i < 100; i++) OBJECTINSERT(s, array[i], array[i]);
	for (i = 0; i < 100; i++) OBJECTDELETE(s, array[i]);
    }
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [ins/del 100]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters/200.0);
    info(buf);

    test("T", "Time setup (ins/del 1000)");
    if (!(t = ur_timer_create(0))) fail("timer");
    if (!(s = OBJCREATE))         fail("object");
    for (iters = 5, useconds = 0; useconds < 300000;) {
	iters *= 2;
	ur_timer_start(t);
	for (k = 0; k < iters; k++) {
	    for (i = 0; i < 1000; i++) OBJECTINSERT(s, array[i], array[i]);
	    for (i = 0; i < 1000; i++) OBJECTDELETE(s, array[i]);
	}
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Time (ins/del 1000)");
    if (!(s = OBJCREATE))         fail("object");
    ur_timer_start(t);
    for (k = 0; k < iters; k++) {
	for (i = 0; i < 1000; i++) OBJECTINSERT(s, array[i], array[i]);
	for (i = 0; i < 1000; i++) OBJECTDELETE(s, array[i]);
    }
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [ins/del 1000]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)
	    /iters/2000.0);
    info(buf);

    test("T", "Time setup (lookup 100)");
    if (!(t = ur_timer_create(0))) fail("timer");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 100; i++) OBJECTINSERT(s, array[i], array[i]);
    for (iters = 10000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	ur_timer_start(t);
	for (k = 0; k < iters; k++) OBJECTLOOKUP(s, array[k % 100]);
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Time (lookup 100)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 100; i++) OBJECTINSERT(s, array[i], array[i]);
    ur_timer_start(t);
    for (k = 0; k < iters; k++) OBJECTLOOKUP(s, array[k % 100]);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    OBJECTPRINTSTATS(s, stdout, 1);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [lookup 100]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time (lookup 1000)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 1000; i++) OBJECTINSERT(s, array[i], array[i]);
    ur_timer_start(t);
    for (k = 0; k < iters; k++) OBJECTLOOKUP(s, array[k % 1000]);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    OBJECTPRINTSTATS(s, stdout, 1);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [lookup 1000]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time (lookup 10000)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 10000; i++) OBJECTINSERT(s, array[i], array[i]);
    ur_timer_start(t);
    for (k = 0; k < iters; k++) OBJECTLOOKUP(s, array[k % 10000]);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    OBJECTPRINTSTATS(s, stdout, 1);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [lookup 10000]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);
    
    
    return EXIT_SUCCESS;
}
#endif

#if defined(OBJECTPUSH) && defined(OBJECTPOP)
static int teststack(void)
{
    OBJECTTYPE    s;
    ur_iterator_t  iter;
    char          buf[2048];
    const char    *datum0  = "datum0 is 42";
    const char    *datum1  = "datum1 is 3.14159265";
    const char    *datum2  = "datum2 is xyz";
    const char    *result;
    int           n[NCASES];
    int           i;
    const int     *j;
    
				/* Test with single datum */
    test("S", "Push/Pop 1a");
    s      = OBJCREATE;
    result = NULL;
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("a");
    result = OBJECTPOP(s);
    if (result) fail("empty");
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("b");
    ok(0);
    end(s);

    test("S", "Push/Pop 1b");
    s      = OBJCREATE;
    result = NULL;
    OBJECTPUSH(s, datum0);
    if (OBJECTDEPTH(s) != 1)                   fail("depth = 1");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0))     fail("a");
    if (OBJECTDEPTH(s) != 0)                   fail("depth = 0");
    result = OBJECTPOP(s);
    if (result) fail("empty");
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("b");
    ok(0);
    end(s);
    
    
    test("S", "Iterate 1");
    s      = OBJCREATE;
    result = NULL;
    OBJECTPUSH(s, datum0);
    if (OBJECTDEPTH(s) != 1)                   fail("depth = 1");
    i = 0;
    result = NULL;
    OBJECTITERATE(s,iter,result) {
	if (strcmp(result, datum0))            fail("iterate a");
	i++;
    }
    if (i != 1)                                fail("no iter");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0))     fail("a");
    if (OBJECTDEPTH(s) != 0)                   fail("depth = 0");
    i = 0;
    result = NULL;
    OBJECTITERATE(s,iter,result) {
	if (!result || strcmp(result, datum0)) fail("iterate b");
    }
    if (i)                                     fail("iter");
    result = OBJECTPOP(s);
    if (result)                                fail("empty");
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0))     fail("b");
    ok(0);
    end(s);

#if defined(OBJECTLAST) && defined(OBJECTAPPEND)
    test("S", "Append/Last 1");
    s      = OBJCREATE;
    result = NULL;
    OBJECTAPPEND(s, datum0);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("a");
    result = OBJECTLAST(s);
    if (result) fail("empty");
    OBJECTAPPEND(s, datum0);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("b");
    ok(0);
    end(s);
#endif
    
				/* Test with two data */
    test("S", "Push/Pop 2");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTPOP(s);
    if (result)                            fail("empty a");
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTPOP(s);
    if (result)                            fail("empty b");
    ok(0);
    end(s);
    
#if defined(OBJECTLAST) && defined(OBJECTAPPEND)
    test("S", "Append/Last 2");
    s      = OBJCREATE;
    result = 0;
    OBJECTAPPEND(s, datum0);
    OBJECTAPPEND(s, datum1);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTLAST(s);
    if (result)                            fail("empty a");
    OBJECTAPPEND(s, datum0);
    OBJECTAPPEND(s, datum1);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTLAST(s);
    if (result)                            fail("empty b");
    ok(0);
    end(s);
#endif
    
#if defined(OBJECTLAST) && defined(OBJECTAPPEND)
    test("S", "Push/Last Append/Pop 2a");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTLAST(s);
    if (result)                            fail("empty a");
    OBJECTAPPEND(s, datum0);
    OBJECTAPPEND(s, datum1);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (result)                            fail("empty b");
    ok(0);
    end(s);
#endif
    
#if defined(OBJECTLAST) && defined(OBJECTAPPEND)
    test("S", "Push/Last Append/Pop 2b");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum1);
    OBJECTAPPEND(s, datum0);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTLAST(s);
    if (result)                            fail("empty a");
    OBJECTAPPEND(s, datum1);
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (result)                            fail("empty b");
    ok(0);
    end(s);
#endif
    
#if defined(OBJECTLAST) && defined(OBJECTAPPEND)
    test("S", "Push/Last Append/Pop 2c");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum1);
    OBJECTAPPEND(s, datum0);
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTLAST(s);
    if (result)                            fail("empty a");
    OBJECTAPPEND(s, datum1);
    OBJECTPUSH(s, datum0);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (result)                            fail("empty b");
    ok(0);
    end(s);
#endif
    
				/* Test top */
    test("S", "Top (Push)");
    s      = OBJCREATE;
    result = NULL;
    OBJECTPUSH(s, datum0);
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    OBJECTPUSH(s, datum1);
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 c");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 aa");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 bb");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 cc");
    result = OBJECTPOP(s);
    if (result)                            fail("empty");
    ok(0);
    end(s);
    
#if defined(OBJECTAPPEND)
    test("S", "Top (Append)");
    s      = OBJCREATE;
    result = NULL;
    OBJECTAPPEND(s, datum0);
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    OBJECTPUSH(s, datum1);
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 c");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 aa");
    result = OBJECTTOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 bb");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 cc");
    result = OBJECTPOP(s);
    if (result)                            fail("empty");
    ok(0);
    end(s);
#endif
    
#if defined(OBJECTAPPEND) && defined(OBJECTBOT) && defined(OBJECTLAST)
				/* Test bot */
    test("S", "Bot");
    s      = OBJCREATE;
    result = NULL;
    OBJECTPUSH(s, datum0);
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    OBJECTAPPEND(s, datum1);
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum1)) fail("datum1 c");
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum0)) fail("datum0 aa");
    result = OBJECTBOT(s);
    if (!result || strcmp(result, datum0)) fail("datum0 bb");
    result = OBJECTLAST(s);
    if (!result || strcmp(result, datum0)) fail("datum0 cc");
    result = OBJECTBOT(s);
    if (result)                 fail("empty");
    ok(0);
    end(s);
#endif

    test("S", "Depth (push/pop)");
    s      = OBJCREATE;
    OBJECTPUSH(s, datum0);
    if (OBJECTDEPTH(s) != 1) fail("1 push");
    OBJECTPUSH(s, datum1);
    if (OBJECTDEPTH(s) != 2) fail("2 push");
    OBJECTPUSH(s, datum0);
    if (OBJECTDEPTH(s) != 3) fail("3 push");
    OBJECTPUSH(s, datum2);
    if (OBJECTDEPTH(s) != 4) fail("4 push");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 3) fail("3 pop");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 2) fail("2 pop");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 1) fail("1 pop");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 0) fail("0 pop a");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 0) fail("0 pop b");
    ok(0);
    end(s);
    
#if defined(OBJECTAPPEND)
    test("S", "Depth (push/pop/append)");
    s      = OBJCREATE;
    OBJECTPUSH(s, datum0);
    if (OBJECTDEPTH(s) != 1) fail("1 push");
    OBJECTPUSH(s, datum1);
    if (OBJECTDEPTH(s) != 2) fail("2 push");
    OBJECTAPPEND(s, datum0);
    if (OBJECTDEPTH(s) != 3) fail("3 push");
    OBJECTPUSH(s, datum1);
    if (OBJECTDEPTH(s) != 4) fail("4 push");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 3) fail("3 pop");
    OBJECTLAST(s);
    if (OBJECTDEPTH(s) != 2) fail("2 pop");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 1) fail("1 pop");
    OBJECTLAST(s);
    if (OBJECTDEPTH(s) != 0) fail("0 pop a");
    OBJECTPOP(s);
    if (OBJECTDEPTH(s) != 0) fail("0 pop b");
    ok(0);
    end(s);
#endif


#if defined(OBJECTSWAP)
				/* Test swap */
    test("S", "Swap");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    OBJECTSWAP(s);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTPOP(s);
    if (result)                 fail("empty a");
    
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    OBJECTSWAP(s);
    OBJECTSWAP(s);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTPOP(s);
    if (result)                 fail("empty b");
    
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    OBJECTSWAP(s);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 c");
    OBJECTSWAP(s);     
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 c");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 c");
    result = OBJECTPOP(s);
    if (result)                 fail("empty c");
    
    ok(0);
    end(s);
#endif

#if defined(OBJECTDUP)
				/* Test dup */
    test("S", "Dup");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTDUP(s);
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 c");
    result = OBJECTPOP(s);
    if (result)                 fail("empty d");
    ok(0);
    end(s);
#endif
    

#if defined(OBJECTPICK)
				/* Test pick */
    test("S", "Pick");
    s      = OBJCREATE;
    result = 0;
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    result = OBJECTPICK(s, 2);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 a");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 a");
    result = OBJECTPOP(s);
    if (result)                 fail("empty a");
    
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    result = OBJECTPICK(s, 1);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 b");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 b");
    result = OBJECTPOP(s);
    if (result)                 fail("empty b");
    
    OBJECTPUSH(s, datum0);
    OBJECTPUSH(s, datum1);
    OBJECTPUSH(s, datum2);
    result = OBJECTPICK(s, 0);
    if (!result || strcmp(result, datum2)) fail("datum2 c");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum2)) fail("datum2 c");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum1)) fail("datum1 c");
    result = OBJECTPOP(s);
    if (!result || strcmp(result, datum0)) fail("datum0 c");
    result = OBJECTPOP(s);
    if (result)                 fail("empty c");
    
    
    ok(0);
    end(s);
#endif

    
				/* More complex tests */
    
    test("S", "Setup for large dataset");
    for(i = 0; i < NCASES; i++) n[i] = i;
    s = OBJCREATE;
    ok(0);
    
    test("S", "Pushing items (large)");
    for(i = 0; i < NCASES; i++) {
	OBJECTPUSH(s, (const void *)&n[i]);
	if (!OBJECTTOP(s))                fail("empty");
	if (*(int *)OBJECTTOP(s) != n[i]) fail("item");
    }
    ok(0);

    test("S", "Iterating items (large)");
    i = NCASES-1;
    OBJECTITERATE(s, iter, j) {
	if (!j)                            fail("empty");
	if (*j != n[i--])                  fail("mismatch");
    }
    if (i != -1)                           fail("no iter");
    ok(0);
    
    test("S", "Popping items (large)");
    for(i = NCASES-1; i >= 0; i--) {
	j = (int *)OBJECTPOP(s);
	if (!j)                            fail("empty");
	if (*j != n[i])                    fail("mismatch");
    }
    ok(0);
    
    test("S", "Interleaved push and pop (large)");
    for(i = 0; i < NCASES; i++) {
	OBJECTPUSH(s, (const void *)&n[i]);
	if (!OBJECTTOP(s))                 fail("empty");
	if (*(int *)OBJECTTOP(s) != n[i])  fail("mismatch");
	j = (int *)OBJECTPOP(s);
	if (!j)                            fail("empty (pop)");
	if (*j != n[i])                    fail("mismatch (pop)");
    }
    ok(0);

#if defined(OBJECTAPPEND) && defined(OBJECTLAST)
    test("S", "Appending items (large)");
    for(i = 0; i < NCASES; i++) {
	OBJECTAPPEND(s, (const void *)&n[i]);
	if (!OBJECTBOT(s))                 fail("empty");
	if (*(int *)OBJECTBOT(s) != n[i])  fail("item");
    }
    ok(0);
    
    test("S", "Lasting items (large)");
    for(i = NCASES-1; i >= 0; i--) {
	j = (int *)OBJECTLAST(s);
	if (!j)                            fail("empty");
	if (*j != n[i])                    fail("mismatch");
    }
    ok(0);
    
    test("S", "Interleaved append and last (large)");
    for(i = 0; i < NCASES; i++) {
	OBJECTAPPEND(s, (const void *)&n[i]);
	if (!OBJECTBOT(s))                 fail("empty");
	if (*(int *)OBJECTBOT(s) != n[i])  fail("mismatch");
	j = (int *)OBJECTLAST(s);
	if (!j)                            fail("empty (pop)");
	if (*j != n[i])                    fail("mismatch (pop)");
    }
    ok(0);
#endif
    
    test("S", "Top (large)");
    for(i = 0; i < NCASES; i++) OBJECTPUSH(s, (const void *)&n[i]);
    if (!OBJECTTOP(s))                       fail("empty");
    if (*(int *)OBJECTTOP(s) != n[NCASES-1]) fail("mismatch");
    ok(0);

    test("S", "Depth (large)");
    if (OBJECTDEPTH(s) != NCASES) {
	sprintf(buf, "depth = %d vs. %d", OBJECTDEPTH(s), NCASES);
	fail(buf);
    }
    ok(0);

#if defined(OBJECTPICK)
    test("S", "Pick (large)");
    if (!OBJECTPICK(s, NCASES/2)) fail("not full");
    if (*(int *)OBJECTPICK(s, NCASES/2) != n[NCASES/2])
	fail("mismatch (pick)");
    if (*(int *)OBJECTTOP(s) != *(int *)OBJECTPICK(s, 0))
	fail("mismatch (top/pick)");
    ok(0);
#endif

#if defined(OBJECTBOT)
    test("S", "Bot (large)");
    for(i = 0; i < NCASES; i++) OBJECTAPPEND(s, (const void *)&n[i]);
    if (!OBJECTBOT(s))                       fail("empty");
    if (*(int *)OBJECTBOT(s) != n[NCASES-1]) fail("mismatch");
    ok(0);
#endif
    
#if defined(OBJECTPICK) && defined(OBJECTSWAP)
    test("S", "Swap (large)");
    if (*(int *)OBJECTPICK(s, 0) != n[NCASES-1]) fail("a");
    if (*(int *)OBJECTPICK(s, 1) != n[NCASES-2]) fail("b");
    OBJECTSWAP(s);
    if (*(int *)OBJECTPICK(s, 0) != n[NCASES-2]) fail("c");
    if (*(int *)OBJECTPICK(s, 1) != n[NCASES-1]) fail("d");
    OBJECTSWAP(s);
    if (*(int *)OBJECTPICK(s, 0) != n[NCASES-1]) fail("e");
    if (*(int *)OBJECTPICK(s, 1) != n[NCASES-2]) fail("f");
    ok(0);
#endif

#if defined(OBJECTDUP) && defined(OBJECTPICK)
    test("S", "Dup (large)");
    OBJECTDUP(s);
    if (*(int *)OBJECTPICK(s, 0) != n[NCASES-1]) fail("a");
    if (*(int *)OBJECTPICK(s, 1) != n[NCASES-1]) fail("b");
    OBJECTPOP(s);
    ok(0);
#endif
    
    end(s);

    return EXIT_SUCCESS;
}

static int timestack(void)
{
    OBJECTTYPE    s;
    char          buf[2048];
    int           i, k;
    ur_timer_t     t;
    ur_timeval_t   tv;
    int           sum;
    int           iters, useconds;

    test("T", "Time setup (push)");
    if (!(t = ur_timer_create(0))) fail("timer");
    for (iters = 10000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	if (!(s = OBJCREATE))         fail("object");
	ur_timer_start(t);
	for (k = 0; k < iters; k++) OBJECTPUSH(s, "foo");
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	for (k = 0; k < iters; k++) OBJECTPOP(s);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
	end(s);
    };
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    
    test("T", "Time (push)");
    if (!(s = OBJCREATE))         fail("object");
    ur_timer_start(t);
    for (k = 0; k < iters; k++) OBJECTPUSH(s, "foo");
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    for (k = 0; k < iters; k++) OBJECTPOP(s);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [push]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time (pop)");
    if (!(s = OBJCREATE))         fail("object");
    for (k = 0; k < iters; k++) OBJECTPUSH(s, "foo");
    ur_timer_start(t);
    for (k = 0; k < iters; k++) OBJECTPOP(s);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [pop]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time (push/pop)");
    if (!(s = OBJCREATE))         fail("object");
    ur_timer_start(t);
    for (k = 0; k < iters/100; k++) {
	for (i = 0; i < 50; i++) OBJECTPUSH(s, "foo");
	for (i = 0; i < 50; i++) OBJECTPOP(s);
    }
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [push/pop]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time setup (depth 100)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 100; i++) OBJECTPUSH(s, "foo");
    for (iters = 10000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	sum = 0;
	ur_timer_start(t);
	for (k = 0; k < iters; k++) sum += OBJECTDEPTH(s);
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    for (k = 0; k < 100; k++) OBJECTPOP(s);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Time (depth 100)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 100; i++) OBJECTPUSH(s, "foo");
    sum = 0;
    ur_timer_start(t);
    for (k = 0; k < iters; k++) sum += OBJECTDEPTH(s);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    for (k = 0; k < 100; k++) OBJECTPOP(s);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [depth 100]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Time setup (depth 1000)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 1000; i++) OBJECTPUSH(s, "foo");
    for (iters = 10000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	ur_timer_start(t);
	for (k = 0; k < iters; k++) sum += OBJECTDEPTH(s);
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    for (k = 0; k < 1000; k++) OBJECTPOP(s);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Time (depth 1000)");
    if (!(s = OBJCREATE))         fail("object");
    for (i = 0; i < 1000; i++) OBJECTPUSH(s, "foo");
    sum = 0;
    ur_timer_start(t);
    for (k = 0; k < iters; k++) sum += OBJECTDEPTH(s);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    for (k = 0; k < 1000; k++) OBJECTPOP(s);
    ok(0);
    end(s);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [depth 1000]", OBJECTNAME,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    ur_timer_destroy(t);

    return EXIT_SUCCESS;
}

#endif
