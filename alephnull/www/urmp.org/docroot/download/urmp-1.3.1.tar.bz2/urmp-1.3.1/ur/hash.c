/* hash.c -- 
 * Created: Mon Jul  5 13:21:48 1999 by faith@dict.org
 * Copyright 1999, 2000, 2002, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: hash.c,v 1.21 2003-09-12 13:15:17 faith Exp $
 *
 * Based on linear hashing from:
 *     Larson, Per-Ake.  Dynamic Hash Tables.  CACM 31(4): April 1988,
 *     pp. 446-457.
 *
 * Hash function based on:
 *     Hanson, David R. C Interfaces and Implementations: Techniques for
 *     Creating Reusable Software.  Reading, Massachusetts: Addison-Wesley,
 *     1997.  Chapter 3, pp. 39-41.
 * 
 */

#include "urP.h"

typedef struct ur_hash_bucket_s {
    const void            *key;
    const void            *datum;
    unsigned long         hash;
    struct ur_hash_bucket_s *next;
} *ur_hash_bucket_t;

typedef struct ur_hash_segment_s {
               ur_hash_bucket_t            bucket[UR_HASH_BUCKET_COUNT];
} *ur_hash_segment_t;

struct ur_hash_s {
    unsigned long             magic;
    ur_hash_hash_t            hash;
    ur_hash_compare_t         compare;
    unsigned long             segment_count;
    unsigned long             bucket_count;
    unsigned long             bucket_limit;
    unsigned long             bucket_next;
    unsigned long             bucket_max;
    
    unsigned long             expansion_count;
    unsigned long             contraction_count;
    unsigned long             element_count;
    unsigned long             retrieval_count;
    unsigned long             hit_count;
    unsigned long             miss_count;
    ur_hash_segment_t         segment[UR_HASH_SEGMENT_COUNT];
    int                       locked;
};

static ur_block_t     _ur_hash_block_bucket;
static ur_block_t     _ur_hash_block_segment;
static int           _ur_hash_block_in_use;

CHECK_FUNCTION(_ur_hash_check, ur_hash_t, UR_HASH_MAGIC)

static __inline__ void _ur_hash_check_key(const void *key)
{
    if (!key) ur_fatal(__FUNCTION__, "Null key\n");
}

static unsigned long _ur_hash_hash(const void *key)
{
    static unsigned long table[256];
    static int           initialized = 0;
    const unsigned char  *pt;
    unsigned long        hash = 0;

    if (!initialized) {
	ur_random_t r;
	int        i;

	r = ur_random_create(UR_RANDOM_ALT2, UR_RANDOM_UNIFORM);
	for (i = 0; i < 256; i++) table[i] = ur_random(r);
	ur_random_destroy(r);
	++initialized;
    }

    for (pt = key; *pt; pt++) hash  ^= table[(unsigned char)*pt];

    return hash;
}

static unsigned long _ur_hash_hash_ul(const void *key)
{
    static unsigned long table[256];
    static int           initialized = 0;
    unsigned long        ulkey = (unsigned long)key;
    const unsigned char  *pt = (const unsigned char *)&ulkey;
    unsigned long        hash = 0;
    int                  i;

    if (!initialized) {
	ur_random_t r;

	r = ur_random_create(UR_RANDOM_ALT2, UR_RANDOM_UNIFORM);
	for (i = 0; i < 256; i++) table[i] = ur_random(r);
	ur_random_destroy(r);
	++initialized;
    }

    for (i = 0; i < sizeof(ulkey); i++, pt++) {
	    hash  ^= table[(unsigned char)*pt];
    }

    return hash;
}
				/* FIXME */
static int _ur_hash_compare(const void *key1, const void *key2)
{
    return strcmp(key1, key2);
}

static int _ur_hash_compare_ul(const void *key1, const void *key2)
{
	unsigned long *a = (unsigned long *)key1;
	unsigned long *b = (unsigned long *)key2;

	if (a < b) {
		return -1;
	} else if (a > b) {
		return 1;
	}
	return 0;
}

static void _ur_hash_alloc_segment(ur_hash_t table)
{
    if (++table->segment_count >= UR_HASH_SEGMENT_COUNT) {
        --table->segment_count;
        ur_hash_print_stats(table, 0, 1);
	ur_internal(__FUNCTION__,
		    "Segment count = %lu (>= %u)\n",
		    table->segment_count + 1,
		    UR_HASH_SEGMENT_COUNT);
    }

    table->segment[table->segment_count-1]
	= (_ur_hash_block_segment
	   ? ur_block_alloc_z(_ur_hash_block_segment)
	   : ur_allocz(sizeof(*table->segment[0])));
    table->bucket_max += UR_HASH_BUCKET_COUNT;
}

static void _ur_hash_free_segment(ur_hash_t table)
{
    int             i;
    ur_hash_bucket_t  b;
    ur_hash_bucket_t  next;
    ur_hash_segment_t s;

    if (!table->segment_count)
	ur_internal(__FUNCTION__, "No more segments left\n");
    
    --table->segment_count;
    
    
    s = table->segment[table->segment_count];
    if (!s)
	ur_internal(__FUNCTION__,
		    "Segment %lu is NULL\n", table->segment_count);
		
    for (i = 0; i < UR_HASH_BUCKET_COUNT; i++) {
	for (b = s->bucket[i]; b; b = next) {
	    next = b->next;
	    if (_ur_hash_block_bucket) ur_block_free(_ur_hash_block_bucket, b);
	    else                     ur_free(b);
	}
    }
    if (_ur_hash_block_segment) ur_block_free(_ur_hash_block_segment, s);
    else                      ur_free(s);
    
    table->segment[table->segment_count] = NULL;
    table->bucket_max -= UR_HASH_BUCKET_COUNT;
}

ur_hash_t ur_hash_create(ur_hash_hash_t hash, ur_hash_compare_t compare)
{
    ur_hash_t table = ur_allocz(sizeof(*table));

    table->magic             = UR_HASH_MAGIC;
    table->hash              = hash    ? hash    : _ur_hash_hash;
    table->compare           = compare ? compare : _ur_hash_compare;
    table->segment_count     = 0;
    table->bucket_count      = UR_HASH_MIN_BUCKETS;
    table->bucket_limit      = 2 * table->bucket_count;
    table->bucket_next       = 0;
    table->bucket_max        = 0;
    
    table->expansion_count   = 0;
    table->contraction_count = 0;
    table->element_count     = 0;
    table->retrieval_count   = 0;
    table->hit_count         = 0;
    table->miss_count        = 0;

    if (UR_USE_BLOCK) {
	if (!_ur_hash_block_bucket)
	    _ur_hash_block_bucket
		= ur_block_create(sizeof(struct ur_hash_bucket_s));
	if (!_ur_hash_block_segment)
	    _ur_hash_block_segment
		= ur_block_create(sizeof(struct ur_hash_segment_s));
	++_ur_hash_block_in_use;
    }

    _ur_hash_alloc_segment(table);
    
    return table;
}

ur_hash_t ur_hash_create_ulkey(void)
{
	return ur_hash_create(_ur_hash_hash_ul, _ur_hash_compare_ul);
}

unsigned long ur_hash_destroy(ur_hash_t table)
{
    unsigned long i;
    unsigned long count;
    unsigned long ret;

    _ur_hash_check(table);
    
    for (i = 0, count = table->segment_count; i < count; i++) {
	_ur_hash_free_segment(table);
    }
    ret = table->magic = ~UR_HASH_MAGIC;
    ur_free(table);
    
    if (UR_USE_BLOCK && !--_ur_hash_block_in_use) {
	if (_ur_hash_block_bucket)  ur_block_destroy(_ur_hash_block_bucket);
	if (_ur_hash_block_segment) ur_block_destroy(_ur_hash_block_segment);
	_ur_hash_block_bucket  = NULL;
	_ur_hash_block_segment = NULL;
    }
    return ret;
}

static ur_hash_bucket_t *_ur_hash_get_bucket(ur_hash_t table, unsigned long hash)
{
    unsigned long segment;
    unsigned long bucket;

    bucket   = hash & (table->bucket_limit - 1);
    if (bucket >= table->bucket_count)
	bucket = hash & (table->bucket_limit / 2 - 1);
    segment  = bucket / UR_HASH_BUCKET_COUNT;

#if 0
    printf("%lx in %lu/%lu\n", hash, segment, bucket);
#endif
    return &table->segment[segment]->bucket[bucket & UR_HASH_BUCKET_MASK];
}

void *ur_hash_lookup(ur_hash_t table, const void *key)
{
    ur_hash_bucket_t  *head;
    ur_hash_bucket_t  bucket;
    ur_hash_bucket_t  prev = NULL;
    unsigned long   hash;

    _ur_hash_check(table);
    _ur_hash_check_key(key);

    hash = table->hash(key);
    head = _ur_hash_get_bucket(table, hash);

    ++table->retrieval_count;
    
    for (bucket = *head; bucket; bucket = bucket->next) {
	if (!table->compare(bucket->key, key)) {
	    if (prev) {
				/* Reorganize list */
                if (!table->locked) {
                    prev->next   = bucket->next;
                    bucket->next = *head;
                    *head        = bucket;
                }
	    } else {
		++table->hit_count;
	    }
	    return (void *)bucket->datum; /* Discard const */
	}
	prev = bucket;
    }

    ++table->miss_count;
    return NULL;
}

unsigned long ur_hash_lookup_ul(ur_hash_t table, const void *key)
{
    void *retval = ur_hash_lookup(table, key);
    return (unsigned long)retval;
}

static void _ur_hash_expand(ur_hash_t table)
{
    unsigned long  old_segment;
    unsigned long  old_bucket;
    unsigned long  old_absolute;
    unsigned long  new_segment;
    unsigned long  new_bucket;
    unsigned long  new_absolute;
    unsigned long  absolute;
    ur_hash_bucket_t *old_b;
    ur_hash_bucket_t *new_b;
    ur_hash_bucket_t b;
    ur_hash_bucket_t next;
    ur_hash_bucket_t prev = NULL;
    
    ++table->bucket_count;
    if (table->bucket_count > table->bucket_max) _ur_hash_alloc_segment(table);
    if (table->bucket_count > table->bucket_max)
	ur_internal(__FUNCTION__, "count = %lu, max = %lu\n",
		    table->bucket_count, table->bucket_max);
    
    old_segment  = table->bucket_next        / UR_HASH_BUCKET_COUNT;
    old_bucket   = table->bucket_next        & UR_HASH_BUCKET_MASK;
    old_absolute = old_segment * UR_HASH_BUCKET_COUNT + old_bucket;
    old_b        = &table->segment[old_segment]->bucket[old_bucket];
    
    new_segment  = (table->bucket_count - 1) / UR_HASH_BUCKET_COUNT;
    new_bucket   = (table->bucket_count - 1) & UR_HASH_BUCKET_MASK;
    new_absolute = new_segment * UR_HASH_BUCKET_COUNT + new_bucket;
    new_b        = &table->segment[new_segment]->bucket[new_bucket];

#if 0
    printf("\nExpand from %lu/%lu to %lu/%lu"
	   " (cnt = %lu, next = %lu, limit = %lu, max= %lu, ld = %.2f)\n",
	   old_segment, old_bucket,
	   new_segment, new_bucket,
	   table->bucket_count,
	   table->bucket_next,
	   table->bucket_limit,
	   table->bucket_max,
	   (double)table->element_count / table->bucket_count);
#endif
    
    for (b = *old_b; b; b = next) {
	next = b->next;
	absolute = b->hash & (table->bucket_limit - 1);
	if (absolute != old_absolute) {
#if 0
	    printf("Moving %lx from %lu/%lu to %lu/%lu (%lu)\n",
		   b->hash, old_segment, old_bucket, new_segment, new_bucket,
		   b->hash & (table->bucket_limit - 1));
#endif
	    if (absolute != new_absolute)
		ur_internal(__FUNCTION__,
			    "Mismatch (%lu, %lu)\n", absolute, new_absolute);
	    if (prev) {
		prev->next = b->next;
	    } else {
		*old_b = b->next;
	    }
	    b->next = *new_b;
	    *new_b  = b;
	} else {
	    prev = b;
	}
    }

    ++table->bucket_next;
    if (table->bucket_next >= table->bucket_limit/2) {
	table->bucket_next   = 0;
	table->bucket_limit *= 2;
    }
    
    ++table->expansion_count;
}

static void _ur_hash_contract(ur_hash_t table)
{
    unsigned long  old_segment;
    unsigned long  old_bucket;
    unsigned long  new_segment;
    unsigned long  new_bucket;
    ur_hash_bucket_t *old_b;
    ur_hash_bucket_t *new_b;
    ur_hash_bucket_t b;
    ur_hash_bucket_t next;

    if (!table->bucket_count--)
	ur_internal(__FUNCTION__, "%ld buckets\n", table->bucket_count);
    
    if (table->bucket_count > table->bucket_max)
	ur_internal(__FUNCTION__, "count = %lu, max = %lu\n",
		    table->bucket_count, table->bucket_max);
    
    if (!table->bucket_next) {
	table->bucket_limit /= 2;
	table->bucket_next   = table->bucket_limit / 2;
    }
    --table->bucket_next;
    
    old_segment  = table->bucket_count / UR_HASH_BUCKET_COUNT;
    old_bucket   = table->bucket_count & UR_HASH_BUCKET_MASK;
    /* old_absolute = old_segment * UR_HASH_BUCKET_COUNT + old_bucket; */
    old_b        = &table->segment[old_segment]->bucket[old_bucket];
    
    new_segment  = table->bucket_next  / UR_HASH_BUCKET_COUNT;
    new_bucket   = table->bucket_next  & UR_HASH_BUCKET_MASK;
    /* new_absolute = new_segment * UR_HASH_BUCKET_COUNT + new_bucket; */
    new_b        = &table->segment[new_segment]->bucket[new_bucket];

#if 0
    printf("\nContract from %lu/%lu to %lu/%lu"
	   " (cnt = %lu, next = %lu, limit = %lu, max= %lu, ld = %.2f)\n",
	   old_segment, old_bucket,
	   new_segment, new_bucket,
	   table->bucket_count,
	   table->bucket_next,
	   table->bucket_limit,
	   table->bucket_max,
	   (double)table->element_count / table->bucket_count);
#endif
    
    for (b = *old_b; b; b = next) {
#if 0
	printf("Moving %lx from %lu/%lu to %lu/%lu (%lu)\n",
	       b->hash, old_segment, old_bucket, new_segment, new_bucket,
	       b->hash & (table->bucket_limit - 1));
#endif
	next = b->next;
	b->next = *new_b;
	*new_b  = b;
    }
    *old_b = NULL;

    ++table->contraction_count;
}

int ur_hash_insert(ur_hash_t table, const void *key, const void *datum)
{
    ur_hash_bucket_t  *head;
    ur_hash_bucket_t  bucket;
    ur_hash_bucket_t  b;
    unsigned long   hash;
    int             retcode = 0;

    _ur_hash_check(table);
    _ur_hash_check_key(key);

    while ((double)table->element_count / (double)table->bucket_count
	   > UR_HASH_BUCKET_LOAD + UR_HASH_BUCKET_MARK)
	_ur_hash_expand(table);

    hash = table->hash(key);
    head = _ur_hash_get_bucket(table, hash);

				/* Check for existing key */
    for (bucket = *head; bucket; bucket = bucket->next)
	if (!table->compare(bucket->key, key)) {
            bucket->datum = datum;
            retcode = 1;
        }

    if (!retcode) {
        b        = (_ur_hash_block_bucket
                    ? ur_block_alloc(_ur_hash_block_bucket)
                    : ur_alloc(sizeof(*b)));
        b->key   = key;
        b->datum = datum;
        b->hash  = hash;
        b->next  = *head;
        *head    = b;
    
        ++table->element_count;
    }

    return retcode;
}

int ur_hash_insert_ul(ur_hash_t table, const void *key, unsigned long datum)
{
    return ur_hash_insert(table, key, (const void *)datum);
}

int ur_hash_delete(ur_hash_t table, const void *key)
{
    ur_hash_bucket_t  prev = NULL;
    ur_hash_bucket_t  *head;
    ur_hash_bucket_t  bucket;
    unsigned long   hash;

    _ur_hash_check(table);
    _ur_hash_check_key(key);

    while ((double)table->element_count / (double)table->bucket_count
	   < UR_HASH_BUCKET_LOAD - UR_HASH_BUCKET_MARK
	   && table->bucket_count > UR_HASH_MIN_BUCKETS) {
	    _ur_hash_contract(table);
    }
    
    hash = table->hash(key);
    head = _ur_hash_get_bucket(table, hash);
    
    for (bucket = *head; bucket; bucket = bucket->next) {
	if (!table->compare(bucket->key, key)) {
	    if (prev) prev->next = bucket->next;
	    else      *head = bucket->next;
	    if (_ur_hash_block_bucket) ur_block_free(_ur_hash_block_bucket, bucket);
	    else                     ur_free(bucket);
	    --table->element_count;
	    return 0;
	}
	prev = bucket;
    }

    return 1;
}

unsigned long ur_hash_items(ur_hash_t table)
{
    return table->element_count;
}

int ur_hash_print_stats(ur_hash_t table, FILE *str, int flags)
{
    unsigned long   i, j;
    ur_hash_bucket_t  bucket;
    unsigned long   len;
    unsigned long   bucket_use      = 0;
    unsigned long   length_max      = 0;
    unsigned long   singleton_count = 0;

    if (!str) str = stdout;
    for (i = 0; i < table->segment_count; i++)
	for (j = 0; j < UR_HASH_BUCKET_COUNT; j++) {
	    len = 0;
	    for (bucket = table->segment[i]->bucket[j];
		 bucket;
		 bucket = bucket->next) ++len;
	    
	    if (len)              ++bucket_use;
	    if (len > length_max) length_max = len;
	    if (len == 1)         ++singleton_count;
	}

    if (flags) {
	fprintf(str,
		"Segs Bckts  BLim BNext Expan Contr  Elems BUsed "
		"  Max  Sngl    Retr     Hit    Miss  Ld\n");
    }
    fprintf(str,
	    "%4lu %5lu %5lu %5lu %5lu %5lu %6lu %5lu %5lu %5lu %7lu %7lu %7lu"
	    " %3.1f\n",
	    table->segment_count,
	    table->bucket_count,
	    table->bucket_limit,
	    table->bucket_next,
	    table->expansion_count,
	    table->contraction_count,
	    table->element_count,
	    bucket_use,
	    length_max,
	    singleton_count,
	    table->retrieval_count,
	    table->hit_count,
	    table->miss_count,
	    (double)table->element_count / (double)table->bucket_count);
    
    return 0;
}

void ur_hash_iterator_init(ur_hash_t table, ur_iterator_t *iter)
{
    _ur_hash_check(table);
    iter->a = table;
    iter->b = NULL;
    iter->c = 0;
    iter->d = 0;
    for (iter->c = 0; iter->c < table->segment_count; iter->c++) {
	for (iter->d = 0; iter->d < UR_HASH_BUCKET_COUNT; iter->d++) {
	    if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return;
	}
    }
}

int ur_hash_iterator_next(ur_iterator_t *iter)
{
    ur_hash_t table = iter->a;
    
    _ur_hash_check(table);

    if (iter->c >= table->segment_count) return 0;
    if (iter->b) iter->b = ((ur_hash_bucket_t)iter->b)->next;
    if (iter->b) return 1;
    for (++iter->d; iter->d < UR_HASH_BUCKET_COUNT; iter->d++) {
	if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return 1;
    }
    for (++iter->c; iter->c < table->segment_count; iter->c++) {
	for (iter->d = 0; iter->d < UR_HASH_BUCKET_COUNT; iter->d++) {
	    if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return 1;
	}
    }
    iter->b = NULL;
    return 0;
}

void *ur_hash_iterator_key(ur_iterator_t *iter)
{
    ur_hash_t table = iter->a;
    
    _ur_hash_check(table);
    if (!iter->b) return NULL;
    return (void *)((ur_hash_bucket_t)iter->b)->key; /* Discard const */
}

void *ur_hash_iterator_datum(ur_iterator_t *iter)
{
    ur_hash_t table = iter->a;
    
    _ur_hash_check(table);
    if (!iter->b) return NULL;
    return (void *)((ur_hash_bucket_t)iter->b)->datum; /* Discard const */
}

unsigned long ur_hash_iterator_datum_ul(ur_iterator_t *iter)
{
    void *retval = ur_hash_iterator_datum(iter);
    return (unsigned long)retval;
}

void ur_hash_iterator_lock(ur_hash_t table)
{
    _ur_hash_check(table);
    table->locked = 1;
}

void ur_hash_iterator_unlock(ur_hash_t table)
{
    _ur_hash_check(table);
    table->locked = 0;
}
