/* ur.c -- 
 * Created: Mon Jul  5 13:08:25 1999 by faith@dict.org
 * Copyright 1999-2000, 2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#define _POSIX_C_SOURCE 200112L
#define _XOPEN_SOURCE
#define _XOPEN_SOURCE_EXTENDED
#include "urP.h"
#ifdef BT_PRODUCTION
#include "backtrace.h"
#endif
#include <signal.h>
#include <sys/ucontext.h>
#include <sys/utsname.h>
#if HAVE_EXECINFO_H
#include <execinfo.h>
#endif
#if HAVE_GNU_LIBC_VERSION_H
#include <gnu/libc-version.h>
#endif

static const char *_ur_program_name;
static ur_flag_t  _ur_trace_flags;
static ur_flag_t  _ur_debug_flags;
static bool       _ur_shutdown_called = false;
static void (*_ur_extra_trailer)(void);

const char *ur_signal_name(int sig)
{
     switch (sig) {
     case SIGHUP:    return "SIGHUP";
     case SIGINT:    return "SIGINT";
     case SIGQUIT:   return "SIGQUIT";
     case SIGILL:    return "SIGILL";
     case SIGTRAP:   return "SIGTRAP";
     case SIGABRT:   return "SIGABRT";
     case SIGBUS:    return "SIGBUS";
     case SIGFPE:    return "SIGFPE";
     case SIGKILL:   return "SIGKILL";
     case SIGUSR1:   return "SIGUSR1";
     case SIGSEGV:   return "SIGSEGV";
     case SIGUSR2:   return "SIGUSR2";
     case SIGPIPE:   return "SIGPIPE";
     case SIGALRM:   return "SIGALRM";
     case SIGTERM:   return "SIGTERM";
     case SIGSTKFLT: return "SIGSTKFLT";
     case SIGCHLD:   return "SIGCHLD";
     case SIGCONT:   return "SIGCONT";
     case SIGSTOP:   return "SIGSTOP";
     case SIGTSTP:   return "SIGTSTP";
     case SIGTTIN:   return "SIGTTIN";
     case SIGTTOU:   return "SIGTTOU";
     case SIGURG:    return "SIGURG";
     case SIGXCPU:   return "SIGXCPU";
     case SIGXFSZ:   return "SIGXFSZ";
     case SIGVTALRM: return "SIGVTALRM";
     case SIGPROF:   return "SIGPROF";
     case SIGWINCH:  return "SIGWINCH";
     case SIGIO:     return "SIGIO";
     case SIGPWR:    return "SIGPWR";
     case SIGSYS:    return "SIGSYS";
     }
     return NULL;
}

static const char *ur_signal_description(siginfo_t *info)
{
    static char buf[64];
    if (!info) return "";
    
    switch (info->si_code) {
    case SI_KERNEL:     return "kernel";
    case SI_QUEUE:      return "sigqueue";
    case SI_TIMER:      return "timer expired";
    case SI_MESGQ:      return "real time mesq state changed";
    case SI_ASYNCIO:    return "AIO completed";
    case SI_SIGIO:      return "queued SIGIO";
    }
    
    switch (info->si_signo) {
    case SIGILL:
        switch (info->si_code) {
        case ILL_ILLOPC:    return "illegal opcode";
        case ILL_ILLOPN:    return "illegal operand";
        case ILL_ILLADR:    return "illegal addressing mode";
        case ILL_ILLTRP:    return "illegal trap";
        case ILL_PRVOPC:    return "privileged opcode";
        case ILL_PRVREG:    return "privileged register";
        case ILL_COPROC:    return "coprocessor error";
        case ILL_BADSTK:    return "internal stack error";
        }
        break;
    case SIGFPE:
        switch (info->si_code) {
        case FPE_INTDIV:    return "integer divide by zero";
        case FPE_INTOVF:    return "integer overflow";
        case FPE_FLTDIV:    return "floating point divide by zero";
        case FPE_FLTOVF:    return "floating point overflow";
        case FPE_FLTUND:    return "floating point underflow";
        case FPE_FLTRES:    return "floating point inexact result";
        case FPE_FLTINV:    return "floating point invalid operation";
        case FPE_FLTSUB:    return "subscript out of range";
        }
        break;
    case SIGSEGV:
        switch (info->si_code) {
        case SEGV_MAPERR:   return "address not mapped to object";
        case SEGV_ACCERR:   return "invalid perm. for mapped object";
        }
        break;
    case SIGBUS:
        switch (info->si_code) {
        case BUS_ADRALN:    return "invalid address alignment";
        case BUS_ADRERR:    return "non-existent physical address";
        case BUS_OBJERR:    return "object specific hardware error";
        }
        break;
    case SIGTRAP:
        switch (info->si_code) {
        case TRAP_BRKPT:    return "process breakpoint";
        case TRAP_TRACE:    return "process trace trap";
        }
        break;
    case SIGCHLD:
        switch (info->si_code) {
        case CLD_EXITED:    return "child has exited";
        case CLD_KILLED:    return "child was killed";
        case CLD_DUMPED:    return "child terminated abnormally";
        case CLD_TRAPPED:   return "traced child has trapped";
        case CLD_STOPPED:   return "child has stopped";
        case CLD_CONTINUED: return "stopped child has continued";
        }
        break;
    case SIGPOLL:
        switch (info->si_code) {
        case POLL_IN:       return "data input available";
        case POLL_OUT:      return "output buffers available";
        case POLL_MSG:      return "input message available";
        case POLL_ERR:      return "I/O error";
        case POLL_PRI:      return "high priority input available";
        case POLL_HUP:      return "device disconnected";
        }
        break;
    }
    if (info->si_code) {
        sprintf(buf, "SI%d", info->si_code);
        return buf;
    }
    return NULL;
}

static void ur_backtrace(void)
{
#if 0
#if HAVE_EXECINFO_H
	void   *array[20];
	int    size;
	char   **strings;
	size_t i;

	size    = backtrace(array, 20);
	strings = backtrace_symbols(array, size);
	fprintf(stderr, "Backtrace:\n");

	for (i = 0; i < size; i++)
		fprintf(stderr, "%s\n", strings[i]);
	free(strings);
#endif
#endif
}

void ur_add_trailer(void (*f)(void))
{
	_ur_extra_trailer = f;
}

static void ur_trailer(void)
{
	struct utsname u;

	uname(&u);
	ur_log_backtrace("Ur Version:        %s\n", ur_version());
	ur_log_backtrace("System name:       %s\n", u.sysname);
	ur_log_backtrace("System release:    %s\n", u.release);
	ur_log_backtrace("System version:    %s\n", u.version);
	ur_log_backtrace("Machine:           %s\n", u.machine);
#if HAVE_GNU_LIBC_VERSION_H
	ur_log_backtrace("Execution Library: glibc %s (%s)\n",
			 gnu_get_libc_version(), gnu_get_libc_release());
#endif
#if defined(__GLIBC__) && defined(__GLIBC_MINOR__)
	ur_log_backtrace("Build Library:     glibc %d.%d\n",
			 __GLIBC__, __GLIBC_MINOR__);
#endif
#if defined(__GNUC__) && defined(__GNUC_MINOR__) &&defined(__GNUC_PATCHLEVEL__)
	ur_log_backtrace("Build Compiler:    gcc %d.%d.%d\n",
			 __GNUC__, __GNUC_MINOR__, __GNUC_PATCHLEVEL__);
#endif
	if (_ur_extra_trailer) _ur_extra_trailer();
}

static void __attribute__((noreturn)) ur_handler(int sig,
						 siginfo_t *info,
						 void *context __unused)
{
	int             fault_valid = 0;
	static int      reentrant   = 0;
	const char      *name, *desc, *msg;
	unsigned long   fault       = 0;

	if (reentrant++) {
		ur_log_backtrace("%s called twice\n", __func__);
		ur_fatal_abort(__func__, "Terminating\n");
	}

	switch (sig) {
	case SIGILL:
	case SIGFPE:
	case SIGSEGV:
	case SIGBUS:
		if (info) {
			fault_valid = 1;
			fault       = (unsigned long)info->si_addr;
		}
		break;
	}

	name = ur_signal_name(sig);
	desc = ur_signal_description(info);
	msg  = info ? strerror(info->si_errno) : "";

	ur_log_backtrace("===== START OF SIGNAL REPORT =====\n");
	ur_log_backtrace("Program: %s\n", _ur_program_name);
	ur_log_backtrace("Pid: %d\n", getpid());
		
	if (info && info->si_errno) {
		ur_log_backtrace("Signal %d%s%s%s%s%s, errno = %d%s%s%s\n",
				 sig,
				 name ? " (" : "",
				 name ? name : "",
				 name ? ")" : "",
				 desc ? ": " : "",
				 desc ? desc : "",
				 info->si_errno,
				 msg ? " (" : "",
				 msg ? msg : "",
				 msg ? ")" : "");
	} else {
		ur_log_backtrace("Signal %d%s%s%s%s%s\n",
				 sig,
				 name ? " (" : "",
				 name ? name : "",
				 name ? ")" : "",
				 desc ? ": " : "",
				 desc ? desc : "");
	}

	if (fault_valid) {
		ur_log_backtrace("Fault: 0x%08lx\n", fault);
	}

	ur_backtrace();
	ur_log_backtrace("===== END OF SIGNAL REPORT =====\n");

	ur_fatal_abort(__func__, "Terminating\n");
}

void ur_signal(int sig, const char *program_name)
{
	int              def[] = { SIGHUP, SIGQUIT, SIGILL,
				   SIGBUS, SIGFPE, SIGSEGV, SIGTERM };
	size_t           i;
	struct sigaction a;

	if (!sig) {
		for (i = 0; i < sizeof(def)/sizeof(def[0]); i++)
			ur_signal(def[i], program_name);
		return;
	}

	memset(&a, 0, sizeof(a));
	a.sa_sigaction = ur_handler;
	a.sa_flags     = SA_SIGINFO;
	sigemptyset(&a.sa_mask);
	sigaddset(&a.sa_mask, sig);
	sigaction(sig, &a, 0);
}

void ur_init(const char *program_name)
{
	_ur_program_name = ur_atom_string(program_name);
	if (!_ur_trace_flags) _ur_trace_flags = ur_flag_create();
	if (!_ur_debug_flags) _ur_debug_flags = ur_flag_create();

	ur_signal(0, program_name);

#ifdef HAVE_ATEXIT
	atexit(ur_shutdown);
#else
#ifdef HAVE_ON_EXIT
	on_exit(ur_shutdown, NULL);
#endif
#endif

	ur_trace_register(UR_TRACE_CHILD_WAIT,  "ur-child-wait");
	ur_trace_register(UR_TRACE_PROC,        "ur-proc");
	ur_trace_register(UR_TRACE_MSG,         "ur-msg");
	ur_trace_register(UR_TRACE_ELF,         "ur-elf");
	ur_trace_register(UR_TRACE_PACK,        "ur-pack");
	ur_trace_register(UR_TRACE_ID3,         "ur-id3");
	ur_trace_register(UR_TRACE_PR,          "ur-pr");
	ur_trace_register(UR_TRACE_ID3_AUGMENT, "ur-id3-augment");
	ur_trace_register(UR_TRACE_PARSE,       "ur-parse");

	ur_debug_register(UR_DEBUG_ID3_ZERO,    "ur-id3-zero");
}

const char *ur_program_name(void)
{
	return _ur_program_name;
}

void ur_shutdown(void)
{
//	ur_proc_destroy();
	_ur_shutdown_called = true;
	if (_ur_trace_flags) {
		ur_flag_destroy(_ur_trace_flags);
		_ur_trace_flags = NULL;
	}
	if (_ur_debug_flags) {
		ur_flag_destroy(_ur_debug_flags);
		_ur_debug_flags = NULL;
	}
	ur_id3_shutdown();
	ur_atom_destroy();
}

const char *ur_version(void)
{
	char              *tmp;
	static const char *version = NULL;

	if (!version) {
		tmp = ur_alloc(128);
		sprintf(tmp, "ur %d.%d.%d (%s)",
			UR_MAJOR, UR_MINOR, UR_PATCH, UR_DATE);
		version = ur_atom_string(tmp);
		ur_free(tmp);
	}
	return version;
}

int ur_version_major(void)
{
	return UR_MAJOR;
}

int ur_version_minor(void)
{
	return UR_MINOR;
}

int ur_version_patch(void)
{
	return UR_PATCH;
}

const char *ur_version_date(void)
{
	return ur_atom_string(UR_DATE);
}

void ur_error(ur_error_t mask, int error,
	      const char *routine, const char *format, va_list ap)
{
	char       buf[2][256];
	int        count;
	const char *type = "unknown";

	if (mask & UR_ERROR_TRACE)    type = "trace";
	if (mask & UR_ERROR_WARN)     type = "warn";
	if (mask & UR_ERROR_INFO)     type = "info";
	if (mask & UR_ERROR_FATAL)    type = "fatal";
	if (mask & UR_ERROR_INTERNAL) type = "internal";

	memset(buf, 0, sizeof(buf));
    
#ifndef HAVE_VSNPRINTF
				/* No vsnprintf implies no security... */
	if (strlen(routine) + strlen(format)
	    < sizeof(buf[0]) - 100 && routine) {
		
		if (mask & UR_ERROR_ERRNO)
			sprintf(buf[0], "%s::%s (%s, errno = %d): %s",
				_ur_program_name ? _ur_program_name : "",
				routine ? routine : "",
				type, error, format);
		else 
			sprintf(buf[0], "%s::%s (%s): %s",
				_ur_program_name ? _ur_program_name : "",
				routine ? routine : "",
				type, format);
	}
#else
	snprintf(buf[0], sizeof(buf[0]), "%s::%s (%s): ",
		 _ur_program_name ? _ur_program_name : "",
		 routine ? routine : "",
		 type);
#endif
	count = strlen(buf[0]);
	vsnprintf(buf[0] + count, sizeof(buf[0] - count), format, ap);
	if (mask & UR_ERROR_ERRNO) {
#if HAVE_STRERROR
		snprintf(buf[1], sizeof(buf[1]), "    errno = %d: %s",
			 error, strerror(error));
#else
		snprintf(buf[1], sizeof(buf[1]), "     errno = %d", error);
#endif
	}
}

				/* error management */
static int _ur_print(const char *progname, const char *routine,
                     const char *format, va_list ap)
{
	int retval = 0;
    
	fflush(stdout);
	fflush(stderr);
	if (progname) {
		if (routine)
			retval += fprintf(stderr, "%s:%d:%s: ",
					  progname, getpid(), routine);
		else
			retval += fprintf(stderr, "%s:%d: ",
					  progname, getpid());
	} else {
		if (routine) retval += fprintf(stderr, "%d:%s: ",
					       getpid(), routine);
	}

	retval += vfprintf(stderr, format, ap);
	ur_log_error_v(routine, format, ap);
	fflush(stderr);
	return retval;
}

void ur_trace(unsigned long flag, const char *routine, const char *format, ...)
{
	va_list ap;
    
	if (!flag || ur_trace_test(flag)) {
		va_start(ap, format);
		_ur_print(NULL, routine, format, ap);
		va_end(ap);
	}
}

void ur_warning(const char *routine, const char *format, ...)
{
	va_list ap;
    
	va_start(ap, format);
	_ur_print(_ur_program_name, routine, format, ap);
	va_end(ap);
}

void ur_fatal(const char *routine, const char *format, ...)
{
	va_list ap;
    
	va_start(ap, format);
	_ur_print(_ur_program_name, routine, format, ap);
	va_end(ap);
#ifdef BT_PRODUCTION
	bt_backtrace(_ur_program_name);
#endif    
	ur_trailer();
	exit(EXIT_FAILURE);
}

void ur_fatal_abort(const char *routine, const char *format, ...)
{
	va_list ap;
    
	va_start(ap, format);
	_ur_print(_ur_program_name, routine, format, ap);
	va_end(ap);
                                /* Do not call bt_* here. */
	ur_trailer();
	abort();
}

void ur_fatal_errno(const char *routine, const char *format, ...)
{
	va_list ap;
	int     save = errno;
    
	va_start(ap, format);
	_ur_print(_ur_program_name, routine, format, ap);
	va_end(ap);
    
#if HAVE_STRERROR
	errno = save;
	fprintf(stderr, "%s: %s\n", routine ? routine : "", strerror(save));
	errno = save;
	ur_log_error(routine, "%s: %s\n", routine ? routine : "",
		     strerror(save));
#else
	fprintf(stderr, "%s: errno = %d\n", routine ? routine : "", save);
	ur_log_error(routine, "%s: errno = %d\n", routine ? routine : "",
		     save);
#endif
   
#ifdef BT_PRODUCTION
	bt_backtrace(_ur_program_name);
#endif    
	ur_trailer();
	exit(EXIT_FAILURE);
}

void ur_internal(const char *routine, const char *format, ... )
{
	va_list ap;
    
	va_start(ap, format);
	_ur_print(_ur_program_name, routine, format, ap);
	va_end(ap);

	if (_ur_program_name)
		fprintf(stderr, "%s: aborting...\n", _ur_program_name);
	else
		fprintf(stderr, "aborting...\n");
	fflush(stderr);
#ifdef BT_PRODUCTION
	bt_backtrace(_ur_program_name);
#endif    
	abort();
}

int ur_log_backtrace(const char *format, ...)
{
	int     retval = 0;
	va_list ap;
    
	va_start(ap, format);
	retval += _ur_print(NULL, NULL, format, ap);
	va_end(ap);
	return retval;
}

void ur_error_callback(int (*f)(int severity, const char *message) __unused)
{
}

void ur_log_file(const char *filename __unused)
{
}

void ur_log_syslog(void)
{
}

void ur_log_close(void)
{
}

void ur_log_error(const char *routine __unused, const char *format __unused,
		  ...)
{
}

void ur_log_error_v(const char *routine __unused, const char *format __unused,
		    va_list ap __unused)
{
}

void ur_log_info(const char *routine __unused, const char *format __unused,
		 ...)
{
}

void ur_log_info_v(const char *routine __unused, const char *format __unused,
		   va_list ap __unused)
{
}


void ur_trace_register(unsigned long flag, const char *name)
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_register(_ur_trace_flags, flag, name);
}
    
void ur_trace_set(unsigned long flag)
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_set(_ur_trace_flags, flag);
}

void ur_trace_unset(unsigned long flag)
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_unset(_ur_trace_flags, flag);
}

				/* FIXME: move to a header for inlining */
int ur_trace_test(unsigned long flag)
{
	if (_ur_shutdown_called) {
		/* Cannot trace after shutdown */
		return false;
	}
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_test(_ur_trace_flags, flag);
}

void ur_trace_set_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_set_by_name(_ur_trace_flags, name, f);
}

void ur_trace_unset_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_unset_by_name(_ur_trace_flags, name, f);
}

int ur_trace_test_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_test_by_name(_ur_trace_flags, name, f);
}

ur_list_t ur_trace_names(void)
{
	if (!_ur_trace_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_names(_ur_trace_flags);
}
void ur_debug_register(unsigned long flag, const char *name)
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_register(_ur_debug_flags, flag, name);
}
    
void ur_debug_set(unsigned long flag)
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_set(_ur_debug_flags, flag);
}

void ur_debug_unset(unsigned long flag)
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_unset(_ur_debug_flags, flag);
}

				/* FIXME: move to a header for inlining */
int ur_debug_test(unsigned long flag)
{
	if (_ur_shutdown_called) {
		/* Cannot trace after shutdown */
		return false;
	}
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_test(_ur_debug_flags, flag);
}

void ur_debug_set_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_set_by_name(_ur_debug_flags, name, f);
}

void ur_debug_unset_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	ur_flag_unset_by_name(_ur_debug_flags, name, f);
}

int ur_debug_test_by_name(const char *name, int (*f)(const char *))
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_test_by_name(_ur_debug_flags, name, f);
}

ur_list_t ur_debug_names(void)
{
	if (!_ur_debug_flags) ur_fatal(__func__, "ur_init not called\n");
	return ur_flag_names(_ur_debug_flags);
}
