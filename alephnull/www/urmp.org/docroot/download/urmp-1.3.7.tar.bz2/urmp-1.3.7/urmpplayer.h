/* urmpplayer.h -- 
 * Created: Mon Dec 29 08:05:01 2008 by faith@acm.org
 * Revised: Tue Dec 30 07:31:20 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPPLAYER_H_
#define _URMPPLAYER_H_

typedef struct {
	uint64_t generation;
	bool     playing;
	bool     paused;
	double   volume;
	double   time_pos;
	int      percent_pos;
} urmp_player_status_t;

extern uint64_t urmp_player_loadfile(const char *filename);
extern uint64_t urmp_player_set_volume(int volume);
extern uint64_t urmp_player_set_position(int position);
extern uint64_t urmp_player_get_status(urmp_player_status_t *status);
extern uint64_t urmp_player_stop(void);
extern uint64_t urmp_player_pause(void);

#endif
