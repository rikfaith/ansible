/* urmpgui.c -- 
 * Created: Sat Sep 27 17:08:37 2008 by faith@acm.org
 * Revised: Sat May 23 06:57:18 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#define _GNU_SOURCE
#include "urmpgui.h"
#include "urmpguiconfig.h"
#include "urmpmodel.h"
#include "urmpconfig.h"
#include "urmpplaylist.h"
#include "urmphook.h"
#include "version.h"
#include <string.h>
#include <gdk/gdkkeysyms.h>

typedef enum {
	URMP_E_LASTFM_USERNAME,
	URMP_E_LASTFM_PASSWORD,
	URMP_E_LASTFM_NOWPLAYING,
	URMP_E_LASTFM_SCROBBLING,
	URMP_E_LASTFM_STORE_PASSWORD,
	URMP_E_LYRICS_LYRICWIKI,
	URMP_E_LYRICS_LYRICSFLY,
	URMP_E_LYRICS_FILES,
	URMP_E_LYRICS_SQL,
	URMP_E_ARCHIVE_ROOT,
} urmp_gui_config_t;

static void urmp_gui_config_toggle(GtkToggleButton *button,
				   gpointer user_data)
{
	urmp_gui_config_t entry = (urmp_gui_config_t)user_data;
	bool              value;

	value = gtk_toggle_button_get_active(button);
	switch (entry) {
	case URMP_E_LASTFM_NOWPLAYING:
		urmp_config_set_lastfm_nowplaying(value);
		break;
	case URMP_E_LASTFM_SCROBBLING:
		urmp_config_set_lastfm_scrobbling(value);
		break;
	case URMP_E_LASTFM_STORE_PASSWORD:
		urmp_config_set_lastfm_store_password(value);
		break;
	case URMP_E_LYRICS_LYRICWIKI:
		urmp_config_set_lyrics_lyricwiki(value);
		break;
	case URMP_E_LYRICS_LYRICSFLY:
		urmp_config_set_lyrics_lyricsfly(value);
		break;
	default:
		ur_fatal(__func__, "Have entry type %d\n", entry);
	}
}

static void urmp_gui_config_entry(GtkEditable *editable, gpointer user_data)
{
	urmp_gui_config_t entry = (urmp_gui_config_t)user_data;
	const char        *value;


	value = gtk_entry_get_text(GTK_ENTRY(editable));
	switch (entry) {
	case URMP_E_LASTFM_USERNAME:
		urmp_config_set_lastfm_username(value);
		break;
	case URMP_E_LASTFM_PASSWORD:
		urmp_config_set_lastfm_password(value);
		break;
	case URMP_E_LYRICS_FILES:
		urmp_config_set_lyrics_tree(value);
		break;
	case URMP_E_LYRICS_SQL:
		urmp_config_set_lyrics_sql(value);
		break;
	default:
		ur_fatal(__func__, "Have entry type %d\n", entry);
	}
}

static void urmp_gui_config_add_pair(GtkWidget *box, GtkWidget *widget,
				     const char *text)
{
	GtkWidget     *label;
	GtkWidget     *hbox;

	hbox = gtk_hbox_new(FALSE, 2);

	label = gtk_label_new(text ? text : " ");
	gtk_label_set_width_chars(GTK_LABEL(label), 20);
	gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
	gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
	gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(hbox), widget, TRUE, TRUE, 0);
	gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 0);
}

static GtkWidget *urmp_gui_config_add_toggle(GtkWidget *vbox,
					     const char *text,
					     bool initial,
					     urmp_gui_config_t type)
{
	GtkWidget *toggle;

	toggle = gtk_check_button_new_with_label(text);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggle), initial);
	g_signal_connect(G_OBJECT(toggle), "toggled",
			 G_CALLBACK(urmp_gui_config_toggle),
			 (gpointer)(uintptr_t)type);
	urmp_gui_config_add_pair(vbox, toggle, NULL);
	return toggle;
}

static GtkWidget *urmp_gui_config_add_entry(GtkWidget *vbox,
					    const char *text,
					    const char *initial,
					    urmp_gui_config_t type)
{
	GtkWidget *entry;

	entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry), initial);
	g_signal_connect(G_OBJECT(entry), "changed",
			 G_CALLBACK(urmp_gui_config_entry),
			 (gpointer)(uintptr_t)type);
	urmp_gui_config_add_pair(vbox, entry, text);
	return entry;
}

static void urmp_gui_config_build_database(urmp_gui_status_t *status)
{
	GtkWidget     *label;
	GtkWidget     *vbox;

	label = gtk_label_new("database");
	vbox  = gtk_vbox_new(FALSE, 4);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	urmp_gui_config_add_entry(vbox, "Root of music archive",
				  "*NOT IMPLEMENTED*",
				  URMP_E_ARCHIVE_ROOT);
}

static void urmp_gui_config_build_lastfm(urmp_gui_status_t *status)
{
	GtkWidget     *label;
	GtkWidget     *vbox;

	label = gtk_label_new("last.fm");
	vbox  = gtk_vbox_new(FALSE, 4);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	urmp_gui_config_add_toggle(
		vbox, 
		"Do last.fm now-playing notification?",
		urmp_config_get_lastfm_nowplaying(),
		URMP_E_LASTFM_NOWPLAYING);

	urmp_gui_config_add_toggle(
		vbox, 
		"Do last.fm audio scrobbling?",
		urmp_config_get_lastfm_scrobbling(),
		URMP_E_LASTFM_SCROBBLING);

	urmp_gui_config_add_toggle(
		vbox, 
		"Save last.fm password (stored as cleartext)?",
		urmp_config_get_lastfm_scrobbling(),
		URMP_E_LASTFM_STORE_PASSWORD);

	urmp_gui_config_add_entry(vbox, "Username",
				  urmp_config_get_lastfm_username(),
				  URMP_E_LASTFM_USERNAME);

	urmp_gui_config_add_entry(vbox, "Password",
				  urmp_config_get_lastfm_password(),
				  URMP_E_LASTFM_PASSWORD);
}

static void urmp_gui_config_build_lyrics(urmp_gui_status_t *status)
{
	GtkWidget     *label;
	GtkWidget     *vbox;

	label = gtk_label_new("lyrics");
	vbox  = gtk_vbox_new(FALSE, 4);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	urmp_gui_config_add_entry(vbox, "Path to lyrics file tree",
				  "*NOT IMPLEMENTED*",
				  URMP_E_LYRICS_FILES);

	urmp_gui_config_add_entry(vbox, "Path to lyrics SQL dump",
				  "*NOT IMPLEMENTD*",
				  URMP_E_LYRICS_SQL);

	urmp_gui_config_add_toggle(vbox,
				   "Get lyrics from lyricwiki.org?",
				   FALSE,
				   URMP_E_LYRICS_LYRICWIKI);

	urmp_gui_config_add_toggle(vbox,
				   "Get lyrics from lyricsfly.com?",
				   FALSE,
				   URMP_E_LYRICS_LYRICSFLY);
}

void urmp_gui_config_build(urmp_gui_status_t *status, GtkWidget *notebook)
{
	GtkWidget     *label;

	label    = gtk_label_new("Config");
	status->config = gtk_notebook_new();
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook),
				 status->config, label);

	urmp_gui_config_build_database(status);
	urmp_gui_config_build_lastfm(status);
	urmp_gui_config_build_lyrics(status);
}
