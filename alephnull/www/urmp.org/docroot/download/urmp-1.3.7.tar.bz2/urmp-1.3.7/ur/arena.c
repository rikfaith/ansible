/* arena.c -- 
 * Created: Mon Jul  5 13:29:22 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003, 2004, 2008 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: arena.c,v 1.13 2004-02-09 02:36:27 faith Exp $
 *
 * Based on the arena implementation in:
 *     Hanson, David R. C Interfaces and Implementations: Techniques for
 *     Creating Reusable Software.  Reading, Massachusetts: Addison-Wesley,
 *     1997.  Chapter 6, pp. 89-102.
 */

#include "urP.h"

typedef struct ur_arena_chunk_s {
    int                     magic;
    size_t                  size;
    struct ur_arena_chunk_s *prev;
    char                    *avail;
    char                    *limit;
} *ur_arena_chunk_t;

struct ur_arena_s {
    unsigned long         magic;
    size_t                alignment;
    ur_arena_chunk_t      head;
    size_t                allocated;
    size_t                used;
    size_t                wasted;
};

typedef union ur_arena_align_u {
    int         i,  *ip;
    long        l,  *lp;
    void        *v, **vp;
    float       f,  *fp;
    double      d,  *dp;
    long double D,  *Dp;
    void        (*funct)(void);
} ur_arena_align_t;

typedef union ur_arena_header_u {
    struct ur_arena_s arena;
    ur_arena_align_t   alignment;
} *ur_arena_header_t;

CHECK_FUNCTION(_ur_arena_check, ur_arena_t, UR_ARENA_MAGIC)

ur_arena_t ur_arena_create(size_t alignment)
{
    ur_arena_t arena = ur_alloc(sizeof(*arena));

    arena->magic     = UR_ARENA_MAGIC;
    arena->head      = NULL;
    arena->allocated = 0;
    arena->used      = 0;
    arena->wasted    = 0;
    arena->alignment = alignment ? alignment : sizeof(ur_arena_align_t);

    return arena;
}

void ur_arena_clear(ur_arena_t arena)
{
    ur_arena_chunk_t chunk;
    ur_arena_chunk_t prev;

    for (chunk = arena->head; chunk; chunk = prev) {
	prev = chunk->prev;
	ur_free(chunk);
    }

    arena->head      = NULL;
    arena->allocated = 0;
    arena->used      = 0;
    arena->wasted    = 0;
}

unsigned long ur_arena_destroy(ur_arena_t arena)
{
    unsigned long ret;
    
    _ur_arena_check(arena);
    ur_arena_clear(arena);
    ret = arena->magic = ~UR_ARENA_MAGIC;
    ur_free(arena);
    return ret;
}

static void _ur_arena_get_chunk(ur_arena_t arena, size_t needed)
{
    ur_arena_chunk_t chunk;
    size_t         size;

    size              = sizeof(ur_arena_header_t) + needed + UR_ARENA_CHUNK;
    chunk             = ur_alloc(size);

    if (arena->head) {
	arena->wasted = arena->head->limit - arena->head->avail;
    }

    chunk->magic      = UR_ARENA_MAGIC;
    chunk->size       = size;
    chunk->prev       = arena->head;
    chunk->avail      = (char *)(chunk + 1);
    chunk->limit      = (char *)chunk + size;

    arena->head       = chunk;
    arena->allocated += size;
}

void *ur_arena_alloc(ur_arena_t arena, size_t size)
{
    ur_arena_chunk_t chunk = arena->head;
    size_t         s;
    
    _ur_arena_check(arena);
    if (size <= 0) ur_fatal(__FUNCTION__, "Size = %lu\n", (unsigned long)size);

    s = ((size + arena->alignment - 1) / arena->alignment) * arena->alignment;

    if (!chunk || s > (size_t)(chunk->limit - chunk->avail))
	_ur_arena_get_chunk(arena, s); /* Get new chunk */

    arena->used        += s;
    if (!arena->head) ur_internal(__FUNCTION__, "NULL Head\n");
    arena->head->avail += s;
    
    return arena->head->avail - s;
}

void *ur_arena_alloc_z(ur_arena_t arena, size_t size)
{
    void *pt = ur_arena_alloc(arena, size);

    memset(pt, 0, size);
    return pt;
}

const char *ur_arena_string_n(ur_arena_t arena, const char *datum, int len)
{
	char *s;

	_ur_arena_check(arena);
	s = ur_arena_alloc(arena, len+1);
	strncpy(s, datum, len);
	s[len] = '\0';
	return s;
}

const char *ur_arena_string(ur_arena_t arena, const char *datum)
{
	return ur_arena_string_n(arena, datum, strlen(datum));
}
