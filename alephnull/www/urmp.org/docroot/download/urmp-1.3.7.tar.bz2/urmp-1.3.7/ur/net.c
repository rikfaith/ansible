/* net.c -- 
 * Created: Sat Aug 02 12:59:48 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: net.c,v 1.2 2003-09-06 03:03:52 faith Exp $
 * 
 */

#include "urP.h"
#include <netdb.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <netinet/in.h>

typedef struct ur_net_info_s {
    int             port;
    ur_net_callback_t cb;
    void            *closure;
} *ur_net_info_t;

struct ur_net_s {
    unsigned long   magic;

    int             fdsUsed;
    int             fdsTotal;
    int             fdsDeleted;
    int             lastDeleted;
    struct pollfd   *ufds;
    ur_net_info_t     info;
    int             slot;
};

CHECK_FUNCTION(_ur_net_check, ur_net_t, UR_NET_MAGIC)

ur_net_t ur_net_create(void)
{
    ur_net_t net = ur_allocz(sizeof(*net));

    net->magic = UR_NET_MAGIC;
    return net;
}

int ur_net_open_tcp(int port)
{
    struct protoent    *protocolEntry;
    struct sockaddr_in ssin;
    int                s;
    const int          one = 1;
    
    memset(&ssin, 0, sizeof(ssin));
    ssin.sin_family      = AF_INET;
    ssin.sin_addr.s_addr = INADDR_ANY;
    ssin.sin_port        = htons(port);
    
    if (!(protocolEntry = getprotobyname("tcp")))
        ur_fatal(__func__, "Cannot get \"tcp\" protocol entry\n");
    
    if ((s = socket(PF_INET, SOCK_STREAM, protocolEntry->p_proto)) < 0)
        ur_fatal_errno(__func__, "Cannot open socket on port %d\n",
                      ntohs(ssin.sin_port));
    
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    
    if (bind(s, (struct sockaddr *)&ssin, sizeof(ssin)) < 0)
        ur_fatal_errno(__func__, "Cannot bind port %d\n", ntohs(ssin.sin_port));
    
    if (listen(s, 10) < 0)
        ur_fatal_errno(__func__, "Cannot listen to port %d\n",
                      ntohs(ssin.sin_port));
    
    return s;
}

unsigned long ur_net_destroy(ur_net_t net)
{
    unsigned long ret;
    
    _ur_net_check(net);
    ret = net->magic = ~UR_NET_MAGIC;
    if (net->ufds) ur_free(net->ufds);
    if (net->info) ur_free(net->info);
    ur_free(net);
    return ret;
}

static int ur_net_get_slot(ur_net_t net)
{
    int oldtotal = net->fdsTotal;

                                /* Reuse? */
    if (net->info && net->fdsDeleted) {
        int i;
        
        for (i = net->lastDeleted; i < net->fdsTotal; i++) {
            if (net->ufds[i].fd < 0) {
                net->lastDeleted = i;
                --net->fdsDeleted;
                return i;
            }
        }
        for (i = 0; i < net->lastDeleted; i++) {
            if (net->ufds[i].fd < 0) {
                net->lastDeleted = i;
                --net->fdsDeleted;
                return i;
            }
        }
        if (net->fdsDeleted < 0)
            ur_fatal(__func__, "deleted = %d\n", net->fdsDeleted);
    }

                                /* Get a new one */
    if (net->fdsUsed + 1 >= net->fdsTotal) {
        net->fdsTotal *= 2;
        if (!net->fdsTotal) net->fdsTotal = 128;
        net->ufds = ur_reallocz(net->ufds,
                                oldtotal * sizeof(*net->ufds),
                                net->fdsTotal * sizeof(*net->ufds));
        net->info = ur_reallocz(net->info,
                                oldtotal * sizeof(*net->info),
                                net->fdsTotal * sizeof(*net->info));
    }
    return net->fdsUsed++;
}

void ur_net_add_port(ur_net_t net, int port, ur_net_callback_t cb, void *closure)
{
    int slot;
    
    _ur_net_check(net);
    slot                    = ur_net_get_slot(net);
    net->info[slot].port    = port;
    net->info[slot].cb      = cb;
    net->info[slot].closure = closure;

    net->ufds[slot].fd      = ur_net_open_tcp(port);
    net->ufds[slot].events  = POLLIN|POLLPRI;
    net->ufds[slot].revents = 0;
}

void ur_net_del_port(ur_net_t net, int port)
{
    int i;

    _ur_net_check(net);
    for (i = 0; i < net->fdsUsed; i++)
        if (net->info[i].port == port) {
            close(net->ufds[i].fd);
            net->slot = i;
            ur_net_del_fd(net, net->ufds[i].fd);
        }
}

void ur_net_add_fd(ur_net_t net, int fd, ur_net_callback_t cb, void *closure)
{
    int slot;
    
    _ur_net_check(net);
    slot                    = ur_net_get_slot(net);
    net->info[slot].cb      = cb;
    net->info[slot].closure = closure;

    net->ufds[slot].fd      = fd;
    net->ufds[slot].events  = POLLIN|POLLPRI;
    net->ufds[slot].revents = 0;
}

static int ur_net_find_slot(ur_net_t net, int fd)
{
    int i;
    
    if (net->slot < net->fdsUsed && net->ufds[net->slot].fd == fd)
        return net->slot;
    
    for (i = 0; i < net->fdsUsed; i++) if (net->ufds[i].fd == fd) return i;

    return -1;
}

void ur_net_del_fd(ur_net_t net, int fd)
{
    int slot;

    _ur_net_check(net);
    if ((slot = ur_net_find_slot(net, fd)) >= 0) {
        if (net->info[slot].port) close(net->ufds[slot].fd);
        net->ufds[slot].fd = -1;
        ++net->fdsDeleted;
        net->lastDeleted = slot;
    }
}

static void ur_net_set(ur_net_t net, int fd, short events)
{
    int slot = ur_net_find_slot(net, fd);
    if (slot >= 0) net->ufds[slot].events = events;
}

void ur_net_set_read(ur_net_t net, int fd)
{
    _ur_net_check(net);
    ur_net_set(net, fd, POLLIN|POLLPRI);
}

void ur_net_set_write(ur_net_t net, int fd)
{
    _ur_net_check(net);
    ur_net_set(net, fd, POLLOUT);
}

void ur_net_set_read_write(ur_net_t net, int fd)
{
    _ur_net_check(net);
    ur_net_set(net, fd, POLLIN|POLLPRI|POLLOUT);
}

void ur_net_server(ur_net_t net)
{
    int i;
    int ret;
    
    _ur_net_check(net);

    for (;;) {
        ret = poll(net->ufds, net->fdsUsed, -1);
        if (ret < 0 && errno != EINTR)
            ur_fatal_errno(__func__, "poll failed\n");
        for (i = 0; i < net->fdsUsed && ret; i++) {
            if (net->ufds[i].revents) {
                --ret;
                if (net->info[i].cb) {
                    int events = 0;
                    net->slot  = i; /* cache current slot */
                    if (net->ufds[i].events & POLLIN)   events |= UR_NET_IN;
                    if (net->ufds[i].events & POLLPRI)  events |= UR_NET_IN;
                    if (net->ufds[i].events & POLLOUT)  events |= UR_NET_OUT;
                    if (net->ufds[i].events & POLLERR)  events |= UR_NET_ERR;
                    if (net->ufds[i].events & POLLHUP)  events |= UR_NET_HUP;
                    if (net->ufds[i].events & POLLNVAL) events |= UR_NET_NVAL;
                    
                    if (net->info[i].cb(net->ufds[i].fd, events,
                                        net->info[i].closure)) return;
                }
                net->ufds[i].revents = 0;
            }
        }
    }
}
