/* alloc.c -- 
 * Created: Mon Oct 13 16:56:23 2008 by faith@acm.org
 * Revised: Sun May  3 12:56:01 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "standard.h"
#include "ur.h"
#include "common.h"

#define PAIRS 8192
#define ITER  1000

static void *mem[PAIRS];

static unsigned long long time_malloc(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;

	gettimeofday(&start, NULL);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = malloc(size);
		}
		for (j = 0; j < PAIRS; j++) {
			free(mem[j]);
		}
	}
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_ur_alloc(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;

	gettimeofday(&start, NULL);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_alloc(size);
		}
		for (j = 0; j < PAIRS; j++) {
			ur_free(mem[j]);
		}
	}
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_block(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;
	ur_block_t block;

	gettimeofday(&start, NULL);
	block = ur_block_create(size);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_block_alloc(block);
		}
		for (j = 0; j < PAIRS; j++) {
			ur_block_free(block, mem[j]);
		}
	}
	ur_block_destroy(block);
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}

static unsigned long long time_arena(int size)
{
	int i, j;
	struct timeval start, stop;
	unsigned long long start_ms, stop_ms;
	ur_arena_t arena;

	gettimeofday(&start, NULL);
	arena = ur_arena_create(0);
	for (i = 0; i < ITER; i++) {
		for (j = 0; j < PAIRS; j++) {
			mem[j] = ur_arena_alloc(arena, size);
		}
		ur_arena_clear(arena);
	}
	ur_arena_destroy(arena);
	gettimeofday(&stop, NULL);
	start_ms = start.tv_sec * 1000 + start.tv_usec / 1000;
	stop_ms  = stop.tv_sec  * 1000 + stop.tv_usec / 1000;
	return (PAIRS*ITER*1000ULL)/(stop_ms - start_ms);
}


int main(int argc, char **argv)
{
	unsigned long long m0, m1, m2;
	bool               verbose = false;
	char               buf[256];

	ur_init(argv[0]);

	if (argc != 1) verbose=true;

	if (!verbose) test("L", "ur_block");
	m0 = time_block(32);
	if (verbose) printf("block(32)      = %10llu iter/sec\n", m0);
	m1 = time_block(256);
	if (verbose) printf("block(256)     = %10llu iter/sec\n", m1);
	m2 = time_block(1024);
	if (verbose) printf("block(1024)    = %10llu iter/sec\n", m2);

	if (!verbose) {
		if (m0 > m1 && m1 > m2) ok(0);
		else {
			sprintf(buf, "%llu %llu %llu", m0, m1, m2);
			fail(buf);
		}
	}

	if (!verbose) test("L", "ur_arena");
	m0 = time_arena(32);
	if (verbose) printf("arena(32)      = %10llu iter/sec\n", m0);
	m1 = time_arena(256);
	if (verbose) printf("arena(256)     = %10llu iter/sec\n", m1);
	m2 = time_arena(1024);
	if (verbose) printf("arena(1024)    = %10llu iter/sec\n", m2);

	if (!verbose) {
		if (m0 > m1 && m1 > m2) ok(0);
		else {
			sprintf(buf, "%llu %llu %llu", m0, m1, m2);
			fail(buf);
		}
	}

	if (!verbose) test("L", "ur_alloc");
	m0 = time_ur_alloc(32);
	if (verbose) printf("ur_alloc(32)   = %10llu iter/sec\n", m0);
	m1 = time_ur_alloc(256);
	if (verbose) printf("ur_alloc(256)  = %10llu iter/sec\n", m1);
	m2 = time_ur_alloc(1024);
	if (verbose) printf("ur_alloc(1024) = %10llu iter/sec\n", m2);

	if (!verbose) {
		if (m0 > m1 && m1 > m2) ok(0);
		else {
			sprintf(buf, "%llu %llu %llu", m0, m1, m2);
			fail(buf);
		}
	}

	if (!verbose) test("L", "malloc");
	m0 = time_malloc(32);
	if (verbose) printf("malloc(32)     = %10llu iter/sec\n", m0);
	m1 = time_malloc(256);
	if (verbose) printf("malloc(256)    = %10llu iter/sec\n", m1);
	m2 = time_malloc(1024);
	if (verbose) printf("malloc(1024)   = %10llu iter/sec\n", m2);
	
	if (!verbose) {
		if (m0 > m1 && m1 > m2) ok(0);
		else {
			sprintf(buf, "%llu %llu %llu", m0, m1, m2);
			fail(buf);
		}
	}

	return 0;
}
