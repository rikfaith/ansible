/* stack.c -- Simple singly-linked stack
 * Created: Mon Jul  5 13:20:30 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: stack.c,v 1.13 2000-08-20 13:16:19 faith Exp $
 *
 * Arenas would improve speed a lot, I believe. -T
 * I agree. -R
 * Without block allocator: 3.235956 S for 421 * 10000 ops
 * With block allocator:    0.911240 S for 421 * 10000 ops
 *
 */

#include "urP.h"

typedef struct ur_stack_element_s {
    const void              *datum;
    struct ur_stack_element_s *next;
} *ur_stack_element_t;

struct ur_stack_s {
    unsigned long    magic;
    ur_stack_element_t head;
    ur_block_t        block;
};

CHECK_FUNCTION(_ur_stack_check, ur_stack_t, UR_STACK_MAGIC)

/*
 * Create an empty stack.
 *
 * Returns: the newly allocated stack object.
 */
ur_stack_t ur_stack_create(void)
{
    ur_stack_t stack = ur_alloc(sizeof(*stack));

    stack->magic = UR_STACK_MAGIC;
    stack->head  = NULL;
    stack->block = NULL;
    if (UR_USE_BLOCK)
	stack->block = ur_block_create(sizeof(struct ur_stack_element_s));
    return stack;
}

/*
 * Free all the allocated memory associated with a stack.
 *
 * Params: stack - the stack to destroy.
 */
unsigned long ur_stack_destroy(ur_stack_t stack)
{
    ur_stack_element_t e;
    ur_stack_element_t next;
    unsigned long    ret;

    _ur_stack_check(stack);
    ret = stack->magic = ~UR_STACK_MAGIC;
    
    if (UR_USE_BLOCK) ur_block_destroy(stack->block);
    else {
	for (e = stack->head; e; e = next) {
	    next = e->next;
	    ur_free(e);
	}
    }
    ur_free(stack);
    return ret;
}

/*
 * Push an item onto the stack.
 *
 * Note: we don't do any real verification of the integrity of
 *       the stack here, remember that.
 *
 * Params: stack - the stack to operate on.
 *         datum - the datum to push onto stack.
 */
void ur_stack_push(ur_stack_t stack, const void *datum)
{
    ur_stack_element_t e;
    
    _ur_stack_check(stack);

    e           = (UR_USE_BLOCK
		   ? ur_block_alloc(stack->block)
		   : ur_alloc(sizeof(*e)));
    e->datum    = datum;
    e->next     = stack->head;
    stack->head = e;
}

/*
 * Pop an item off the stack.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item formerly on the top of the stack.
 *
 */
void *ur_stack_pop(ur_stack_t stack)
{
    ur_stack_element_t e;
    const void       *datum = NULL;
    
    _ur_stack_check(stack);
    e = stack->head;
    if (e) {
	stack->head = e->next;
	datum       = e->datum;
	if (UR_USE_BLOCK) ur_block_free(stack->block, e); else ur_free(e);
    }
    return (void *)datum;	/* Discard const */
}

/*
 * Return the value on the top of the stack (without affecting the
 * stack). Top == most recently pushed.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item at depth 0.
 */
const void *ur_stack_top(ur_stack_t stack)
{
    _ur_stack_check(stack);
    return stack->head ? stack->head->datum : NULL;
}

/*
 * Picks an item from a stack (without affecting the stack).
 *
 * Params: stack - the stack to pick from.
 *         n     - the depth of the item to pick, 0 being the top of the
 *                 stack (most recently pushed).
 *
 * Returns: the item picked.
 */
void *ur_stack_pick(ur_stack_t stack, unsigned int n)
{
    ur_stack_element_t e;
    unsigned int     i;
    
    _ur_stack_check(stack);

    for (e = stack->head, i = 0; e && i < n; e = e->next, i++);
    return e ? (void *)e->datum : NULL;	/* Discard const */
}


/*
 * Get the depth of a stack. Note that this means the number of
 * items - calling this on a stack with one item will return 1,
 * but that item is at depth 0.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the number of items on the stack.
 */
unsigned int ur_stack_depth(ur_stack_t stack)
{
    ur_stack_element_t e;
    unsigned int     i;

    _ur_stack_check(stack);

    for (e = stack->head, i = 0; e; e = e->next) ++i;
    return i;
}


/*
 * Swap the top two items on the stack.
 *
 * Params: stack - the stack to operate on.
 */
void ur_stack_swap(ur_stack_t stack)
{
    const void *datum0;
    const void *datum1;

    _ur_stack_check(stack);

    datum0 = ur_stack_pop(stack);
    datum1 = ur_stack_pop(stack);

    if (datum0) ur_stack_push(stack, datum0);
    if (datum1) ur_stack_push(stack, datum1);
}

/*
 * Duplicate the item on the top of the stack.
 *
 * Params: stack - the stack to operate on.
 */
void ur_stack_dup(ur_stack_t stack)
{
    const void *datum;
    
    _ur_stack_check(stack);
    if ((datum = ur_stack_top(stack))) ur_stack_push(stack, datum);
}

void ur_stack_iterator_init(ur_stack_t stack, ur_iterator_t *iter)
{
    _ur_stack_check(stack);
    iter->a = stack;
    iter->b = stack->head;
}

int ur_stack_iterator_next(ur_iterator_t *iter)
{
    ur_stack_t stack = iter->a;

    _ur_stack_check(stack);
    if (!iter->b) return 0;
    iter->b = ((ur_stack_element_t)iter->b)->next;
    return iter->b != NULL;
}

void *ur_stack_iterator_datum(ur_iterator_t *iter)
{
    ur_stack_t stack = iter->a;

    _ur_stack_check(stack);
    if (!iter->b) return NULL;
    return (void *)((ur_stack_element_t)iter->b)->datum; /* Discard const */
}
