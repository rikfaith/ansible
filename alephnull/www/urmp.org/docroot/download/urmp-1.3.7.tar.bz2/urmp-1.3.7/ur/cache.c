/* cache.c -- 
 * Created: Sat May 23 07:12:22 2009 by faith@acm.org
 * Revised: Wed Jul  1 06:10:39 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * 
 */

#include "urP.h"
#include <alloca.h>
#include <sys/stat.h>
#include <fcntl.h>

struct ur_cache_s {
	unsigned long      magic;
	const char         *root;
	ur_cache_convert_t convert;
};

CHECK_FUNCTION(_ur_cache_check, ur_cache_t, UR_CACHE_MAGIC)

static const char *_ur_cache_convert(const char *filename)
{
	char       *tmp;
	char       *d;
	int        len;
	const char *s;

	if (!filename) return NULL;

	len = strlen(filename);
	tmp = alloca(len + 1);

	for (d = tmp, s = filename; *s; s++) {
		unsigned char ch = (unsigned char)*s;

		if (ch == ' ' && (d == tmp || d[-1] != '_')) {
			*d++ = '_';
			continue;
		}
		if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) {
			*d++ = ch;
			continue;
		}
		if (ch >= 'A' && ch <= 'Z') {
			*d++ = ch + 32;
			continue;
		}
	}
	*d = '\0';
	return ur_atom_string(tmp);
}

ur_cache_t ur_cache_create(const char *root, ur_cache_convert_t convert)
{
	ur_cache_t  cache = ur_allocz(sizeof(*cache));
	struct stat sb;
	int         retval;

	retval = stat(root, &sb);
	if (!retval) {
		if (!S_ISDIR(sb.st_mode)) return NULL;
		if (access(root, R_OK|W_OK|X_OK)) return NULL;
	} else {
		retval = mkdir(root, 0775);
	}

	cache->magic   = UR_CACHE_MAGIC;
	cache->root    = root;
	cache->convert = convert ? convert : _ur_cache_convert;
	return cache;
}

unsigned long ur_cache_destroy(ur_cache_t cache)
{
	unsigned long ret;

	_ur_cache_check(cache);
	ret = cache->magic = ~UR_CACHE_MAGIC;
	ur_free(cache);
	return ret;
}

static void ur_cache_construct(ur_cache_t cache,
			       const char **dir1,
			       const char **dir2,
			       const char **dir3,
			       const char **filename,
			       const char *class,
			       const char *subclass,
			       const char *type)
{
	const char *c;
	const char *s;
	const char *t;
	char       *tmp;
	int        len;

	c = class    ? cache->convert(class) : "_";
	s = subclass ? cache->convert(subclass) : "_";
	t = type     ? cache->convert(type) : "_";

	*dir1 = ur_atom_string_n(c, 1);
	*dir2 = ur_atom_string_n(c[1] ? c+1 : "_", 1);
	*dir3 = c;

	len = strlen(*dir1) + strlen(*dir2) + strlen(*dir3)
	      + strlen(c) + strlen(s) + strlen(t) + 16;
	tmp = alloca(len);
	snprintf(tmp, len-1, "%s-%s.%s", c, s, t);
	*filename = ur_atom_string(tmp);
}

int ur_cache_insert(ur_cache_t cache, const char *class, const char *subclass,
		    const char *type, const char *string)
{
	const char  *dir1, *dir2, *dir3, *filename;
	char        *path;
	int         len;
	struct stat sb;
	int         fd;

	_ur_cache_check(cache);
	ur_cache_construct(cache, &dir1, &dir2, &dir3, &filename,
			   class, subclass, type);
	len = strlen(cache->root)
	      + strlen(dir1) + strlen(dir2) + strlen(dir3)
	      + strlen(filename) + 32;
	path = alloca(len);

	snprintf(path, len-1, "%s/%s", cache->root, dir1);
	if (stat(path, &sb)) mkdir(path, 0775);

	snprintf(path, len-1, "%s/%s/%s", cache->root, dir1, dir2);
	if (stat(path, &sb)) mkdir(path, 0775);

	snprintf(path, len-1, "%s/%s/%s/%s", cache->root, dir1, dir2, dir3);
	if (stat(path, &sb)) mkdir(path, 0775);

	snprintf(path, len-1, "%s/%s/%s/%s/%s", cache->root,
		 dir1, dir2, dir3, filename);

	fd = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0664);
	if (fd >= 0) {
		int bytes  = strlen(string);
		int retval = 0;

		if (write(fd, string, bytes) != bytes) {
			retval = errno;
		}
		close(fd);
		return 0;
	}
	return errno;
}

const char *ur_cache_lookup(ur_cache_t cache, const char *class,
			    const char *subclass, const char *type)
{
	const char  *dir1, *dir2, *dir3, *filename;
	char        *path;
	int         len;
	struct stat sb;
	int         fd;
	char        *string = NULL;

	_ur_cache_check(cache);
	ur_cache_construct(cache, &dir1, &dir2, &dir3, &filename,
			   class, subclass, type);
	len = strlen(cache->root)
	      + strlen(dir1) + strlen(dir2) + strlen(dir3)
	      + strlen(filename) + 32;
	path = alloca(len);

	snprintf(path, len-1, "%s/%s/%s/%s/%s", cache->root,
		 dir1, dir2, dir3, filename);

	fd = open(path, O_RDONLY);
	if (fd >= 0 && !fstat(fd, &sb)) {
		int bytes;

		string = ur_alloc(sb.st_size + 1);
		bytes = read(fd, string, sb.st_size);

		if (bytes != sb.st_size) {
			ur_warning(__func__, "read returned %d\n", bytes);
			sb.st_size = 0;
		}
		string[sb.st_size] = '\0';
		close(fd);
	}
	ur_trace(UR_TRACE_CACHE, __func__,
		 "fd=%d path=%s size=%d string=\"%s\"\n",
		 fd, path, (int)sb.st_size, string);
	return string;
}

int ur_cache_delete(ur_cache_t cache, const char *class,
		    const char *subclass, const char *type)
{
	const char  *dir1, *dir2, *dir3, *filename;
	char        *path;
	int         len;

	_ur_cache_check(cache);
	ur_cache_construct(cache, &dir1, &dir2, &dir3, &filename,
			   class, subclass, type);
	len = strlen(cache->root)
	      + strlen(dir1) + strlen(dir2) + strlen(dir3)
	      + strlen(filename) + 32;
	path = alloca(len);

	snprintf(path, len-1, "%s/%s/%s/%s/%s", cache->root,
		 dir1, dir2, dir3, filename);

	if (unlink(path)) return errno;
	return 0;
}

void ur_cache_free(const char *string)
{
	ur_free((char *)string);
}
