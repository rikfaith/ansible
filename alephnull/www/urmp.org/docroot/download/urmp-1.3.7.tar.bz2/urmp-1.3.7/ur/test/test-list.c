/* test-list.c -- 
 * Created: Sun Dec 26 15:16:58 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-list.c,v 1.8 2000-12-28 20:35:54 faith Exp $
 *
 */

#define NCASES 421

#define OBJECTNAME       "ur_list"
#define OBJECTTYPE       ur_list_t
#define OBJECTCREATEV    ur_list_create
#define OBJECTDESTROY    ur_list_destroy
#define OBJECTPUSH       ur_list_push
#define OBJECTPOP        ur_list_pop
#define OBJECTDEPTH      ur_list_depth
#define OBJECTTOP        ur_list_top
#define OBJECTBOT        ur_list_bot
#define OBJECTLAST       ur_list_last
#define OBJECTAPPEND     ur_list_append
#define OBJECTITERATE    UR_LIST_ITERATE
#define OBJECTINFO

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    ur_list_t      s;
    const char    *datum0  = "datum0 is 42";
    const char    *datum1  = "datum1 is 3.14159265";
    int           c;
    const char    **v;
    
				/* ParseString */
    test("L", "ParseString empty");
    s = ur_list_create();
    ur_list_parse_string(s, "");
    if (ur_list_depth(s) != 0)        fail("empty");
    ok(0);
    end(s);
    
    test("L", "ParseString white 1");
    s = ur_list_create();
    ur_list_parse_string(s, " ");
    if (ur_list_depth(s) != 0)        fail("empty");
    ok(0);
    test("L", "ParseString white 5");
    ur_list_parse_string(s, " \t\f\n\r");
    if (ur_list_depth(s) != 0)        fail("empty");
    ok(0);
    
    test("L", "ParseString a");
    ur_list_parse_string(s, "a");
    if (ur_list_depth(s) != 1)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString white a");
    ur_list_parse_string(s, "  a");
    if (ur_list_depth(s) != 1)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString a white");
    ur_list_parse_string(s, "a  ");
    if (ur_list_depth(s) != 1)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString white a white");
    ur_list_parse_string(s, "\na  ");
    if (ur_list_depth(s) != 1)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    ok(0);

    test("L", "ParseString a b");
    ur_list_parse_string(s, "a b");
    if (ur_list_depth(s) != 2)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    if (strcmp(ur_list_pop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString white a b");
    ur_list_parse_string(s, " a b");
    if (ur_list_depth(s) != 2)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    if (strcmp(ur_list_pop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString a b white");
    ur_list_parse_string(s, "a b ");
    if (ur_list_depth(s) != 2)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    if (strcmp(ur_list_pop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString white a b white");
    ur_list_parse_string(s, " a b ");
    if (ur_list_depth(s) != 2)        fail("depth");
    if (strcmp(ur_list_pop(s), "a"))  fail("a");
    if (strcmp(ur_list_pop(s), "b"))  fail("b");
    ok(0);

    test("L", "ParseString 'a b'");
    ur_list_parse_string(s, "'a b'");
    if (ur_list_depth(s) != 1)          fail("depth");
    if (strcmp(ur_list_pop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString white 'a b'");
    ur_list_parse_string(s, " 'a b'");
    if (ur_list_depth(s) != 1)          fail("depth");
    if (strcmp(ur_list_pop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString 'a b' white");
    ur_list_parse_string(s, " 'a b' ");
    if (ur_list_depth(s) != 1)          fail("depth");
    if (strcmp(ur_list_pop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString white 'a b' white");
    ur_list_parse_string(s, " 'a b' ");
    if (ur_list_depth(s) != 1)          fail("depth");
    if (strcmp(ur_list_pop(s), "a b"))  fail("a b");
    ok(0);
    
    test("L", "ParseString 'a b\\''");
    ur_list_parse_string(s, "'a b\\''");
    if (ur_list_depth(s) != 1)           fail("depth");
    if (strcmp(ur_list_pop(s), "a b'"))  fail("a b'");
    ok(0);
    
    test("L", "ParseString '\"'");
    ur_list_parse_string(s, "'\"'");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "\""))  fail("\"");
    ok(0);
    
    test("L", "ParseString '\"\"'");
    ur_list_parse_string(s, "'\"\"'");
    if (ur_list_depth(s) != 1)           fail("depth");
    if (strcmp(ur_list_pop(s), "\"\""))  fail("\"\"");
    ok(0);
    
    test("L", "ParseString '\"a\"'");
    ur_list_parse_string(s, "'\"a\"'");
    if (ur_list_depth(s) != 1)            fail("depth");
    if (strcmp(ur_list_pop(s), "\"a\""))  fail("\"a\"");
    ok(0);
    
    test("L", "ParseString 'a\"\"'");
    ur_list_parse_string(s, "'a\"\"'");
    if (ur_list_depth(s) != 1)            fail("depth");
    if (strcmp(ur_list_pop(s), "a\"\""))  fail("a\"\"");
    ok(0);
    
    test("L", "ParseString '\"\"a'");
    ur_list_parse_string(s, "'\"\"a'");
    if (ur_list_depth(s) != 1)            fail("depth");
    if (strcmp(ur_list_pop(s), "\"\"a"))  fail("\"\"a");
    ok(0);
    
    test("L", "ParseString 'a\"b\"'");
    ur_list_parse_string(s, "'a\"b\"'");
    if (ur_list_depth(s) != 1)             fail("depth");
    if (strcmp(ur_list_pop(s), "a\"b\""))  fail("a\"b\"");
    ok(0);
    
    test("L", "ParseString '\"a\"b'");
    ur_list_parse_string(s, "'\"a\"b'");
    if (ur_list_depth(s) != 1)             fail("depth");
    if (strcmp(ur_list_pop(s), "\"a\"b"))  fail("\"a\"b");
    ok(0);
    
    test("L", "ParseString \"'\"");
    ur_list_parse_string(s, "\"'\"");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "'"))   fail("'");
    ok(0);
    
    test("L", "ParseString \"");
    ur_list_parse_string(s, "\"");
    if (ur_list_depth(s) != 0)         fail("depth");
    ok(0);
    
    test("L", "ParseString '");
    ur_list_parse_string(s, "'");
    if (ur_list_depth(s) != 0)         fail("depth");
    ok(0);
    
    test("L", "ParseString \\");
    ur_list_parse_string(s, "\\");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "\\"))  fail("\\");
    ok(0);
    
    test("L", "ParseString \\\\");
    ur_list_parse_string(s, "\\\\");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "\\"))  fail("\\");
    ok(0);
    
    test("L", "ParseString foo'");
    ur_list_parse_string(s, "foo'");
    if (ur_list_depth(s) != 1)          fail("depth");
    if (strcmp(ur_list_pop(s), "foo"))  fail("foo");
    ok(0);
    test("L", "ParseString 'foo");
    ur_list_parse_string(s, "'foo");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "foo")) fail("foo");
    ok(0);
    test("L", "ParseString foo\"");
    ur_list_parse_string(s, "foo\"");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "foo")) fail("foo");
    ok(0);
    test("L", "ParseString \"foo");
    ur_list_parse_string(s, "foo\"");
    if (ur_list_depth(s) != 1)         fail("depth");
    if (strcmp(ur_list_pop(s), "foo")) fail("foo");
    ok(0);
    
    test("L", "ParseString 'a b\\'' \\\"f \\\"\"fo'\"");
    ur_list_parse_string(s, "'a b\\'' \\\"f \\\"\"fo'\"");
    if (ur_list_depth(s) != 3)           fail("depth");
    if (strcmp(ur_list_pop(s), "a b'"))  fail("a b'");
    if (strcmp(ur_list_pop(s), "\"f"))   fail("\"f");
    if (strcmp(ur_list_pop(s), "\"fo'")) fail("\"fo'");
    ok(0);

    end(s);
    
    test("L", "MakeArgv");
    s      = ur_list_create();
    ur_list_make_argv(s, &c, &v);
    if (c != 0)               fail("argc 0");
    if (v[0] != NULL)         fail("argv 0");
    ur_free(v);
    
    ur_list_push(s, datum0);
    ur_list_make_argv(s, &c, &v);
    if (c != 1)               fail("argc 1");
    if (v[1] != NULL)         fail("argv 1");
    if (strcmp(datum0, v[0])) fail("datum0 1");
    ur_free(v);
    
    ur_list_push(s, datum0);
    ur_list_make_argv(s, &c, &v);
    if (c != 2)               fail("argc 2");
    if (v[2] != NULL)         fail("argv 2");
    if (strcmp(datum0, v[0])) fail("datum0 2a");
    if (strcmp(datum0, v[1])) fail("datum0 2b");
    ur_free(v);
    
    ur_list_push(s, datum1);
    ur_list_make_argv(s, &c, &v);
    if (c != 3)               fail("argc 3");
    if (v[3] != NULL)         fail("argv 3");
    if (strcmp(datum1, v[0])) fail("datum1 3");
    if (strcmp(datum0, v[1])) fail("datum0 3a");
    if (strcmp(datum0, v[2])) fail("datum0 3b");
    ur_free(v);

    ok(0);
    end(s);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;
    
    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = teststack()))  return retcode;
	if ((retcode = testlocal()))  return retcode;
    } else {
	if ((retcode = timestack()))  return retcode;
    }
    
    return EXIT_SUCCESS;
}
