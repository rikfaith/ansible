/* test-timer.c -- 
 * Created: Thu Dec 23 06:19:16 1999 by faith@dict.org
 * Copyright 1999, 2000, 2004, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-timer.c,v 1.6 2004-02-09 02:36:27 faith Exp $
 * 
 */

#define OBJECTTYPE     ur_timer_t
#define OBJECTCREATE0  ur_timer_create
#define OBJECTDESTROY  ur_timer_destroy
#define OBJECTINFO

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    ur_timer_t     t;
    ur_timer_t     t0;
    ur_timeval_t   v;
    char          buf[2048];
    double        d = 0;
    int           i;
    unsigned long elapsed;
    
    t0 = ur_timer_create(0);

				/* Time for 2 seconds */
    test("L", "2 seconds");
    t = ur_timer_create(0);
    sleep(2);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &v);
    ok(0);
    test("L", "2 seconds wall");
    sprintf(buf, "wall %ld %ld", v.wall.tv_sec, v.wall.tv_usec);
    elapsed = v.wall.tv_sec * 1000000 + v.wall.tv_usec;
    if (elapsed < 1500000 || elapsed > 3000000) fail(buf);
    ok(0);
    info(buf);
    test("L", "2 seconds user");
    sprintf(buf, "user %ld %ld", v.user.tv_sec, v.user.tv_usec);
    if (v.user.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "2 seconds system");
    sprintf(buf, "system %ld %ld", v.system.tv_sec, v.system.tv_usec);
    if (v.system.tv_sec) fail(buf);
    ok(0);
    info(buf);
    end(t);

    test("L", "Restart");
    t = ur_timer_create(0);
    sleep(3);
    ur_timer_start(t);
    sleep(2);
    ur_timer_stop(t);
    sleep(1);
    ur_timer_get_elapsed(t, &v);
    ok(0);
    test("L", "Restart wall");
    sprintf(buf, "wall %ld %ld", v.wall.tv_sec, v.wall.tv_usec);
    elapsed = v.wall.tv_sec * 1000000 + v.wall.tv_usec;
    if (elapsed < 1500000 || elapsed > 3000000) fail(buf);
    ok(0);
    info(buf);
    test("L", "Restart user");
    sprintf(buf, "user %ld %ld", v.user.tv_sec, v.user.tv_usec);
    if (v.user.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Restart system");
    sprintf(buf, "system %ld %ld", v.system.tv_sec, v.system.tv_usec);
    if (v.system.tv_sec) fail(buf);
    ok(0);
    info(buf);
    end(t);
    
    test("L", "Minimum a");
    t = ur_timer_create(0);
    ur_timer_start(t);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &v);
    ok(0);
    test("L", "Minimum wall");
    sprintf(buf, "wall %ld %ld", v.wall.tv_sec, v.wall.tv_usec);
    if (v.wall.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Minimum user");
    sprintf(buf, "user %ld %ld", v.user.tv_sec, v.user.tv_usec);
    if (v.user.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Minimum system");
    sprintf(buf, "system %ld %ld", v.system.tv_sec, v.system.tv_usec);
    if (v.system.tv_sec) fail(buf);
    ok(0);
    info(buf);
    end(t);

    test("L", "Minimum b");
    t = ur_timer_create(0);
    ur_timer_start(t);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &v);
    ok(0);
    test("L", "Minimum wall");
    sprintf(buf, "wall %ld %ld", v.wall.tv_sec, v.wall.tv_usec);
    if (v.wall.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Minimum user");
    sprintf(buf, "user %ld %ld", v.user.tv_sec, v.user.tv_usec);
    if (v.user.tv_sec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Minimum system");
    sprintf(buf, "system %ld %ld", v.system.tv_sec, v.system.tv_usec);
    if (v.system.tv_sec) fail(buf);
    ok(0);
    info(buf);
    end(t);

				/* Total */
    test("L", "Total");
    for (i = 0; i < 1000000; i++) {
        time_t t2;
	d += (double)(i-1) / (double)(i+1);
        time(&t2);		/* Do a system call so we use system time */
    }
    ur_timer_stop(t0);
    ur_timer_get_elapsed(t0, &v);
    sprintf(buf, "%0.3f", d);
    ok(buf);
    test("L", "Total wall");
    sprintf(buf, "wall %ld %ld", v.wall.tv_sec, v.wall.tv_usec);
    elapsed = v.wall.tv_sec * 1000000 + v.wall.tv_usec;
    if (elapsed < 7500000 || elapsed > 12000000) fail(buf);
    ok(0);
    info(buf);
    test("L", "Total user");
    sprintf(buf, "user %ld %ld", v.user.tv_sec, v.user.tv_usec);
    if (v.user.tv_sec > 1 || !v.user.tv_usec) fail(buf);
    ok(0);
    info(buf);
    test("L", "Total system");
    sprintf(buf, "system %ld %ld", v.system.tv_sec, v.system.tv_usec);
    if (v.system.tv_sec) fail(buf);
    ok(0);
    info(buf);
    end(t0);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
