/* checksum.c -- 
 * Created: Tue May 26 05:33:50 2009 by faith@acm.org
 * Revised: Tue May 26 06:19:29 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 *
 */

#include "urP.h"
#ifdef WORDS_BIGENDIAN
#define ARCH_IS_BIG_ENDIAN 1
#else
#define ARCH_IS_BIG_ENDIAN 0
#endif
#include "md5.h"

struct ur_checksum_s {
	unsigned long      magic;
	ur_checksum_type_t type;
	md5_state_t        md5_ctx;
};

CHECK_FUNCTION(_ur_checksum_check, ur_checksum_t, UR_CHECKSUM_MAGIC)

ur_checksum_t ur_checksum_create(ur_checksum_type_t type)
{
	ur_checksum_t cs = ur_allocz(sizeof(*cs));
	
	cs->magic    = UR_CHECKSUM_MAGIC;
	cs->type     = type;
	switch (type) {
	case UR_CHECKSUM_MD5:
		md5_init(&cs->md5_ctx);
		break;
	}
	return cs;
}

unsigned long ur_checksum_destroy(ur_checksum_t cs)
{
	unsigned long ret;
	
	_ur_checksum_check(cs);
	ret = cs->magic = ~UR_CHECKSUM_MAGIC;
	ur_free(cs);
	return ret;
}

void ur_checksum_update(ur_checksum_t cs, const char *buf, int len)
{
	_ur_checksum_check(cs);
	switch (cs->type) {
	case UR_CHECKSUM_MD5:
		md5_append(&cs->md5_ctx, (unsigned char *)buf, len);
		break;
	}
}

void ur_checksum_final(ur_checksum_t cs, char *buf, int len)
{
	md5_byte_t digest[16];
	int i;

	_ur_checksum_check(cs);
	switch (cs->type) {
	case UR_CHECKSUM_MD5:
		md5_finish(&cs->md5_ctx, digest);
		for (i = 0; i < 16 && i*2+1 < len; i++) {
			snprintf(buf+2*i, 3, "%02x", digest[i]);
		}
		break;
	}
}
