/* udataconv.c -- Convert UnicodeCharacterDatabase to C struct
 * Created: Sun Jan 14 10:14:02 2001 by faith@dict.org
 * Revised: Sat Jan 27 17:04:14 2001 by faith@dict.org
 * Copyright 2001 Rickard E. Faith (faith@dict.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id: udataconv.c,v 1.3 2001-01-29 19:12:40 faith Exp $
 * 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "urP.h"

#define UR_UNI_DEBUG 0

typedef unsigned int ur_uni_t;
#define UR_UNI_CHARS (64*1024)
#define UR_UNI_NORMS (16000)	/* Maximum number of normalization tests */


				/* General Category */
typedef enum {
				/* Normative Categories */
    UR_UNI_LU, /* Letter, Uppercase */
    UR_UNI_LL, /* Letter, Lowercase */
    UR_UNI_LT, /* Letter, Titlecase */
    UR_UNI_MN, /* Mark, Non-Spacing */
    UR_UNI_MC, /* Mark, Spacing Combining */
    UR_UNI_ME, /* Mark, Enclosing */
    UR_UNI_ND, /* Number, Decimal Digit */
    UR_UNI_NL, /* Number, Letter */
    UR_UNI_NO, /* Number, Other */
    UR_UNI_ZS, /* Seperator, Space */
    UR_UNI_ZL, /* Seperator, Line */
    UR_UNI_ZP, /* Seperator, Paragraph */
    UR_UNI_CC, /* Other, Control */
    UR_UNI_CF, /* Other, Format */
    UR_UNI_CS, /* Other, Surrogate */
    UR_UNI_CO, /* Other, Private Use */
    UR_UNI_CN, /* Other, Not Assigned */

				/* Informative Categories */
    UR_UNI_LM,	/* Latter, Modifier */
    UR_UNI_LO, /* Letter, Other */
    UR_UNI_PC, /* Punctuation, Connector */
    UR_UNI_PD, /* Punctuation, Dash */
    UR_UNI_PS, /* Punctuation, Open */
    UR_UNI_PE, /* Punctuation, Close */
    UR_UNI_PI, /* Punctuation, Initial quote */
    UR_UNI_PF, /* Punctuation, Final quote */
    UR_UNI_PO, /* Punctuation, Other */
    UR_UNI_SM, /* Symbol, Math */
    UR_UNI_SC, /* Symbol, Currency */
    UR_UNI_SK, /* Symbol, Modifier */
    UR_UNI_SO, /* Symbol, Other */
} ur_uni_gen_cat_t;

				/* Canonical Combining Classes */
typedef int ur_uni_c_c_cT;

				/* Bidirectional Category */
typedef enum {
    UR_UNI_L,   /* Left-to-Right */
    UR_UNI_LRE, /* Left-to-Right Embedding */
    UR_UNI_LRO, /* Left-to-Right Override */
    UR_UNI_R,   /* Right-to-Left */
    UR_UNI_AL,  /* Right-to-Left Arabic */
    UR_UNI_RLE, /* Right-to-Left Embedding */
    UR_UNI_RLO, /* Right-to-Left Override */
    UR_UNI_PDF, /* Pop Directional Format */
    UR_UNI_EN,  /* European Number */
    UR_UNI_ES,  /* European Number Separator */
    UR_UNI_ET,  /* European Number Terminator */
    UR_UNI_AN,  /* Arabic Number */
    UR_UNI_CNS, /* Common Number Separator */
    UR_UNI_NSM, /* Non-Spacing Mark */
    UR_UNI_BN,  /* Boundary Neutral */
    UR_UNI_B,   /* Paragraph Separator */
    UR_UNI_S,   /* Segment Separator */
    UR_UNI_WS,  /* Whitespace */
    UR_UNI_ON,  /* Other Neutrals */
} ur_uni_bid_cat_t;

typedef enum {
    UR_UNI_LOWERCASE, /* Lowercase */
    UR_UNI_EXCEPTION  /* Exception */
} ur_uni_status_t;

typedef enum {
    UR_UNI_NFD,		/* Normalization Form D */
    UR_UNI_NFC,		/* Normalization Form C */
    UR_UNI_NFKD,		/* Normalization Form KD */
    UR_UNI_NFKC		/* Normalization Form Kc */
} ur_uni_form_t;

struct genCatS {
    const char    *code;
    ur_uni_gen_cat_t value;
} genCatTable[] = {
    { "Lu", UR_UNI_LU },
    { "Ll", UR_UNI_LL },
    { "Lt", UR_UNI_LT },
    { "Mn", UR_UNI_MN },
    { "Mc", UR_UNI_MC },
    { "Me", UR_UNI_ME },
    { "Nd", UR_UNI_ND },
    { "Nl", UR_UNI_NL },
    { "No", UR_UNI_NO },
    { "Zs", UR_UNI_ZS },
    { "Zl", UR_UNI_ZL },
    { "Zp", UR_UNI_ZP },
    { "Cc", UR_UNI_CC },
    { "Cf", UR_UNI_CF },
    { "Cs", UR_UNI_CS },
    { "Co", UR_UNI_CO },
    { "Cn", UR_UNI_CN },
    { "Lm", UR_UNI_LM },
    { "Lo", UR_UNI_LO },
    { "Pc", UR_UNI_PC },
    { "Pd", UR_UNI_PD },
    { "Ps", UR_UNI_PS },
    { "Pe", UR_UNI_PE },
    { "Pi", UR_UNI_PI },
    { "Pf", UR_UNI_PF },
    { "Po", UR_UNI_PO },
    { "Sm", UR_UNI_SM },
    { "Sc", UR_UNI_SC },
    { "Sk", UR_UNI_SK },
    { "So", UR_UNI_SO },
    { NULL, 0 }
};

struct bidCatS {
    const char    *code;
    ur_uni_gen_cat_t value;
} bidCatTable[] = {
    { "L",   UR_UNI_L },
    { "LRE", UR_UNI_LRE },
    { "LRO", UR_UNI_LRO },
    { "R",   UR_UNI_R },
    { "AL",  UR_UNI_AL },
    { "RLE", UR_UNI_RLE },
    { "RLO", UR_UNI_RLO },
    { "PDF", UR_UNI_PDF },
    { "EN",  UR_UNI_EN },
    { "ES",  UR_UNI_ES },
    { "ET",  UR_UNI_ET },
    { "AN",  UR_UNI_AN },
    { "CS",  UR_UNI_CNS },
    { "NSM", UR_UNI_NSM },
    { "BN",  UR_UNI_BN },
    { "B",   UR_UNI_B },
    { "S",   UR_UNI_S },
    { "WS",  UR_UNI_WS },
    { "ON",  UR_UNI_ON },
    { NULL,  0 }
};

typedef struct ur_uni_char_s {
				/* From UnicodeData-*.txt */
    ur_uni_t       codepoint;    /* Code point */
    const char    *name;	/* Character name */
    ur_uni_gen_cat_t gencat;	/* General Category */
    ur_uni_c_c_cT    ccc;		/* Canonical Combining Classes */
    ur_uni_bid_cat_t bidcat;	/* Bidirectional Category */
    const char    *tag;		/* Compatibility tag; NULL = canonical */
    ur_uni_t       *decomp;	/* Character Decomposition Mapping */
    int           decomplen;	/* Length of decomp */
    int           hasDecimal;	/* Decimal digit value preset */
    int           decimal;	/* Decimal digit value */
    int           hasDigit;	/* Digit value present */
    int           digit;	/* Digit value */
    const char    *numeric;	/* Numeric value */
    int           mirrored;	/* Mirrored */
    const char    *oldname;	/* Unicode 1.0 Name */
    const char    *comment;	/* 10646 comment field */
    ur_uni_t       *uppercase;	/* Uppercase Mapping */
    ur_uni_t       *lowercase;	/* Lowercase Mapping */
    ur_uni_t       *titlecase;	/* Titlecase Mapping */

				/* From CaseFolding-*.txt */
    ur_uni_status_t status;
    ur_uni_t       *folding;

				/* Composition support */
    int           compose;	/* Part of a composeable pair */
    int           exclude;	/* Never a composition target */
    int           trie[2];
} ur_uni_char_t;

typedef struct ur_uni_data_s {
    ur_uni_char_t   u[UR_UNI_CHARS];
    
				 /* Composition trie support */
    int           dims[2];	 /* Dimensions of trie */
    ur_uni_t       **composition; /* Composition table */
} *ur_uni_data_t;

typedef struct ur_uni_norm_test_s {
    ur_uni_t       *c[5];
    const char    *comment;
} ur_uni_norm_test_t;

typedef struct ur_uni_norm_s {
    int             count;
    ur_uni_norm_test_t t[UR_UNI_NORMS];
} *ur_uni_norm_t;

int ur_uni_len(ur_uni_t *s)
{
    int i;

    for (i = 0; *s; ++i, ++s);
    return i;
}

ur_uni_data_t ur_uni_data_create(void)
{
    ur_uni_data_t ud = ur_allocz(sizeof(*ud));
    int         i;

    for (i = 0; i < UR_UNI_CHARS; i++) ud->u[i].gencat = UR_UNI_CN;

    return ud;
}

ur_uni_norm_t ur_uni_norm_create(void)
{
    ur_uni_norm_t norm = ur_allocz(sizeof(*norm));
    return norm;
}

void ur_uni_data_destroy(ur_uni_data_t ud)
{
    int i;
    
    for (i = 0; i < UR_UNI_CHARS; i++) {
	if (ud->u[i].name)    ur_free((void *)ud->u[i].name);
	if (ud->u[i].decomp)  ur_free(ud->u[i].decomp);
	if (ud->u[i].oldname) ur_free((void *)ud->u[i].oldname);
	if (ud->u[i].comment) ur_free((void *)ud->u[i].comment);
    }
    if (ud->composition) ur_free(ud->composition);
    ur_free(ud);
}

void ur_uni_norm_destroy(ur_uni_norm_t norm)
{
    int i;
    
    for (i = 0; i < UR_UNI_NORMS; i++) {
	if (norm->t[i].comment) ur_free((void *)norm->t[i].comment);
    }
    ur_free(norm);
}

ur_uni_t *ur_uni_from_hex(const char *s)
{
    char       *endptr;
    const char *pt;
    ur_uni_t    *buf, *d;

    buf = ur_alloc((strlen(s)/4 + 1) * sizeof(*buf));

    for (pt = s, d = buf; *pt; pt = endptr) *d++ = strtol(pt, &endptr, 16);
    *d = 0;

    return buf;
}

int ur_uni_data_read_database(ur_uni_data_t ud, FILE *str) {
    char          buf[1024];
    int           codeValue;
    char          *f[16];
    int           i;
    ur_uni_char_t   *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	f[0] = buf;
	for (i = 1; i < 16; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}
	if ((codeValue = strtol(f[0], NULL, 16)) > UR_UNI_CHARS) return 0;

	pt = &ud->u[codeValue];

	pt->codepoint  = codeValue;              /* Code Point */
	pt->name       = ur_str_dup(f[1]);        /* Character Name */
	pt->ccc        = strtol(f[3], NULL, 10); /* Canonical Comb. Classes */
	pt->hasDecimal = (f[6][0] != '\0');
	pt->decimal    = strtol(f[6], NULL, 10); /* Decimal digit value */
	pt->hasDigit   = (f[7][0] != '\0');
	pt->digit      = strtol(f[7], NULL, 10); /* Digit value */
	pt->numeric    = ur_atom_string(f[8]);    /* Numeric value */
	pt->mirrored   = (*f[9] == 'Y') ? 1 : 0; /* Mirrored */
	pt->oldname    = ur_str_dup(f[10]);       /* Unicode 1.0 Name */
	pt->comment    = ur_str_dup(f[11]);       /* 10646 comment field */
	pt->uppercase  = ur_uni_from_hex(f[12]);   /* Uppercase Mapping */
	pt->lowercase  = ur_uni_from_hex(f[13]);   /* Lowercase Mapping */
	pt->titlecase  = ur_uni_from_hex(f[14]);   /* Titlecase Mapping */

				/* General Category */
	if (*f[2]) {
	    struct genCatS *p;

	    for (p = &genCatTable[0]; p->code; ++p) {
		if (!strcmp(f[2], p->code)) {
		    pt->gencat = p->value;
		    break;
		}
	    }
	}

				/* Bidirectional Category */
	if (*f[4]) {
	    struct bidCatS *p;

	    for (p = &bidCatTable[0]; p->code; ++p) {
		if (!strcmp(f[4], p->code)) {
		    pt->bidcat = p->value;
		    break;
		}
	    }
	    
	}

				/* Compatibility tag */
	if (*f[5]) {
	    const char *decomp = f[5];
	    
	    if (*f[5] == '<') {
		pt->tag = ur_atom_string(strtok(f[5]+1, ">"));
		decomp  = strtok(NULL, "");
	    }
	    pt->decomp    = ur_uni_from_hex(decomp);
	    pt->decomplen = ur_uni_len(pt->decomp);
	}
    }
    
    return 0;
}

void ur_uni_print_hex(FILE *str, const ur_uni_t *s)
{
    const ur_uni_t *pt;
    
    if (!s) return;
    for (pt = s; *pt; pt++) {
	if (pt != s) fprintf(str, " %04X", *pt);
	else         fprintf(str, "%04X", *pt);
    }
}

static void _ur_uni_print_hex(ur_uni_data_t ud, FILE *str, const ur_uni_t *s)
{
    const ur_uni_t *pt;
    
    if (!s) return;
    for (pt = s; *pt; pt++) {
	if (pt != s) fprintf(str, " %04X/%d", *pt, ud->u[*pt].ccc);
	else         fprintf(str, "%04X/%d", *pt, ud->u[*pt].ccc);
    }
}

int ur_uni_data_compute_composition(ur_uni_data_t ud, FILE *str)
{
    int  i, j;
    char buf[1024];

				/* Remove old trie and exclusion data*/
    for (i = 0; i < UR_UNI_CHARS; i++) {
	ud->u[i].trie[0] = ud->u[i].trie[1] = 0;
	ud->u[i].compose = 0;
	ud->u[i].exclude = 1;
    }
    ud->dims[0] = ud->dims[1] = 0;
    if (ud->composition) ur_free(ud->composition);

				/* Determine trie indices */
    for (i = 0; i < UR_UNI_CHARS; i++) {
	ur_uni_char_t *pt  = &ud->u[i];
	
	if (pt->tag || !pt->decomp) continue; /* No canonical decomp. */
	if (pt->decomplen != 2)     continue; /* Singleton */
	if (ud->u[*pt->decomp].ccc) continue; /* Not starter */

	for (j = 0; j < 2; j++) {
	    ur_uni_char_t *p = &ud->u[ pt->decomp[j] ];
	    if (!p->trie[j]) p->trie[j] = ++ud->dims[j];
	    ++p->compose;
	}
    }

				/* Allocate trie */
    printf("Trie[%d,%d]\n", ud->dims[0], ud->dims[1]);
    ud->composition = ur_alloc((ud->dims[0] + 1) * sizeof(*ud->composition));
    for (i = 0; i <= ud->dims[0]; i++)
	ud->composition[i] = ur_allocz((ud->dims[1] + 1)
				       * sizeof(*ud->composition[0]));

				/* Fill composition table */
    for (i = 0; i < UR_UNI_CHARS; i++) {
	ur_uni_char_t *pt  = &ud->u[i];
	
	if (!pt->tag && pt->decomp) {
	    int i0, i1;
	    
	    if (pt->decomplen != 2) continue;
	    if (ud->u[*pt->decomp].ccc) continue;

	    i0 = ud->u[ pt->decomp[0] ].trie[0];
	    i1 = ud->u[ pt->decomp[1] ].trie[1];
	    ud->composition[i0][i1] = i;
	    pt->exclude             = 0;
	}
    }

				/* Read special exclusion table */
    while (fgets(buf, sizeof(buf)-1, str)) {
	ur_uni_t codepoint;
	
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	codepoint  = strtol(buf, NULL, 16);
	ud->u[codepoint].exclude = 1;
    }
    
    return 0;
}

int ur_uni_data_read_folding(ur_uni_data_t ud, FILE *str) {
    char          buf[1024];
    int           codeValue;
    char          *f[4];
    int           i;
    ur_uni_char_t   *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	f[0] = buf;
	for (i = 1; i < 4; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}
	if ((codeValue = strtol(f[0], NULL, 16)) > UR_UNI_CHARS) return 0;

	pt = &ud->u[codeValue];

	pt->status  = f[1][1] == 'L' ? UR_UNI_LOWERCASE : UR_UNI_EXCEPTION;
	pt->folding = ur_uni_from_hex(f[2]);
    }
    
    return 0;
}

int ur_uni_norm_read(ur_uni_norm_t norm, FILE *str) {
    char            buf[1024];
    char            *f[6];
    int             i;
    ur_uni_norm_test_t *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	f[0] = buf;
	for (i = 1; i < 6; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}

	if (norm->count >= UR_UNI_NORMS)
	    ur_fatal(__FUNCTION__,
		     "More than %d normalization tests\n", norm->count);

	pt = &norm->t[norm->count++];
	for (i = 0; i < 5; i++) pt->c[i] = ur_uni_from_hex(f[i]);
	pt->comment = ur_str_dup(f[5]);
    }
    
    return 0;
}

const char *_ur_uni_gen_cat_name(ur_uni_gen_cat_t gencat)
{
    switch (gencat) {
    case UR_UNI_LU: return "Lu";
    case UR_UNI_LL: return "Ll";
    case UR_UNI_LT: return "Lt";
    case UR_UNI_MN: return "Mn";
    case UR_UNI_MC: return "Mc";
    case UR_UNI_ME: return "Me";
    case UR_UNI_ND: return "Nd";
    case UR_UNI_NL: return "Nl";
    case UR_UNI_NO: return "No";
    case UR_UNI_ZS: return "Zs";
    case UR_UNI_ZL: return "Zl";
    case UR_UNI_ZP: return "Zp";
    case UR_UNI_CC: return "Cc";
    case UR_UNI_CF: return "Cf";
    case UR_UNI_CS: return "Cs";
    case UR_UNI_CO: return "Co";
    case UR_UNI_CN: return "Cn";
    case UR_UNI_LM: return "Lm";
    case UR_UNI_LO: return "Lo";
    case UR_UNI_PC: return "Pc";
    case UR_UNI_PD: return "Pd";
    case UR_UNI_PS: return "Ps";
    case UR_UNI_PE: return "Pe";
    case UR_UNI_PI: return "Pi";
    case UR_UNI_PF: return "Pf";
    case UR_UNI_PO: return "Po";
    case UR_UNI_SM: return "Sm";
    case UR_UNI_SC: return "Sc";
    case UR_UNI_SK: return "Sk";
    case UR_UNI_SO: return "So";
    default: ur_fatal(__FUNCTION__, "Unknown category = %d\n", gencat);
    }
}

const char *_ur_uni_bid_cat_name(ur_uni_bid_cat_t bidcat)
{
    switch (bidcat) {
    case UR_UNI_L:   return "L";
    case UR_UNI_LRE: return "LRE";
    case UR_UNI_LRO: return "LRO";
    case UR_UNI_R:   return "R";
    case UR_UNI_AL:  return "AL";
    case UR_UNI_RLE: return "RLE";
    case UR_UNI_RLO: return "RLO";
    case UR_UNI_PDF: return "PDF";
    case UR_UNI_EN:  return "EN";
    case UR_UNI_ES:  return "ES";
    case UR_UNI_ET:  return "ET";
    case UR_UNI_AN:  return "AN";
    case UR_UNI_CNS: return "CS";
    case UR_UNI_NSM: return "NSM";
    case UR_UNI_BN:  return "BN";
    case UR_UNI_B:   return "B";
    case UR_UNI_S:   return "S";
    case UR_UNI_WS:  return "WS";
    case UR_UNI_ON:  return "ON";
    default: ur_fatal(__FUNCTION__, "Unknown category = %d\n", bidcat);
    }
}

void ur_uni_data_dump_database(ur_uni_data_t ud, FILE *str)
{
    int i;
    
    for (i = 0; i < UR_UNI_CHARS; i++) {
	ur_uni_char_t *pt = &ud->u[i];

	if (pt->name) {
	    fprintf(str, "%04X", pt->codepoint);
	    fprintf(str, ";%s",  pt->name);
	    fprintf(str, ";%s", _ur_uni_gen_cat_name(pt->gencat));
	    fprintf(str, ";%d", pt->ccc);
	    fprintf(str, ";%s", _ur_uni_bid_cat_name(pt->bidcat));

	    fprintf(str, ";");
	    if (pt->tag) fprintf(str, "<%s> ", pt->tag);
	    ur_uni_print_hex(str, pt->decomp);

	    fprintf(str, ";");
	    if (pt->hasDecimal) fprintf(str, "%d", pt->decimal);
	    fprintf(str, ";");
	    if (pt->hasDigit)   fprintf(str, "%d", pt->digit);
	    
	    fprintf(str, ";%s", pt->numeric ? pt->numeric : "");
	    fprintf(str, ";%c", pt->mirrored ? 'Y' : 'N');
	    fprintf(str, ";%s", pt->oldname ? pt->oldname : "");
	    fprintf(str, ";%s", pt->comment ? pt->comment : "");
	    
	    fprintf(str, ";"); ur_uni_print_hex(str, pt->uppercase);
	    fprintf(str, ";"); ur_uni_print_hex(str, pt->lowercase);
	    fprintf(str, ";"); ur_uni_print_hex(str, pt->titlecase);
	    fprintf(str, "\n");
	}
    }
}

void ur_uni_data_dump_folding(ur_uni_data_t ud, FILE *str)
{
    int i;
    
    for (i = 0; i < UR_UNI_CHARS; i++) {
	ur_uni_char_t *pt = &ud->u[i];

	if (pt->folding) {
	    fprintf(str, "%04X", i);
	    fprintf(str, "; %c", pt->status == UR_UNI_LOWERCASE ? 'L' : 'E');
	    fprintf(str, "; ");
	    ur_uni_print_hex(str, pt->folding);
	    fprintf(str, ";\t#%s\n", pt->name);
	}
    }
}

void ur_uni_norm_dump(ur_uni_norm_t norm, FILE *str)
{
    int i, j;
    
    for (i = 0; i < norm->count; i++) {
	ur_uni_norm_test_t *pt = &norm->t[i];

	for (j = 0; j < 5; j++) {
	    ur_uni_print_hex(str, pt->c[j]);
	    fprintf(str, ";");
	}
	fprintf(str, "%s", pt->comment);
    }
}

ur_uni_t *ur_uni_cpy(ur_uni_t *dst, const ur_uni_t *src)
{
    ur_uni_t       *d;
    const ur_uni_t *s;

				/* FIXME: this can be optimized */
    for (s = src, d = dst; *s; s++, d++) *d = *s;
    *d = 0;
    return dst;
}

int ur_uni_cmp(const ur_uni_t *s1, const ur_uni_t *s2)
{
    for (;*s1 && *s2; s1++, s2++) {
	if (*s1 < *s2) return -1;
	if (*s1 > *s2) return 1;
    }
    if (*s1 < *s2) return -1;
    if (*s1 > *s2) return 1;
    return 0;
}

static void _ur_uni_canonical_ordering(ur_uni_data_t ud, ur_uni_t *src)
{
    ur_uni_char_t   *a, *b;
    ur_uni_t       *s, tmp;
    int           changed;

    do {
	for (changed = 0, s = src; *s; s++) {
	    a = &ud->u[s[0]];
	    b = &ud->u[s[1]];
	    if (b->ccc && a->ccc > b->ccc) {
		changed = 1;
		tmp     = s[1];
		s[1]    = s[0];
		s[0]    = tmp;
	    }
	}
    } while (changed);
}

static int _ur_uni_compose_hangul(ur_uni_t *dst, const ur_uni_t *src)
{
    const int     SBase  = 0xac00;
    const int     LBase  = 0x1100;
    const int     VBase  = 0x1161;
    const int     TBase  = 0x11a7;
    const int     LCount = 19;
    const int     VCount = 21;
    const int     TCount = 28;
    ur_uni_t       *d;
    const ur_uni_t *s;
    int           LIndex;
    int           VIndex;
    int           TIndex;
    int           len;

    for (d = dst, s = src; *s;) {
	if (!s[0] || !s[1]) {
	    *d++ = *s++;
	    continue;
	}
	if ((LIndex = s[0] - LBase) < 0 || LIndex >= LCount) {
	    *d++ = *s++;
	    continue;
	}
	if ((VIndex = s[1] - VBase) < 0 || VIndex >= VCount) {
	    *d++ = *s++;
	    continue;
	}
	if (!s[2] || (TIndex = s[2] - TBase) < 0 || TIndex >= TCount) {
	    TIndex = 0;
	    len    = 2;
	} else {
	    len    = 3;
	}

	*d++ = (LIndex * VCount + VIndex) * TCount + TIndex + SBase;
	s   += len;
    }
    *d = 0;
    return 0;
}

static int _ur_uni_decompose_hangul(ur_uni_t *d, ur_uni_t s)
{
    const int SBase  = 0xac00;
    const int LBase  = 0x1100;
    const int VBase  = 0x1161;
    const int TBase  = 0x11a7;
    const int SCount = 11172;
/*     const int LCount = 19; */
    const int VCount = 21;
    const int TCount = 28;
    const int NCount = VCount * TCount;
    int       SIndex;
    int       L, V, T;

    if ((SIndex = s - SBase) < 0 || SIndex >= SCount) {
	*d = s;
	return 1;
    }

    L    = LBase + SIndex / NCount;
    V    = VBase + (SIndex % NCount) / TCount;
    T    = TBase + SIndex % TCount;
    *d++ = L;
    *d++ = V;
    if (T == TBase) return 2;
    *d++ = T;
    return 3;
}

static void ur_uni_decompose(ur_uni_data_t ud, int compatibility,
			    ur_uni_t *dst, int len, const ur_uni_t *src)
{
    ur_uni_t       *d;
    const ur_uni_t *s;
    const ur_uni_t *p;
    int           changed = 0;
    ur_uni_t       *buf;
    ur_uni_char_t   *pt;

#if UR_UNI_DEBUG
    printf("  Decomp. src[%p]=", src);
    _ur_uni_print_hex(ud, stdout, src);
    printf("\n");
#endif

    buf = ur_alloc(len);
    for (s = src, d = buf; *s; s++) {
	pt = &ud->u[*s];
	if ((compatibility || !pt->tag) && pt->decomp) {
	    for (p = pt->decomp; *p;) *d++ = *p++;
	    ++changed;
	} else {
	    d += _ur_uni_decompose_hangul(d, *s);
	}
    }
    *d = 0;
    if (changed) ur_uni_decompose(ud, compatibility, dst, len, buf);
    else         ur_uni_cpy(dst, buf);
    _ur_uni_canonical_ordering(ud, dst);
    ur_free(buf);
    
#if UR_UNI_DEBUG
    printf("  Decomp. res[%p]=", src);
    _ur_uni_print_hex(ud, stdout, dst);
    printf("\n");
#endif
}

static void ur_uni_compose(ur_uni_data_t ud, ur_uni_t *dst, int len,
			  const ur_uni_t *src)
{
    ur_uni_t       *d;
    int           idx;
    const ur_uni_t *s;
    int           changed = 0;
    ur_uni_t       *buf;
    ur_uni_char_t   *p0, *p1;
    int           i0, i1;
    ur_uni_t       codepoint;

#if UR_UNI_DEBUG
    printf("  Compose src[%p]=", src);
    _ur_uni_print_hex(ud, stdout, src);
    printf("\n");
#endif
    
    buf = ur_alloc(len);
    for (s = src, d = buf; *s; ++d) {
	p0 = &ud->u[*s];
	p1 = s[1] ? &ud->u[s[1]] : NULL;
	if (!p1 || p0->ccc || !p0->compose) {
	    *d = *s++;
	    continue;
	}

	idx = 0;
	++s;
	do {
	    i0        = p0->trie[0];
	    i1        = p1->trie[1];
	    codepoint = ud->composition[i0][i1];
	    if (codepoint && !ud->u[codepoint].exclude) {
		*d = ud->composition[i0][i1];
		++s;
		++changed;
#if UR_UNI_DEBUG
		printf("    %04X (%d, %d) %04X (%d, %d) -> %04X\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d);
#endif
	    } else if (!p1->ccc) { /* Starter */
		*d = p0->codepoint;
#if UR_UNI_DEBUG
		printf("    %04X (%d, %d) %04X (%d, %d) -> %04X %04X\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d, *s);
#endif
		break;
	    } else {
		*d       = p0->codepoint;
		d[++idx] = p1->codepoint;
		++s;
#if UR_UNI_DEBUG
		printf("    %04X (%d,%d) %04X (%d,%d) -> %04X ? %04X [%04X]\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d, d[idx], *s);
#endif
		while (*s && ud->u[*s].ccc == p1->ccc) {
#if UR_UNI_DEBUG
		    printf("    Skip %04X (%d) [%04X]\n",
			   *s, ud->u[*s].ccc, s[1]);
#endif
		    d[++idx] = *s++;
		}
	    }

	    p0   = &ud->u[*d];
	    p1   = *s ? &ud->u[*s] : NULL;
#if UR_UNI_DEBUG
	    printf("    p0 = %04X, p1 = %04X\n", p0->codepoint,
		   p1 ? p1->codepoint : 0);
#endif
	} while (p1 && p0->compose);
	d += idx;
    }
    *d = 0;

#if UR_UNI_DEBUG
    printf("  Compose res[%p]=", buf);
    _ur_uni_print_hex(ud, stdout, buf);
    printf(" (%d)\n", changed);
#endif

#if 1
    changed = 0;
#endif
    if (changed) ur_uni_compose(ud, dst, len, buf);
    else         _ur_uni_compose_hangul(dst, buf);
    ur_free(buf);
}

void ur_uni_normalize(ur_uni_data_t ud,
		     ur_uni_t *d, int len, const ur_uni_t *s, ur_uni_form_t form)
{
    ur_uni_t *tmp;
    
    switch (form) {
    case UR_UNI_NFD:  ur_uni_decompose(ud, 0, d, len, s); break;
    case UR_UNI_NFKD: ur_uni_decompose(ud, 1, d, len, s); break;
    case UR_UNI_NFC:
	tmp = ur_alloc(len * sizeof(*tmp));
	ur_uni_decompose(ud, 0, tmp, len, s);
	ur_uni_compose(ud, d, len, tmp);
	ur_free(tmp);
	break;
    case UR_UNI_NFKC:
	tmp = ur_alloc(len * sizeof(*tmp));
	ur_uni_decompose(ud, 1, tmp, len, s);
	ur_uni_compose(ud, d, len, tmp);
	ur_free(tmp);
	break;
    }
}

static void _ur_uni_norm_fail(ur_uni_data_t ud, int test, const char *desc,
			    const ur_uni_t *got, const ur_uni_t *source,
			    const ur_uni_t *target)
{
    printf("Test %5d (%s) failed:\n           ", test, desc);
    _ur_uni_print_hex(ud, stdout, source);
    printf("\n        -> ");
    _ur_uni_print_hex(ud, stdout, target);
    printf("\n        != ");
    _ur_uni_print_hex(ud, stdout, got);
    printf("\n");
}

static void _ur_uni_norm_one_test(ur_uni_data_t ud, ur_uni_norm_t norm,
			       int test, ur_uni_form_t form,
			       int target, int source)
{
    ur_uni_norm_test_t *pt = &norm->t[test];
    ur_uni_t         buf[1024];

#if UR_UNI_DEBUG
    printf("Test %d ======================================\n", test);
#endif
    
    ur_uni_normalize(ud, buf, sizeof(buf)-1, pt->c[source-1], form);

#if UR_UNI_DEBUG
    printf("   Test %d: ", test);
    ur_uni_print_hex(stdout, pt->c[source-1]);
    printf(" -> ");
    ur_uni_print_hex(stdout, buf);
    printf("\n");
#endif
    
    if (ur_uni_cmp(buf, pt->c[target-1])) {
	char       desc[64];
	const char *formname = "?";
	
	switch (form) {
	case UR_UNI_NFD:  formname = "NFD";  break;
	case UR_UNI_NFC:  formname = "NFC";  break;
	case UR_UNI_NFKD: formname = "NFKD"; break;
	case UR_UNI_NFKC: formname = "NFKC"; break;
	}

	sprintf(desc, "c%d == %s(c%d)", target, formname, source);
	_ur_uni_norm_fail(ud, test, desc, buf, pt->c[source-1], pt->c[target-1]);
	exit(1);
    }
}

void ur_uni_norm_test(ur_uni_data_t ud, ur_uni_norm_t norm)
{
    int             i;

    for (i = 0; i < norm->count; i++) {
	/* NFD
	   c3 == NFD(c1) == NFD(c2) == NFD(c3)
	   c5 == NFD(c4) == NFD(c5) */
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFD, 3, 1);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFD, 3, 2);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFD, 3, 3);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFD, 5, 4);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFD, 5, 5);
	
	/* NFKD
	   c5 == NFKD(c1) == NFKD(c2) == NFKD(c3) == NFKD(c4) == NFKD(c5) */
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKD, 5, 1);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKD, 5, 2);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKD, 5, 3);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKD, 5, 4);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKD, 5, 5);

	/* NFC
	   c2 == NFC(c1) == NFC(c2) == NFC(c3)
	   c4 == NFC(c4) == NFC(c5) */
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFC, 2, 1);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFC, 2, 2);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFC, 2, 3);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFC, 4, 4);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFC, 4, 5);

	/* NFKC
	   c4 == NFKC(c1) == NFKC(c2) == NFKC(c3) == NFKC(c4) == NFKC(c5) */
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKC, 4, 1);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKC, 4, 2);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKC, 4, 3);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKC, 4, 4);
	_ur_uni_norm_one_test(ud, norm, i, UR_UNI_NFKC, 4, 5);
    }
}

int main(int argc, char **argv)
{
    ur_uni_data_t ud;
    ur_uni_norm_t norm;
    FILE        *str;
    
    ud = ur_uni_data_create();
    norm = ur_uni_norm_create();

    if (!(str = fopen("unicode/UnicodeData-3.0.1.txt", "r"))) {
	fprintf(stderr, "Cannot open database\n");
	exit(1);
    }
    ur_uni_data_read_database(ud, str);
    fclose(str);
    
    if (!(str = fopen("unicode/CompositionExclusions-2.txt", "r"))) {
	fprintf(stderr, "Cannot open database\n");
	exit(1);
    }
    ur_uni_data_compute_composition(ud, str);
    fclose(str);

    if (!(str = fopen("unicode/CaseFolding-2.txt", "r"))) {
	fprintf(stderr, "Cannot open folding information\n");
	exit(1);
    }
    ur_uni_data_read_folding(ud, str);
    fclose(str);

    if (!(str = fopen("unicode/NormalizationTest-3.0.1.txt", "r"))) {
	fprintf(stderr, "Cannot open normalization test\n");
	exit(1);
    }
    ur_uni_norm_read(norm, str);
    fclose(str);
    
    if (!(str = fopen("tmp.database", "w"))) {
	fprintf(stderr, "Cannot open tmp.database\n");
	exit(1);
    }
    ur_uni_data_dump_database(ud, str);
    fclose(str);

    if (!(str = fopen("tmp.folding", "w"))) {
	fprintf(stderr, "Cannot open tmp.folding\n");
	exit(1);
    }
    ur_uni_data_dump_folding(ud, str);
    fclose(str);

    if (!(str = fopen("tmp.norm", "w"))) {
	fprintf(stderr, "Cannot open tmp.norm\n");
	exit(1);
    }
    ur_uni_norm_dump(norm, str);
    fclose(str);

    ur_uni_norm_test(ud, norm);

    ur_uni_data_destroy(ud);
    ur_uni_norm_destroy(norm);

    return 0;
}
