/* test-checksum.c -- 
 * Created: Tue May 26 05:14:11 2009 by faith@acm.org
 * Revised: Tue May 26 06:24:12 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * The original C code for md5.c and md5.h is available here:
 * ftp://mirror.cs.wisc.edu/pub/mirrors/ghost/packages/md5.tar.gz
 *
 */

#define OBJECTTYPE     ur_checksum_t
#define OBJECTCREATEC  ur_checksum_create
#define OBJECTDESTROY  ur_checksum_destroy
#define OBJECTINFO

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static void check(const char *name,
		  ur_checksum_type_t type,
		  const char *input,
		  const char *output)
{
	ur_checksum_t cs;
	char          hash[512];
	char          buf[512];

	sprintf(buf, "%s", name);
	test("L", buf);
	if (!(cs = ur_checksum_create(type))) fail("create");
	ur_checksum_update(cs, input, strlen(input));
	ur_checksum_final(cs, hash, sizeof(hash));
	if (strcmp(output, hash)) {
		sprintf(buf, "%s instead of %s", hash, output);
		fail(buf);
	}
	sprintf(buf, "%s [%s]", hash, output);
	ok(buf);
	end(cs);
}

static void timer(const char *name, ur_checksum_type_t type,
		  const char *input)
{
	unsigned long v = 0;
	ur_checksum_t  cs;
	ur_timer_t     t;
	ur_timeval_t   tv;
	int            i;
	char           buf[2048];
	int            iters;
	int            useconds;
	int            len;

	len = strlen(input);

	test("T", "Time setup");
	if (!(t = ur_timer_create(0))) fail("timer");
	if (!(cs = ur_checksum_create(type))) fail("create");
	for (iters = 1000, useconds = 0; useconds < 100000;) {
		iters *= 2;
		ur_timer_start(t);
		for (i = 0; i < iters; i++) ur_checksum_update(cs, input, len);
		ur_timer_stop(t);
		ur_timer_get_elapsed(t, &tv);
		useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
	}
	ok(0);
	end(cs);
	sprintf(buf, "%d iters @ %ld.%06ld S",
		iters, tv.wall.tv_sec, tv.wall.tv_usec);
	info(buf);
	
	sprintf(buf, "%s time", name);
	test("T", buf);
	if (!(cs = ur_checksum_create(type))) fail("create");
	ur_timer_start(t);
	for (i = 0; i < iters; i++) ur_checksum_update(cs, input, len);
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	ur_timer_destroy(t);
	sprintf(buf, "%lu", v);
	ok(buf);
	end(cs);
	sprintf(buf, "%ld.%06ld S for %d ops",
		tv.wall.tv_sec, tv.wall.tv_usec, iters);
	info(buf);
	sprintf(buf, ":: %20s %10.1f nS [%s]", "ur_checksum",
		1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters,
		name);
	info(buf);
}
    
static int testlocal(void)
{
				/* From RFC 1321 */
	check("MD5", UR_CHECKSUM_MD5, "",
	      "d41d8cd98f00b204e9800998ecf8427e");
	check("MD5", UR_CHECKSUM_MD5, "a",
	      "0cc175b9c0f1b6a831c399e269772661");
	check("MD5", UR_CHECKSUM_MD5, "abc",
	      "900150983cd24fb0d6963f7d28e17f72");
	check("MD5", UR_CHECKSUM_MD5, "message digest",
	      "f96b697d7cb7938d525a2f31aaf161d0");
	check("MD5", UR_CHECKSUM_MD5, "abcdefghijklmnopqrstuvwxyz",
	      "c3fcd3d76192e4007dfb496cca67e13b");
	check("MD5", UR_CHECKSUM_MD5,
	      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	      "d174ab98d277d9f5a5611c2c9f419d9f");
	check("MD5", UR_CHECKSUM_MD5,
	      "1234567890123456789012345678901234567890123456789"
	      "0123456789012345678901234567890",
	      "57edf4a22be3c955ac49da2e2107b67a");
	return EXIT_SUCCESS;
}

static int time_local(void)
{
	timer("MD5", UR_CHECKSUM_MD5, "a");
	return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
	int retcode;

	ur_init(argv[0]);

	if (argc == 1) {
		if ((retcode = testcreate())) return retcode;
		if ((retcode = testlocal()))  return retcode;
	} else {
		if ((retcode = time_local()))  return retcode;
	}
	
	return EXIT_SUCCESS;
}
