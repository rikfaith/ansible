/* test-ur.c -- 
 * Created: Thu Dec 23 06:20:17 1999 by faith@acm.org
 * Copyright 1999-2000, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define FLAG1 0x00000001
#define FLAG2 0x40000010
#define FLAG3 0x80000100
#define FLAG4 0xc0001000

static int testlocal(const char *realprog)
{
    const char *prog;
    char       buf[2048];
    
    test("L", "Version String");
    ok(ur_version());
    
    test("L", "Version Major");
    sprintf(buf, "%d", ur_version_major());
    ok(buf);

    test("L", "Version Minor");
    sprintf(buf, "%d", ur_version_minor());
    ok(buf);

    test("L", "Version Patch");
    sprintf(buf, "%d", ur_version_patch());
    ok(buf);
    
    test("L", "Version Date");
    ok(ur_version_date());

    test("L", "Program Name");
    prog = ur_program_name();
    if (strcmp(realprog, prog)) fail(prog);
    ok(prog);

    test("L", "trace");
    ur_trace_register(FLAG1, "one");
    ur_trace_register(FLAG2, "two");
    ur_trace_set(FLAG1);
    if (!ur_trace_test(FLAG1)) fail("1 not set");
    ur_trace_unset(FLAG1);
    if (ur_trace_test(FLAG1)) fail("1 set a");
    if (ur_trace_test(FLAG2)) fail("2 set a");
    if (ur_trace_test(FLAG3)) fail("3 set a");
    if (ur_trace_test(FLAG4)) fail("4 set a");
    ur_trace_set(FLAG1);
    ur_trace_set(FLAG2);
    if (!ur_trace_test(FLAG1)) fail("1 not set b");
    if (!ur_trace_test(FLAG2)) fail("2 not set b");
    if (ur_trace_test(FLAG3)) fail("3 set b");
    if (ur_trace_test(FLAG4)) fail("4 set b");
    ur_trace_unset(FLAG2);
    if (!ur_trace_test(FLAG1)) fail("1 not set c");
    if (ur_trace_test(FLAG2)) fail("2 set c");
    if (ur_trace_test(FLAG3)) fail("3 set c");
    if (ur_trace_test(FLAG4)) fail("4 set c");
    ur_trace_unset(FLAG1);
    if (ur_trace_test(FLAG1)) fail("1 set d");
    if (ur_trace_test(FLAG2)) fail("2 set d");
    if (ur_trace_test(FLAG3)) fail("3 set d");
    if (ur_trace_test(FLAG4)) fail("4 set d");
    ok(0);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testlocal(argv[0])))  return retcode;
    }

    return EXIT_SUCCESS;
}
