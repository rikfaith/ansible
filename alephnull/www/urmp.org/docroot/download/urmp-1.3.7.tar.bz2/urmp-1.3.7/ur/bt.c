/* bt.c -- 
 * Created: Thu Aug  7 21:25:30 2008 by faith@acm.org
 * Revised: Tue Aug 12 13:15:16 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */


/*
 * The DWARF register number mapping is defined in the processor ABI.
 * For AMD64, see figure 3.36 on page 56 in "System V Application Binary
 * Interface: AMD64 Architecture Processor Supplement, Draft Version
 * 0.99", edited by Michael Matz, Jan Hubicka, Andreas Jaeger, and Mark
 * Mitchell, December 7, 2007.  Available from
 * http://www.x86-64.org/documentation/abi.pdf
 *
 * DWARF   AMD64    Intel32
 *  0      REG_RAX  REG_EAX
 *  1      REG_RDX  REG_ECX
 *  2      REG_RCX  REG_EDX
 *  3      REG_RBX  REG_EBX
 *  4      REG_RSI  REG_ESP
 *  5      REG_RDI  REG_EBP
 *  6      REG_RBP  REG_ESI
 *  7      REG_RSP  REG_EDI
 *  8
 *  9
 * 10
 * 11
 * 12
 * 13
 * 14
 * 15
 */

int main(int argc, char **argv)
{
	ur_init(argv[0]);
}
