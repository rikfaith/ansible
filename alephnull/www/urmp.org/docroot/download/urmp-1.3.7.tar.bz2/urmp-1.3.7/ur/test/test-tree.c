/* test-tree.c -- 
 * Created: Sun Aug  6 10:19:28 2000 by faith@dict.org
 * Copyright 2000, 2003 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-tree.c,v 1.4 2003-08-10 23:27:26 faith Exp $
 *
 */

#define OBJECTTYPE     ur_tree_t
#define OBJECTCREATE0  ur_tree_create
#define OBJECTDESTROY  ur_tree_destroy_tree

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    ur_tree_t      t, t2, t5;
    ur_tree_t      n;
    int           pos;
    ur_iterator_t  iter;
    int           retcode;
    
				/* Test with single node */
    test("L", "Inorder 1");
    t = ur_tree_create(1);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    retcode = ur_tree_iterator_next(&iter);
    if (retcode != 1) fail("a");
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    retcode = ur_tree_iterator_next(&iter);
    if (retcode != 0) fail("b");
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra 2");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Preorder 1");
    t = ur_tree_create(1);
    ur_tree_iterator_init(t, &iter, UR_TREE_PREORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    retcode = ur_tree_iterator_next(&iter);
    if (retcode != 0) fail("a");
    ok(0);
    end(t);

    test("L", "Postorder 1");
    t = ur_tree_create(1);
    ur_tree_iterator_init(t, &iter, UR_TREE_POSTORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    retcode = ur_tree_iterator_next(&iter);
    if (retcode != 0) fail("a");
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);
    
				/* Test with two nodes */
    test("L", "Inorder 2a");
    t = ur_tree_make(1, ur_tree_create(2), 0);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Inorder 2b (append)");
    t = ur_tree_make(1, 0);
    ur_tree_append(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Inorder 2c (insert after)");
    t = ur_tree_make(1, 0);
    ur_tree_insert_after(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Inorder 2d (insert last)");
    t = ur_tree_make(1, 0);
    ur_tree_insert_last(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Inorder 2e (insert last)");
    t = ur_tree_make(1, 0);
    ur_tree_insert_last(t, ur_tree_create(2));
    ur_tree_insert_last(t, ur_tree_create(3));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 3) fail("pre 3");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 3) fail("post 3");
    ok(0);
    ur_tree_print(t, NULL);
    end(t);

    test("L", "Preorder 2a");
    t = ur_tree_make(1, ur_tree_create(2), 0);
    ur_tree_iterator_init(t, &iter, UR_TREE_PREORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Preorder 2b (append)");
    t = ur_tree_make(1, 0);
    ur_tree_append(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_PREORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Preorder 2c (insert after)");
    t = ur_tree_make(1, 0);
    ur_tree_insert_after(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_PREORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != -1 || ur_tree_id(n) != 1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != -1 || ur_tree_id(n) != 2) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2a");
    t = ur_tree_make(1, ur_tree_create(2), 0);
    ur_tree_iterator_init(t, &iter, UR_TREE_POSTORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2b (append)");
    t = ur_tree_make(1, 0);
    ur_tree_append(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_POSTORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2c (insert after)");
    t = ur_tree_make(1, 0);
    ur_tree_insert_after(t, ur_tree_create(2));
    ur_tree_iterator_init(t, &iter, UR_TREE_POSTORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n != t || pos != 1 || ur_tree_id(n) != 1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (pos != 1 || ur_tree_id(n) != 2) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

				/* Test with multiple nodes */
    test("L", "Inorder 3a");
    t = ur_tree_make(1,
		    t2 = ur_tree_make(2, ur_tree_create(3), ur_tree_create(4), 0),
		    t5 = ur_tree_create(5),
		    0);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 2 || pos != -1) fail("pre 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 3 || pos != -1) fail("pre 3");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 3 || pos !=  1) fail("post 3");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 4 || pos != -1) fail("pre 4");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 4 || pos !=  1) fail("post 4");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 2 || pos !=  1) fail("post 2");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);

    test("L", "DestroyTree");
    ur_tree_destroy_tree(t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);

    test("L", "Prepend");
    t2 = ur_tree_make(20, ur_tree_create(30), ur_tree_create(40), 0);
    ur_tree_prepend(t, t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);

    test("L", "Disconnect");
    ur_tree_disconnect(t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);
    ur_tree_print(t2, NULL);

    test("L", "Append");
    ur_tree_append(t, t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);

    test("L", "Disconnect");
    ur_tree_disconnect(t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Insert Before");
    t2 = ur_tree_make(20, ur_tree_create(30), ur_tree_create(40), 0);
    ur_tree_insert_before(t5, t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Disconnect");
    ur_tree_disconnect(t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Insert After");
    ur_tree_insert_after(t5, t2);
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertFirst 1");
    ur_tree_insert_first(t5, ur_tree_create(6));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos != -1) fail("pre 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos !=  1) fail("post 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertFirst 2");
    ur_tree_insert_first(t2, ur_tree_create(7));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos != -1) fail("pre 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos !=  1) fail("post 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos != -1) fail("pre 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos !=  1) fail("post 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertLast 1");
    ur_tree_insert_last(t2, ur_tree_create(8));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos != -1) fail("pre 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos !=  1) fail("post 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos != -1) fail("pre 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos !=  1) fail("post 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 8 || pos != -1) fail("pre 8");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 8 || pos !=  1) fail("post 8");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertLast 2");
    ur_tree_insert_last(t5, ur_tree_create(9));
    ur_tree_iterator_init(t, &iter, UR_TREE_INORDER);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos != -1) fail("pre 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos != -1) fail("pre 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 7 || pos !=  1) fail("post 7");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos != -1) fail("pre 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 6 || pos !=  1) fail("post 6");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos != -1) fail("pre 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 5 || pos !=  1) fail("post 5");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos != -1) fail("pre 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos != -1) fail("pre 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 30 || pos !=  1) fail("post 30");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos != -1) fail("pre 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 40 || pos !=  1) fail("post 40");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 20 || pos !=  1) fail("post 20");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 8 || pos != -1) fail("pre 8");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 8 || pos !=  1) fail("post 8");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 9 || pos != -1) fail("pre 9");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 9 || pos !=  1) fail("post 9");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (ur_tree_id(n) != 1 || pos !=  1) fail("post 1");
    ur_tree_iterator_next(&iter);
    n = ur_tree_iterator_datum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    ur_tree_print(t, NULL);

    test("L", "String 1");
    if (ur_tree_has_string(t)) fail("has");
    ur_tree_set_string(t, "foo");
    if (!ur_tree_has_string(t)) fail("not has");
    if (strcmp(ur_tree_string(t), "foo")) fail(ur_tree_string(t));
    ok(0);

    test("L", "Integer 1");
    if (ur_tree_has_integer(t)) fail("has");
    ur_tree_set_integer(t, 31415);
    if (!ur_tree_has_integer(t)) fail("not has");
    if (ur_tree_integer(t) != 31415) fail(0);
    ok(0);

    test("L", "String 2");
    if (!ur_tree_has_string(t)) fail("not has a");
    ur_tree_set_string(t, "foobar");
    if (!ur_tree_has_string(t)) fail("not has b");
    if (strcmp(ur_tree_string(t), "foobar")) fail(ur_tree_string(t));
    ok(0);

    test("L", "Integer 2");
    if (ur_tree_has_integer(t2)) fail("has");
    ur_tree_set_integer(t2, 5);
    if (!ur_tree_has_integer(t2)) fail("not has");
    if (ur_tree_integer(t2) != 5) fail(0);
    ok(0);

    test("L", "Real");
    if (ur_tree_has_real(t5)) fail("has");
    ur_tree_set_real(t5, 3.1);
    if (!ur_tree_has_real(t5)) fail("not has");
    if (ur_tree_real(t5) < 3.1 || ur_tree_real(t5) > 3.1) fail(0);
    ok(0);

    test("L", "Attrib 1");
    ur_tree_set_attrib(t5, "attrib1", "val1");
    if (strcmp("val1", ur_tree_attrib(t5, "attrib1"))) fail(0);
    ok(0);

    ur_tree_print(t, NULL);
    end(t);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
