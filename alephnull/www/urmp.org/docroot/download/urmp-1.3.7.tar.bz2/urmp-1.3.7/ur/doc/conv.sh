#!/bin/sh
# conv.sh -- 
# Created: Mon Jul 14 16:25:30 2008 by faith@acm.org
# Revised: Mon Jul 14 20:14:04 2008 by faith@acm.org
# Copyright 2008 Rickard E. Faith (faith@acm.org)
# This program comes with ABSOLUTELY NO WARRANTY.
# 
# $Id$
# 
#

cat $1 \
    | sed 's,MAA_,UR_,g' \
    | sed 's,MAAP_,URP_,g' \
    | sed 's,maa\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\),ur_\l\1_\l\2_\l\3_\l\4,g' \
    | sed 's,maa\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\),ur_\l\1_\l\2_\l\3,g' \
    | sed 's,maa\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9]*\),ur_\l\1_\l\2,g' \
    | sed 's,maa\([A-Z][a-z0-9]*\),ur_\l\1,g' \
    | sed 's,ur_a_v_l_,ur_avl_,g' \
    | sed 's,ur_avl_tree\([A-Z][a-z0-9]*\)\([A-Z][a-z0-9_]*\),url_avl_\l\1_\l\2,g' \
    | sed 's,ur_avl_tree\([A-Z][a-z0-9]*\),url_avl_\l\1,g' \
    | sed 's,ur_p.h",urP.h",g' \
    | sed 's,maa.h",ur.h",g' \
    | sed 's,urP.h$,urP.h",g' \
    | sed 's,ur_alloc_z,ur_allocz,g' \
    | sed 's,ur_realloc_z,ur_reallocz,g' \
    | sed 's,ur_skip_list_,ur_sl_,g' \
    | cat
