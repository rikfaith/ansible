/* tree.c -- 
 * Created: Mon Jul 10 13:43:52 2000 by faith@dict.org
 * Copyright 2000, 2004, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: tree.c,v 1.5 2004-02-09 02:36:27 faith Exp $
 * 
 */

#include "urP.h"

typedef enum {
    UR_TREE_STRING = 0x0001,
    UR_TREE_INT    = 0x0002,
    UR_TREE_REAL   = 0x0004
} ur_tree_mask_t;

struct ur_tree_s {
    unsigned long   magic;
    int             id;		/* Node id */
    int             head;	/* Non-zero if head of sibling list */
    struct ur_tree_s *left;	/* Left sibling */
    struct ur_tree_s *right;	/* Right sibling */
    struct ur_tree_s *down;	/* Children */
    struct ur_tree_s *parent;	/* Parent */
    ur_tree_mask_t    attribs;	/* Attributes set */
    const char      *string;	/* Attribute */
    int             integer;	/* Attribute */
    double          real;	/* Attribute */
    ur_list_t        list;	/* Attribute list */
};

static ur_block_t _ur_tree_block;

CHECK_FUNCTION(_ur_tree_check, ur_tree_t, UR_TREE_MAGIC)

ur_tree_t ur_tree_create(int id)
{
    ur_tree_t node;

    if (UR_USE_BLOCK && !_ur_tree_block)
	_ur_tree_block = ur_block_create(sizeof(*node));

    node        = (_ur_tree_block
		   ? ur_block_alloc_z(_ur_tree_block)
		   : ur_allocz(sizeof(*node)));
    
    node->magic = UR_TREE_MAGIC;
    node->id    = id;
    node->right = node->left = node;
    node->head  = 1;

    return node;
}

ur_tree_t ur_tree_make(int id, ...)
{
    va_list  ap;
    ur_tree_t n;
    ur_tree_t node;

    node = ur_tree_create(id);
    va_start(ap, id);
    while ((n = va_arg(ap, ur_tree_t))) {
	_ur_tree_check(n);	/* May fail if no terminating 0 */
	if (n->parent) ur_internal(__FUNCTION__, "Node has parent\n");
	ur_tree_append(node, n);
    }
    va_end(ap);
    
    return node;
}

unsigned long ur_tree_destroy_node(ur_tree_t node)
{
    unsigned long  ret;
    
    _ur_tree_check(node);

    if (node->down || node->left != node || node->right != node)
        ur_internal(__FUNCTION__, "Attempt to destroy linked node\n");

    if (node->parent && node->parent->down == node)
	node->parent->down = NULL;
    ret      = node->magic = ~UR_TREE_MAGIC;
    node->id = -node->id;

    if (node->list) {
	ur_iterator_t   iter;
	ur_tree_attrib_t pair;

	UR_LIST_ITERATE(node->list, iter, pair) ur_free(pair);
	ur_list_destroy(node->list);
    }
    
    if (_ur_tree_block) ur_block_free(_ur_tree_block, node);
    else                ur_free(node);
    
    return ret;
}

unsigned long ur_tree_destroy_tree(ur_tree_t root)
{
    ur_tree_t top;
    ur_tree_t pt;
    ur_tree_t old;
    
    _ur_tree_check(root);

    top = ur_tree_disconnect(root);
    
    if (!top->down) return ur_tree_destroy_node(top); /* No children */

    for (pt = top;;) {
	if (pt->down) pt = pt->down;
	else {
	    if (!pt->right->head) {
		old = pt;
		pt  = pt->right;
                ur_tree_disconnect(old);
		ur_tree_destroy_node(old);
	    } else {
		do {
		    old = pt;
		    if (!pt->parent)
			ur_internal(__FUNCTION__, "Parent doesn't exist\n");
		    pt = pt->parent;
                    ur_tree_disconnect(old);
		    ur_tree_destroy_node(old);
		    if (pt == top) return ur_tree_destroy_node(top);
		} while (pt->right->head);
		old = pt;
		pt  = pt->right;
                ur_tree_disconnect(old);
		ur_tree_destroy_node(old);
	    }
	}
    }
}

/* Disconnect subtree rooted at node and return pointer to node. */

ur_tree_t ur_tree_disconnect(ur_tree_t node)
{
    _ur_tree_check(node);

    if (!node) return NULL;

				/* Make sibling a proper head */
    if (node->head) {
	node->right->head = 1;

	if (node->parent) {
	    if (node->parent->down != node)
		ur_internal(__FUNCTION__,
			    "Head node is not parent's child\n");
	    if (node->right != node) node->parent->down = node->right;
	    else                     node->parent->down = NULL;
	}
    }

				/* Disconnect from siblings */
    node->right->left = node->left;
    node->left->right = node->right;
    node->right       = node->left = node;
    node->parent      = NULL;
    node->head        = 1;

    return node;
}

ur_tree_t ur_tree_append(ur_tree_t parent, ur_tree_t child)
{
    _ur_tree_check(parent);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");

    if (parent->down) {		/* Parent already has children */
	child->right              = parent->down;
	child->left               = parent->down->left;
	child->head               = 0;
	parent->down->left->right = child;
	parent->down->left        = child;
    } else {			/* Parent doesn't have children */
	parent->down = child;
	child->head  = 1;
    }
    
    child->parent = parent;

    return parent;
}

ur_tree_t ur_tree_prepend(ur_tree_t parent, ur_tree_t child)
{
    _ur_tree_check(parent);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");
    
    if (parent->down) {		/* Parent already has children */
	child->right              = parent->down;
	child->left               = parent->down->left;
	parent->down->left->right = child;
	parent->down->left        = child;
	parent->down->head        = 0;
    }
    
    parent->down  = child;
    child->head   = 1;
    child->parent = parent;

    return parent;
}

ur_tree_t ur_tree_insert_before(ur_tree_t sibling, ur_tree_t child)
{
    _ur_tree_check(sibling);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");

    child->left          = sibling->left;
    child->right         = sibling;
    child->parent        = sibling->parent;
    sibling->left->right = child;
    sibling->left        = child;

    if (sibling->head) {
	sibling->head = 0;
	child->head   = 1;
	if (sibling->parent) sibling->parent->down = child;
    } else {
	child->head   = 0;
    }

    return sibling;
}

ur_tree_t ur_tree_insert_after(ur_tree_t sibling, ur_tree_t child)
{
    _ur_tree_check(sibling);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");

    child->left          = sibling;
    child->right         = sibling->right;
    child->parent        = sibling->parent;
    child->head          = 0;
    sibling->right->left = child;
    sibling->right       = child;

    return sibling;
}

ur_tree_t ur_tree_insert_last(ur_tree_t sibling, ur_tree_t child)
{
    ur_tree_t point;
    
    _ur_tree_check(sibling);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");

				/* Find last sibling */
    if (sibling->head) {
	point = sibling->left;
    } else { 
	for (point = sibling; !point->right->head; point = point->right)
	    ;
    }
    ur_tree_insert_after(point, child);
    
    return sibling;
}

ur_tree_t ur_tree_insert_first(ur_tree_t sibling, ur_tree_t child)
{
    ur_tree_t point;
    
    _ur_tree_check(sibling);
    _ur_tree_check(child);

    if (child->parent) ur_internal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	ur_internal(__FUNCTION__, "Child has siblings\n");

				/* Find first sibling */
    for (point = sibling; !point->head; point = point->left)
	;
    ur_tree_insert_before(point, child);
    
    return sibling;
}
	
void ur_tree_set_string(ur_tree_t node, const char *string)
{
    _ur_tree_check(node);
    node->string   = string ? ur_atom_string(string) : NULL;
    node->attribs |= UR_TREE_STRING;
}

void ur_tree_set_integer(ur_tree_t node, int i)
{
    _ur_tree_check(node);
    node->integer  = i;
    node->attribs |= UR_TREE_INT;
}

void ur_tree_set_real(ur_tree_t node, double r)
{
    _ur_tree_check(node);
    node->real     = r;
    node->attribs |= UR_TREE_REAL;
}

void ur_tree_set_attrib(ur_tree_t node, const char *name, const char *value)
{
    ur_tree_attrib_t pair;

    _ur_tree_check(node);
    if (!name) return;
    pair        = ur_allocz(sizeof(*pair));
    pair->name  = ur_atom_string(name);
    pair->value = value ? ur_atom_string(value) : NULL;
    if (!node->list) node->list = ur_list_create();
    ur_list_append(node->list, pair);
}

int ur_tree_has_string(ur_tree_t node)
{
    _ur_tree_check(node);
    return (node->attribs & UR_TREE_STRING) != 0;
}

int ur_tree_has_integer(ur_tree_t node)
{
    _ur_tree_check(node);
    return (node->attribs & UR_TREE_INT) != 0;
}

int ur_tree_has_real(ur_tree_t node)
{
    _ur_tree_check(node);
    return (node->attribs & UR_TREE_REAL) != 0;
}

int ur_tree_has_attrib(ur_tree_t node)
{
    _ur_tree_check(node);
    return (node->list != NULL);
}

int ur_tree_id(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->id;
}

ur_tree_t ur_tree_parent(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->parent;
}

ur_tree_t ur_tree_child(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->down;
}

ur_tree_t ur_tree_sibling(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->right != node ? node->right : NULL;
}

const char *ur_tree_string(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->string;
}

int ur_tree_integer(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->integer;
}

double ur_tree_real(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->real;
}

const char *ur_tree_attrib(ur_tree_t node, const char *name)
{
    ur_iterator_t   iter;
    ur_tree_attrib_t pair;
    const char     *n;
    
    _ur_tree_check(node);
    if (!node->list || !name) return NULL;
    n = ur_atom_string(name);
    UR_LIST_ITERATE(node->list, iter, pair) {
	if (pair->name == n) return pair->value;
    }
    return NULL;
}

ur_list_t ur_tree_attrib_list(ur_tree_t node)
{
    _ur_tree_check(node);
    return node->list;
}

void ur_tree_iterator_init(ur_tree_t node, ur_iterator_t *iter, ur_tree_walk_t walk)
{
    _ur_tree_check(node);
    
    iter->a = node;
    iter->b = NULL;
    iter->c = walk;
    iter->d = 0;
    iter->e = 1;
    ur_tree_iterator_next(iter);
}

int ur_tree_iterator_next(ur_iterator_t *iter)
{
    ur_tree_t     root = iter->a;
    ur_tree_t     this = iter->b;
    ur_tree_walk_t walk = iter->c;
    int          pos  = iter->d;

    if (!iter->e) return 0;	/* End of walk */
    
    for (;;) {
	if (!this) {
	    this = root, pos  = -1;
	} else {
	    if (pos == 1 && this->right == root) {
		iter->b = NULL;
		iter->e = 0;
		return 0;
	    }
	    if (pos == -1) {
		if (this->down) this = this->down, pos = -1;
		else            pos = 1;
	    } else {
		if (!this->right->head) this = this->right, pos = -1;
		else {
		    if (pos == 1) {
			if (!this->parent)
			    ur_internal(__FUNCTION__, "No parent\n");
			this = this->parent, pos = 1;
		    } else
			pos = 1;
		}
	    }
	}
	if (walk == UR_TREE_PREORDER  && pos != -1) continue;
	if (walk == UR_TREE_POSTORDER && pos !=  1) continue;
	iter->b = this;
	iter->d = pos;
	return 1;
    }
}

ur_tree_t ur_tree_iterator_datum(ur_iterator_t *iter, int *position)
{
    _ur_tree_check(iter->a);
    if (position) *position = iter->d;
    return iter->b;
}

void ur_tree_print(ur_tree_t root, FILE *stream)
{
    ur_iterator_t iter;
    ur_tree_t     node;
    int          pos;
    int          offset = 0;
    int          first  = 1;
    int          nodes  = 0;
    
    _ur_tree_check(root);
    if (!stream) stream = stdout;

    UR_TREE_ITERATE(root, iter, node, UR_TREE_INORDER, pos) {
	nodes = 1;
	if (pos < 0) {
	    if (first) first = 0;
	    else       fprintf(stream, "\n");
	    fprintf(stream, "%*c%d", offset += 2, '(', ur_tree_id(node));
	    if (ur_tree_has_integer(node))
		fprintf(stream, "/%d", ur_tree_integer(node));
	    if (ur_tree_has_real(node))
		fprintf(stream, "/%f", ur_tree_real(node));
	    if (ur_tree_has_string(node))
		fprintf(stream, "/\"%s\"", ur_tree_string(node));
	    if (ur_tree_has_attrib(node)) {
		ur_iterator_t   iter2;
		ur_tree_attrib_t pair;
		ur_list_t       list = ur_tree_attrib_list(node);

		UR_LIST_ITERATE(list, iter2, pair) {
		    fprintf(stream, " [%s=%s]", pair->name, pair->value);
		}
	    }
	} else {
	    fprintf(stream, ")");
	    offset -= 2;
	}
    }
    if (nodes) printf("\n");
}
