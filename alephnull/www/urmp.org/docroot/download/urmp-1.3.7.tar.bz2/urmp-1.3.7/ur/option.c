/* option.c -- 
 * Created: Mon Jul  5 16:21:58 1999 by faith@dict.org
 * Copyright 1999, 2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: option.c,v 1.6 2003-06-14 12:14:33 faith Exp $
 * 
 */

#include "urP.h"

struct ur_option_s {
	unsigned long    magic;
    
	int              argc;
	const char       **argv;
	ur_option_list_t *list;
	ur_list_t        other;
    
	const char       *arg;
	int              argfree;
	int              ind;
	int              next_short;
	int              listfree;
};

CHECK_FUNCTION(_ur_option_check, ur_option_t, UR_OPTION_MAGIC)

ur_option_t ur_option_create(ur_option_list_t *list)
{
	ur_option_t opt = ur_allocz(sizeof(*opt));

	opt->magic = UR_OPTION_MAGIC;
	opt->list  = list;
	return opt;
}

void ur_option_parse_argv(ur_option_t opt, int argc, const char **argv)
{
	_ur_option_check(opt);

	if (opt->argfree  && opt->argv)  ur_free(opt->argv);
	if (opt->listfree && opt->other) ur_list_destroy(opt->other);
    
	opt->argc       = argc;
	opt->argv       = argv;
	opt->argfree    = 0;
    
	opt->arg        = NULL;
	opt->ind        = 1;
	opt->next_short = 0;
    
	opt->other      = ur_list_create();
	opt->listfree   = 1;
}

void ur_option_parse_string(ur_option_t opt, const char *string)
{
	int        argc;
	const char **argv;
	ur_list_t   list;
    
	_ur_option_check(opt);
	list = ur_list_create();
	ur_list_parse_string(list, string);
	ur_list_make_argv(list, &argc, &argv);
	ur_list_destroy(list);
	ur_option_parse_argv(opt, argc, argv);
	opt->argfree    = 1;
	opt->ind        = 0;
}

void ur_option_parse_list(ur_option_t opt, ur_list_t list)
{
	int        argc;
	const char **argv;

	_ur_option_check(opt);
	ur_list_make_argv(list, &argc, &argv);
	ur_option_parse_argv(opt, argc, argv);
	opt->argfree = 1;
	opt->ind     = 0;
}

unsigned long ur_option_destroy(ur_option_t opt)
{
	unsigned long ret;
    
	_ur_option_check(opt);
	ret = opt->magic = ~UR_OPTION_MAGIC;
	if (opt->argfree  && opt->argv)  ur_free(opt->argv);
	if (opt->listfree && opt->other) ur_list_destroy(opt->other);
	ur_free(opt);
	return ret;
}

static void _ur_option_get_arg(ur_option_t opt)
{
	if (opt->next_short && opt->argv[opt->ind][opt->next_short + 1])
		opt->arg = ur_atom_string(&opt->argv[opt->ind]
					  [opt->next_short + 1]);
	else
		opt->arg = ur_atom_string(opt->argv[++opt->ind]);
	opt->next_short = 0;
}

static int _ur_option_short(ur_option_t opt)
{
	ur_option_list_t *pt;
    
	if (!opt->next_short) opt->next_short = 1;
    
	for (pt = opt->list; pt && pt->shortname; ++pt) {
		if (pt->shortname == opt->argv[opt->ind][opt->next_short]) {
			if (pt->type != UR_OPTION_NONE) {
				_ur_option_get_arg(opt);
				++opt->ind;
			} else if (!opt->argv[opt->ind][++opt->next_short]) {
				opt->next_short = 0;
				++opt->ind;
			}
			return pt->shortname;
		}
	}
	return '?';
}

static int _ur_option_long(ur_option_t opt)
{
	ur_option_list_t *pt;

	for (pt = opt->list; pt && pt->longname; ++pt) {
		if (!strcmp(pt->longname, &opt->argv[opt->ind][2])) {
			if (pt->type != UR_OPTION_NONE)
				_ur_option_get_arg(opt);
			++opt->ind;
			return pt->shortname;
		}
	}
	return '?';
}

static void _ur_option_get_other(ur_option_t opt)
{
	int i;

	for (i = opt->ind; i < opt->argc; i++) {
		ur_list_append(opt->other, ur_atom_string(opt->argv[i]));
	}
}

int ur_option_get(ur_option_t opt)
{
	_ur_option_check(opt);

	opt->arg = NULL;
	if (opt->next_short) return _ur_option_short(opt);
	if (opt->ind >= opt->argc) {
		_ur_option_get_other(opt);
		return EOF;
	}
	if (opt->argv[opt->ind][0] != '-'
	    || (opt->argv[opt->ind][0] && opt->argv[opt->ind][1] == '\0')) {
		_ur_option_get_other(opt);
		return EOF; /* FIXME: try to permute */
	}
	if (opt->argv[opt->ind][1] != '-') {
		return _ur_option_short(opt);
	}
	if (opt->argv[opt->ind][2] == '\0') {
		++opt->ind;		/* skip -- */
		_ur_option_get_other(opt);
		return EOF;
	}
	return _ur_option_long(opt);
}

long ur_option_int(ur_option_t opt)
{
	_ur_option_check(opt);

	return opt->arg ? strtol(opt->arg, NULL, 0) : 0;
}

double ur_option_real(ur_option_t opt)
{
	_ur_option_check(opt);
	return opt->arg ? strtod(opt->arg, NULL) : 0;
}

const char *ur_option_string(ur_option_t opt)
{
	_ur_option_check(opt);
	return opt->arg;
}

ur_list_t ur_option_list(ur_option_t opt, ur_list_t current_list)
{
	char     *buf;
	char     *pt;
	char     *prev;
	ur_list_t list;
    
	_ur_option_check(opt);
	if (!opt->arg) return current_list;
	
	if (current_list) {
	    list = current_list;
	} else {
		list = ur_list_create();
	}
	buf  = ur_alloc(strlen(opt->arg) + 1);
	strcpy(buf, opt->arg);
	for (pt = prev = buf; pt; pt++) {
		if (!*pt || *pt == ',') {
			char save = *pt;
			*pt = '\0';
			ur_list_append(list, ur_atom_string(prev));
			prev = pt + 1;
			*pt = save;
		}
		if (!*pt) break;
	}
	ur_free(buf);
	return list;
}

ur_list_t ur_option_other(ur_option_t opt, ur_list_t current_list)
{
	void      *datum;

	_ur_option_check(opt);
	if (!opt->other || !ur_list_depth(opt->other)) return current_list;

	opt->listfree = 0;
	if (!current_list) {
		return opt->other;
	}
	while ((datum = ur_list_last(opt->other))) {
		ur_list_push(current_list, datum);
	}
	return current_list;
}

int ur_option_in_range(const char *range, unsigned long val)
{
	const char    *pt;
	char          *endptr;
	unsigned long v0, v1;
	
	if (!range) return 1;
	for (pt = range;; pt = endptr) {
		if (*pt == ',') ++pt;
		if (*pt == '-') {
			v0     = 0;
			endptr = (char *)pt;
		} else {
			v0 = strtoul(pt, &endptr, 0);
			if (pt == endptr && *endptr) {
				++endptr;
				v0 = 0;
			}
		}
		if (*endptr == '-') {
			v1 = strtoul(endptr + 1, &endptr, 0);
			if (val >= v0 && val <= v1)            return 1;
			if (v0 > v1 && val <= v0 && val >= v1) return 1;
		} else if (val == v0) return 1;
		if (!*endptr) return 0;
	}
}
