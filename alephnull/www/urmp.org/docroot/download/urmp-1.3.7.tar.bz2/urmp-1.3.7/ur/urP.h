/* urP.h -- Private header for ur
 * Created: Sun Jul  4 11:25:37 1999 by faith@dict.org
 * Revised: Tue May 26 05:40:30 2009 by faith@dict.org
 * Copyright 1999-2000, 2003, 2008-2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: ur_p.h,v 1.23 2003-09-06 03:03:52 faith Exp $
 * 
 */

#ifndef _URP_H_
#define _URP_H_

#include "standard.h"
#include "ur.h"
#include "version.h"
#include "config.h"

#if defined(__GNUC__) && !defined(__LCLINT__)
#define __unused __attribute__((unused))
#else
#define __unused
#endif

#define UR_ARENA_MAGIC        0x55727701LU
#define UR_AVLTREE_MAGIC      0x55727702LU
#define UR_BLOCK_MAGIC        0x55727703LU
#define UR_BLOCK_NEXT_MAGIC   0x55727704LU
#define UR_FLAG_MAGIC         0x55727705LU
#define UR_HASH_MAGIC         0x55727706LU
#define UR_LIST_MAGIC         0x55727707LU
#define UR_OPTION_MAGIC       0x55727708LU
#define UR_RANDOM_MAGIC       0x55727709LU
#define UR_SKIPLIST_MAGIC     0x5572770aLU
#define UR_STACK_MAGIC        0x5572770bLU
#define UR_TIMER_MAGIC        0x5572770cLU
#define UR_TREE_MAGIC         0x5572770dLU
#define UR_FILE_MAGIC         0x5572770eLU
#define UR_MAIL_MAGIC         0x5572770fLU
#define UR_NGRAM_MAGIC        0x55727710LU
#define UR_TRIGRAM_MAGIC      0x55727711LU
#define UR_NET_MAGIC          0x55727712LU
#define UR_BUF_MAGIC          0x55727713LU
#define UR_BUF_CHUNK_MAGIC    0x55727714LU
#define UR_BUF_BUFFER_MAGIC   0x55727715LU
#define UR_PROC_MAGIC	      0x55727716LU
#define UR_MSG_MAGIC	      0x55727717LU
#define UR_ELF_MAGIC	      0x55727718LU
#define UR_ID3_MAGIC          0x55727719LU
#define UR_MSG_RECV_MAGIC     0x5572771aLU
#define UR_PARSE_MAGIC        0x5572771bLU
#define UR_CACHE_MAGIC        0x5572771cLU
#define UR_CHECKSUM_MAGIC     0x5572771dLU

#define UR_TRACE_CHILD_WAIT   0xc0000001UL
#define UR_TRACE_PROC         0xc0000002UL
#define UR_TRACE_MSG          0xc0000004UL
#define UR_TRACE_ELF          0xc0000010UL
#define UR_TRACE_PACK         0xc0000020UL
#define UR_TRACE_PR	      0xc0000040UL
#define UR_TRACE_ID3	      0xc0000080UL
#define UR_TRACE_ID3_AUGMENT  0xc0000100UL
#define UR_TRACE_PARSE        0xc0000200UL
#define UR_TRACE_CACHE	      0xc0000400UL

#define UR_DEBUG_ID3_ZERO     0xc0000001UL

#define UR_USE_BLOCK          1	/* Use block allocator internally */

#define UR_ARENA_CHUNK        (16*1024)
#define UR_BUF_CHUNK          1024
#define UR_MAIL_CHUNK         4096
#define UR_MAIL_FUDGE         32       /* Guess at malloc overhead */

#define UR_HASH_SEGMENT_COUNT 1024
#define UR_HASH_BUCKET_COUNT  64
#define UR_HASH_BUCKET_MASK   (UR_HASH_BUCKET_COUNT - 1)
#define UR_HASH_MIN_BUCKETS   1
#define UR_HASH_BUCKET_LOAD   5.0
#define UR_HASH_BUCKET_MARK   0.25

#define UR_SKIPLIST_MAXLEVEL  15

#define CHECK_FUNCTION(name,type,magicvalue)                      \
static __inline__ void name(type object)                          \
{                                                                 \
    if (!object) ur_fatal(__FUNCTION__, "Null object\n");         \
    if (object->magic != magicvalue)                              \
	ur_fatal(__FUNCTION__,                                    \
		 "Bad magic (found 0x%08lx instead of 0x%08lx\n", \
		 object->magic,                                   \
		 magicvalue);                                     \
}

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#endif
