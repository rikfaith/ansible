/* test-proc.c -- 
 * Created: Sun Aug  3 11:02:44 2008 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#include "standard.h"
#include "ur.h"
#include "common.h"
#include <signal.h>

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define _unused __attribute__((unused))

static bool verbose = false;

static int domsg(ur_msg_t msg, int type _unused , void *buf,
		 int length _unused, void *arg _unused)
{
	int val;
	char sbuf[100];

	val = strtol(buf, NULL, 0);
	if (verbose) printf("Received msg=%p from val=%d\n", (void *)msg, val);
	fflush(stdout);
	memset(sbuf, 0, sizeof(sbuf));
	snprintf(sbuf, sizeof(sbuf), "%d", val * 2);
	ur_msg_reply(msg, 0, sbuf, sizeof(sbuf));
	if (verbose) printf("Reply %s sent...\n", sbuf);
	fflush(stdout);
	return 0;
}

static int work(ur_msg_t msg _unused, int type _unused, void *buf _unused,
		int length _unused, void *arg)
{
	char *string = (char *)arg;
	int i;

	for (i = 0; i < 3; i++) {
		printf("CHILD: %s\n", string);
		sleep(1);
	}
	return 0;
}

static int cleanup(int pid, int status, int err,
		   void *arg __attribute__((unused)))
{
	if (status > 0) {
		printf("caught %s for pid=%d, status=%d, errno=%d\n",
		       ur_signal_name(status), pid, status, err);
	} else {
		printf("got %d for pid %d, errno=%d\n",
		       status, pid, errno);
	}
	fflush(stdout);
	return 0;
}

static void __attribute__((noreturn)) usage(void)
{
	ur_list_t list;
	const char *str;

	printf("usage: test-proc [-t trace-list]\n");
	if ((list = ur_trace_names())) {
		printf("       trace-list in:\n");
		while ((str = ur_list_pop(list))) {
			printf("           %s\n", str);
		}
	}
	exit(1);
}

static void handler(int sig _unused)
{
}

static void init(void)
{
	int              sig[] = { SIGHUP, SIGINT, SIGQUIT, SIGILL,
				   SIGBUS, SIGFPE, SIGSEGV, SIGTERM };
	size_t           i;
	struct sigaction a;

	for (i = 0; i < sizeof(sig)/sizeof(sig[0]); i++) {
		memset(&a, 0, sizeof(a));
		a.sa_handler = handler;
		sigemptyset(&a.sa_mask);
		sigaddset(&a.sa_mask, sig[i]);
		sigaction(sig[i], &a, NULL);
	}
}

int main(int argc, const char **argv)
{
	ur_proc_t        proc;
	ur_msg_t         msg;
	ur_list_t        list = NULL;
	ur_option_t      opt;
	ur_option_list_t optlist[] = {
		{ "trace", 't', UR_OPTION_LIST },
		{ "verbose", 'v', UR_OPTION_LIST },
		{ NULL, 0, 0 }
	};
	int c;
	char *str;
	char buf[4096];
	int val;
	int len;
	char mbuf[512];

	ur_init(argv[0]);
	init();

	opt = ur_option_create(optlist);
	ur_option_parse_argv(opt, argc, argv);
	while ((c = ur_option_get(opt)) != EOF) {
		switch (c) {
		case 't':
			list = ur_option_list(opt, list);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_trace_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		case 'v':
			verbose = true;
			break;
		default:
			usage();
		}
		
	}

	test("L", "Ping");
	fflush(stdout);
	proc = ur_proc_create(domsg, NULL, cleanup, NULL, NULL, NULL);
	snprintf(buf, sizeof(buf), "%d", 37);
	len = strlen(buf) + 1;
	msg = ur_msg_send(proc, UR_MSG_PING, buf, len);
	if (!msg) {
		fail("Message not sent");
		return 1;
	}
	memset(buf, 0, sizeof(buf));
	msg = ur_msg_wait(msg, buf, sizeof(buf));
	if (!msg) {
		fail("Message reply not received");
		return 1;
	}
	if (ur_msg_reply_type(msg) != UR_MSG_PING) {
		fail("Reply type was not UR_MSG_PING");
		return 1;
	}
	val = strtol(buf, NULL, 0);

	sprintf(mbuf, "%d %lu", val, ur_msg_sequence(msg));
	if (val == 37 && ur_msg_sequence(msg) == 2) {
		ok(mbuf);
	} else {
		fail(mbuf);
	}
		  
	if (verbose) {
		printf("Value:         %d\n", val);
		printf("Sequence:      %lu\n", ur_msg_sequence(msg));
		printf("Time sent:     %lu\n", ur_msg_time_sent(msg));
		printf("Time received: %lu\n", ur_msg_time_received(msg));
		printf("Time replied:  %lu\n", ur_msg_time_replied(msg));
	}
	ur_msg_destroy(msg);


	test("L", "Message passing");
	fflush(stdout);
	snprintf(buf, sizeof(buf), "%d", 37);
	len = strlen(buf) + 1;
	msg = ur_msg_send(proc, 1, buf, len);
	if (!msg) {
		fail("Message not sent");
		return 1;
	}
	memset(buf, 0, sizeof(buf));
	msg = ur_msg_wait(msg, buf, sizeof(buf));
	if (!msg) {
		fail("Message reply not received");
		return 1;
	}
	val = strtol(buf, NULL, 0);
	sprintf(mbuf, "%d %lu", val, ur_msg_sequence(msg));
	if (val == 2 * 37 && ur_msg_sequence(msg) == 3) {
		ok(mbuf);
	} else {
		fail(mbuf);
	}
		  
	if (verbose) {
		printf("Value:         %d\n", val);
		printf("Sequence:      %lu\n", ur_msg_sequence(msg));
		printf("Time sent:     %lu\n", ur_msg_time_sent(msg));
		printf("Time received: %lu\n", ur_msg_time_received(msg));
		printf("Time replied:  %lu\n", ur_msg_time_replied(msg));
	}
	ur_msg_destroy(msg);
	ur_proc_destroy(proc);
		    
	return EXIT_SUCCESS;

	test("L", "Process creation");
	ok(0);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	sleep(5);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	sleep(1);
	ur_proc_destroy_all();

	return EXIT_SUCCESS;
}
