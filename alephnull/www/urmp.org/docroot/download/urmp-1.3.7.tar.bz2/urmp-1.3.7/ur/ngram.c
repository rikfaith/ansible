/* ngram.c -- 
 * Created: Thu Jun 12 13:08:24 2003 by faith@dict.org
 * Copyright 2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: ngram.c,v 1.2 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "urP.h"
#include <math.h>

struct ur_ngram_s {
    unsigned long magic;
    int           n;
    ur_hash_t      hash;
    unsigned long unique_ngrams;
    unsigned long total_ngrams;
};

CHECK_FUNCTION(_ur_ngram_check, ur_ngram_t, UR_NGRAM_MAGIC)

ur_ngram_t ur_ngram_create(int n)
{
    ur_ngram_t ng = ur_allocz(sizeof(*ng));

    ng->magic = UR_NGRAM_MAGIC;
    ng->n     = n;
    ng->hash  = ur_hash_create(NULL, NULL);
    return ng;
}

unsigned long ur_ngram_destroy(ur_ngram_t ng)
{
    unsigned long ret;
    
    _ur_ngram_check(ng);
    ret = ng->magic = ~UR_NGRAM_MAGIC;
    if (ng->hash) ur_hash_destroy(ng->hash);
    ur_free(ng);
    return ret;
}

int ur_ngram_put(ur_ngram_t ng, const char *filename)
{
    ur_iterator_t     iter;
    const char       *key;
    unsigned long    datum;
    FILE             *str;

    _ur_ngram_check(ng);
    if (!(str = fopen(filename, "w"))) return -1;

    fprintf(str, "0x%08lx %d %zd %zd %lu %lu\n",
            ng->magic, ng->n, sizeof(datum), sizeof(*key),
            ng->unique_ngrams, ng->total_ngrams);
    UR_HASH_ITERATE_UL(ng->hash, iter, key, datum) {
	    fwrite(key,    sizeof(*key),  ng->n, str);
	    fwrite(&datum, sizeof(datum), 1,     str);
    }
    fclose(str);
    return 0;
}

ur_ngram_t ur_ngram_get(const char *filename)
{
    unsigned long  magic;
    unsigned long  dsize, ksize, klen;
    const char     *key;
    unsigned long  datum;
    FILE           *str;
    char           *buf;
    ur_ngram_t      ng;
    int            retval;
    
    if (!(str = fopen(filename, "r"))) return NULL;
    ng = ur_ngram_create(0);
    retval = fscanf(str, "0x%08lx %d %lu %lu %lu %lu\n",
		    &magic, &ng->n, &dsize, &ksize,
		    &ng->unique_ngrams, &ng->total_ngrams);
    if (retval           < 6
	|| ng->magic     != magic
        || ksize         != sizeof(*key)
        || dsize         != sizeof(datum)) {
        ur_ngram_destroy(ng);
        return NULL;
    }
    klen = ksize * ng->n;
    buf  = ur_alloc(klen + dsize + 1);
    while (fread(buf, klen + dsize, 1, str)) {
        key       = ur_atom_string_n(buf, klen);
        datum     = *(unsigned long *)(buf + klen);
        ur_hash_insert_ul(ng->hash, key, datum);
    }
    ur_free(buf);
    return ng;
}

void ur_ngram_add(ur_ngram_t ng, const void *buf, int len)
{
    int           i;
    const char    *pt;
    unsigned long value;
    const void    *ngram;

    _ur_ngram_check(ng);
    if (!len) len = strlen(buf);

    for (i = 0, pt = buf; pt && *pt && i < len - ng->n; ++pt, ++i) {
        ngram = ur_atom_string_n(pt, ng->n);
        value = ur_hash_lookup_ul(ng->hash, ngram);
        if (!value) ++ng->unique_ngrams;
        ++ng->total_ngrams;
        ur_hash_insert_ul(ng->hash, ngram, value + 1);
    }
}

void ur_ngram_print(ur_ngram_t ng, FILE *stream __unused)
{
    ur_iterator_t     iter;
    const char       *key;
    unsigned long    datum;

    _ur_ngram_check(ng);
    UR_HASH_ITERATE_UL(ng->hash, iter, key, datum) {
        printf("%-20.20s %lu\n", key, datum);
    }
}

static double _ur_ngram_matches(ur_ngram_t a, ur_ngram_t b)
{
    ur_iterator_t     iter;
    const char       *key;
    int              matches = 0;
    int              total;

    ur_hash_iterator_lock(a->hash);
    UR_HASH_ITERATE_UL_NODATUM(a->hash, iter, key)
        if (ur_hash_lookup_ul(b->hash, key)) ++matches;
    ur_hash_iterator_unlock(a->hash);

    total = a->unique_ngrams + b->unique_ngrams;
    return (double)matches / (double)(total - matches);
}

static double _ur_ngram_dot(ur_ngram_t a, ur_ngram_t b)
{
    ur_iterator_t     iter;
    const char       *key;
    unsigned long    datum0, datum1;
    double           product = 0;
    
    ur_hash_iterator_lock(a->hash);
    UR_HASH_ITERATE_UL(a->hash, iter, key, datum0)
        if ((datum1 = ur_hash_lookup_ul(b->hash, key))) {
            double partial;
            partial = ((double)datum0/a->total_ngrams
                       *(double)datum1/b->total_ngrams);
            product += partial;
        }
    ur_hash_iterator_unlock(a->hash);

    return product;
}

static double _ur_ngram_cosine(ur_ngram_t a, ur_ngram_t b)
{
    ur_iterator_t     iter;
    const char       *key;
    unsigned long    datum0, datum1;
    double           num  = 0;
    double           sum0 = 0;
    double           sum1 = 0;
    
    ur_hash_iterator_lock(a->hash);
    UR_HASH_ITERATE_UL(a->hash, iter, key, datum0) {
        double f = (double)datum0/a->total_ngrams;
        sum0 += f * f;
        if ((datum1 = ur_hash_lookup_ul(b->hash, key)))
            num += f * (double)datum1/b->total_ngrams;
    }
    ur_hash_iterator_unlock(a->hash);

    ur_hash_iterator_lock(b->hash);
    UR_HASH_ITERATE_UL(b->hash, iter, key, datum1) {
        double f = (double)datum1/b->total_ngrams;
        sum1 += f * f;
    }
    ur_hash_iterator_unlock(b->hash);
    
    return num / (sqrt(sum0) * sqrt(sum1));
}

double ur_ngram_compare(ur_ngram_t a, ur_ngram_t b, ur_ngram_alg_t alg)
{
    _ur_ngram_check(a);
    _ur_ngram_check(b);
    switch (alg) {
    case UR_NGRAM_MATCHES: return _ur_ngram_matches(a, b);
    case UR_NGRAM_DOT:     return _ur_ngram_dot(a, b);
    case UR_NGRAM_COSINE:  return _ur_ngram_cosine(a, b);
    }
    return 0;
}
