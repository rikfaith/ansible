/* buf.c -- 
 * Created: Sat Aug  2 13:20:42 2003 by faith@dict.org
 * Copyright 2003, 2008 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: buf.c,v 1.6 2003-09-12 13:15:17 faith Exp $
 *
 */

#include "urP.h"
#include <sys/uio.h>

typedef struct ur_buf_buffer_s {
    unsigned long magic;
    int           refcount;
    int           size;
    ur_buf_t      owner;
    unsigned char *buf;
} *ur_buf_buffer_t;

typedef struct ur_buf_chunk_s {
    unsigned long       magic;
    int                 start;
    int                 used;
    ur_buf_buffer_t       buffer;
    struct ur_buf_chunk_s *next;
} *ur_buf_chunk_t;

struct ur_buf_s {
    unsigned long magic;
    unsigned long len;

    int            count;
    ur_buf_chunk_t head, tail;

                                /* Statistics */
    unsigned long append;
    unsigned long read1, readn;
    unsigned long write1, writen;
};

CHECK_FUNCTION(_ur_buf_check, ur_buf_t, UR_BUF_MAGIC)
CHECK_FUNCTION(_ur_buf_chunk_check, ur_buf_chunk_t, UR_BUF_CHUNK_MAGIC)
CHECK_FUNCTION(_ur_buf_buffer_check, ur_buf_buffer_t, UR_BUF_BUFFER_MAGIC)

ur_buf_t ur_buf_create(void)
{
    ur_buf_t buf = ur_allocz(sizeof(*buf));

    buf->magic = UR_BUF_MAGIC;
    return buf;
}

unsigned long ur_buf_destroy(ur_buf_t buf)
{
    unsigned long ret;
    _ur_buf_check(buf);
    ur_trace(0, __func__, "r %lu %lu (a%lu); w %lu %lu\n",
             buf->read1, buf->readn, buf->append,
             buf->write1, buf->writen);
    ret = buf->magic = ~UR_BUF_MAGIC;
    ur_free(buf);
    return ret;
}

static ur_buf_buffer_t ur_buf_buffer_create(int size)
{
    ur_buf_buffer_t buffer = ur_allocz(sizeof(*buffer));

    buffer->magic    = UR_BUF_BUFFER_MAGIC;
    buffer->size     = size ? size : 4096;
    buffer->buf      = ur_alloc(buffer->size);

    return buffer;
}

static unsigned long ur_buf_buffer_destroy(ur_buf_buffer_t buffer)
{
    unsigned long ret;
    
    _ur_buf_buffer_check(buffer);
    ret = buffer->magic = ~UR_BUF_BUFFER_MAGIC;
    if (!buffer->refcount) {
        ur_free(buffer->buf);
        ur_free(buffer);
    }
    return ret;
}

static ur_buf_chunk_t ur_buf_chunk_create(ur_buf_buffer_t buffer,
                                      ur_buf_chunk_t *head,
                                      ur_buf_chunk_t *tail)
{
    ur_buf_chunk_t chunk = ur_allocz(sizeof(*chunk));

    if (buffer)        _ur_buf_buffer_check(buffer);
    if (head && *head) _ur_buf_chunk_check(*head);
    if (tail && *tail) _ur_buf_chunk_check(*tail);
    chunk->magic       = UR_BUF_CHUNK_MAGIC;
    chunk->start       = 0;
    chunk->used        = 0;
    chunk->buffer      = buffer ? buffer : ur_buf_buffer_create(0);
    chunk->next        = NULL;

    if (head && !*head) *head = chunk;
    if (tail) {
        if (!*tail) {
            *tail         = chunk;
        } else {
            if ((*tail)->next) ur_fatal(__func__, "Tail not tail\n");
            (*tail)->next = chunk;
            *tail         = chunk;
        }
    }

    if (chunk->buffer) ++chunk->buffer->refcount;
    
    return chunk;
}

static unsigned long ur_buf_chunk_destroy(ur_buf_chunk_t chunk)
{
    unsigned long ret;
    _ur_buf_chunk_check(chunk);
    ret = chunk->magic = ~UR_BUF_CHUNK_MAGIC;
    if (chunk->buffer) {
        --chunk->buffer->refcount;
        ur_buf_buffer_destroy(chunk->buffer);
    }
    ur_free(chunk);
    return ret;
}

static void ur_buf_chunk_destroy_chain(ur_buf_chunk_t chunk)
{
    ur_buf_chunk_t pt, next;

    if (!chunk) return;
    _ur_buf_chunk_check(chunk);
    for (pt = chunk, next = chunk->next; pt; pt = next) {
        next = pt->next;
        ur_buf_chunk_destroy(pt);
    }
}

#if 0
static int ur_buf_add_chunk(ur_buf_t buf)
{
    int offset = buf->chunkCount++;
    
    if (buf->chunkMax < buf->chunkCount) {
        if (!(buf->chunkMax *= 2)) buf->chunkMax = 8;
        buf->chunks = ur_realloc(buf->chunks,
                                 buf->chunkMax * sizeof(*buf->chunks));
    }
    buf->chunks[offset] = ur_buf_chunk_create();
    return offset;
}

static void ur_buf_free_chunks(ur_buf_t buf, int start, int end)
{
    int i;

    for (i = start; i <= end && i < buf->chunkCount; i++) {
        ur_buf_chunk_destroy(buf->chunks[i]);
    }
}

static void ur_buf_allocate(ur_buf_t buf, int len)
{
    int i;
    int total = 0;

    for (i = 0; i < buf->chunkCount; i++) {
        total += buf->chunks[i]->total;
        if (total >= len) {
            ur_buf_free_chunks(buf, i+1, buf->chunkCount-1);
            return;
        }
    }
    do {
        i = ur_buf_add_chunk(buf);
        total += buf->chunks[i]->total;
    } while (total < len);
}
#endif

int ur_buf_read(ur_buf_t buf, int fd, int len)
{
    struct iovec  *vector;
    int           i;
    int           total;
    ur_buf_chunk_t  head = NULL, tail = NULL, pt, prev;
    int           count;
    int           retval = EOF;

    _ur_buf_check(buf);

    if (buf->tail && !buf->tail->buffer->owner) {
        int offset = buf->tail->start + buf->tail->used;

        if (buf->tail->buffer->size - offset >= len) {
            ++buf->append;
            ++buf->read1;
            if ((total = read(fd, buf->tail->buffer->buf + offset, len)) > 0) {
                buf->len        += total;
                buf->tail->used += total;
                if (buf->tail->buffer->refcount > 1)
                    buf->tail->buffer->owner = buf;
                return total;
            }
        }
    }

    for (i = 0, count = 0; i < len; i += tail->buffer->size, ++count)
        ur_buf_chunk_create(NULL, &head, &tail);

    vector = ur_alloc(count * sizeof(*vector));
    for (pt = head, i = 0; pt; pt = pt->next, i++) {
        vector[i].iov_base = pt->buffer->buf;
        vector[i].iov_len  = pt->buffer->size;
    }
    ++buf->readn;
    total = readv(fd, vector, count);
    ur_free(vector);

    if (total > 0) {
        retval      = total;
        buf->len   += total;
        buf->count += count;

        for (pt = head, prev = NULL, i = 0;
             pt && total;
             prev = pt, pt = pt->next, i++) {
            int used = 0;

            if (total >= pt->buffer->size) used = pt->buffer->size;
            else                           used = total;
            total    -= used;
            pt->used  = used;
        }
        if (pt) {
            ur_buf_chunk_destroy_chain(pt);
            tail = prev;
        }

        if (!head || !tail)
            ur_internal(__func__, "head = %p, tail = %p\n",
                        (void *)head, (void *)tail);

        if (!buf->head) {
            buf->head = head;
            buf->tail = tail;
        } else {
            buf->tail->next = head;
            buf->tail       = tail;
        }

    } else {
        if (buf->tail) buf->tail->next = NULL;
        else if (buf->head)
            ur_internal(__func__, "Head but no tail\n");
        ur_buf_chunk_destroy_chain(head);
    }
    
    return retval;
}

int ur_buf_write(ur_buf_t buf, int fd, int len)
{
    int          i;
    struct iovec *vector;
    int          total;
    ur_buf_chunk_t pt, prev;

    vector = ur_alloc(buf->count * sizeof(*vector));
    for (pt = buf->head, i = 0, total = 0; pt; pt = pt->next, i++) {
        vector[i].iov_base = pt->buffer->buf + pt->start;
        if (len && total + pt->used > len) {
            vector[i].iov_len  = len - total;
            break;
        }
        vector[i].iov_len  = pt->used;
        total             =+ pt->used;
    }
    ++buf->writen;
    total = writev(fd, vector, i+1);
    ur_free(vector);

    if (total > 0) {
        buf->len -= total;
        for (pt = buf->head, prev = NULL; pt; prev = pt, pt = pt->next) {
            if (pt->used  >= total) {
                pt->used  -= total;
                pt->start += total;
                break;
            } else {
                pt->used = 0;
            }
            total -= pt->used;
        }
        if (!pt->used) {
            prev = pt;
            pt   = pt->next;
        }
        /* pt is the new head; prev is the last to be removed */
        if (prev) {
            prev->next = NULL;                  /* disconnect */
            ur_buf_chunk_destroy_chain(buf->head); /* free beginning of chain */
        }
        buf->head                 = pt;
        if (!buf->head) buf->tail = NULL;    /* if last block */
    }

    return total;
}

#if 0
extern ur_buf_t       ur_buf_get_line(ur_buf_t buf);
extern void          ur_buf_iterator_init(ur_buf_t buf, ur_iterator_t iter,
                                        const char *delim, const char *quote,
                                        const char *escape);
extern ur_buf_t       ur_buf_iterator_string(ur_iterator_t iter);
extern void          ur_buf_iterator_next(ur_iterator_t iter);
extern void          ur_buf_free(ur_buf_t buf);
extern void          ur_buf_append(ur_buf_t buf, ur_buf_t s);
extern void          ur_buf_append_s(ur_buf_t buf, const char *s);
extern void          ur_buf_append_s_n(ur_buf_t buf, const char *s, int len);
extern void          ur_buf_printf(ur_buf_t buf, const char *format, ...);

static void _ur_arena_get_chunk(ur_arena_t arena, size_t needed)
{
    ur_arena_chunk_t chunk;
    size_t         size;

    size              = sizeof(ur_arena_header_t) + needed + UR_ARENA_CHUNK;
    chunk             = ur_alloc(size);

    if (arena->head) {
	arena->wasted = arena->head->limit - arena->head->avail;
    }

    chunk->magic      = UR_ARENA_MAGIC;
    chunk->size       = size;
    chunk->prev       = arena->head;
    chunk->avail      = (char *)(chunk + 1);
    chunk->limit      = (char *)chunk + size;

    arena->head       = chunk;
    arena->allocated += size;
}

void *ur_arena_alloc(ur_arena_t arena, size_t size)
{
    ur_arena_chunk_t chunk = arena->head;
    size_t         s;
    
    _ur_arena_check(arena);
    if (size <= 0) ur_fatal(__FUNCTION__, "Size = %lu\n", (unsigned long)size);

    s = ((size + arena->alignment - 1) / arena->alignment) * arena->alignment;

    if (!chunk || s > (size_t)(chunk->limit - chunk->avail))
	_ur_arena_get_chunk(arena, s); /* Get new chunk */

    arena->used        += s;
    if (!arena->head) ur_internal(__FUNCTION__, "NULL Head\n");
    arena->head->avail += s;
    
    return arena->head->avail - s;
}

void *ur_arena_alloc_z(ur_arena_t arena, size_t size)
{
    void *pt = ur_arena_alloc(arena, size);

    memset(pt, 0, size);
    return pt;
}
#endif
