/* list.c -- Doubly-linked list
 * Created: Mon Jul  5 13:24:11 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: list.c,v 1.10 2003-06-12 13:58:58 faith Exp $
 * 
 */

#include "urP.h"

typedef struct ur_list_element_s {
    const void               *datum;
    struct ur_list_element_s *prev;
    struct ur_list_element_s *next;
} *ur_list_element_t;

struct ur_list_s {
    unsigned long     magic;
    ur_list_element_t head;
    ur_list_element_t tail;
    ur_block_t        block;
    unsigned int      depth;
};

static ur_block_t _ur_list_block;

CHECK_FUNCTION(_ur_list_check, ur_list_t, UR_LIST_MAGIC)

/* Create an empty list. */
ur_list_t ur_list_create(void)
{
	ur_list_t list;

	if (UR_USE_BLOCK && !_ur_list_block)
		_ur_list_block = ur_block_create(sizeof(*list));

	list = (_ur_list_block
		? ur_block_alloc_z(_ur_list_block)
		: ur_allocz(sizeof(*list)));

	list->magic = UR_LIST_MAGIC;
	if (UR_USE_BLOCK)
		list->block = ur_block_create(
			sizeof(struct ur_list_element_s));
	return list;
}

/* Free all allocated memory associated with list. */
unsigned long ur_list_destroy(ur_list_t list)
{
    ur_list_element_t e;
    ur_list_element_t next;
    unsigned long   ret;

    _ur_list_check(list);
    ret = list->magic = ~UR_LIST_MAGIC;

    if (UR_USE_BLOCK) ur_block_destroy(list->block);
    else {
	for (e = list->head; e; e = next) {
	    next = e->next;
	    ur_free(e);
	}
    }
    if (_ur_list_block) ur_block_free(_ur_list_block, list);
    else                ur_free(list);
    return ret;
}

void ur_list_push(ur_list_t list, const void *datum)
{
    ur_list_element_t e;

    _ur_list_check(list);

    e          = (UR_USE_BLOCK
		  ? ur_block_alloc(list->block)
		  : ur_alloc(sizeof(*e)));
    e->datum   = datum;
    e->prev    = NULL;
    e->next    = list->head;
    if (list->head) list->head->prev = e;
    list->head = e;
    if (!list->tail) list->tail = e; /* first element */
    ++list->depth;
}

void ur_list_append(ur_list_t list, const void *datum)
{
    ur_list_element_t e;

    _ur_list_check(list);

    e          = (UR_USE_BLOCK
		  ? ur_block_alloc(list->block)
		  : ur_alloc(sizeof(*e)));
    e->datum   = datum;
    e->prev    = list->tail;
    e->next    = NULL;
    if (list->tail) list->tail->next = e;
    list->tail = e;
    if (!list->head) list->head = e; /* first element */
    ++list->depth;
}

void *ur_list_pop(ur_list_t list)
{
    ur_list_element_t e;
    const void      *datum = NULL;

    _ur_list_check(list);
    e = list->head;
    if (e) {
	if (e->next) e->next->prev = NULL;
	list->head = e->next;
	datum      = e->datum;
	if (list->tail == e) list->tail = NULL; /* last element */
	if (UR_USE_BLOCK) ur_block_free(list->block, e); else ur_free(e);
	--list->depth;
    }
    return (void *)datum;	/* Discard const */
}

void *ur_list_top(ur_list_t list)
{
    _ur_list_check(list);
    return list->head ? (void *)list->head->datum : NULL; /* Discard const */
}

void *ur_list_last(ur_list_t list)
{
    ur_list_element_t e;
    const void      *datum = NULL;

    _ur_list_check(list);
    e = list->tail;
    if (e) {
	if (e->prev) e->prev->next = NULL;
	list->tail = e->prev;
	datum      = e->datum;
	if (list->head == e) list->head = NULL; /* last element */
	if (UR_USE_BLOCK) ur_block_free(list->block, e); else ur_free(e);
	--list->depth;
    }
    return (void *)datum;	/* Discard const */
}

void *ur_list_bot(ur_list_t list)
{
    _ur_list_check(list);
    return list->tail ? (void *)list->tail->datum : NULL; /* Discard const */
}

void *ur_list_nth(ur_list_t list, int n)
{
    ur_list_element_t e;
    int             i;
    
    _ur_list_check(list);
    if (n < 1)                            return NULL;
    if ((unsigned)n > ur_list_depth(list)) return NULL;

    for (i = 1, e = list->head; i < n; i++, e = e->next)
	;
    return (void *)e->datum;	/* Discard const */
}

unsigned int ur_list_depth(ur_list_t list)
{
    _ur_list_check(list);
    return list->depth;
}

void ur_list_make_argv(ur_list_t list, int *argc, const char ***argv)
{
    int             c;
    const char      **v;
    ur_list_element_t e;
    int             i;

    _ur_list_check(list);
    c = ur_list_depth(list);
    v = ur_alloc((c + 1) * sizeof(*v));
    for (e = list->head, i = 0; e; e = e->next, i++) v[i] = e->datum;
    v[c]  = NULL;
    *argc = c;
    *argv = v;
}

void ur_list_parse(ur_list_t list, const char *string, const char *delim,
		   const char *quote, const char *escape, bool escapes)
{
    int        inquote = 0;
    const char *pt     = string;
    int        len;
    char       *buf;
    char       *last;
    
    _ur_list_check(list);
    buf = ur_alloc(strlen(string)+1);

    for (last = buf, len = 0; *pt; ++pt) {
	if (delim && !inquote && strchr(delim, *pt)) {
	    if (last != buf) ur_list_append(list, ur_atom_string_n(buf, len));
	    last = buf;
	    len  = 0;
	} else if (quote && strchr(quote, *pt)) {
	    if (inquote == *pt) {
		ur_list_append(list, ur_atom_string_n(buf, len));
		last    = buf;
		len     = 0;
		inquote = 0;
	    } else {
		if (!inquote) {
		    inquote = *pt;
		    if (pt[1]) {
			*last++ = *++pt;
			++len;
		    }
		} else {
		    *last++ = *pt;
		    ++len;
		}
	    }
	} else if (escape && pt[1] && strchr(escape, *pt)) {
		char ch = *++pt;
		if (escapes) {
			switch (ch) {
			case 'n': ch = '\n'; break;
			case 'r': ch = '\r'; break;
			case 't': ch = '\t'; break;
			}
		}
		*last++ = ch;
		++len;
	} else {
	    *last++ = *pt;
	    ++len;
	}
    }
    if (last != buf) ur_list_append(list, ur_atom_string_n(buf, len));
    
    ur_free(buf);
}

void ur_list_parse_string(ur_list_t list, const char *string)
{
    ur_list_parse(list, string,
		  UR_LIST_DELIM, UR_LIST_QUOTE, UR_LIST_ESCAPE, true);
}

void ur_list_iterator_init(ur_list_t list, ur_iterator_t *iter)
{
    _ur_list_check(list);
    iter->a = list;
    iter->b = list->head;
}

int ur_list_iterator_next(ur_iterator_t *iter)
{
    ur_list_t list = iter->a;
    
    _ur_list_check(list);
    if (!iter->b) return 0;
    iter->b = ((ur_list_element_t)iter->b)->next;
    return iter->b != NULL;
}

void *ur_list_iterator_datum(ur_iterator_t *iter)
{
    ur_list_t list = iter->a;
    
    _ur_list_check(list);
    if (!iter->b) return NULL;
    return (void *)((ur_list_element_t)iter->b)->datum; /* Discard const */
}
