/* test-atom.c -- 
 * Created: Thu Dec 23 10:08:16 1999 by faith@acm.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-atom.c,v 1.5 2003-08-10 23:27:26 faith Exp $
 * 
 */

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    const char *s = "foo";
    const char *t = "This is a test of a string that is longer than 64 bytes";
    const char *s0;
    const char *s1;
    const char *s2;
    const char *s3;
    int        i;
    int        len;
    char       buf[2048];
    
    test("L", "String");
    s0 = ur_atom_string(s);
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d", i);
	    fail(buf);
	}
    }
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string(s);
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_string(s);
    if (s2 == s) fail("same 2");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    ok(0);
    
    test("L", "StringN a");
    s0 = ur_atom_string_n(s, strlen(s));
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d", i);
	    fail(buf);
	}
    }
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string_n(s, strlen(s));
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_string_n(s, strlen(s));
    if (s2 == s) fail("same 2");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    ok(0);
    
    test("L", "StringN b");
    s0 = ur_atom_string_n(s, strlen(s) - 1);
    for (i = 0, len = strlen(s); i < len + 1 - 2; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d", i);
	    fail(buf);
	}
    }
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string_n(s, strlen(s) - 1);
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_string_n(s, strlen(s) - 1);
    if (s2 == s) fail("same 2");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    s3 = ur_atom_string_n(s, strlen(s));
    if (s3 == s)  fail("same 3");
    if (s3 == s0) fail("same 4");
    if (s3 == s1) fail("same 5");
    if (s3 == s2) fail("same 6");
    ok(0);
    
    test("L", "New");
    s0 = ur_atom_new(s, strlen(s)+1);
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "differ at %d\n", i);
	    fail(buf);
	}
    }
    if (s0 == s) fail("same 0");
    s1 = ur_atom_new(s, strlen(s)+1);
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_new(s, strlen(s)+1);
    if (s2 == s) fail("same 2");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    ok(0);

    test("L", "Multiple Strings");
    s0 = ur_atom_string(s);
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string(t);
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d\n", i);
	    fail(buf);
	}
    }
    if (s1 == t) fail("same 1");
    if (s0 == s1) fail("same 2");
    s2 = ur_atom_string(s);
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 1");
    if (s2 == s1) fail("same 4");
    s3 = ur_atom_string(t);
    if (s3 == t) fail("same 5");
    if (s3 == s0) fail("same 6");
    if (s3 != s1) fail("different 1");
    if (s3 == s2) fail("same 7");
    ok(0);
    
    test("L", "Multiple StringNs");
    s0 = ur_atom_string_n(s, strlen(s));
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string_n(t, strlen(t));
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d\n", i);
	    fail(buf);
	}
    }
    if (s1 == t) fail("same 1");
    if (s0 == s1) fail("same 2");
    s2 = ur_atom_string_n(s, strlen(s));
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 1");
    if (s2 == s1) fail("same 4");
    s3 = ur_atom_string_n(t, strlen(t));
    if (s3 == t) fail("same 5");
    if (s3 == s0) fail("same 6");
    if (s3 != s1) fail("different 1");
    if (s3 == s2) fail("same 7");
    ok(0);
    
    test("L", "Multiple News");
    s0 = ur_atom_new(s, strlen(s)+1);
    if (s0 == s) fail("same 0");
    s1 = ur_atom_new(t, strlen(t)+1);
    for (i = 0, len = strlen(s); i < len + 1; i++) {
	if (s0[i] != s[i]) {
	    sprintf(buf, "s0 differs at %d\n", i);
	    fail(buf);
	}
    }
    if (s1 == t) fail("same 1");
    if (s0 == s1) fail("same 2");
    s2 = ur_atom_new(s, strlen(s)+1);
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 1");
    if (s2 == s1) fail("same 4");
    s3 = ur_atom_new(t, strlen(t)+1);
    if (s3 == t) fail("same 5");
    if (s3 == s0) fail("same 6");
    if (s3 != s1) fail("different 1");
    if (s3 == s2) fail("same 7");
    ok(0);
    
    test("L", "Mixed New/String");
    s0 = ur_atom_new(s, strlen(s)+1);
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string(s);
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_new(s, strlen(s)+1);
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    s3 = ur_atom_string(s);
    if (s3 == s) fail("same 4");
    if (s3 != s0) fail("different 4");
    if (s3 != s1) fail("different 5");
    if (s3 != s2) fail("different 6");
    ok(0);
    
    test("L", "Mixed New/StringN");
    s0 = ur_atom_new(s, strlen(s)+1);
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string_n(s, strlen(s));
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_new(s, strlen(s)+1);
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    s3 = ur_atom_string_n(s, strlen(s));
    if (s3 == s) fail("same 4");
    if (s3 != s0) fail("different 4");
    if (s3 != s1) fail("different 5");
    if (s3 != s2) fail("different 6");
    ok(0);
    
    test("L", "Mixed String/StringN");
    s0 = ur_atom_string(s);
    if (s0 == s) fail("same 0");
    s1 = ur_atom_string_n(s, strlen(s));
    if (s1 == s) fail("same 1");
    if (s0 != s1) fail("different 1");
    s2 = ur_atom_string(s);
    if (s2 == s) fail("same 3");
    if (s2 != s0) fail("different 2");
    if (s2 != s1) fail("different 3");
    s3 = ur_atom_string_n(s, strlen(s));
    if (s3 == s) fail("same 4");
    if (s3 != s0) fail("different 4");
    if (s3 != s1) fail("different 5");
    if (s3 != s2) fail("different 6");
    ok(0);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testlocal())) return retcode;
    }
    
    return EXIT_SUCCESS;
}
