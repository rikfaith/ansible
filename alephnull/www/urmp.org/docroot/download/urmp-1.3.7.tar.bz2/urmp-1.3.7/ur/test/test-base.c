/* test-base.c -- 
 * Created: Sun Aug 13 10:15:05 2000 by faith@dict.org
 * Copyright 2000, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * $Id: test-base.c,v 1.3 2003-09-12 13:15:19 faith Exp $
 *
 */

#define OBJECTINFO

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int sub(const char *name,
	       unsigned long base,
	       const char *(*encode)(unsigned long),
	       unsigned long (*decode)(const char *))
{
    const char    *r0, *r1, *pt;
    unsigned long val;
    char          buf[2048];
    unsigned long i;
    char          b[256];
    unsigned long count;

    sprintf(buf, "%s cache 0", name);
    test("L", buf);
    r0 = encode(0);
    r1 = encode(0);
    if (r0 != r1)       fail("pointer");
    if (strcmp(r0, r1)) fail("content");
    ok(0);

    sprintf(buf, "%s cache 2600", name);
    test("L", buf);
    r0 = encode(2600);
    r1 = encode(2600);
    if (r0 != r1)       fail("pointer");
    if (strcmp(r0, r1)) fail("content");
    ok(0);

    test("L", "zero");
    r0 = encode(0);
    if (decode(r0) != 0) fail(r0);
    ok(r0);

    test("L", "one");
    r0 = encode(1);
    if (decode(r0) != 1) fail(r0);
    ok(r0);

    test("L", "base-1");
    r0 = encode(base-1);
    if (decode(r0) != base-1) fail(r0);
    ok(r0);

    test("L", "base");
    r0 = encode(base);
    if (decode(r0) != base) fail(r0);
    ok(r0);

    test("L", "base+1");
    r0 = encode(base+1);
    if (decode(r0) != base+1) fail(r0);
    ok(r0);

    test("L", "unique 1");
    for (i = 0; i < 256; i++) b[i] = 0;
    for (i = 0; i < base; i++) {
	r0 = encode(i);
	b[(unsigned char)*r0] = 1;
    }
    for (i = 0, count = 0; i < 256; i++) count += b[i];
    sprintf(buf, "%lu for base%lu", count, base);
    if (count != base) fail(buf);
    ok(buf);

    test("L", "unique 2");
    for (i = 0; i < 256; i++) b[i] = 0;
    for (i = 0; i < base * 10; i++) {
	r0 = encode(i);
	for (pt = r0; *pt; pt++) b[(unsigned char)*pt] = 1;
    }
    for (i = 0, count = 0; i < 256; i++) count += b[i];
    sprintf(buf, "%lu for base%lu", count, base);
    if (count != base) fail(buf);
    ok(buf);

    test("L", "low");
    for (i = 0x00000000UL; i < 0x0000ffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "mid");
    for (i = 0x00ff0000UL; i < 0x00ffffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "high");
    for (i = 0xffff0000UL; i < 0xffffffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    return EXIT_SUCCESS;
}

static int tim(const char *name,
	       int base __attribute__((unused)),
	       const char *(*encode)(unsigned long),
	       unsigned long (*decode)(const char *))
{
    const char    *r0 = encode(0);
    char          buf[2048];
    int           i;
    ur_timer_t     t;
    ur_timeval_t   tv;
    int           iters;
    int           useconds;

    test("T", "Time setup");
    if (!(t = ur_timer_create(0))) fail("timer");
    for (iters = 1000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	ur_timer_start(t);
	for (i = 0; i < iters; i++) r0 = encode(i);
	ur_timer_stop(t);
	ur_timer_get_elapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Encode");
    ur_timer_start(t);
    for (i = 0; i < iters; i++) r0 = encode(i);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [encode]", name,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Decode");
    ur_timer_start(t);
    for (i = 0; i < iters; i++) decode(r0);
    ur_timer_stop(t);
    ur_timer_get_elapsed(t, &tv);
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [decode]", name,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    return EXIT_SUCCESS;
}

static int testlocal(void)
{
    int r;
    
    if ((r = sub("ur_base26", 26, ur_base26_encode, ur_base26_decode))) return r;
    if ((r = sub("ur_base64", 64, ur_base64_encode, ur_base64_decode))) return r;
    if ((r = sub("ur_base85", 85, ur_base85_encode, ur_base85_decode))) return r;
    return EXIT_SUCCESS;
}

static int time_local(void)
{
    int r;
    
    if ((r = tim("ur_base26", 26, ur_base26_encode, ur_base26_decode))) return r;
    if ((r = tim("ur_base64", 64, ur_base64_encode, ur_base64_decode))) return r;
    if ((r = tim("ur_base85", 85, ur_base85_encode, ur_base85_decode))) return r;
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testlocal()))  return retcode;
    } else {
	if ((retcode = time_local()))  return retcode;
    }

    return EXIT_SUCCESS;
}
