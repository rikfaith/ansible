/* elf.c -- 
 * Created: Thu Aug 14 14:51:42 2008 by faith@acm.org
 * Revised: Sat Apr 11 18:28:31 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urP.h"
#include <stdbool.h>

#define UR_ELF_ERR_BUF 256

struct ur_elf_s {
	unsigned long magic;
	int           error;
	bool          class32;
	char          *error_string;
};

typedef struct {
	unsigned char ident[16];
	uint16_t      type;
	uint16_t      machine;
	uint32_t      version;
	uint32_t      entry;
	uint32_t      ph_offset;
	uint32_t      sh_offset;
	uint32_t      flags;
	uint16_t      eh_size;
	uint16_t      ph_entry_size;
	uint16_t      ph_number;
	uint16_t      sh_entry_size;
	uint16_t      sh_number;
	uint16_t      sh_string_index;
} ur_elf32_header_t;

typedef struct {
	unsigned char ident[16];
	uint16_t      type;
	uint16_t      machine;
	uint32_t      version;
	uint64_t      entry;
	uint64_t      ph_offset;
	uint64_t      sh_offset;
	uint32_t      flags;
	uint16_t      eh_size;
	uint16_t      ph_entry_size;
	uint16_t      ph_number;
	uint16_t      sh_entry_size;
	uint16_t      sh_number;
	uint16_t      sh_string_index;
} ur_elf64_header_t;

typedef union {
	struct {
		uint8_t           magic[4];
		uint8_t           class;
		uint8_t           data;
		uint8_t           version;
		uint8_t           osabi;
	};
	ur_elf32_header_t elf32;
	ur_elf64_header_t elf64;
} ur_elf_header_t;

CHECK_FUNCTION(_ur_elf_check, ur_elf_t, UR_ELF_MAGIC)

ur_elf_t ur_elf_create(const char *filename)
{
	FILE *str;
	ur_elf_t        elf;
	ur_elf_header_t h;

	elf = ur_allocz(sizeof(*elf));
	elf->magic = UR_ELF_MAGIC;
	elf->error_string = ur_allocz(UR_ELF_ERR_BUF);

	if (!(str = fopen(filename, "r"))) {
		elf->error = errno;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "Cannot open %s: %s",
			 filename,
			 strerror(elf->error));
		return elf;
	}
	if (fread(&h, sizeof(h), 1, str) != 1) {
		elf->error = errno;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "Cannot read from %s: %s",
			 filename,
			 strerror(elf->error));
		fclose(str);
		return elf;
	}
	if (h.magic[0] != 0x7f
	    || h.magic[1] != 'E'
	    || h.magic[2] != 'L'
	    || h.magic[3] != 'F') {
		elf->error = -1;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "ELF header not found");
		return elf;
	}
	switch (h.class) {
	case 1:
		elf->class32 = true;
		break;
	case 2:
		elf->class32 = false;
		break;
	default:
		elf->error = -1;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "ELF class = %d: not 32- or 64-bit",
			h.class);
		return elf;
	}
	if (h.data != 1) {
		elf->error = -1;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "ELF data = %d: not little endian",
			 h.data);
		return elf;
	}
	if (h.version != 1) {
		elf->error = -1;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "ELF version = %d: unknown",
			 h.version);
		return elf;
	}
	if (h.osabi != 0 && h.osabi != 3) {
		elf->error = -1;
		snprintf(elf->error_string, UR_ELF_ERR_BUF,
			 "ELF ABI = %d: not System V or Linux",
			 h.osabi);
		return elf;
	}
	return elf;
}

#ifdef UR_DEVEL
int main(int argc, char **argv)
{
	ur_elf_t elf;

	elf = ur_elf_create(argv[0]);
	if (elf->error) {
		ur_fatal(__func__, "%s\n", elf->error_string);
	}
	return 0;
}
#endif
