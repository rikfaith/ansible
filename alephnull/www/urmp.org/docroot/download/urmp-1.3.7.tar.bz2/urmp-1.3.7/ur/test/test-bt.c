/* test-bt.c -- 
 * Created: Fri Apr 18 12:06:52 2003 by faith@acm.org
 * Revised: Mon Jul 14 20:19:01 2008 by faith@acm.org
 * Copyright 2003, 2008 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-bt.c,v 1.2 2003-08-10 23:30:43 faith Exp $
 * 
 */

#include "standard.h"
#include "ur.h"
#include "common.h"

int main(int argc __attribute__((unused)), char **argv)
{
    int retcode = 0;
    
    ur_init(argv[0]);

    test("L", "Backtrace");
    printf("Infinity = %d\n", 37 / retcode);
    fail("no abort");
    ok("");

    return EXIT_SUCCESS;
}
