/* block.c -- Same-size block allocator
 * Created: Sat Aug  7 18:56:30 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: block.c,v 1.5 2000-01-17 11:58:07 faith Exp $
 *
 */

#include "urP.h"

struct ur_block_s {
    unsigned long  magic;
    size_t         size;
    ur_arena_t      arena;
    void           *next;
    size_t         allocated;
    size_t         used;
    size_t         freed;
};

typedef struct ur_block_next_s {
    unsigned long  magic;
    void           *next;
} *ur_block_next_t;

CHECK_FUNCTION(_ur_block_check, ur_block_t, UR_BLOCK_MAGIC)
CHECK_FUNCTION(_ur_block_next_check, ur_block_next_t, UR_BLOCK_NEXT_MAGIC)

ur_block_t ur_block_create(size_t blocksize)
{
    ur_block_t block = ur_alloc(sizeof(*block));

    block->magic     = UR_BLOCK_MAGIC;
    block->size      = (blocksize < sizeof(struct ur_block_next_s)
			? sizeof(struct ur_block_next_s)
			: blocksize);
    block->arena     = ur_arena_create(0);
    block->next      = NULL;
    block->allocated = 0;
    block->used      = 0;
    block->freed     = 0;
    
    return block;
}

unsigned long ur_block_destroy(ur_block_t block)
{
    unsigned long ret;
    
    _ur_block_check(block);
    ur_arena_destroy(block->arena);
    ret = block->magic = ~UR_BLOCK_MAGIC;
    ur_free(block);
    return ret;
}

void *ur_block_alloc(ur_block_t block)
{
    ur_block_next_t next = block->next;
    
    _ur_block_check(block);
    if (next) {
	_ur_block_next_check(next);
	block->next = next->next;
	next->magic = 0;
	next->next  = NULL;
	return next;
    }

    return ur_arena_alloc(block->arena, block->size);
}

void *ur_block_alloc_z(ur_block_t block)
{
    ur_block_next_t next;
    
    _ur_block_check(block);
    if ((next = block->next)) {
	_ur_block_next_check(next);
	block->next = next->next;
	memset(next, 0, block->size);
	return next;
    }

    return ur_arena_alloc_z(block->arena, block->size);
}

void ur_block_free(ur_block_t block, void *area)
{
    ur_block_next_t current = (ur_block_next_t)area;

    _ur_block_check(block);
    if (!current) ur_fatal(__FUNCTION__, "Freeing NULL pointer\n");
    
    current->magic = UR_BLOCK_NEXT_MAGIC;
    current->next  = block->next;
    block->next    = current;
}
