/* avltree.c --
 * Created: Mon Dec 20 16:32:09 1999 by tek@wiw.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * References:
 *    D. Knuth - ``The Art of Computer Programming''
 *    N. Wirth - ``Algorithms + Data Structures = Programs''
 *    B. Pfaff - ``An Iterative Algorithm for Deletion from AVL-Balanced
 *                 Binary Trees''
 *
 * $Id: avltree.c,v 1.11 2003-09-12 13:15:17 faith Exp $
 */

#include "urP.h"

typedef struct ur_avl_node {
    const void *key, *datum;
    int bal;
    struct ur_avl_node *left, *right;
} *ur_avl_node_t;

struct ur_avl_s {
    unsigned long      magic;
    int                n_nodes;
    ur_avl_node_t    top;
    ur_avl_compare_t cmp;
};

CHECK_FUNCTION(_ur_avl_check, ur_avl_t, UR_AVLTREE_MAGIC)

static int _ur_avl_compare(const void *key1, const void *key2)
{
    return strcmp(key1, key2);
}

ur_avl_t ur_avl_create(ur_avl_compare_t compare)
{
    ur_avl_t p = ur_allocz(sizeof(*p));

    p->magic   = UR_AVLTREE_MAGIC;
    p->top     = NULL;
    p->n_nodes = 0;
    p->cmp     = compare ? compare : _ur_avl_compare;
    
    return p;
}

static void ur_avl_destroy_internal(ur_avl_node_t p)
{
    if(p == NULL) return;

    ur_avl_destroy_internal(p->left);
    ur_avl_destroy_internal(p->right);
    ur_free(p);
}

unsigned long ur_avl_destroy(ur_avl_t tree)
{
    unsigned long ret;
    
    _ur_avl_check(tree);
    ur_avl_destroy_internal(tree->top);
    ret = tree->magic = ~UR_AVLTREE_MAGIC;
    ur_free(tree);
    return ret;
}

void *ur_avl_lookup(ur_avl_t tree, const void *key)
{
    int cmp;
    ur_avl_node_t p;
    
    _ur_avl_check(tree);
    p = tree->top;
    while(p != NULL) {
        cmp = (*tree->cmp)(key, p->key);
        if(cmp > 0) {
            p = p->right;
        } else if(cmp < 0) {
            p = p->left;
        } else {
            return (void *)p->datum; /* Discard const */
        }
    }

    return NULL;
}

static void ur_avl_tree_fix(ur_avl_node_t *p, int *flag)
{
    ur_avl_node_t q, r;

    if((*p)->bal == 1) {
    } else if((*p)->bal == 0) {
        *flag = 0;
    } else if((*p)->bal == -1) {
    } else if((*p)->bal == -2) {
        q = (*p)->left;
        if(q->bal == -1) { /* LL rotation */
            (*p)->left = q->right;
            q->right = *p;
            (*p)->bal = 0;
            *p = q;
                    
        } else { /* LR rotation */
            r = q->right;
            q->right = r->left;
            r->left = q;
            (*p)->left = r->right;
            r->right = *p;
                    
            if(r->bal == -1) {
                (*p)->bal = 1;
            } else {
                (*p)->bal = 0;
            }

            if(r->bal == 1) {
                q->bal = -1;
            } else {
                q->bal = 0;
            }

            *p = r;
        }
        
        (*p)->bal = 0;
        *flag = 0;
    } else if((*p)->bal == 2) {
        q = (*p)->right;
        if(q->bal == 1) { /* RR rotation */
            (*p)->right = q->left;
            q->left = *p;
            (*p)->bal = 0;
            *p = q;
                    
        } else { /* RL rotation */
            r = q->left;
            q->left = r->right;
            r->right = q;
            (*p)->right = r->left;
            r->left = *p;
                    
            if(r->bal == 1) {
                (*p)->bal = -1;
            } else {
                (*p)->bal = 0;
            }

            if(r->bal == -1) {
                q->bal = 1;
            } else {
                q->bal = 0;
            }

            *p = r;
        }

        (*p)->bal = 0;
        *flag = 0;
    } else {
        /* the tree is too unbalanced */
        ur_fatal(__FUNCTION__, "AVL tree has become unstable - algorithm bug");
    }

    return;
}

static int ur_avl_insert_internal(ur_avl_t tree, ur_avl_node_t *p,
				     int *flag, const void *key,
				     const void *datum)
{
    int cmp;

    if(*p == NULL) {
        tree->n_nodes++;
        *p = ur_alloc(sizeof(**p));
        (*p)->left = NULL;
        (*p)->right = NULL;
        (*p)->key = key;
        (*p)->datum = datum;
        (*p)->bal = 0;
        *flag = 1;

    } else if((cmp = (*tree->cmp)(key, (*p)->key)) < 0) {
        ur_avl_insert_internal(tree, &((*p)->left), flag, key, datum);

        if(*flag) {
            (*p)->bal--;
            ur_avl_tree_fix(p, flag);
        }

    } else if(cmp > 0) {
        ur_avl_insert_internal(tree, &((*p)->right), flag, key, datum);

        if(*flag) {
            (*p)->bal++;
            ur_avl_tree_fix(p, flag);
        }

    } else {
        *flag = 0;
        return 1;		/* Duplicate insertion */
    }

    return 0;
}

int ur_avl_delete(ur_avl_t tree, const void *key)
{
    int cmp;
    ur_avl_node_t p, *q, r, s, *t;
    ur_avl_node_t *P;
    int *a, k, l;

    _ur_avl_check(tree);
    
    a = ur_alloc(tree->n_nodes*sizeof(*a));
    P = ur_alloc(tree->n_nodes*sizeof(*P));

    a[0] = 0;
    P[0] = tree->top;
    k = 1;
    p = tree->top;

    if (!p) return 1;

    do {
        cmp = (*tree->cmp)(key, p->key);
        if(cmp < 0) {
            P[k] = p;
            a[k] = -1;
            p = p->left;
            k++;
            if(p == NULL) return 1; /* Item not found */
        } else if(cmp > 0) {
            P[k] = p;
            a[k] = 1;
            p = p->right;
            k++;
            if(p == NULL) return 1; /* Item not found */
        } else {
            q = (a[k-1] < 0) ? &P[k-1]->left :
                ((a[k-1] == 0) ? &P[k-1] : &P[k-1]->right);
            if(p->right == NULL) {
                *q = p->left;
                if(*q != NULL) {
                    (*q)->bal = 0;
                }
            } else {
                r = p->right;
                if(r->left == NULL) {
                    r->left = p->left;
                    *q = r;
                    r->bal = p->bal;
                    a[k] = 1;
                    P[k] = r;
                    k++;
                } else {
                    s = r->left;
                    l = k;
                    k++;
                    a[k] = -1;
                    P[k] = r;
                    k++;

                    while(s->left != NULL) {
                        r = s;
                        s = s->left;
                        a[k] = -1;
                        P[k] = r;
                        k++;
                    }

                    a[l] = 1;
                    P[l] = s;
                    s->left = p->left;
                    r->left = s->right;
                    s->right = p->right;
                    s->bal = p->bal;
                    *q = s;
                }
            }
            
            do {
                k--;
                if(k == 0) {
                    tree->top = P[0];
                    ur_free(a);
                    ur_free(P);
                    return 0;
                }
                s = P[k];
                if(s->bal == 0) {
                    s->bal = -a[k];
                    ur_free(a);
                    ur_free(P);
                    ur_free(p);
                    tree->n_nodes--;
                    return 0;
                } else if(s->bal == a[k]) {
                    s->bal = 0;
                } else {
                    r = (-a[k] < 0) ? s->left : s->right;
                    if(r->bal == 0) {
                        t = (-a[k] < 0) ? &s->left : &s->right;
                        *t = (a[k] < 0) ? r->left : r->right;
                        t = (a[k] < 0) ? &r->left : &r->right;
                        *t = s;
                        r->bal = a[k];
                        t = (a[k-1] < 0) ? &P[k-1]->left :
                            ((a[k-1] == 0) ? &P[k-1] : &P[k-1]->right);
                        *t = r;
                        tree->top = P[0];
                        ur_free(p);
                        ur_free(a);
                        ur_free(P);
                        tree->n_nodes--;
                        return 0;
                    } else if(r->bal == -a[k]) {
                        t = (-a[k] < 0) ? &s->left : &s->right;
                        *t = (a[k] < 0) ? r->left : r->right;
                        t = (a[k] < 0) ? &r->left : &r->right;
                        *t = s;
                        s->bal = r->bal = 0;
                        t = (a[k-1] < 0) ? &P[k-1]->left :
                            ((a[k-1] == 0) ? &P[k-1] : &P[k-1]->right);
                        *t = r;
                    } else {
                        p = (a[k] < 0) ? r->left : r->right;
                        t = (a[k] < 0) ? &r->left : &r->right;
                        *t = (-a[k] < 0) ? p->left : p->right;
                        t = (-a[k] < 0) ? &p->left : &p->right;
                        *t = r;
                        t = (-a[k] < 0) ? &s->left : &s->right;
                        *t = (a[k] < 0) ? p->left : p->right;
                        t = (a[k] < 0) ? &p->left : &p->right;
                        *t = s;
                        
                        if(p->bal == -a[k]) {
                            s->bal = a[k];
                            r->bal = 0;
                        } else if(p->bal == 0) {
                            s->bal = r->bal = 0;
                        } else {
                            s->bal = 0;
                            r->bal = -a[k];
                        }
                        p->bal = 0;
                        t = (a[k-1] < 0) ? &P[k-1]->left :
                            ((a[k-1] == 0) ? &P[k-1] : &P[k-1]->right);
                        *t = p;
                    }
                }
            } while(1);
        }
    } while(1);

    ur_free(a);
    ur_free(P);
    
    return 0;
}

int ur_avl_insert(ur_avl_t tree, const void *key, const void *datum)
{
    int flag = 0;

    _ur_avl_check(tree);
    return ur_avl_insert_internal(tree, &tree->top, &flag, key, datum);
}

int ur_avl_print_stats(ur_avl_t tree, FILE *str, int flags __unused)
{
    _ur_avl_check(tree);
    fprintf(str, "%d nodes\n", tree->n_nodes);
    return 0;
}

/* EOF avltree.c */
