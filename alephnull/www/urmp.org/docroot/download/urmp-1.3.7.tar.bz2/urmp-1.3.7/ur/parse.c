/* parse.c -- 
 * Created: Sat Apr 11 16:20:14 2009 by faith@acm.org
 * Revised: Sun Apr 12 12:11:30 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * 
 */

#include "urP.h"
#include <pcre.h>

struct ur_parse_s {
	unsigned long magic;
	int           filters;
	int           max_filters;
	ur_list_t     *lists;
	int           *v0;
	const char    **v1;
};

CHECK_FUNCTION(_ur_parse_check, ur_parse_t, UR_PARSE_MAGIC)


ur_parse_t ur_parse_create(void)
{
	ur_parse_t parse = ur_allocz(sizeof(*parse));

	parse->magic = UR_PARSE_MAGIC;
	return parse;
}

unsigned long ur_parse_destroy(ur_parse_t parse)
{
	int           i;
	unsigned long ret;

	_ur_parse_check(parse);
	ret = parse->magic = ~UR_PARSE_MAGIC;

	for (i = 0; i < parse->filters; i++) {
		ur_list_destroy(parse->lists[i]);
	}
	ur_free(parse->lists);
	ur_free(parse->v0);
	ur_free(parse->v1);
	ur_free(parse);
	return ret;
}

static void _ur_parse_add(ur_list_t list, const char *regexp)
{
	pcre       *p;
	int        error_code;
	int        error_offset;
	const char *error_message;

	p = pcre_compile2(regexp,
			  0,
			  &error_code,
			  &error_message,
			  &error_offset,
			  NULL);
	if (error_code) {
		printf("%s\n", regexp);
		printf("%*.*s\n", error_offset + 1, error_offset + 1, "^");
		ur_fatal(__func__,
			 "Error %d when compiling regular expression: %s\n",
			 error_code, error_message);
	}
	ur_list_append(list, p);
	ur_list_append(list, regexp);
	ur_trace(UR_TRACE_PARSE, __func__, "Added: %s\n", regexp);
}

void ur_parse_filter_add(ur_parse_t parse, const char *filter)
{
	int old = parse->max_filters;

	_ur_parse_check(parse);

	if (parse->filters + 1 > parse->max_filters) {
		++parse->max_filters;
		parse->max_filters *= 2;
		parse->lists = ur_reallocz(parse->lists,
					   old * sizeof(*parse->lists),
					   parse->max_filters
					   * sizeof(*parse->lists));
		parse->v0    = ur_reallocz(parse->v0,
					   old * sizeof(*parse->v0),
					   parse->max_filters
					   * sizeof(*parse->v0));
		parse->v1    = ur_reallocz(parse->v1,
					   old * sizeof(*parse->v1),
					   parse->max_filters
					   * sizeof(*parse->v1));
	}
	parse->lists[parse->filters++] = ur_list_create();
	_ur_parse_add(parse->lists[parse->filters - 1], filter);
}

void ur_parse_item_add(ur_parse_t parse, const char *item)
{
	_ur_parse_check(parse);
	if (parse->filters < 1) {
		ur_fatal(__func__, "Cannot add item when filters=%d\n",
			 parse->filters);
	}
	if (!parse->lists[parse->filters - 1]) {
		ur_internal(__func__, "No list, filters=%d\n", parse->filters);
	}
	_ur_parse_add(parse->lists[parse->filters - 1], item);
}

ur_list_t ur_parse(ur_parse_t parse, const char *string,
		   int *v0, const char **v1)
{
	ur_iterator_t iter;
	pcre          *p;
	int           i;
	ur_list_t     result = ur_list_create();
	
	_ur_parse_check(parse);

	for (i = 0; i < parse->filters; i++) {
		ur_list_t list = parse->lists[i];
		pcre      *filter = ur_list_top(list);
		int       retcode;
		int       ovector[10];
		int       iteration = 0;

		retcode = pcre_exec(filter,
				    NULL,
				    string,
				    strlen(string),
				    0,
				    0,
				    ovector,
				    sizeof(ovector)/sizeof(ovector[0]));

		if (retcode <= 0) {
			ur_trace(UR_TRACE_PARSE, __func__,
				 "retcode=%d\n", retcode);
			continue; /* No match */
		}
		
		UR_LIST_ITERATE(list, iter, p) {
			const char *item;
			++iteration;
			if (iteration < 3 || !(iteration & 1)) continue;
			retcode = pcre_exec(p,
					    NULL,
					    string,
					    strlen(string),
					    0,
					    0,
					    ovector,
					    sizeof(ovector)
					    /sizeof(ovector[0]));
			if (retcode <= 1) {
				ur_trace(UR_TRACE_PARSE, __func__,
					 "retcode=%d iteration=%d\n",
					 retcode, iteration);
				ur_list_append(result, "");
				continue;
			}
			ur_trace(UR_TRACE_PARSE, __func__,
				 "retcode=%d ovector=[%d,%d,%d,%d]\n",
				 retcode, ovector[0], ovector[1],
				 ovector[2], ovector[3]);
			
			item = ur_atom_string_n(string + ovector[2],
						ovector[3] - ovector[2]);
			ur_list_append(result, item);
			ur_trace(UR_TRACE_PARSE, __func__,
				 "%d \"%s\"\n", iteration, item);
		}
		break;
	}

	if (!ur_list_depth(result)) {
		ur_list_destroy(result);
		return NULL;
	}
	if (!v0) *v0 = parse->v0[i];
	if (!v1) *v1 = parse->v1[i];
	return result;
}

void ur_parse_attribute_int(ur_parse_t parse, int v0)
{
	_ur_parse_check(parse);
	parse->v0[parse->filters - 1] = v0;
}

void ur_parse_attribute_string(ur_parse_t parse, const char *v1)
{
	_ur_parse_check(parse);
	parse->v1[parse->filters - 1] = ur_atom_string(v1);
}

int ur_parse_get_attribute_int(ur_parse_t parse, int filter)
{
	_ur_parse_check(parse);
	if (filter >= parse->filters) return 0;
	return parse->v0[filter];
}

const char *ur_parse_get_attribute_string(ur_parse_t parse, int filter)
{
	_ur_parse_check(parse);
	if (filter >= parse->filters) return NULL;
	return parse->v1[filter];
}

const char *ur_parse_get_filter(ur_parse_t parse, int filter)
{
	_ur_parse_check(parse);
	if (filter >= parse->filters) return NULL;
	return ur_list_nth(parse->lists[filter], 2);
}

const char *ur_parse_get_item(ur_parse_t parse, int filter, int item)
{
	_ur_parse_check(parse);
	if (filter >= parse->filters) return NULL;
	if (item < 0 || item > 4) return NULL;
	return ur_list_nth(parse->lists[filter], (item + 1) * 2 + 2);
}
