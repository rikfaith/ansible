/* pr.c -- Process creation and tracking support
 * Created: Sun Jan  7 13:34:08 1996 by faith@acm.org
 * Revised: Thu Dec 25 11:43:06 2008 by faith@acm.org
 * Copyright 1996 Rickard E. Faith (faith@acm.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * \section{Process Management Routines}
 *
 * \intro The process management routines are designed to facilitate the
 * creation and management of child processes, coprocesses, and associated
 * pipelines and I/O.  Some support for daemons and socket connections is
 * also provided. 
 *
 */

#define _XOPEN_SOURCE 500
#include "urP.h"
#include <errno.h>
#include <signal.h>
#include <fcntl.h>

#if HAVE_SYS_PRCTL_H
# include <sys/prctl.h>
#endif

#if HAVE_SYS_PARAM_H
# include <sys/param.h>
#endif

#if HAVE_SYS_WAIT_H
# include <sys/wait.h>
#endif
#ifndef WEXITSTATUS
# define WEXITSTATUS(stat_val) ((unsigned)(stat_val) >> 8)
#endif
#ifndef WIFEXITED
# define WIFEXITED(stat_val) (((stat_val) & 255) == 0)
#endif

#define ur_max(a,b) ((a)>(b)?(a):(b))

typedef struct {
   int pid;
} *ur_pr_object_t;

static ur_pr_object_t ur_pr_objects = NULL;

#if 0
static void _pr_check( pr_Object object, const char *function )
{
   Obj o = (Obj)object;

   if (!o) err_internal( function, "object is null\n" );
#if MAA_MAGIC
   if (o->magic != PR_MAGIC)
      err_internal( function,
		    "Magic match failed: 0x%08x (should be 0x%08x)\n",
		    o->magic,
		    PR_MAGIC );
#endif
}
#endif

/* The idea for the max_fd call is from W. Richard Stevens; Advanced
   Programming in the UNIX Environment (Addison-Wesley Publishing Co.,
   1992); page 43.  The implementation here, however, is different from
   that provided by Stevens for his open_max routine. */

static int ur_pr_max_fd( void )
{
	static int maxFd = 0;

	if (maxFd) return maxFd;

#ifdef _SC_OPEN_MAX
	if ((maxFd = sysconf(_SC_OPEN_MAX)) > 0) return maxFd;
#endif

#ifdef NOFILE
	return maxFd = NOFILE;	/* Usually in sys/params.h */
#else
# ifdef _NFILE
	return maxFd = _NFILE;
# else
	return maxFd = 256;		/* best guess */
# endif
#endif
}

static void ur_pr_init( void )
{
	if (!ur_pr_objects)
		ur_pr_objects = ur_allocz(ur_pr_max_fd()
					  * sizeof(*ur_pr_objects));
}

void ur_pr_shutdown(void)
{
	int i;

	if (ur_pr_objects) {
		for (i = 0; i < ur_pr_max_fd(); i++) {
			/* FIXME: blah */;
			if (ur_pr_objects[i].pid) {
				kill(ur_pr_objects[i].pid, SIGTERM);
				ur_pr_wait(ur_pr_objects[i].pid);
				ur_pr_objects[i].pid = 0;
			}
		}
		ur_free(ur_pr_objects);
		ur_pr_objects = NULL;
	}
}

int ur_pr_open(const char *command, ur_pr_flags_t flags, int *infd,
	       int *outfd, int *errfd)
{
	int         pid;
	int         fdin[2];
	int         fdout[2];
	int         fderr[2];
	ur_list_t   list;
	int         argc;
	const char  **argv;
	int         null;
   
	ur_pr_init();

	if (flags & ~(UR_PR_USE_STDIN | UR_PR_USE_STDOUT | UR_PR_USE_STDERR
		      | UR_PR_CREATE_STDIN | UR_PR_CREATE_STDOUT
		      | UR_PR_CREATE_STDERR | UR_PR_STDERR_TO_STDOUT))
		ur_fatal(__func__, "Illegal flags: 0x%08x\n", flags);
	if ((flags & UR_PR_USE_STDIN) && (flags & UR_PR_CREATE_STDIN))
		ur_fatal(__func__, "Cannot both use and create stdin\n" );
	if ((flags & UR_PR_USE_STDOUT) && (flags & UR_PR_CREATE_STDOUT))
		ur_fatal(__func__, "Cannot both use and create stdout\n" );
	if ((flags & UR_PR_USE_STDERR) && (flags & UR_PR_CREATE_STDERR))
		ur_fatal(__func__, "Cannot both use and create stderr\n" );
	if ((flags & UR_PR_STDERR_TO_STDOUT)
	    && ((flags & UR_PR_USE_STDERR) || (flags & UR_PR_CREATE_STDERR)))
		ur_fatal(__func__,
			 "Cannot use/create stderr when duping to stdout\n" );
   
	list = ur_list_create();
	ur_list_parse_string(list, command);
	ur_list_make_argv(list, &argc, &argv);
	ur_trace(UR_TRACE_PR, __func__,
		 "Execing %s with \"%s\"\n", argv[0], command);

	if ((flags & UR_PR_CREATE_STDIN) && pipe(fdin) < 0)
		ur_fatal_errno(__func__, "Cannot create pipe for stdin\n" );
	if ((flags & UR_PR_CREATE_STDOUT) && pipe(fdout) < 0)
		ur_fatal_errno(__func__, "Cannot create pipe for stdout\n" );
	if ((flags & UR_PR_CREATE_STDERR) && pipe(fderr) < 0)
		ur_fatal_errno(__func__, "Cannot create pipe for stderr\n" );
   
	if ((pid = vfork()) < 0)
		ur_fatal_errno(__func__, "Cannot fork\n" );

	if (pid == 0) {		/* child */
		int        i;

		ur_trace(UR_TRACE_PR, __func__,
			 "child pid=%d pgid=%d\n", getpid(),
			 getpgid(getpid()));

#define CHILD(CREATE,USE,fds,writefd,readfd,fd,FILENO,flag)		\
		if (flags & CREATE) {					\
			close(fds[writefd]);				\
			dup2(fds[readfd], FILENO);			\
			close(fds[readfd]);				\
		} else if (flags & USE) {				\
			if (fd && *fd) {				\
				dup2(*fd, FILENO);			\
				close(*fd);				\
			} else {					\
				if ((null = open( "/dev/null", flag )) >= 0){ \
					dup2(null, FILENO);		\
					close(null);			\
				}					\
			}						\
		}
      
		CHILD(UR_PR_CREATE_STDIN,  UR_PR_USE_STDIN,
		      fdin,  1, 0, infd,  STDIN_FILENO, O_RDONLY);
		CHILD(UR_PR_CREATE_STDOUT, UR_PR_USE_STDOUT,
		      fdout, 0, 1, outfd, STDOUT_FILENO, O_WRONLY);
		CHILD(UR_PR_CREATE_STDERR, UR_PR_USE_STDERR,
		      fderr, 0, 1, errfd, STDERR_FILENO, O_WRONLY);
      
#undef CHILD

		if (flags & UR_PR_STDERR_TO_STDOUT)
			dup2(STDOUT_FILENO, STDERR_FILENO);
		
		for (i = 0; i < ur_pr_max_fd(); i++)
			if (ur_pr_objects[i].pid > 0) close( i );

#if HAVE_SYS_PRCTL_H
		prctl(PR_SET_PDEATHSIG, SIGKILL);
#endif
		execvp(argv[0], (char **)argv);
		_exit(127);
	}
				/* parent */
#define PARENT(CREATE,USE,fds,readfd,writefd,fd,flag,name)		\
	if (flags & CREATE) {						\
		close(fds[readfd]);					\
		*fd = fds[writefd];					\
		ur_pr_objects[*fd].pid = pid;				\
		ur_trace(UR_TRACE_PR, __func__, name " = %d; ",*fd);	\
	} else if (flags & USE) {					\
		if (fd && *fd) {					\
			ur_trace(UR_TRACE_PR, __func__, name " = %d*; ",\
				 *fd);					\
			ur_pr_objects[*fd].pid =0;			\
			close(*fd);					\
		}							\
	}
	
	PARENT(UR_PR_CREATE_STDIN,  UR_PR_USE_STDIN,
	       fdin,  0, 1, infd,  "w", "stdin" );
	PARENT(UR_PR_CREATE_STDOUT, UR_PR_USE_STDOUT,
	       fdout, 1, 0, outfd, "r", "stdout" );
	PARENT(UR_PR_CREATE_STDERR, UR_PR_USE_STDERR,
	       fderr, 1, 0, errfd, "r", "stderr" );
   
#undef PARENT

	ur_trace(UR_TRACE_PR, __func__,
		 "child pid=%d pgid=%d\n", pid, getpgid(pid));
	ur_list_destroy(list);
   
	return pid;
}

int ur_pr_wait(int pid)
{   
	int exitStatus = 0;
	int status;
   
	ur_trace(UR_TRACE_PR, __func__, "waiting on pid %d\n", pid);
   
	while (waitpid(pid, &status, 0) < 0) {
		if (errno != EINTR) {
			if (errno == ECHILD) return 0;	/* We already waited */
			/* This is really bad... */
			ur_trace(UR_TRACE_PR, __func__,
				 "waitpid() < 0, errno = %d\n", errno);
			perror(__func__);
			return -1;
		}
	}
   
	if (WIFEXITED(status))
		exitStatus |= WEXITSTATUS(status);
      
	/* SIGPIPE is ok here, since tar may shutdown early.  Anything
	   else is a problem.  */
	if (WIFSIGNALED(status) && WTERMSIG(status) != SIGPIPE)
		exitStatus |= 128 + WTERMSIG(status); /* like bash :-) */

	ur_trace(UR_TRACE_PR, __func__,
		 "Child %d exited with status 0x%04x\n", pid, exitStatus);
   
	return exitStatus;
}

int ur_pr_close_nowait(int fd)
{
	int pid;

	if (!ur_pr_objects)
		ur_fatal(__func__, "No previous call to pr_open()\n");
	if (!(pid = ur_pr_objects[fd].pid))
		ur_fatal(__func__, "File (%d) not created by pr_open()\n", fd);

	ur_pr_objects[fd].pid = 0;

	close(fd);
	return pid;
}

int ur_pr_close(int fd)
{
	int pid = ur_pr_close_nowait(fd);
   
	return ur_pr_wait(pid);
}

int ur_pr_readwrite(int in, int out,
		    const char *inBuffer, int inLen,
		    char *outBuffer, int outMaxLen)
{
	long           flags;
	const char     *inPt  = inBuffer;
	char           *outPt = outBuffer;
	int            outLen = 0;
	fd_set         rfds, wfds, efds;
	struct timeval tv;
	int            n;
	int            count;
	int            retval;
	int            status;
	
	if ((flags = fcntl(in, F_GETFL )) < 0)
		ur_fatal_errno(__func__,
			       "Can't get flags for output stream\n");
#ifdef O_NONBLOCK
	flags |= O_NONBLOCK;
#else
	flags |= FNDELAY;
#endif
	fcntl(in, F_SETFL, flags);

	if ((flags = fcntl(out, F_GETFL)) < 0)
		ur_fatal_errno(__func__, "Can't get flags for input stream\n");
#ifdef O_NONBLOCK
	flags |= O_NONBLOCK;
#else
	flags |= FNDELAY;
#endif
	fcntl(out, F_SETFL, flags);

	n = ur_max(in, out) + 1;

	for (;;) {
		tv.tv_sec  = 5;
		tv.tv_usec = 0;
		FD_ZERO(&rfds);
		FD_ZERO(&wfds);
		FD_ZERO(&efds);
		FD_SET(out, &rfds);
		FD_SET(out, &efds);
		if (inLen) {
			FD_SET(in, &wfds);
			FD_SET(in, &efds);
		}
   
		switch ((retval = select(n, &rfds, &wfds, &efds, &tv))) {
		case -1:
			ur_fatal_errno(__func__, "Filter failed\n");
			break;
/*       case 0:  err_fatal( __FUNCTION__, "Filter hung\n" );         break; */
		default:
			if (ur_trace_test(UR_TRACE_PR)) {
				printf("select(2) returns %d,"
				       " inLen = %d, outLen = %d,"
				       " outMaxLen = %d\n",
				       retval, inLen, outLen, outMaxLen);
				if (FD_ISSET(in,  &rfds))
					printf("  in/read\n");
				if (FD_ISSET(out, &rfds))
					printf("  out/read\n");
				if (FD_ISSET(in,  &wfds))
					printf("  in/write\n");
				if (FD_ISSET(out, &wfds))
					printf("  out/write\n");
				if (FD_ISSET(in,  &efds))
					printf("  in/error\n");
				if (FD_ISSET(out, &efds))
					printf("  out/error\n");
			}
			if (inLen) {
				if ((count = write(in, inPt, inLen)) <= 0) {
					if (errno != EAGAIN)
						ur_fatal_errno(__func__,
							       "Error writing to filter\n");
				} else {
					ur_trace(UR_TRACE_PR, __func__, "  wrote %d\n", count);
					inLen -= count;
					inPt  += count;
					if (!inLen) {
						ur_pr_close_nowait( in );
						n = out + 1;
					}
				}
			}
			if ((count = read(out, outPt, outMaxLen)) <= 0) {
				if (!count) {
					if (inLen)
						ur_fatal(__func__, 
							 "End of output, but input not flushed\n");
					if ((status = ur_pr_close(out)))
						ur_warning(__func__, 
							   "Filter had non-zero exit status: 0x%x\n",
							   status);
					return outLen;
				} else if (errno != EAGAIN)
					ur_fatal_errno(__func__, "Error reading from filter\n");
			} else {
				ur_trace(UR_TRACE_PR, __func__, "  read %d\n", count);
				outLen    += count;
				outPt     += count;
				if ((outMaxLen -= count) < 0)
					ur_fatal(__func__, "Output buffer overflow\n");
			}
			break;
		}
	}
}

int ur_pr_filter(const char *command,
		 const char *inBuffer, int inLen,
		 char *outBuffer, int outMaxLen)
{
	int  pid;
	int  in, out;
	
	pid = ur_pr_open(command, UR_PR_CREATE_STDIN | UR_PR_CREATE_STDOUT,
			 &in, &out, NULL );
	return ur_pr_readwrite(in, out, inBuffer, inLen, outBuffer, outMaxLen);
}

int ur_pr_spawn(const char *command)
{
	ur_list_t   list;
	int         argc;
	const char  **argv;
	int         pid;
	int         status;
	int         exitStatus = 0;
   
	ur_pr_init();

	list = ur_list_create();
	ur_list_parse_string(list, command);
	ur_list_make_argv(list, &argc, &argv);
	ur_trace(UR_TRACE_PR, __func__,
		 "Execing %s with \"%s\"\n", argv[0], command);
   
	if ((pid = vfork()) < 0)
		ur_fatal_errno(__func__, "Cannot fork\n");

	if (pid == 0) {		/* child */
		ur_trace(UR_TRACE_PR, __func__,
			 "child: pid=%d pgid=%d\n", getpid(),
			 getpgid(getpid()));
		execvp(argv[0], (char **)argv);
		_exit(127);
	}
   
				/* parent */
	ur_trace(UR_TRACE_PR, __func__,
		 "parent: ppid=%d cpid=%d pgid=%d\n",
		 getpid(), pid, getpgid(pid));
	ur_list_destroy(list);

	ur_trace(UR_TRACE_PR, __func__, "waiting on pid %d\n", pid);
	while (waitpid(pid, &status, 0) < 0) {
		if (errno != EINTR) {
			if (errno == ECHILD) return 0;	/* Already waited */
			/* This is really bad... */
			ur_trace(UR_TRACE_PR, __func__,
				 "waitpid() < 0, errno = %d\n", errno);
			perror(__func__);
			return -1;
		}
	}
   
	if (WIFEXITED(status))
		exitStatus |= WEXITSTATUS(status);
      
	/* SIGPIPE is ok here, since tar may shutdown early.  Anything
	   else is a problem.  */
	if (WIFSIGNALED(status) && WTERMSIG(status) != SIGPIPE)
		exitStatus |= 128 + WTERMSIG(status); /* like bash :-) */

	ur_trace(UR_TRACE_PR, __func__,
		 "Child %d exited with status 0x%04x\n", pid, exitStatus);
   
	return exitStatus;
}
