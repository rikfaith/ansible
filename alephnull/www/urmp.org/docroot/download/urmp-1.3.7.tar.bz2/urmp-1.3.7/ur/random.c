/* random.c -- 
 * Created: Mon Jul  5 13:32:00 1999 by faith@dict.org
 * Copyright 1999, 2002, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: random.c,v 1.4 2002-12-23 17:05:00 faith Exp $
 *
 * References
 *
 * [BD76] Carter Bays and S. D. Durham. "Improving a Poor Random Number
 * Generator".  ACM Trans. Math. Softw. 2(1), March 1976, pp. 59-64.
 *
 * [Knuth98] Donald E. Knuth. The Art of Computer Programming.  Volume 2:
 * Seminumerical Algorithms.  3rd ed. Reading, Massachusetts:
 * Addison-Wesley, 1998.
 *
 * [Leva92] Joseph L. Leva.  Algorithm 712: A Normal Random Number Generator.
 * ACM Trans. Math. Softw. 18(4), December 1992, pp. 454-5.
 *
 * [LE88] Pierre L'Ecuyer. "Efficient and Portable Combined Random Number
 * Generators".  CACM 31(6), June 1988, pp. 742-774.
 *
 * [LE90] Pierre L'Ecuyer. "Random Numbers for Simulation". CACM 33(10,
 * October 1990, pp. 85-97.
 *
 * [PM88] Stephen K. Park and Keith W. Miller. "Random Number Generators:
 * Good Ones are Hard to Find". CACM 31(10), October 1988, pp. 1192-1201.
 *
 * [Sch92] Bruce Schneier. "Pseudo-Random Sequence Generator for 32-Bit
 * CPUs".  Dr. Dobb's Journal 17(2), February 1992, pp. 34, 37-38, 40.
 *
 * [PMS93] Stephen K. Park, Keith W. Miller, and Paul K. Stockmeyer.  In
 * "Technical Correspondence: Remarks on Choosing and Implementing Random
 * Number Generators". CACM 36(7), July 1993, pp. 105-110.
 *
 */

#include "urP.h"

typedef struct {
	uint32_t      a;
	uint32_t      m;
	uint32_t      q;		/* m div a */
	uint32_t      r;		/* m mod a */
	uint32_t      seed;
} ur_random_mlcg_t;

static ur_random_mlcg_t _ur_mlcg[] = {
				/* Reference followed by value after 10000
                                 * iterations starting with seed = 1.
				 *
				 * Values for LE88 are from
				 * http://www.ddj.com/cpp/184403024?pgno=7
				 * (Dr. Dobb's; Quick and Portable
				 * Random Number Generators; June 1,
				 * 1995; Jerry Dwyer).  And in
				 * Measurement Canada; Specifications
				 * for Random Sampling and
				 * Randomization; specification S-S-01,
				 * 2008-11-10, page 10.
				 *
				 * From various random code on the net,
				 * the additive combination of the two
				 * LE88's give 2060321752 in the 10000th
				 * iteration.
				 */
    { 16807, 2147483647, 127773,  2836, 1 }, /* [PM88]  1043618065 */
    { 48271, 2147483647,  44488,  3399, 1 }, /* [PMS93]  399268537 */
    { 40014, 2147483563,  53668, 12211, 1 }, /* [LE88]  1919456777 */
    { 40692, 2147483399,  52774,  3791, 1 }  /* [LE88]  2006618587 */
};

struct ur_random_s {
	unsigned long        magic;
	ur_random_type_t     type;
	ur_random_modifier_t modifier;
	unsigned long        (*getrnd)(ur_random_t prng);
	unsigned long        (*base)(ur_random_t prng);
	void                 (*setseed)(ur_random_t prng,
					unsigned long seed0,
					unsigned long seed1);

	unsigned long        max;
	ur_random_mlcg_t     m0;
	ur_random_mlcg_t     m1;

				/* Shuffle support */
	unsigned long        *shuffle;
	unsigned long        shuffle_next;
};

CHECK_FUNCTION(_ur_random_check, ur_random_t, UR_RANDOM_MAGIC)

static __inline__ unsigned long _ur_random_mlcg(ur_random_mlcg_t *s)
{
    unsigned long  hi;
    unsigned long  lo;

    hi      = s->seed / s->q;
    lo      = s->seed % s->q;
    s->seed = s->a * lo - s->r * hi;
    if (s->seed >= s->m) {
	s->seed += s->m;
	s->seed &= 0xffffffff;	/* Keep 32-bit */
    }

    return s->seed;
}

static unsigned long _ur_random_mlcg_random(ur_random_t prng)
{
    return _ur_random_mlcg(&prng->m0);
}

static void _ur_random_mlcg_seed(ur_random_t prng,
				 unsigned long seed0,
				 unsigned long seed1)
			       
{
    ur_random_mlcg_t *s = &prng->m0;

    s->seed = seed0 + seed1;
    if (!s->seed || s->seed >= s->m) s->seed = s->m - 1;
}

static unsigned long _ur_random_long_random(ur_random_t prng)
{
    unsigned long s1 = _ur_random_mlcg(&prng->m0);
    unsigned long s2 = _ur_random_mlcg(&prng->m1);
    unsigned long z  = s1 - s2;

    if (!z || z > prng->m0.m) {
	z += prng->m0.m - 1;
	z &= 0xffffffff;
    }
    return z;
}

static void _ur_random_long_seed(ur_random_t prng,
				 unsigned long seed0,
				 unsigned long seed1)
			       
{
    ur_random_mlcg_t *s0 = &prng->m0;
    ur_random_mlcg_t *s1 = &prng->m1;

    s0->seed = seed0;
    if (!s0->seed || s0->seed >= s0->m) s0->seed = s0->m - 1;
    
    s1->seed = seed1;
    if (!s1->seed || s1->seed >= s1->m) s1->seed = s1->m - 1;
}

/* Algorithm from [BD76] as presented in [Knuth98, p. 33].  Knuth suggests
   making the table size equal to the byte size of the machine, and using
   the high-order byte of Y as J.  This simplifies the code.  */
static unsigned long _ur_random_shuffle(ur_random_t prng)
{
    unsigned long j = (prng->shuffle_next & 0xff000000) >> 24;

    prng->shuffle_next = prng->shuffle[j];
    prng->shuffle[j]   = (*prng->base)(prng);
    
    return prng->shuffle_next;
}

static void _ur_random_shuffle_init(ur_random_t prng)
{
    int i;

    prng->getrnd       = _ur_random_shuffle;
    prng->shuffle      = ur_alloc(256 * sizeof(*prng->shuffle));

    for (i = 0; i < 256; i++) prng->shuffle[i] = (*prng->base)(prng);
    prng->shuffle_next = (*prng->base)(prng);
}

/* This is the 32-slot shuffle everyone else uses. */
static unsigned long _ur_random_shuffle32(ur_random_t prng)
{
	unsigned long j;
	unsigned long r0 = _ur_random_mlcg(&prng->m0);
	unsigned long r1 = _ur_random_mlcg(&prng->m1);

	j = prng->shuffle_next / (prng->m0.m / 32);

#if 0
	printf("r0=%lu r1=%lu j=%lu shuffle_next=%lu\n", r0, r1, j,
		prng->shuffle_next);
	{
		int i;
		for (i = 0; i < 32; i++) {
			printf("%d => %lu\n", i, prng->shuffle[i] - r1);
		}
	}
#endif

	prng->shuffle_next = prng->shuffle[j] - r1;
	if (!prng->shuffle_next
	    || prng->shuffle_next > prng->m0.m) {
		prng->shuffle_next += prng->m0.m - 1;
		prng->shuffle_next &= 0xffffffff;
	}
	prng->shuffle[j]   = r0;

//	printf("providing %lu\n", prng->shuffle_next);
	fflush(stdout);
	return prng->shuffle_next;
}

static void _ur_random_shuffle_init32(ur_random_t prng)
{
	int i;

	if (!prng->shuffle) {
		prng->shuffle = ur_alloc(32 * sizeof(*prng->shuffle));
	}

	prng->getrnd = _ur_random_shuffle32;

	if (!prng->m0.seed || prng->m0.seed >= prng->m0.m) {
		prng->m0.seed      = 1;
	}
	if (!prng->m1.seed || prng->m1.seed >= prng->m1.m) {
		prng->m1.seed      = 1;
	}

	for (i = 0; i < 8; i++) {
		_ur_random_mlcg(&prng->m0);
	}
	for (i = 31; i >= 0; i--) {
		prng->shuffle[i] = _ur_random_mlcg(&prng->m0);
//		printf("loaded %d with %lu\n", i, prng->shuffle[i]);
	}
	prng->shuffle_next = prng->shuffle[0];
}

static void _ur_random_shuffle_seed32(ur_random_t prng,
				      unsigned long seed0,
				      unsigned long seed1)
{
	_ur_random_long_seed(prng, seed0, seed1);
	_ur_random_shuffle_init32(prng);
}

ur_random_t ur_random_create(ur_random_type_t type,
			     ur_random_modifier_t modifier)
{
    ur_random_t prng = ur_allocz(sizeof(*prng));

    prng->magic    = UR_RANDOM_MAGIC;
    prng->type     = type;
    prng->modifier = modifier;

    switch (type) {
    case UR_RANDOM_STD:
	prng->m0              = _ur_mlcg[0];
	prng->max             = prng->m0.m - 1;
	prng->base            = _ur_random_mlcg_random;
	prng->setseed         = _ur_random_mlcg_seed;
	break;
    case UR_RANDOM_ALT0:
	prng->m0              = _ur_mlcg[1];
	prng->max             = prng->m0.m - 1;
	prng->base            = _ur_random_mlcg_random;
	prng->setseed         = _ur_random_mlcg_seed;
	break;
    case UR_RANDOM_ALT1:
	prng->m0              = _ur_mlcg[2];
	prng->max             = prng->m0.m - 1;
	prng->base            = _ur_random_mlcg_random;
	prng->setseed         = _ur_random_mlcg_seed;
	break;
    case UR_RANDOM_ALT2:
	prng->m0              = _ur_mlcg[3];
	prng->max             = prng->m0.m - 1;
	prng->base            = _ur_random_mlcg_random;
	prng->setseed         = _ur_random_mlcg_seed;
	break;
    case UR_RANDOM_LONG0:
	prng->m0              = _ur_mlcg[2];
	prng->m1              = _ur_mlcg[3];
	prng->max             = prng->m0.m - 1;
	prng->base            = _ur_random_long_random;
	prng->setseed         = _ur_random_long_seed;
	break;
    case UR_RANDOM_LONG1:
	prng->m0              = _ur_mlcg[2];
	prng->m1              = _ur_mlcg[3];
	prng->max             = prng->m0.m - 1;
	prng->base            = NULL;
	prng->setseed         = _ur_random_shuffle_seed32;
	_ur_random_shuffle_seed32(prng, 1, 1);
	return prng;
    }

    if (modifier & UR_RANDOM_SHUFFLE)        _ur_random_shuffle_init(prng);
    else                                     prng->getrnd = prng->base;

    return prng;
}

unsigned long ur_random_destroy(ur_random_t prng)
{
    unsigned long ret;

    _ur_random_check(prng);
    ret = prng->magic = ~UR_RANDOM_MAGIC;
    if (prng->shuffle) ur_free(prng->shuffle);
    ur_free(prng);
    return ret;
}

void ur_random_seed(ur_random_t prng, unsigned long seed0, unsigned long seed1)
{
    _ur_random_check(prng);
    (*prng->setseed)(prng, seed0, seed1);
}

unsigned long ur_random(ur_random_t prng)
{
    _ur_random_check(prng);
    return (*prng->getrnd)(prng);
}

unsigned long ur_random_max(ur_random_t prng)
{
    _ur_random_check(prng);
    return prng->max;
}

unsigned long ur_random_range(ur_random_t prng,
			      unsigned long min,
			      unsigned long max)
{

    _ur_random_check(prng);
    if (min > max) ur_internal(__func__, "%lu > %lu\n", min, max);
    return min + (unsigned long)(ur_random_real(prng) * (max - min + 1));
}

double ur_random_real(ur_random_t prng)
{
    _ur_random_check(prng);
    return (double)prng->getrnd(prng) / ((double)prng->max + 1.0);
}
