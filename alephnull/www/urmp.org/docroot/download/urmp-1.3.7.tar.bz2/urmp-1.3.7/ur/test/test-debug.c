/* test-debug.c -- 
 * Created: Sun Jul 23 10:52:23 2000 by faith@dict.org
 * Copyright 2000, 2003 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * $Id: test-debug.c,v 1.3 2003-06-11 12:39:20 faith Exp $
 *
 */

#define OBJECTTYPE     ur_flag_t
#define OBJECTCREATEV  ur_flag_create
#define OBJECTDESTROY  ur_flag_destroy

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define FLAG0 0x00000002
#define FLAG1 0x00000001
#define FLAG2 0x40000010
#define FLAG3 0x80000100
#define FLAG4 0xc0001000

static int testlocal(void)
{
    ur_flag_t       flags;
    const char     *name;
    
    test("L", "Register/name");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    name = ur_flag_name(flags, FLAG1);
    if (strcmp("one", name)) fail(name);
    ok(0);
    end(flags);

    test("L", "Not set");
    flags = ur_flag_create();
    if (ur_flag_test(flags, FLAG1)) fail("1 set");
    if (ur_flag_test(flags, FLAG2)) fail("2 set");
    if (ur_flag_test(flags, FLAG3)) fail("3 set");
    if (ur_flag_test(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Set");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    if (ur_flag_test(flags, FLAG1)) fail("1 set");
    ur_flag_set(flags, FLAG1);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set");
    if (ur_flag_test(flags, FLAG2)) fail("2 set");
    if (ur_flag_test(flags, FLAG3)) fail("3 set");
    if (ur_flag_test(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Set 2");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_register(flags, FLAG2, "two");
    if (ur_flag_test(flags, FLAG1)) fail("1 set");
    ur_flag_set(flags, FLAG1);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set a");
    if (ur_flag_test(flags, FLAG2)) fail("2 set a");
    if (ur_flag_test(flags, FLAG3)) fail("3 set a");
    if (ur_flag_test(flags, FLAG4)) fail("4 set a");
    ur_flag_set(flags, FLAG2);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set b");
    if (!ur_flag_test(flags, FLAG2)) fail("2 not set b");
    if (ur_flag_test(flags, FLAG3)) fail("3 set b");
    if (ur_flag_test(flags, FLAG4)) fail("4 set b");
    ok(0);
    end(flags);

    test("L", "Set 2 by name");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_register(flags, FLAG2, "two");
    if (ur_flag_test(flags, FLAG1)) fail("1 set");
    ur_flag_set_by_name(flags, "one", NULL);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set a");
    if (ur_flag_test(flags, FLAG2)) fail("2 set a");
    if (ur_flag_test(flags, FLAG3)) fail("3 set a");
    if (ur_flag_test(flags, FLAG4)) fail("4 set a");
    ur_flag_set_by_name(flags, "two", NULL);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set b");
    if (!ur_flag_test(flags, FLAG2)) fail("2 not set b");
    if (ur_flag_test(flags, FLAG3)) fail("3 set b");
    if (ur_flag_test(flags, FLAG4)) fail("4 set b");
    ok(0);
    end(flags);

    test("L", "Unset");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_set(flags, FLAG1);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set");
    ur_flag_unset(flags, FLAG1);
    if (ur_flag_test(flags, FLAG1)) fail("1 set");
    if (ur_flag_test(flags, FLAG2)) fail("2 set");
    if (ur_flag_test(flags, FLAG3)) fail("3 set");
    if (ur_flag_test(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Unset 2");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_register(flags, FLAG2, "two");
    ur_flag_set(flags, FLAG1);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set");
    ur_flag_unset(flags, FLAG1);
    if (ur_flag_test(flags, FLAG1)) fail("1 set a");
    if (ur_flag_test(flags, FLAG2)) fail("2 set a");
    if (ur_flag_test(flags, FLAG3)) fail("3 set a");
    if (ur_flag_test(flags, FLAG4)) fail("4 set a");
    ur_flag_set(flags, FLAG1);
    ur_flag_set(flags, FLAG2);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set b");
    if (!ur_flag_test(flags, FLAG2)) fail("2 not set b");
    if (ur_flag_test(flags, FLAG3)) fail("3 set b");
    if (ur_flag_test(flags, FLAG4)) fail("4 set b");
    ur_flag_unset(flags, FLAG2);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set c");
    if (ur_flag_test(flags, FLAG2)) fail("2 set c");
    if (ur_flag_test(flags, FLAG3)) fail("3 set c");
    if (ur_flag_test(flags, FLAG4)) fail("4 set c");
    ur_flag_unset(flags, FLAG1);
    if (ur_flag_test(flags, FLAG1)) fail("1 set d");
    if (ur_flag_test(flags, FLAG2)) fail("2 set d");
    if (ur_flag_test(flags, FLAG3)) fail("3 set d");
    if (ur_flag_test(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);
    
    test("L", "Unset 2 alt");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_register(flags, FLAG0, "zero");
    ur_flag_set(flags, FLAG1);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set");
    ur_flag_unset(flags, FLAG1);
    if (ur_flag_test(flags, FLAG0)) fail("0 set a");
    if (ur_flag_test(flags, FLAG1)) fail("1 set a");
    if (ur_flag_test(flags, FLAG2)) fail("2 set a");
    if (ur_flag_test(flags, FLAG3)) fail("3 set a");
    if (ur_flag_test(flags, FLAG4)) fail("4 set a");
    ur_flag_set(flags, FLAG1);
    ur_flag_set(flags, FLAG0);
    if (!ur_flag_test(flags, FLAG0)) fail("0 not set b");
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set b");
    if (ur_flag_test(flags, FLAG2)) fail("2 set b");
    if (ur_flag_test(flags, FLAG3)) fail("3 set b");
    if (ur_flag_test(flags, FLAG4)) fail("4 set b");
    ur_flag_unset(flags, FLAG0);
    if (ur_flag_test(flags, FLAG0)) fail("0 set c");
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set c");
    if (ur_flag_test(flags, FLAG2)) fail("2 set c");
    if (ur_flag_test(flags, FLAG3)) fail("3 set c");
    if (ur_flag_test(flags, FLAG4)) fail("4 set c");
    ur_flag_unset(flags, FLAG1);
    if (ur_flag_test(flags, FLAG0)) fail("0 set d");
    if (ur_flag_test(flags, FLAG1)) fail("1 set d");
    if (ur_flag_test(flags, FLAG2)) fail("2 set d");
    if (ur_flag_test(flags, FLAG3)) fail("3 set d");
    if (ur_flag_test(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);
    
    test("L", "Unset 2 by name");
    flags = ur_flag_create();
    ur_flag_register(flags, FLAG1, "one");
    ur_flag_register(flags, FLAG2, "two");
    ur_flag_set_by_name(flags, "one", NULL);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set");
    ur_flag_unset_by_name(flags, "one", NULL);
    if (ur_flag_test(flags, FLAG1)) fail("1 set a");
    if (ur_flag_test(flags, FLAG2)) fail("2 set a");
    if (ur_flag_test(flags, FLAG3)) fail("3 set a");
    if (ur_flag_test(flags, FLAG4)) fail("4 set a");
    ur_flag_set(flags, FLAG1);
    ur_flag_set(flags, FLAG2);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set b");
    if (!ur_flag_test(flags, FLAG2)) fail("2 not set b");
    if (ur_flag_test(flags, FLAG3)) fail("3 set b");
    if (ur_flag_test(flags, FLAG4)) fail("4 set b");
    ur_flag_unset_by_name(flags, "two", NULL);
    if (!ur_flag_test(flags, FLAG1)) fail("1 not set c");
    if (ur_flag_test(flags, FLAG2)) fail("2 set c");
    if (ur_flag_test(flags, FLAG3)) fail("3 set c");
    if (ur_flag_test(flags, FLAG4)) fail("4 set c");
    ur_flag_unset_by_name(flags, "one", NULL);
    if (ur_flag_test(flags, FLAG1)) fail("1 set d");
    if (ur_flag_test(flags, FLAG2)) fail("2 set d");
    if (ur_flag_test(flags, FLAG3)) fail("3 set d");
    if (ur_flag_test(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    ur_init(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
