/* memory.c -- 
 * Created: Mon Jul  5 13:30:18 1999 by faith@dict.org
 * Copyright 1999, 2001, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: memory.c,v 1.14 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "urP.h"

#ifdef DMALLOC_FUNC_CHECK
#undef ur_alloc
#undef ur_allocz
#undef ur_realloc
#undef ur_reallocz
#undef ur_free
#undef ur_strdup
#endif

void *ur_alloc(size_t size)
{
    void *ret;

    if (size <= 0) ur_fatal(__FUNCTION__, "Invalid size = %zd\n", size);
    ret = malloc(size);
    if (!ret) ur_fatal(__FUNCTION__, "Out of memory\n");
    return ret;
}

void *ur_allocz(size_t size)
{
    void *ret;

    if (size <= 0) ur_fatal(__FUNCTION__, "Invalid size = %zd\n", size);
    ret = malloc(size);
    if (!ret) ur_fatal(__FUNCTION__, "Out of memory\n");
    memset(ret, 0, size);
    return ret;
}

void *ur_realloc(void *old, size_t size)
{
    void *ret;

    if (size <= 0) ur_fatal(__FUNCTION__, "Invalid size = %zd\n", size);

    if (!old) return ur_alloc(size);
    
    ret = realloc(old, size);
    if (!ret) ur_fatal(__FUNCTION__, "Out of memory\n");

    return ret;
}

void *ur_reallocz(void *old, size_t oldsize, size_t newsize)
{
    void *ret;

    if (newsize <= 0) ur_fatal(__FUNCTION__, "Invalid size = %zd\n", newsize);
    if (!old || !oldsize) return ur_allocz(newsize);

    ret = realloc(old, newsize);
    if (!ret) ur_fatal(__FUNCTION__, "Out of memory\n");
    memset((char *)ret + oldsize, 0, newsize - oldsize);
    return ret;
}

void ur_free(void *object)
{
    if (!object) ur_fatal(__FUNCTION__, "Freeing NULL pointer\n");
    free(object);
}

char *ur_strdup(const char *s)
{
    char *d = ur_alloc(strlen(s) + 1);
    strcpy(d, s);
    return d;
}

/* EOF memory.c */
