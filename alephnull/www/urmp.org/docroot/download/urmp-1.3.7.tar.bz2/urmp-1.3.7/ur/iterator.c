/* iterator.c -- 
 * Created: Mon Jul  5 13:28:28 1999 by faith@dict.org
 * Copyright 1999 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: iterator.c,v 1.2 1999-12-22 16:25:22 faith Exp $
 * 
 */

#include "urP.h"

ur_iterator_t ur_iterator_create(const void *object)
{
}

void ur_iterator_destroy(ur_iterator_t iterator)
{
}

const void *ur_iterator_datum(ur_iterator_t iterator)
{
}

const void *ur_iterator_key(ur_iterator_t iterator)
{
}

unsigned int ur_iterator_n(ur_iterator_t iterator)
{
}

int ur_iterator_next(ur_iterator_t iterator)
{
}

