/* id3.c -- 
 * Created: Wed Sep 10 18:00:28 2008 by faith@acm.org
 * Revised: Wed Jul  1 22:16:59 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 *
 * ID3 v1.x: http://www.id3.org/ID3v1
 * Lyrics3 v2.00: http://www.id3.org/lyrics3200.html
 * MP3 headers: http://www.mp3-tech.org/programmer/frame_header.html
 * 
 */

#define _BSD_SOURCE
#define _GNU_SOURCE
#include "urP.h"
#include <stdbool.h>
#include <fcntl.h>
#include <alloca.h>
#include <ctype.h>
#include <pcre.h>
#include <locale.h>
#include <sys/mman.h>

#define UR_ID3_PAGESIZE    4096
#define UR_ID3_V1_STDLEN    128
#define UR_ID3_V1_MAXLEN   4096
#define UR_ID3_V2_CHUNKLEN (4096*4)
#define UR_ID3_V2_CHUNKMAX (4096*32)
#define UR_ID3_V2_HLEN      512
#define UR_ID3_MP3_LEN      512

static ur_arena_t _ur_id3_arena;

struct ur_id3_s {
	unsigned long         magic;
	bool                  valid;
	ur_id3_source_t       source;
	int                   header_size;
	const char            *filename;
	const char            *title;
	const char            *artist;
	const char            *album;
	const char            *year;
	const char            *comment;
	int                   track;
	int                   genre;

	int                   iattr;
	const char            *sattr;

	int                   file_size;
	time_t                file_mtime;
	int                   file_meta_size;
	
	ur_id3_mpeg_version_t mpeg_version;
	ur_id3_mpeg_layer_t   mpeg_layer;
	int                   mpeg_cbr;
	int                   mpeg_sample_rate;
	bool                  mpeg_padded;
	ur_id3_mpeg_mode_t    mpeg_mode;
	int                   mpeg_duration;
	int                   mpeg_vbr;
	const char            *track_string;
	const char            *duration_string;
	const char            *rate_string;
	const char            *search;

	int                   current_playtime;
	time_t                current_starttime;
};

typedef enum {
	UR_ID3_ARTIST,
	UR_ID3_ALBUM,
	UR_ID3_TITLE,
	UR_ID3_TRACK
} ur_id3_field_t;

typedef enum {
	UR_ID3_ENC_ISO_8859_1 = 0,
	UR_ID3_ENC_UTF_16     = 1,
	UR_ID3_ENC_UTF_16BE   = 2,
	UR_ID3_ENC_UTF_8      = 3
} ur_id3_enc_t;

typedef struct ur_id3_augment_s {
	ur_id3_field_t field;
	int            position;
	const char     *pattern;
} ur_id3_augment_t;

typedef struct ur_id3_io_s {
	unsigned long buf_size;
	const char    *buf;
	const char    *buf_start;
	const char    *buf_end;
	unsigned long size;
	unsigned long file_offset;
} ur_id3_io_t;

CHECK_FUNCTION(_ur_id3_check, ur_id3_t, UR_ID3_MAGIC)

static void ur_id3_init(void)
{
	if (_ur_id3_arena) ur_internal(__func__, "Arena already exists\n");
	_ur_id3_arena = ur_arena_create(1);
}

void ur_id3_shutdown(void)
{
	if (_ur_id3_arena) ur_arena_destroy(_ur_id3_arena);
	_ur_id3_arena = NULL;
}

int ur_id3_pack(ur_id3_t e, char *buf, int len)
{
	char *pt   = buf;
	int  rem   = len;
	int  valid = e->valid ? 1 : 0;

	_ur_id3_check(e);

	pt = ur_pack_int(pt,    &rem, valid);
	pt = ur_pack_int(pt,    &rem, e->source);
	pt = ur_pack_string(pt, &rem, e->filename);
	pt = ur_pack_string(pt, &rem, e->title);
	pt = ur_pack_string(pt, &rem, e->artist);
	pt = ur_pack_string(pt, &rem, e->album);
	pt = ur_pack_string(pt, &rem, e->year);
	pt = ur_pack_string(pt, &rem, e->comment);
	pt = ur_pack_int(pt,    &rem, e->track);
	pt = ur_pack_time(pt,   &rem, e->file_mtime);
	pt = ur_pack_int(pt,    &rem, e->file_size);
	pt = ur_pack_int(pt,    &rem, e->mpeg_version);
	pt = ur_pack_int(pt,    &rem, e->mpeg_layer);
	pt = ur_pack_int(pt,    &rem, e->mpeg_cbr);
	pt = ur_pack_int(pt,    &rem, e->mpeg_sample_rate);
	pt = ur_pack_int(pt,    &rem, e->mpeg_mode);
	pt = ur_pack_int(pt,    &rem, e->mpeg_duration);
	pt = ur_pack_int(pt,    &rem, e->mpeg_vbr);
	pt = ur_pack_string(pt, &rem, e->search);
	pt = ur_pack_int(pt,    &rem, e->current_playtime);
	pt = ur_pack_time(pt,   &rem, e->current_starttime);

	if (rem) return len-rem;
	return -1;
}

static void ur_id3_update_rate_string(ur_id3_t e)
{
	int  rate;
	char buf[256];

	if (e->mpeg_vbr) {
		rate = e->mpeg_vbr;
		snprintf(buf, sizeof(buf)-1, "~%d", (int)(rate/1000.0));
	} else {
		rate = e->mpeg_cbr * 1000;
		snprintf(buf, sizeof(buf)-1, "%d", (int)(rate/1000.0));
	}
	e->rate_string = ur_atom_string(buf);
}

ur_id3_t ur_id3_unpack(char *buf, int len)
{
	ur_id3_t e;
	char     *pt = buf;
	int      rem = len;
	int      valid;

	e = ur_id3_create();

	pt = ur_unpack_int(pt,    &rem, &valid);
	pt = ur_unpack_int(pt,    &rem, (int *)&e->source);
	pt = ur_unpack_string(pt, &rem, &e->filename);
	pt = ur_unpack_string(pt, &rem, &e->title);
	pt = ur_unpack_string(pt, &rem, &e->artist);
	pt = ur_unpack_string(pt, &rem, &e->album);
	pt = ur_unpack_string(pt, &rem, &e->year);
	pt = ur_unpack_string(pt, &rem, &e->comment);
	pt = ur_unpack_int(pt,    &rem, &e->track);
	pt = ur_unpack_time(pt,   &rem, &e->file_mtime);
	pt = ur_unpack_int(pt,    &rem, &e->file_size);
	pt = ur_unpack_int(pt,    &rem, (int *)&e->mpeg_version);
	pt = ur_unpack_int(pt,    &rem, (int *)&e->mpeg_layer);
	pt = ur_unpack_int(pt,    &rem, &e->mpeg_cbr);
	pt = ur_unpack_int(pt,    &rem, &e->mpeg_sample_rate);
	pt = ur_unpack_int(pt,    &rem, (int *)&e->mpeg_mode);
	pt = ur_unpack_int(pt,    &rem, &e->mpeg_duration);
	pt = ur_unpack_int(pt,    &rem, &e->mpeg_vbr);
	pt = ur_unpack_string(pt, &rem, &e->search);
	pt = ur_unpack_int(pt,    &rem, &e->current_playtime);
	pt = ur_unpack_time(pt,   &rem, &e->current_starttime);

	ur_id3_set_track(e, e->track);
	ur_id3_set_mpeg_duration(e, e->mpeg_duration);
	ur_id3_update_rate_string(e);

	if (rem) {
		ur_id3_destroy(e);
		return NULL;
	}
	e->valid = !!valid;
	return e;
}

ur_id3_t ur_id3_create(void)
{
	ur_id3_t e = ur_allocz(sizeof(*e));

	e->magic = UR_ID3_MAGIC;
	return e;
}

unsigned long ur_id3_destroy(ur_id3_t e)
{
	unsigned long ret;
	
	ret = e->magic = ~UR_ID3_MAGIC;
	ur_free(e);
	return ret;
}


static int ur_id3_unsyncsafe(const char *in)
{
	const unsigned char *inu = (const unsigned char *)in;
	int value;

	value = (inu[0] << 21)
		| (inu[1] << 14)
		| (inu[2] <<  7)
		| inu[3];
	ur_trace(UR_TRACE_ID3, __func__,
		 "0x%02x 0x%02x 0x%02x 0x%02x => 0x%04x = %d\n",
		 inu[0], inu[1], inu[2], inu[3], value, value);
	return value;
}

static int ur_id3_getint(const char *in, int length)
{
	const unsigned char *inu = (const unsigned char *)in;
	int value;

	switch (length) {
	case 4:
		value = (inu[0] << 24)
			| (inu[1] << 16)
			| (inu[2] <<  8)
			| inu[3];
		break;
	case 3:
		value = (inu[0] << 16)
			| (inu[1] << 8)
			| inu[2];
		break;
	case 2:
		value = (inu[0] << 8)
			| inu[1];
		break;
	case 1:
		value = inu[0];
		break;
	default:
		ur_internal(__func__,
			    "Length=%d (must be 1, 2, 3, or 4)\n", length);
	}
	return value;
}

/* Make dest be of length 2x+1, when src is of length x. */
int ur_id3_utf8ify(char *dest, const char *src, int n)
{
	const char *s;
	char       *d;
	bool       utf8 = false;
	int        i;
	int        remaining = n;

	for (d = dest, s = src; *s && remaining; s++, --remaining) {
		unsigned char ch = *s;

		if (ch < 0x7f || utf8) {
			*d++ = *s;
			continue;
		}
		if (ch >= 0xc0) {
			int count = 0;
			if ((ch & 0xc0) == 0xc0) count = 2;
			if ((ch & 0xe0) == 0xe0) count = 3;
			if ((ch & 0xf0) == 0xf0) count = 4;
			if (!count) goto latin1;
			for (i = 1; i < count; i++) {
				if ((s[i] & 0x80) != 0x80
				    || (s[i] & 0x40) != 0x00) {
					goto latin1;
				}
			}
			utf8 = true;
			*d++ = *s;
		} else {
latin1:
			if (ch <= 0xbf) {
				*d++ = (signed char)0xc2;
				*d++ = ch;
			} else {
				*d++ = (signed char)0xc3;
				*d++ = ch - 0x40;
			}
		}
	}
	*d = '\0';
	return d - dest;
}

static const char *ur_id3_string(const char *s, int len)
{
	const char *pt;
	const char *new;
	char       *final;
	int        length;

	for (pt = s, length = len; *pt == ' ' && length; ++pt, --length)
		;
	new = pt;
	for (pt = new + length; *pt == ' ' && pt > new; --pt, --length)
		;

	final  = alloca(length * 2 + 1);
	length = ur_id3_utf8ify(final, new, length);
	return ur_atom_string_n(final, length);
}

static const char *ur_id3_decode_string(ur_id3_enc_t encoding,
					const char *source, int length)
{
	int                 len;
	unsigned char       *buf;
	unsigned char       *d;
	const unsigned char *s = (const unsigned char *)source;
	bool                known;
	bool                be;
	uint16_t            ucs2, ucs2b;
	uint32_t            ucs4;
	int                 rem;

	switch (encoding) {
	case UR_ID3_ENC_UTF_16:
		be    = true;
		known = false;
		break;
	case UR_ID3_ENC_UTF_16BE:
		be    = true;
		known = true;
		break;
	case UR_ID3_ENC_ISO_8859_1:
	case UR_ID3_ENC_UTF_8:
		return ur_id3_string(source, length); /* XXX FIXME */
		break;
	default:
		ur_fatal(__func__, "Encoding=%d\n", encoding);
		break;
	}
	buf = alloca(length*4+2);

	for (len=0, d=buf, rem=length; *s && rem >= 2; s += 2, rem -= 2) {

		if (!known) {
			if (s[0] == 0xfe && s[1] == 0xff) {
				be = true;
			} else if (s[0] == 0xff && s[1] == 0xfe) {
				be = false;
			} else {
				ur_fatal(__func__,
					 "BOM = 0x%02x 0x%02x\n",
					 s[0], s[1]);
			}
			known=true;
		} else {
			/* See RFC2781, section 2.2 Decoding UTF-16 */
			if (be) ucs2 = s[0] * 256 + s[1];
			else    ucs2 = s[1] * 256 + s[0];
			if (ucs2 < 0xd800 || ucs2 > 0xfddd) {
				ucs4 = ucs2;
			} else {
				if (ucs2 < 0xd800
				    || ucs2 > 0xdbff
				    || rem < 2) {
					/* Error, skip */
					printf("Skip: 0x%04x %d\n",
					       ucs2, rem);
					continue;
				}
				if (be) ucs2b = s[0] * 256 + s[1];
				else    ucs2b = s[1] * 256 + s[0];
				s += 2;
				rem -= 2;
				if (ucs2b < 0xdc || ucs2b > 0xdfff) {
					/* Error, skip */
					printf("Skip: 0x%04x 0x%04x\n",
					       ucs2, ucs2b);
					continue;
				}
				ucs4 = ((ucs2 & 0x3fff) << 10)
				       | (ucs2b & 0x3fff);
				ucs4 += 0x10000;
			}
			/* See http://en.wikipedia.org/wiki/UTF-8 */
			if (ucs4 <= 0x7f) {
				*d++ = 0x00
				       | ((ucs4 & 0x7f) >> 0);
				len += 1;
			} else if (ucs4 <= 0x7ff) {
				*d++ = 0xc0
				       | ((ucs4 & 0x700) >> 6)
				       | ((ucs4 & 0x0c0) >> 6);
				*d++ = 0x80
				       | ((ucs4 & 0x03f) >> 0);
				len += 2;
			} else if (ucs4 <= 0xffff) {
				*d++ = 0xe0
				       | ((ucs4 & 0xf000) >> 16);
				*d++ = 0x80
				       | ((ucs4 & 0x0f00) >> 2)
				       | ((ucs4 & 0x00c0) >> 6);
				*d++ = 0x80
				       | ((ucs4 & 0x003f) >> 0);
				len += 3;
			} else if (ucs4 <= 0x10ffff) {
				*d++ = 0xf0
				       | ((ucs4 & 0x1c0000) >> 2);
				*d++ = 0x80
				       | ((ucs4 & 0x030000) << 4)
				       | ((ucs4 & 0x00f000) >> 4);
				*d++ = 0x80
				       | ((ucs4 & 0x000f00) << 2)
				       | ((ucs4 & 0x0000c0) >> 6);
				*d++ = 0x80
				       | ((ucs4 & 0x00003f) >> 0);
				len += 4;
			} else {
				printf("Skipping 0x%08x\n", ucs4);
			}
		}
	}

	return ur_id3_string((char *)buf, len); /* XXX FIXME do more */
}

static int ur_id3_read_one_id3v2(ur_id3_t e, const char *start,
				 const char *end)
{
	const char  *pt;
	bool        flag_unsync = false;
	bool        flag_exth   = false;
	bool        flag_exp    = false;
	bool        flag_foot   = false;
	int         size, offset, fsize = 0, count;
	char        fname[5];

	_ur_id3_check(e);

	/* Check for ID3v2 */
	pt = start;
	if (pt + 10 > end
	    || strncmp(pt, "ID3", 3)
	    || (unsigned char)pt[3] > 5
	    || (unsigned char)pt[3] == 0xff
	    || (unsigned char)pt[4] == 0xff
	    || (pt[5] & 0x0f)
	    || (unsigned char)pt[6] > 0x80
	    || (unsigned char)pt[7] > 0x80
	    || (unsigned char)pt[8] > 0x80
	    || (unsigned char)pt[9] > 0x80) {
		return ENODATA;
	}
	e->source = UR_ID3_V2_UNKNOWN;
	if (pt[3] == 2) {
		if (pt[5] & 0x40) {
				/* Cannot parse compression */
			return ENODATA;
		}
		e->source = UR_ID3_V2_2;
	}
	if (pt[3] == 3) e->source = UR_ID3_V2_3;
	if (pt[3] == 4) e->source = UR_ID3_V2_4;

	if (e->source == UR_ID3_V2_UNKNOWN) {
		return ENODATA;
	}

	e->valid = true;

	if (pt[5] & 0x80) flag_unsync = true;
	if (pt[5] & 0x40) flag_exth   = true;
	if (pt[5] & 0x20) flag_exp    = true;
	if (pt[5] & 0x10) flag_foot   = true;

	size = ur_id3_unsyncsafe(pt + 6);
	e->header_size = size + 10 + (flag_foot ? 10 : 0);
	ur_trace(UR_TRACE_ID3, __func__, "size=%d header_size=%d\n",
		 size, e->header_size);
	if (size > end - start) {
		if (end - start < UR_ID3_V2_CHUNKMAX) return ENOMEM;
		size = end - start;
	}
	e->file_meta_size += size;

	pt += 10;
	if (pt + 4 > end) return 0;
	if (flag_exth) {
		count = offset = ur_id3_unsyncsafe(&pt[0]);
		ur_trace(UR_TRACE_ID3, __func__, "eh size = %d\n", count);
	} else {
		count = offset = 0;
	}
	pt += offset;

	while (count < size && pt + 4 < end) {
		if (!((*pt >= 'A' && *pt <= 'Z')
		      || (*pt >= '0' && *pt <= '9'))) {
			++pt;
			++count;
		}
		switch (e->source) {
		case UR_ID3_V2_2:
			fname[0] = pt[0];
			fname[1] = pt[1];
			fname[2] = pt[2];
			fname[3] = '\0';
			fsize = ur_id3_getint(&pt[3], 3);
			pt += 6;
			count += 6;
			break;
		case UR_ID3_V2_3:
			fname[0] = pt[0];
			fname[1] = pt[1];
			fname[2] = pt[2];
			fname[3] = pt[3];
			fname[4] = '\0';
			fsize = ur_id3_getint(&pt[4], 4);
			pt += 10;
			count += 10;
			break;
		case UR_ID3_V2_4:
			fname[0] = pt[0];
			fname[1] = pt[1];
			fname[2] = pt[2];
			fname[3] = pt[3];
			fname[4] = '\0';
			fsize = ur_id3_unsyncsafe(&pt[4]);
			pt += 10;
			count += 10;
			break;
		default:
			ur_internal(__func__,
				    "Unexpected source =%d\n", e->source);
		}

		if (fsize < 0) break;
		if (!fsize && !isupper(fname[0])) break;
		if (pt + fsize > end) break;
		
		ur_trace(UR_TRACE_ID3, __func__,
			 "fsize=%d fname='%s' size=%d count=%d enc=%d\n",
			 fsize, fname, size, count, pt[0]);


		if (!strcmp(fname, "TT2") || !strcmp(fname, "TIT2"))
			e->title = ur_id3_decode_string(*pt, pt+1, fsize-1);

		if (!strcmp(fname, "TP1") || !strcmp(fname, "TPE1"))
			e->artist = ur_id3_decode_string(*pt, pt+1, fsize-1);
		    
		if (!strcmp(fname, "TAL") || !strcmp(fname, "TALB"))
			e->album = ur_id3_decode_string(*pt, pt+1, fsize-1);

		if (!strcmp(fname, "TYE") || !strcmp(fname, "TYER"))
			e->year = ur_id3_decode_string(*pt, pt+1, fsize-1);

		if (!strcmp(fname, "TRK") || !strcmp(fname, "TRCK"))
			e->track = strtol(ur_id3_decode_string(*pt, pt+1,
							       fsize-1),
					  NULL, 10);
		pt += fsize;
		count += fsize;
	}
	ur_trace(UR_TRACE_ID3, __func__,
		 "fname=%4.4s fsize=%d count=%d size=%d pt=%p end=%p\n",
		 fname, fsize, count, size, pt, end);
	return 0;
}

static int ur_id3_read_id3v2(ur_id3_t e, const char *start,
			     const char *end)
{
	int retcode;
	int retcode2;
	
	retcode = ur_id3_read_one_id3v2(e, start, end);

	if (!retcode) {		/* Check for another */
		ur_id3_t e2 = ur_id3_create();
		e2->filename = e->filename;
		e2->file_size = e->file_size;
		e2->file_mtime = e->file_mtime;
		e2->file_meta_size = e->file_meta_size;
		retcode2 = ur_id3_read_one_id3v2(e2,
						 start + e->header_size, end);
		if (!retcode2) {
			printf("MULTIHEADERS: %d %d %s\n",
			       e->header_size,
			       e2->header_size,
			       e->filename);
			e->header_size += e2->header_size;
		}
		ur_id3_destroy(e2);
	}

	return retcode;
}

static int ur_id3_read_id3v1(ur_id3_t e, const char *start, const char *end)
{
	const char *pt;
	int        len;

	_ur_id3_check(e);

	/* Check for ID3v1 */
	pt = end - UR_ID3_V1_STDLEN;
	if (pt < start || strncmp(pt, "TAG", 3)) return ENODATA;

	/* Have ID3v1 */
	e->valid = true;
	e->source = UR_ID3_V1;
	pt += 3;
	if (pt + 30 > end) return ENODATA;
	e->title   = ur_id3_string(pt, 30);
	pt += 30;
	if (pt + 30 > end) return ENODATA;
	e->artist  = ur_id3_string(pt, 30);
	pt += 30;
	if (pt + 30 > end) return ENODATA;
	e->album   = ur_id3_string(pt, 30);
	pt += 30;
	if (pt + 4 > end) return ENODATA;
	e->year    = ur_id3_string(pt, 4);
	pt += 4;
	if (pt + 30 > end) return ENODATA;
	e->comment = ur_id3_string(pt, 30);
	pt += 28;
	if (pt[0] == '\0' && pt[1] != '\0') {
		/* Have ID3v1.1 */
		e->source = UR_ID3_V1_1;
		e->track  = (unsigned char)pt[1];
	}
	pt += 2;
	e->genre = (unsigned char)pt[0];

	/* Check for Lyrics3v2 */
	pt = end - UR_ID3_V1_STDLEN - 9;
	if (pt < start || strncmp(pt, "LYRICS200", 9)) return 0;

	pt = end - UR_ID3_V1_STDLEN - 9 - 6;
	if (pt < start) return 0;
	len = strtol(pt, NULL, 10);

	pt = end - UR_ID3_V1_STDLEN - 9 - 6 - len;
	if (pt < start || strncmp(pt, "LYRICSBEGIN", 11)) return 0;

	pt += 11;
	e->source = UR_ID3_LYRICS3_V2;
	
	while (pt < end) {
		len = strtol(pt + 3, NULL, 10);
		if (!len) break;
		if (len > 30 && pt + 8 + len < end) {
			if (!strncmp(pt, "ETT", 3)) {
				if (!strncmp(pt + 8, e->title, 30)) {
					e->title = ur_id3_string(pt + 8, len);
				}
			}
			if (!strncmp(pt, "EAR", 3)) {
				if (!strncmp(pt + 8, e->artist, 30)) {
					e->artist = ur_id3_string(pt + 8, len);
				}
			}
			if (!strncmp(pt, "EAL", 3)) {
				if (!strncmp(pt + 8, e->album, 30)) {
					e->album = ur_id3_string(pt + 8, len);
				}
			}
		}
		pt += 8 + len;
	}
	
	return 0;
}

static int ur_id3_mpeg_decode_cbr(ur_id3_t e, int code)
{
	int v1l1[] = {   0,  32,  64,  96, 128, 160, 192, 224,
		       256, 288, 320, 352, 384, 416, 448, 0 };
	int v1l2[] = {   0,  32,  48,  56,  64,  80,  96, 112,
		       128, 160, 192, 224, 256, 320, 384, 0 };
	int v1l3[] = {   0,  32,  40,  48,  56,  64,  80, 96,
		       112, 128, 160, 192, 224, 256, 320, 0 };
	int v2l1[] = {   0,  32,  48,  56,  64,  80,  96, 112,
		       128, 144, 160, 176, 192, 224, 256, 0 };
	int v2l2[] = {   0,   8,  16,  24,  32,  40,  48,  56,
		        64,  80,  96, 112, 128, 144, 160, 0 };

	if (code < 0 || code > 15) return 0;

	switch (e->mpeg_version) {
	case UR_ID3_MPEG_V1:
		switch (e->mpeg_layer) {
		case UR_ID3_MPEG_L_I:   return v1l1[code];
		case UR_ID3_MPEG_L_II:  return v1l2[code];
		case UR_ID3_MPEG_L_III: return v1l3[code];
		default:                return 0;
		}
		break;
	case UR_ID3_MPEG_V2:
	case UR_ID3_MPEG_V2_5:
		switch (e->mpeg_layer) {
		case UR_ID3_MPEG_L_I:   return v2l1[code];
		case UR_ID3_MPEG_L_II:
		case UR_ID3_MPEG_L_III: return v2l2[code];
		default:                return 0;
		}
		break;
	default: return 0;
	}
}

static int ur_id3_mpeg_decode_sample_rate(ur_id3_t e, int code)
{
	int v1[]  = { 44100, 48000, 32000, 0 };
	int v2[]  = { 22050, 24000, 16000, 0 };
	int v25[] = { 11025, 12000,  8000, 0 };

	if (code < 0 || code > 3) return 0;

	switch (e->mpeg_version) {
	case UR_ID3_MPEG_V1:   return v1[code];
	case UR_ID3_MPEG_V2:   return v2[code];
	case UR_ID3_MPEG_V2_5: return v25[code];
	default:               return 0;
	}
	return 0;
}

static int ur_id3_mpeg_sample_size(ur_id3_t e)
{
	switch (e->mpeg_layer) {
	case UR_ID3_MPEG_L_I:  return  384;
	case UR_ID3_MPEG_L_II: return 1152;
	case UR_ID3_MPEG_L_III:
		switch (e->mpeg_version) {
		case UR_ID3_MPEG_V1:   return 1152;
		case UR_ID3_MPEG_V2:
		case UR_ID3_MPEG_V2_5: return  576;
		default:               return    0;
		}
	default:               return    0;
	}
}

static int ur_id3_mpeg_cbr_frames(ur_id3_t e)
{
	int mult;

	switch (e->mpeg_layer) {
	case UR_ID3_MPEG_L_I:  mult = 348; break;
	case UR_ID3_MPEG_L_II: mult = 144; break;
	case UR_ID3_MPEG_L_III:
		switch (e->mpeg_version) {
		case UR_ID3_MPEG_V1:   mult = 144; break;
		case UR_ID3_MPEG_V2:
		case UR_ID3_MPEG_V2_5: mult = 72; break;
		default:               return    0;
		}
		break;
	default:               return    0;
	}

	ur_trace(UR_TRACE_ID3, __func__,
		 "size=%d meta_size=%d mult=%d cbr=%d sample_rate=%d\n",
		 e->file_size, e->file_meta_size, mult,
		 e->mpeg_cbr, e->mpeg_sample_rate);

	return (e->file_size - e->file_meta_size)
		/ ((mult * e->mpeg_cbr * 1000)/ e->mpeg_sample_rate);
}

static int ur_id3_mpeg_xing_offset(ur_id3_t e)
{
	int offset = 4;

	switch (e->mpeg_layer) {
	case UR_ID3_MPEG_L_I:
	case UR_ID3_MPEG_L_II:
		break;
	case UR_ID3_MPEG_L_III:
		switch (e->mpeg_version) {
		case UR_ID3_MPEG_V1:
			if (e->mpeg_mode == UR_ID3_MPEG_MONO) offset += 17;
			else                                  offset += 32;
			break;
		case UR_ID3_MPEG_V2:
		case UR_ID3_MPEG_V2_5:
			if (e->mpeg_mode == UR_ID3_MPEG_MONO) offset +=  9;
			else                                  offset += 17;
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	return offset;
}


static int ur_id3_read_mp3(ur_id3_t e, const char *start, const char *end)
{
	const char *pt;
	int        i;
	bool       cbr = false;
	const char *xing_offset = NULL;

	_ur_id3_check(e);

	ur_trace(UR_TRACE_ID3, __func__, "Starting at offset 0x%0x\n",
		 e->header_size);
	pt = start + e->header_size;
	if (pt >= end) {
		if (end - start < UR_ID3_V2_CHUNKMAX) return ENOMEM;
		return 0;	/* give up... */
	}
	for (i = 0; i < 8192 && pt + 4 < end; i++, ++pt) {
		unsigned int a = (unsigned char)pt[0];
		unsigned int b = (unsigned char)pt[1];
		unsigned int c = (unsigned char)pt[2];
		unsigned int d = (unsigned char)pt[3];

		ur_trace(UR_TRACE_ID3, __func__,
			 "0x%04x: %x %x %x %x\n",
			 i + e->header_size, a, b, c, d);

		if (!strncmp(pt, "Xing", 4) || !strncmp(pt, "Info", 4)) {
			printf("XING: %s\n",
			       e->filename);
			xing_offset = pt;
		}

		if (!a || a != 0xff || (b & 0xe0) != 0xe0) continue;

		switch ((b & 0x18) >> 3) {
		case 0: e->mpeg_version = UR_ID3_MPEG_V2_5;      break;
		case 1: e->mpeg_version = UR_ID3_MPEG_V_UNKNOWN; break;
		case 2: e->mpeg_version = UR_ID3_MPEG_V2;        break;
		case 3: e->mpeg_version = UR_ID3_MPEG_V1;        break;
		}

		switch ((b & 0x06) >> 1) {
		case 0: e->mpeg_layer = UR_ID3_MPEG_L_UNKNOWN; break;
		case 1: e->mpeg_layer = UR_ID3_MPEG_L_III;     break;
		case 2: e->mpeg_layer = UR_ID3_MPEG_L_II;      break;
		case 3: e->mpeg_layer = UR_ID3_MPEG_L_I;       break;
		}

		e->mpeg_cbr = ur_id3_mpeg_decode_cbr(e, (c & 0xf0) >> 4);
		e->mpeg_sample_rate
			= ur_id3_mpeg_decode_sample_rate(e, (c & 0x0c) >> 2);

		if (!e->mpeg_cbr
		    || !e->mpeg_sample_rate
		    || e->mpeg_version == UR_ID3_MPEG_V_UNKNOWN
		    || e->mpeg_layer   == UR_ID3_MPEG_L_UNKNOWN) {
			ur_trace(UR_TRACE_ID3, __func__, "Bad header\n");
			continue;
		}
		    

		if (c & 0x01) e->mpeg_padded = true;

		e->mpeg_duration = (ur_id3_mpeg_cbr_frames(e)
				    * ur_id3_mpeg_sample_size(e))
				   / e->mpeg_sample_rate;
		ur_trace(UR_TRACE_ID3, __func__,
			 "CBRduration=%d frames=%d size=%d rate=%d\n",
			 e->mpeg_duration,
			 ur_id3_mpeg_cbr_frames(e),
			 ur_id3_mpeg_sample_size(e),
			 e->mpeg_sample_rate);

		switch ((d & 0xc0) >> 6) {
		case 0: e->mpeg_mode = UR_ID3_MPEG_STEREO;       break;
		case 1: e->mpeg_mode = UR_ID3_MPEG_JOINT_STEREO; break;
		case 2: e->mpeg_mode = UR_ID3_MPEG_DUAL;         break;
		case 3: e->mpeg_mode = UR_ID3_MPEG_MONO;         break;
		}

		break;
	}

	pt += ur_id3_mpeg_xing_offset(e);
	if (pt + 4 > end) return 0;

	if (xing_offset
	    && strncmp("Xing", pt, 4)
	    && strncmp("Info", pt, 4)) {
				/* No Xing found here, so try saved value */
		pt = xing_offset;
	}
	if (pt + 120 > end) return 0;

	if (!strncmp("Info", pt, 4)) cbr = true;
		
	if (!strncmp("Xing", pt, 4) || !strncmp("Info", pt, 4)) {
		bool     frames_present;
		bool     bytes_present;
		bool     toc_present;
		bool     qual_present;
		uint32_t frames = 0;
		uint32_t bytes = 0;

		pt += 4;

		frames_present = !!(pt[3] & 0x01);
		bytes_present  = !!(pt[3] & 0x02);
		toc_present    = !!(pt[3] & 0x04);
		qual_present   = !!(pt[3] & 0x08);

		pt += 4;

		if (frames_present) {
			frames = ur_id3_getint(pt, 4);
			e->mpeg_duration = frames
					   * ur_id3_mpeg_sample_size(e)
					   / e->mpeg_sample_rate;
			ur_trace(UR_TRACE_ID3, __func__,
				 "VBRduration=%d frames=%d size=%d rate=%d\n",
				 e->mpeg_duration,
				 frames,
				 ur_id3_mpeg_sample_size(e),
				 e->mpeg_sample_rate);

			pt += 4;
			if (bytes_present && e->mpeg_duration) {
				bytes = ur_id3_getint(pt, 4);
				e->mpeg_vbr = bytes * 8 / e->mpeg_duration;
			}
		}
		if (cbr) {
			int c = e->mpeg_vbr / 1000;
			if (c < e->mpeg_cbr - 1 || c > e->mpeg_cbr + 1) {
				
				ur_trace(UR_TRACE_ID3, __func__,
					 "Xing: CBR %d %d frames=%u"
					 " bytes=%u\n",
					 e->mpeg_cbr, e->mpeg_vbr,
					 frames, bytes);
			}
			e->mpeg_vbr = 0; /* CBR */
		}
	}

	return 0;
}

int ur_id3_searchify(char *dest, const char *src)
{
	const char    *s;
	char          *d;
	unsigned char ch;

	for (d = dest, s = src; *s; s++) {
		ch = (unsigned char)*s;

		if (ch == ' ' || ch == '\t') {
			if (d > dest && d[-1] != ' ') {
				*d++ = ' ';
			}
			continue;
		}

		if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) {
			*d++ = ch;
			continue;
		}
		if (ch >= 'A' && ch <= 'Z') {
			*d++ = ch + 32;
			continue;
		}

		if (ch == 0xc2 && (unsigned char)s[1] < 0xc0) {
			ch = (unsigned char)s[1];
#if 0
			printf("0x%02x 0x%02x -> 0x%02x\n",
			       (unsigned char)s[0], (unsigned char)s[1], ch);
#endif
			++s;
		} else if (ch == 0xc3 && (unsigned char)s[1] < 0xc0) {
			ch = (unsigned char)s[1] + 0x40;
#if 0
			printf("0x%02x 0x%02x -> 0x%02x\n",
			       (unsigned char)s[0], (unsigned char)s[1], ch);
#endif
			++s;
		}

		switch (ch) {
		case 0xE0: case 0xE1: case 0xE2:
		case 0xE3: case 0xE4: case 0xE5:
		case 0xC0: case 0xC1: case 0xC2: case 0xC3: case 0xC4:
		case 0xC5: *d++ = 'a';             break;
		case 0xE6:
		case 0xC6: *d++ = 'a'; *d++ = 'e'; break;
		case 0xE7:
		case 0xC7: *d++ = 'c';             break;
		case 0xE8: case 0xE9: case 0xEA: case 0xEB:
		case 0xC8: case 0xC9: case 0xCA:
		case 0xCB: *d++ = 'e';             break;
		case 0xEC: case 0xED: case 0xEE: case 0xEF:
		case 0xCC: case 0xCD: case 0xCE:
		case 0xCF: *d++ = 'i';             break;
		case 0xF0:
		case 0xD0: *d++ = 'd';             break;
		case 0xF1:
		case 0xD1: *d++ = 'n';             break;
		case 0xF2: case 0xF3: case 0xF4:
		case 0xF5: case 0xF6: case 0xF8:
		case 0xD8: case 0xD2: case 0xD3: case 0xD4: case 0xD5:
		case 0xD6: *d++ = 'o';             break;
		case 0xD7: *d++ = 'x';             break;
		case 0xF9: case 0xFA: case 0xFB: case 0xFC:
		case 0xD9: case 0xDA: case 0xDB:
		case 0xDC: *d++ = 'u';             break; case 0xFD: case 0xFF:
		case 0xDD: *d++ = 'y';             break;
		case 0xFE:
		case 0xDE: *d++ = 't'; *d++ = 'h'; break;
		case 0xDF: *d++ = 's';             break;
		}
	}
	while (d > dest && d[-1] == ' ') --d;
	*d = '\0';

	return d - dest;
}

static int ur_id3_search_add(ur_sl_t list, const char *string)
{
	char       *buf, *pt, *prev;
	const char *copy;
	int        len;
	int        total_len = 0;

	if (!string || !*string) return 0;

	buf = ur_arena_alloc(_ur_id3_arena, 2*strlen(string)+10);

	ur_id3_searchify(buf, string);

	for (prev = pt = buf; *pt; pt++) {
		if (*pt == ' ') {
			*pt = '\0';
			len = pt - prev;
			if (len) {
				total_len += len + 1;
				copy = ur_arena_string_n(_ur_id3_arena,
							 prev, len);
				ur_sl_insert(list, copy, copy);
			}
			prev = ++pt;
		}
	}
	len = pt - prev;
	if (len) {
		total_len += len + 1;
		copy = ur_arena_string_n(_ur_id3_arena, prev, len);
		ur_sl_insert(list, copy, copy);
	}
	return total_len;
}

void ur_id3_search_compute(ur_id3_t e)
{
	ur_sl_t       list;
	ur_iterator_t iter;
	const char    *key;
	const char    *datum;
	char          *buf, *pt;
	int           len = 0;
	
	_ur_id3_check(e);

	if (!_ur_id3_arena) ur_id3_init();
	ur_arena_clear(_ur_id3_arena);

	list = ur_sl_create(NULL);
	len += ur_id3_search_add(list, e->title);
	len += ur_id3_search_add(list, e->artist);
	len += ur_id3_search_add(list, e->album);
	if (e->year && e->year[0] != '0')
		len += ur_id3_search_add(list, e->year);

	if (len) {
		pt = buf = ur_arena_alloc(_ur_id3_arena, len + 1);
		UR_SL_ITERATE(list, iter, key, datum) {
			int length = strlen(datum);
			strcpy(pt, datum);
			pt += length;
			*pt++ = ' ';
			++length;
		}
		*pt = '\0';
		ur_sl_destroy(list);

		e->search = ur_atom_string(buf);
	}
}

static char *ur_id3_search_substring(const char *needle, char *haystack)
{
	int  need = strlen(needle);
	int  left = strlen(haystack);
	char *pt;

	for (pt = haystack; *pt && left > need; pt++) {
		if (!strncmp(needle, pt, need)) {
			ur_trace(UR_TRACE_ID3_AUGMENT, __func__,
				 "%s//%s//%s\n", needle, haystack, pt);
			return pt;
		} else {
			ur_trace(UR_TRACE_ID3_AUGMENT, __func__,
				 "%s//%s//%s\n", needle, pt, "NOMATCH");
		}
	}
	ur_trace(UR_TRACE_ID3_AUGMENT, __func__,
		 "%s//%s//NULL\n", needle, haystack);
	return NULL;
}

static int ur_id3_augment(ur_id3_t e, const char *filename)
{
	char       **buf;
	int        count, i;
	const char *s;
	char       *d;
	char       *pt;

	_ur_id3_check(e);
	if (!_ur_id3_arena) ur_id3_init();

	for (count = 1, s = filename; *s; s++) {
		if (*s == '/') ++count;
	}

	buf = ur_arena_alloc(_ur_id3_arena, sizeof(*buf) * count);
	for (i = 0; i < count; i++) {
		buf[i] = ur_arena_alloc(_ur_id3_arena,
					2 * strlen(filename) + 10);
	}

	for (s = filename, d = buf[0], i = 0; *s; s++) {
		if (*s == '/') {
			if (d == buf[i]) {
				--count;
				continue;
			}
			*d = '\0';
			d = buf[++i];
		} else {
			*d++ = *s;
		}
	}
	*d = '\0';
	if (count && (pt = strrchr(buf[count-1], '.'))) *pt = '\0';

	ur_trace(UR_TRACE_ID3_AUGMENT, __func__, "filename: %s\n", filename);
	for (i = 0; i < count; i++) {
		ur_trace(UR_TRACE_ID3_AUGMENT, __func__,
			 "buf[%d]: %s\n", i, buf[i]);
	}

	if (e->title) {
		int oldlen = strlen(e->title);
		pt         = ur_id3_search_substring(e->title, buf[count-1]);

		if (pt
		    && strlen(e->title) < strlen(pt)
		    && pt[oldlen] != '-') {
			char *tmp = alloca(strlen(pt)*2 + 1);
			ur_id3_utf8ify(tmp, pt, strlen(pt));
			e->title = ur_atom_string(tmp);

			switch (e->source) {
			case UR_ID3_V1:
				e->source = UR_ID3_V1_AUGMENTED;
				break;
			case UR_ID3_V1_1:
				e->source = UR_ID3_V1_1_AUGMENTED;
				break;
			case UR_ID3_LYRICS3_V2:
				e->source = UR_ID3_LYRICS3_V2_AUGMENTED;
				break;
			default:
				ur_fatal(__func__,
					 "Should not augment source type %s\n",
					 ur_id3_source(e));
			}
		}
	}

#if 0
	if (0) {
		pcre       *re;
		const char *error;
		int        erroffset;
		int        retcode;
		int        ovector[30];
		int        i;
			
		re = pcre_compile(".*/([0-9]*) - (.*)",
				  0, &error, &erroffset, NULL);
		if (!re) {
			ur_fatal(__func__, "RE failed at offset %d: %s\n",
				 erroffset, error);
		}
		retcode = pcre_exec(re, NULL, filename, strlen(filename),
				    0, 0, ovector,
				    sizeof(ovector)/sizeof(ovector[0]));
		if (retcode < 0) {
			ur_fatal(__func__, "Error %d\n", retcode);
		}

		for (i = 0; i < retcode; i++) {
			const char *pt = filename + ovector[2*i];
			int        len = ovector[2*i+1] - ovector[2*i];
			ur_trace(UR_TRACE_ID3_AUGMENT, __func__,
				 "%d: %.*s\n", i, len, pt);
		}
	}
#endif

	return count;
}

static int ur_id3_v1_meta_size(const char *start, const char *end)
{
	int        size = 0;
	const char *pt;
	int        len;

	pt = end - UR_ID3_V1_STDLEN;
	if (pt < start) return size;
	if (!strncmp(pt, "TAG", 3)) size = UR_ID3_V1_STDLEN;

	pt = end - UR_ID3_V1_STDLEN - 9;
	if (pt < start || strncmp(pt, "LYRICS200", 9)) return size;

	pt = end - UR_ID3_V1_STDLEN - 9 - 6;
	if (pt < start) return size;
	len = strtol(pt, NULL, 10);

	pt = end - UR_ID3_V1_STDLEN - 9 - 6 - len;
	if (pt < start || strncmp(pt, "LYRICSBEGIN", 11)) return size;
	size += 9 + 6 + len;
	return size;
}

static bool ur_id3_enomem(int retval, ur_id3_t e, unsigned long max_head)
{
	if (retval != ENOMEM) return false;
	if (max_head < UR_ID3_V2_CHUNKMAX
	    && e->file_size > max_head + UR_ID3_V1_MAXLEN) {
		return true;
	}
	ur_warning(__func__, "Cannot analyze file with length %d: %s\n",
		   e->file_size, e->filename);
	return false;
}

static void ur_id3_setup_directio(ur_id3_io_t *chunk, char *buf, int buflen,
				  bool head, int filelen, int maxlen)
{
	if (head) {
		chunk->buf_size     = buflen;
		chunk->buf          = buf;
		chunk->buf_start    = buf + UR_ID3_PAGESIZE
				      - ((uintptr_t)buf % UR_ID3_PAGESIZE);
		chunk->file_offset  = 0;
		chunk->size         = (filelen >= maxlen) ? maxlen : filelen;
		chunk->size        -= chunk->size % UR_ID3_PAGESIZE;
		if (!chunk->size) chunk->size = UR_ID3_PAGESIZE;
		chunk->buf_end      = chunk->buf_start + chunk->size;
	} else {
		chunk->buf_size     = buflen;
		chunk->buf          = buf;
		chunk->buf_start    = buf + UR_ID3_PAGESIZE
				      - ((uintptr_t)buf % UR_ID3_PAGESIZE);
		if (filelen > maxlen) {
			chunk->file_offset  = filelen - maxlen;
			chunk->file_offset -= chunk->file_offset
					      % UR_ID3_PAGESIZE;
		} else {
			chunk->file_offset  = 0;
			
		}
		chunk->size         = filelen - chunk->file_offset;
		chunk->size        += UR_ID3_PAGESIZE
				      - (chunk->size % UR_ID3_PAGESIZE);
		chunk->buf_end      = chunk->buf_start + chunk->size;
	}

	if (chunk->size > chunk->buf_size)
		ur_internal(__func__, "size=%lu > buf_size=%lu\n",
			    (long unsigned)chunk->size,
			    (long unsigned)chunk->buf_size);
	if (chunk->buf_start < &chunk->buf[0])
		ur_internal(__func__, "buf_start=%p < buf[0]=%p\n",
			    chunk->buf_start, &chunk->buf[0]);
	if (chunk->buf_end > &chunk->buf[chunk->buf_size-1])
		ur_internal(__func__, "buf_end=%p > buf[]=%p\n",
			    chunk->buf_end, &chunk->buf[chunk->buf_size-1]);
	if ((uintptr_t)chunk->buf_start % UR_ID3_PAGESIZE)
		ur_internal(__func__, "buf_start=%p\n", chunk->buf_start);
	if ((uintptr_t)chunk->size % UR_ID3_PAGESIZE)
		ur_internal(__func__, "size=%lu\n", chunk->size);
	if (chunk->file_offset % UR_ID3_PAGESIZE)
		ur_internal(__func__, "file_offset=%lu=0x%0lx\n",
			    (long unsigned)chunk->file_offset,
			    (long unsigned)chunk->file_offset);
	if (chunk->file_offset >= filelen)
		ur_internal(__func__, "file_offset=%lu >= file_size=%d\n",
			    (long unsigned)chunk->file_offset, filelen);
}

static void ur_id3_setup_io(ur_id3_io_t *chunk, char *buf, int buflen,
			    bool head, int filelen, int maxlen)
{
	if (head) {
		chunk->buf_size     = buflen;
		chunk->buf          = buf;
		chunk->buf_start    = buf;
		chunk->file_offset  = 0;
		chunk->size         = (filelen >= maxlen) ? maxlen : filelen;
		chunk->buf_end      = chunk->buf_start + chunk->size;
	} else {
		chunk->buf_size     = buflen;
		chunk->buf          = buf;
		chunk->buf_start    = buf;
		chunk->file_offset  = (filelen > maxlen) ? filelen-maxlen : 0;
		chunk->size         = filelen - chunk->file_offset;
		chunk->buf_end      = chunk->buf_start + chunk->size;
	}

	if (chunk->size > chunk->buf_size)
		ur_internal(__func__, "size=%lu > buf_size=%lu\n",
			    (long unsigned)chunk->size,
			    (long unsigned)chunk->buf_size);
	if (chunk->buf_start < &chunk->buf[0])
		ur_internal(__func__, "buf_start=%p < buf[0]=%p\n",
			    chunk->buf_start, &chunk->buf[0]);
	if (chunk->buf_end > &chunk->buf[chunk->buf_size-1])
		ur_internal(__func__, "buf_end=%p > buf[]=%p\n",
			    chunk->buf_end, &chunk->buf[chunk->buf_size-1]);
	if (chunk->file_offset >= filelen)
		ur_internal(__func__, "file_offset=%lu >= file_size=%d\n",
			    (long unsigned)chunk->file_offset, filelen);
}

static const char *ur_id3_stringify(const char *src)
{
	char       *dest, *d, *utf8dest;
	const char *s;
	bool       upcase = true;
	int        length;

	dest = alloca(2 * strlen(src));

	for (d = dest, s = src; *s; s++) {
		if (*s == '_') {
			*d++ = ' ';
			upcase = true;
		} else if (upcase) {
			*d++ = toupper(*s);
			upcase = false;
		} else {
			*d++ = *s;
		}
	}
	*d = '\0';

	utf8dest = alloca(2 * strlen(dest) + 2);
	length = ur_id3_utf8ify(utf8dest, dest, strlen(dest));
	return ur_atom_string_n(utf8dest, length);
}

static int ur_id3_read_custom(ur_id3_t e, ur_parse_t p)
{
	ur_list_t     list;
	ur_iterator_t iter;
	const char    *string;
	int           item = 0;

	if (!p) return -1;

	list = ur_parse(p, e->filename, &e->iattr, &e->sattr);
	if (!list) return -1;
	UR_LIST_ITERATE(list, iter, string) {
		if (strlen(string)) {
			switch (item) {
			case 0: e->title  = ur_id3_stringify(string); break;
			case 1: e->artist = ur_id3_stringify(string); break;
			case 2: e->album  = ur_id3_stringify(string); break;
			case 3: e->track  = strtol(string, NULL, 10); break;
			}
		}
		++item;
	}
	e->valid = true;
	return 0;
}

static int _ur_id3_read_chunks(ur_id3_t e, const char *filename,
			       ur_id3_read_t flag, ur_id3_io_t *chunk,
			       int max_head, int max_tail)
{
	int           fd;
	struct stat   sbuf;
	int           retcode;
	int           open_flags;
	int           i;
	char          buf0[UR_ID3_V2_CHUNKMAX + UR_ID3_PAGESIZE];
	char          buf1[UR_ID3_V1_MAXLEN   + UR_ID3_PAGESIZE * 2];
	bool          directio;

	directio    = !!(flag & UR_ID3_READ_DIRECT);
	open_flags  = O_RDONLY | (directio ? O_DIRECT : 0) ;

	if ((fd = open(filename, open_flags)) < 0) return ENODATA;
	fstat(fd, &sbuf);
	e->file_size  = sbuf.st_size;
	e->file_mtime = sbuf.st_mtime;

	if (!e->file_size) return ENODATA;

	if (directio) {
		ur_id3_setup_directio(&chunk[0], buf0, sizeof(buf0),
				      true, e->file_size, max_head);
		ur_id3_setup_directio(&chunk[1], buf1, sizeof(buf1),
				      false, e->file_size, max_tail);
	} else {
		ur_id3_setup_io(&chunk[0], buf0, sizeof(buf0),
				true, e->file_size, max_head);
		ur_id3_setup_io(&chunk[1], buf1, sizeof(buf1),
				false, e->file_size, max_tail);
	}

	for (i = 0; i < 2; i++) {
		ur_trace(UR_TRACE_ID3, __func__,
			 "direct=%d file_size=%d chunk[%d].buf_size=%lu buf=%p"
			 " buf_start=%p buf_end=%p size=%lu file_offset=%lu\n",
			 directio, e->file_size, i, chunk[i].buf_size,
			 chunk[i].buf, chunk[i].buf_start, chunk[i].buf_end,
			 chunk[i].size, chunk[i].file_offset);

		memset((void *)chunk[i].buf, 0, chunk[i].buf_size);
		if (ur_debug_test(UR_DEBUG_ID3_ZERO)) continue;
		retcode = lseek(fd, chunk[i].file_offset, SEEK_SET);
		if (retcode < 0) {
			ur_warning(__func__, "Cannot seek to %lu: %s\n",
				   chunk[i].file_offset, strerror(errno));
			return ENODATA;
		}
		retcode = read(fd, (void *)chunk[i].buf_start, chunk[i].size);
		if (retcode < 0) {
			ur_warning(__func__, "Cannot read %lu: %s\n",
				   chunk[i].size, strerror(errno));
			return ENODATA;
		}
		chunk[i].buf_end = chunk[i].buf_start + retcode;
	}
	close(fd);
	return 0;
}

static ur_file_t _ur_id3_read_mmap(ur_id3_t e, const char *filename,
				   ur_id3_io_t *chunk)
{
	ur_file_t file;
	int       i;

	file = ur_file_open(filename);
	if (!file) return NULL;
	e->file_size  = ur_file_size(file);
	e->file_mtime = ur_file_mtime(file);
	if (!e->file_size) {
		ur_file_close(file);
		return NULL;
	}
	for (i = 0; i < 2; i++) {
		chunk[i].buf_size    = e->file_size;
		chunk[i].buf         = ur_file_start(file);
		chunk[i].buf_start   = ur_file_start(file);
		chunk[i].buf_end     = ur_file_end(file);
		chunk[i].size        = e->file_size;
		chunk[i].file_offset = 0;
	}

	return file;
}

static int _ur_id3_read(ur_id3_t e, const char *filename, ur_id3_read_t flag,
			int max_head, int max_tail, ur_parse_t p)
{
	int           retcode;
	int           retval;
	ur_id3_io_t   chunk[2];
	bool          map;
	ur_file_t     file = NULL;

	if (!filename || filename[0] == '\0') {
		ur_fatal(__func__, "Zero-length filename\n");
	}
	e->filename = ur_atom_string(filename);
	map         = !!(flag & UR_ID3_READ_MMAP);

	if (map) {
		file = _ur_id3_read_mmap(e, filename, chunk);
		if (!file) return ENODATA;
	} else {
		retcode = _ur_id3_read_chunks(e, filename, flag, chunk,
					      max_head, max_tail);
		if (retcode) return retcode;
	}

	e->file_meta_size = ur_id3_v1_meta_size(chunk[1].buf_start,
						chunk[1].buf_end);

	switch (flag & UR_ID3_READ_MASK) {
	case UR_ID3_READ_BEST:
		retval = ur_id3_read_id3v2(e,
					   chunk[0].buf_start,
					   chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		if (retval) {
			retval = ur_id3_read_id3v1(e,
						   chunk[1].buf_start,
						   chunk[1].buf_end);
			if (!retval && e->source != UR_ID3_LYRICS3_V2) {
				ur_id3_augment(e, filename);
			}
		}
		if (retval && p) {
			retval = ur_id3_read_custom(e, p);
		}
		retval = ur_id3_read_mp3(e,
					 chunk[0].buf_start,
					 chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		ur_id3_search_compute(e);
		break;
	case UR_ID3_READ_CUSTOM:
		retval = ur_id3_read_custom(e, p);
		retval = ur_id3_read_mp3(e,
					 chunk[0].buf_start,
					 chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		ur_id3_search_compute(e);
		break;
	case UR_ID3_READ_V1:
		ur_id3_read_id3v1(e,
				  chunk[1].buf_start,
				  chunk[1].buf_end);
		break;
	case UR_ID3_READ_V2:
		retval = ur_id3_read_id3v2(e,
					   chunk[0].buf_start,
					   chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		break;
	case UR_ID3_READ_MP3:
		retval = ur_id3_read_id3v2(e,
					   chunk[0].buf_start,
					   chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		e->valid = true;
		retval = ur_id3_read_mp3(e,
					 chunk[0].buf_start,
					 chunk[0].buf_end);
		if (ur_id3_enomem(retval, e, max_head)) return ENOMEM;
		break;
	}
	if (file) ur_file_close(file);
	return 0;
}

ur_id3_t ur_id3_read(const char *filename, ur_id3_read_t flag, ur_parse_t p)
{
	int      retval;
	ur_id3_t e    = ur_id3_create();
	int      head = UR_ID3_V2_CHUNKLEN;

	do {
		if (e->header_size < head || head >= UR_ID3_V2_CHUNKMAX) {
			retval = _ur_id3_read(e, filename, flag,
					      head, UR_ID3_V1_MAXLEN, p);
		}
		head *= 2;
	} while (retval == ENOMEM && head <= UR_ID3_V2_CHUNKMAX);
	return e;
}

void ur_id3_set_valid(ur_id3_t e, bool valid)
{
	_ur_id3_check(e);
	e->valid = valid;
}

void ur_id3_set_source(ur_id3_t e, ur_id3_source_t source)
{
	_ur_id3_check(e);
	e->source = source;
}

void ur_id3_set_filename(ur_id3_t e, const char *filename)
{
	_ur_id3_check(e);

	if (!filename || filename[0] == '\0') {
		ur_fatal(__func__, "Zero-length filename\n");
	}

	e->filename = filename;
}

void ur_id3_set_title(ur_id3_t e, const char *title)
{
	_ur_id3_check(e);
	e->title = title;
}

void ur_id3_set_artist(ur_id3_t e, const char *artist)
{
	_ur_id3_check(e);
	e->artist = artist;
}

void ur_id3_set_album(ur_id3_t e, const char *album)
{
	_ur_id3_check(e);
	e->album = album;
}

void ur_id3_set_year(ur_id3_t e, const char *year)
{
	_ur_id3_check(e);
	e->year = year;
}

void ur_id3_set_track(ur_id3_t e, int track)
{
	char buf[16];
	_ur_id3_check(e);
	e->track = track;
	snprintf(buf, sizeof(buf)-1, "%d", track);
	e->track_string = ur_atom_string(buf);
}

void ur_id3_set_mtime(ur_id3_t e, time_t mtime)
{
	_ur_id3_check(e);
	e->file_mtime = mtime;
}

void ur_id3_set_size(ur_id3_t e, int size)
{
	_ur_id3_check(e);
	e->file_size = size;
}

void ur_id3_set_mpeg_version(ur_id3_t e, ur_id3_mpeg_version_t mpeg_version)
{
	_ur_id3_check(e);
	e->mpeg_version = mpeg_version;
}

void ur_id3_set_mpeg_layer(ur_id3_t e, ur_id3_mpeg_layer_t mpeg_layer)
{
	_ur_id3_check(e);
	e->mpeg_layer = mpeg_layer;
}

void ur_id3_set_mpeg_mode(ur_id3_t e, ur_id3_mpeg_mode_t mpeg_mode)
{
	_ur_id3_check(e);
	e->mpeg_mode = mpeg_mode;
}

void ur_id3_set_mpeg_sample_rate(ur_id3_t e, int mpeg_sample_rate)
{
	_ur_id3_check(e);
	e->mpeg_sample_rate = mpeg_sample_rate;
}

void ur_id3_set_mpeg_cbr(ur_id3_t e, int mpeg_cbr)
{
	_ur_id3_check(e);
	e->mpeg_cbr = mpeg_cbr;
	ur_id3_update_rate_string(e);
}

void ur_id3_set_mpeg_vbr(ur_id3_t e, int mpeg_vbr)
{
	_ur_id3_check(e);
	e->mpeg_vbr = mpeg_vbr;
	ur_id3_update_rate_string(e);
}

void ur_id3_set_mpeg_duration(ur_id3_t e, int mpeg_duration)
{
	int  h, m, s;
	char buf[256];

	_ur_id3_check(e);
	e->mpeg_duration = mpeg_duration;

	h = e->mpeg_duration / 3600;
	m = (e->mpeg_duration - h * 3600) / 60;
	s = e->mpeg_duration - h * 3600 - m * 60;
	snprintf(buf, sizeof(buf), "%d:%02d", m + h * 60, s);
	e->duration_string = ur_atom_string(buf);
}

void ur_id3_set_search(ur_id3_t e, const char *search)
{
	_ur_id3_check(e);
	e->search = search;
}

void ur_id3_set_current_playtime(ur_id3_t e, int playtime)
{
	_ur_id3_check(e);
	e->current_playtime = playtime;
	if (!playtime) time(&e->current_starttime);
}

int ur_id3_current_playtime(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->current_playtime;
}

time_t ur_id3_current_starttime(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->current_starttime;
}

const char *ur_id3_filename(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->filename ? e->filename : "";
}

const char *ur_id3_title(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->title ? e->title : "";
}

const char *ur_id3_artist(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->artist ? e->artist : "";
}

const char *ur_id3_album(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->album ? e->album : "";
}

const char *ur_id3_year(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->year ? e->year : "";
}

int ur_id3_track(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->track;
}

const char *ur_id3_track_string(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->track_string ? e->track_string : "";
}

time_t ur_id3_mtime(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->file_mtime;
}

int ur_id3_size(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->file_size;
}

bool ur_id3_valid(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->valid;
}

const char *ur_id3_search(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->search;
}

int ur_id3_iattr(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->iattr;
}

const char *ur_id3_sattr(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->sattr;
}

const char *ur_id3_source(ur_id3_t e)
{
	_ur_id3_check(e);

	switch (e->source) {
	case UR_ID3_PATH:                 return "pathname";
	case UR_ID3_V1:                   return "id3v1";
	case UR_ID3_V1_1:                 return "id3v1.1";
	case UR_ID3_V1_AUGMENTED:         return "id3v1+";
	case UR_ID3_V1_1_AUGMENTED:       return "id3v1.1+";
	case UR_ID3_LYRICS3_V2:           return "lyrics3v2";
	case UR_ID3_LYRICS3_V2_AUGMENTED: return "lyrics3v2+";
	case UR_ID3_V2_UNKNOWN:           return "id3v2.?";
	case UR_ID3_V2_2:                 return "id3v2.2";
	case UR_ID3_V2_3:                 return "id3v2.3";
	case UR_ID3_V2_4:                 return "id3v2.4";
	case UR_ID3_WEBSTREAM:            return "webstream";
	default:                          return "unknown";
	}
}

ur_id3_source_t ur_id3_source_decode(const char *s)
{
	if (!strcmp(s, "pathname"))   return UR_ID3_PATH;
	if (!strcmp(s, "id3v1"))      return UR_ID3_V1;
	if (!strcmp(s, "id3v1.1"))    return UR_ID3_V1_1;
	if (!strcmp(s, "id3v1+"))     return UR_ID3_V1_AUGMENTED;
	if (!strcmp(s, "id3v1.1+"))   return UR_ID3_V1_1_AUGMENTED;
	if (!strcmp(s, "lyrics3v2"))  return UR_ID3_LYRICS3_V2;
	if (!strcmp(s, "lyrics3v2+")) return UR_ID3_LYRICS3_V2_AUGMENTED;
	if (!strcmp(s, "id3v2.?"))    return UR_ID3_V2_UNKNOWN;
	if (!strcmp(s, "id3v2.2"))    return UR_ID3_V2_2;
	if (!strcmp(s, "id3v2.3"))    return UR_ID3_V2_3;
	if (!strcmp(s, "id3v2.4"))    return UR_ID3_V2_4;
	if (!strcmp(s, "webstream"))  return UR_ID3_WEBSTREAM;
	return UR_ID3_UNKNOWN;
}

const char *ur_id3_mpeg_version(ur_id3_t e)
{
	_ur_id3_check(e);

	switch (e->mpeg_version) {
	case UR_ID3_MPEG_V2_5:  return "2.5";
	case UR_ID3_MPEG_V2:    return "2";
	case UR_ID3_MPEG_V1:    return "1";
	default:                return "unknown";
	}
}

ur_id3_mpeg_version_t ur_id3_mpeg_version_decode(const char *s)
{
	if (!strcmp(s, "2.5")) return UR_ID3_MPEG_V2_5;
	if (!strcmp(s, "2"))   return UR_ID3_MPEG_V2;
	if (!strcmp(s, "1"))   return UR_ID3_MPEG_V1;
	return UR_ID3_MPEG_V_UNKNOWN;
}

const char *ur_id3_mpeg_layer(ur_id3_t e)
{
	_ur_id3_check(e);

	switch (e->mpeg_layer) {
	case UR_ID3_MPEG_L_I:   return "I";
	case UR_ID3_MPEG_L_II:  return "II";
	case UR_ID3_MPEG_L_III: return "III";
	default:                return "unknown";
	}
}

ur_id3_mpeg_layer_t ur_id3_mpeg_layer_decode(const char *s)
{
	if (!strcmp(s, "I"))   return UR_ID3_MPEG_L_I;
	if (!strcmp(s, "II"))  return UR_ID3_MPEG_L_II;
	if (!strcmp(s, "III")) return UR_ID3_MPEG_L_III;
	return UR_ID3_MPEG_L_UNKNOWN;
}

const char *ur_id3_mpeg_mode(ur_id3_t e)
{
	_ur_id3_check(e);

	switch (e->mpeg_mode) {
	case UR_ID3_MPEG_STEREO:        return "stereo";
	case UR_ID3_MPEG_JOINT_STEREO:  return "joint stereo";
	case UR_ID3_MPEG_DUAL:          return "dual";
	case UR_ID3_MPEG_MONO:          return "mono";
	case UR_ID3_MPEG_UNKNOWN:       return "unknown";
	}
	return "unknown";
}

ur_id3_mpeg_mode_t ur_id3_mpeg_mode_decode(const char *s)
{
	if (!strcmp(s, "stereo"))       return UR_ID3_MPEG_STEREO;
	if (!strcmp(s, "joint stereo")) return UR_ID3_MPEG_JOINT_STEREO;
	if (!strcmp(s, "dual"))         return UR_ID3_MPEG_DUAL;
	if (!strcmp(s, "mono"))         return UR_ID3_MPEG_MONO;
	return UR_ID3_MPEG_UNKNOWN;
}

int ur_id3_mpeg_sample_rate(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->mpeg_sample_rate;
}

int ur_id3_mpeg_cbr(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->mpeg_cbr;
}

int ur_id3_mpeg_vbr(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->mpeg_vbr;
}

int ur_id3_mpeg_duration(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->mpeg_duration;
}

const char *ur_id3_duration_string(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->duration_string;
}

const char *ur_id3_rate_string(ur_id3_t e)
{
	_ur_id3_check(e);
	return e->rate_string;
}

void ur_id3_print(ur_id3_t e, FILE *str, bool mpeg)
{
	fprintf(str, "File:    %s\n", e->filename);
	if (!e->valid) {
		fprintf(str, "Invalid\n");
		return;
	}

	fprintf(str, "Source:  %s\n", ur_id3_source(e));
	fprintf(str, "Title:   %s\n", e->title);
	fprintf(str, "Artist:  %s\n", e->artist);
	fprintf(str, "Album:   %s\n", e->album);
	fprintf(str, "Year:    %s\n", e->year);
	fprintf(str, "Comment: %s\n", e->comment);
	fprintf(str, "Track:   %d\n", e->track);
	fprintf(str, "Genre:   %d\n", e->genre);
	if (mpeg) {
		fprintf(str, "MPEG Version:  %s\n", ur_id3_mpeg_version(e));
		fprintf(str, "MPEG Layer:    %s\n", ur_id3_mpeg_layer(e));
		fprintf(str, "MPEG CBR:      %d kbps\n", e->mpeg_cbr);
		fprintf(str, "MPEG Rate:     %d Hz\n", e->mpeg_sample_rate);
		fprintf(str, "MPEG Mode:     %s\n", ur_id3_mpeg_mode(e));
		if (!ur_id3_duration_string(e)) {
			ur_id3_set_mpeg_duration(e, e->mpeg_duration);
		}
		fprintf(str, "MPEG Duration: %s\n", ur_id3_duration_string(e));
		fprintf(str, "MPEG VBR:      %d kbps\n", e->mpeg_vbr / 1000);
	}
	fprintf(str, "Search:        %s\n", e->search);
}

void ur_id3_canonify(ur_id3_t e)
{
	if (!e->valid) return;
	if (!e->filename) e->filename = "";
	if (!e->title)    e->title    = "";
	if (!e->artist)   e->artist   = "";
	if (!e->album)    e->album    = "";
	if (!e->year)     e->year     = "";
	if (!e->comment)  e->comment  = "";
}

#ifdef UR_DEVEL
#include <ftw.h>

static int dump(const char *filename, const struct stat *sb,
		int typeflag)
{
	ur_id3_t e;
	int len = strlen(filename);

	if (typeflag == FTW_F && !strncmp(&filename[len-4], ".mp3", 4)) {
		printf("\n\n%s", filename);
		e = ur_id3_read(filename);
		ur_id3_print(e, stdout, true);
		ur_id3_destroy(e);
	}

	return 0;
}

int main(int argc, char **argv)
{
	int i;

	ur_init(argv[0]);

	for (i = 1; i < argc; i++) {
		ftw(argv[i], dump, 10);
	}

	return 0;
}
#endif
