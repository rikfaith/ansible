/* test-cache.c -- 
 * Created: Sat May 23 09:15:27 2009 by faith@acm.org
 * Revised: Wed Jul  1 06:00:43 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#define OBJECTNAME       "ur_cache"
#define OBJECTTYPE       ur_cache_t
#define OBJECTROOT       "/tmp/ur-test-cache"
#define OBJECTCREATEROOT ur_cache_create
#define OBJECTINSERT3    ur_cache_insert
#define OBJECTLOOKUP3    ur_cache_lookup
#define OBJECTDELETE3    ur_cache_delete
#define OBJECTDESTROY    ur_cache_destroy
#define OBJECTINFO
#define OBJECTALNUM      3
#define OBJECTLENLIMIT   200
#define OBJECTCASEDUP

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif



int main(int argc, const char **argv)
{
	char             buf[1024];
	char             buf2[1024];
	ur_cache_t       cache;
	char             root[1024];
	struct stat      sb;
	int              retcode;
	const char       *string;
	bool             verbose = false;
	int              c;
	ur_option_t      opt;
	ur_list_t        list;
	ur_option_list_t optlist[] = {
		{ "verbose", 'v', UR_OPTION_NONE },
		{ NULL, 0, 0 }
	};

	ur_init(argv[0]);
	opt = ur_option_create(optlist);
	ur_option_parse_argv(opt, argc, argv);
	while ((c = ur_option_get(opt)) != EOF) {
		switch (c) {
		case 'v':
			verbose = true;
			break;
		}
	}

	snprintf(root, sizeof(root), "/tmp/ur-%d", getpid());

	test("L", "ur_cache_create");
	cache = ur_cache_create(root, NULL);
	if (!cache) fail("NULL returned");
	retcode = stat(root, &sb);
	if (retcode) {
		snprintf(buf, sizeof(buf), "cannot stat %s, errno=%d: %s",
			 root, errno, strerror(errno));
		fail(buf);
	}
	if (!S_ISDIR(sb.st_mode)) fail("not a directory");
	ok(0);

	test("L", "ur_cache_insert 1");
	ur_cache_insert(cache, "CL_ASS", "____SubClass", "txt", "Test string");
	snprintf(buf2, sizeof(buf), "%s/c/l/class/class-subclass.txt", root);
	retcode = stat(buf2, &sb);
	if (retcode) {
		snprintf(buf, sizeof(buf), "cannot stat %s, errno=%d: %s",
			 buf2, errno, strerror(errno));
		fail(buf);
	}
	ok(0);

	if (verbose) {
		snprintf(buf, sizeof(buf), "ls -lRa %s", root);
		if (system(buf) < 0)
			printf("system(%s) failed\n", buf);
	}

	test("L", "ur_cache_lookup 1");
	string = ur_cache_lookup(cache, "_C!L*ass", "s.u.b.c.l.a.s.s", "txt");
	if (strcmp(string, "Test string")) fail(string);
	ok(string);

	test("L", "ur_cache_lookup 2");
	string = ur_cache_lookup(cache, "_C!L*asss", "s.u.b.c.l.a.s.s", "txt");
	if (string) fail("found non-existent file");
	ok(0);

	test("L", "ur_cache_insert 2");
	ur_cache_insert(cache, "C", "____SubClass", "txt", "Test32");
	snprintf(buf2, sizeof(buf), "%s/c/_/c/c-subclass.txt", root);
	retcode = stat(buf2, &sb);
	if (retcode) {
		snprintf(buf, sizeof(buf), "cannot stat %s, errno=%d: %s",
			 buf2, errno, strerror(errno));
		fail(buf);
	}
	ok(0);

	if (verbose) {
		snprintf(buf, sizeof(buf), "ls -lRa %s", root);
		if (system(buf) < 0)
			printf("system(%s) failed\n", buf);
	}

	test("L", "ur_cache_lookup 3");
	string = ur_cache_lookup(cache, "C", "____SubClass", "txt");
	if (strcmp(string, "Test32")) fail(string);
	ok(string);

	test("L", "ur_cache_lookup 4");
	string = ur_cache_lookup(cache, "_C!L*ass", "s.u.b.c.l.a.s.s", "txt");
	if (strcmp(string, "Test string")) fail(string);
	ok(string);

 	test("L", "ur_cache_insert 3");
	ur_cache_insert(cache, " C", "____SubClass", "txt", "Test32");
	snprintf(buf2, sizeof(buf), "%s/_/c/_c/_c-subclass.txt", root);
	retcode = stat(buf2, &sb);
	if (retcode) {
		snprintf(buf, sizeof(buf), "cannot stat %s, errno=%d: %s",
			 buf2, errno, strerror(errno));
		fail(buf);
	}
	ok(0);

	if (verbose) {
		snprintf(buf, sizeof(buf), "ls -lRa %s", root);
		if (system(buf) < 0)
			printf("system(%s) failed\n", buf);
	}

	test("L", "ur_cache_lookup 5");
	string = ur_cache_lookup(cache, " C", "____SubClass", "txt");
	if (strcmp(string, "Test32")) fail(string);
	ok(string);

	test("L", "ur_cache_lookup 6");
	string = ur_cache_lookup(cache, "_C!L*ass", "s.u.b.c.l.a.s.s", "txt");
	if (strcmp(string, "Test string")) fail(string);
	ok(string);

	test("L", "clean up");
	snprintf(buf, sizeof(buf), "rm -rf %s", root);
	if (verbose) printf("%s\n", buf);
	if (system(buf) < 0) {
		fail("fork failed");
	} else {
		ok(0);
	}

	list = ur_option_other(opt, NULL);
	if (list && ur_list_depth(list)) {
		if ((retcode = timecontainer())) return retcode;
	} else {
		if ((retcode = testcreate()))    return retcode;
		if ((retcode = testcontainer())) return retcode;
	}

	test("L", "clean up");
	snprintf(buf, sizeof(buf), "rm -rf %s", OBJECTROOT);
	if (verbose) printf("%s\n", buf);
	if (system(buf) < 0) {
		fail("system failed");
	} else {
		ok(0);
	}

	return EXIT_SUCCESS;
}
