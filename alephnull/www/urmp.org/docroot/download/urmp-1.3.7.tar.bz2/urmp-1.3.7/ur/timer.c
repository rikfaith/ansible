/* timer.c -- 
 * Created: Mon Jul  5 13:33:05 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: timer.c,v 1.9 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "urP.h"

struct ur_timer_s {
    unsigned long   magic;
    ur_timer_type_t   type;
    ur_timeval_t     start;
    ur_timeval_t     stop;
};

CHECK_FUNCTION(_ur_timer_check, ur_timer_t, UR_TIMER_MAGIC)

ur_timer_t ur_timer_create(ur_timer_type_t type)
{
    ur_timer_t timer = ur_allocz(sizeof(*timer));

    timer->magic = UR_TIMER_MAGIC;
    timer->type  = type ? type : UR_TIMER_ALL;
    ur_timer_start(timer);

    return timer;
}

unsigned long ur_timer_destroy(ur_timer_t timer)
{
    unsigned long ret;
    
    _ur_timer_check(timer);
    ret = timer->magic = ~timer->magic;
    ur_free(timer);
    return ret;
}

static void _ur_timer_snap(ur_timer_type_t type, ur_timeval_t *val)
{
    struct rusage ru;
    
    if (type & UR_TIMER_WALL) gettimeofday(&val->wall, NULL);

    if (type & UR_TIMER_CPU) {
	getrusage(RUSAGE_SELF, &ru);
	val->user.tv_sec    = ru.ru_utime.tv_sec;
	val->user.tv_usec   = ru.ru_utime.tv_usec;
	val->system.tv_sec  = ru.ru_stime.tv_sec;
	val->system.tv_usec = ru.ru_stime.tv_usec;
	getrusage(RUSAGE_CHILDREN, &ru);
	val->children_user.tv_sec    = ru.ru_utime.tv_sec;
	val->children_user.tv_usec   = ru.ru_utime.tv_usec;
	val->children_system.tv_sec  = ru.ru_stime.tv_sec;
	val->children_system.tv_usec = ru.ru_stime.tv_usec;
    }
}

void ur_timer_start(ur_timer_t timer)
{
    _ur_timer_check(timer);
    _ur_timer_snap(timer->type, &timer->start);
}

void ur_timer_stop(ur_timer_t timer)
{
    _ur_timer_check(timer);
    _ur_timer_snap(timer->type, &timer->stop);
}

static __inline__ void _ur_timer_copy(ur_timeval_t *d, ur_timeval_t *s)
{
    memcpy((void *)d, (void *)s, sizeof(*d));
}

void ur_timer_get_start(ur_timer_t timer, ur_timeval_t *timeval)
{
    _ur_timer_check(timer);
    if (!timeval) ur_fatal(__FUNCTION__, "NULL pointer\n");
    _ur_timer_copy(timeval, &timer->start);
}

void ur_timer_get_stop(ur_timer_t timer, ur_timeval_t *timeval)
{
    _ur_timer_check(timer);
    if (!timeval) ur_fatal(__FUNCTION__, "NULL pointer\n");
    _ur_timer_copy(timeval, &timer->stop);
}

void ur_timer_set_start(ur_timer_t timer, ur_timeval_t *timeval)
{
    _ur_timer_check(timer);
    if (!timeval) ur_fatal(__FUNCTION__, "NULL pointer\n");
    _ur_timer_copy(&timer->start, timeval);
}

void ur_timer_set_stop(ur_timer_t timer, ur_timeval_t *timeval)
{
    _ur_timer_check(timer);
    if (!timeval) ur_fatal(__FUNCTION__, "NULL pointer\n");
    _ur_timer_copy(&timer->stop, timeval);
}

static void _ur_timer_diff(struct timeval *result,
                          struct timeval *stop,
                          struct timeval *start)
{
    memcpy((void *)result, (void *)stop, sizeof(*result));
    
    if (result->tv_usec < start->tv_usec) {
	if (!result->tv_sec)
	    ur_internal(__FUNCTION__,
			"(%lu,%lu) -> (%lu,%lu)\n",
			start->tv_sec,
			start->tv_usec,
			stop->tv_sec,
			stop->tv_usec);
	result->tv_usec += 1000000;
	--result->tv_sec;
    }
    if (result->tv_usec < start->tv_usec
	|| result->tv_sec < start->tv_sec) {
	    ur_internal(__FUNCTION__,
			"(%lu,%lu) -> (%lu,%lu)\n",
			start->tv_sec,
			start->tv_usec,
			stop->tv_sec,
			stop->tv_usec);
    }
    result->tv_sec  -= start->tv_sec;
    result->tv_usec -= start->tv_usec;
}

void ur_timer_get_elapsed(ur_timer_t timer, ur_timeval_t *timeval)
{
    _ur_timer_check(timer);
    if (!timeval) ur_fatal(__FUNCTION__, "NULL pointer\n");
    _ur_timer_diff(&timeval->wall, &timer->stop.wall, &timer->start.wall);
    _ur_timer_diff(&timeval->user, &timer->stop.user, &timer->start.user);
    _ur_timer_diff(&timeval->system, &timer->stop.system, &timer->start.system);
    _ur_timer_diff(&timeval->children_user,
		  &timer->stop.children_user, &timer->start.children_user);
    _ur_timer_diff(&timeval->children_system,
		  &timer->stop.children_system, &timer->start.children_system);
}
