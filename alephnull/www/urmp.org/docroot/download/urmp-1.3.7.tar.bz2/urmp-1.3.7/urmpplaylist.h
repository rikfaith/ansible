/* urmpplaylist.h -- 
 * Created: Mon Feb 16 12:42:54 2009 by faith@acm.org
 * Revised: Sun Apr 26 14:13:41 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPPLAYLIST_H_
#define _URMPPLAYLIST_H_

#include "urmp.h"
#include "urmpconfig.h"

extern void       urmp_playlist_write(const char *filename, ur_list_t list);
extern ur_list_t  urmp_playlist_read(const char *filename);
extern const char *urmp_playlist_list(void **cookie);

#endif
