/* urmphook.c -- 
 * Created: Sun May 10 21:00:17 2009 by faith@acm.org
 * Revised: Sun May 17 15:42:36 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmphook.h"
#include <time.h>

static ur_id3_t id3;
static time_t   start;
static time_t   elapsed;
static bool     paused = false;

void urmp_hook_stop(ur_id3_t e)
{
	time_t now;

	if (!e || !id3 || e != id3) {
		return;
	}

	if (!paused) {
		time(&now);
		elapsed += now - start;
	}

	id3 = NULL;

	ur_trace(URMP_TRACE_SCROB, __func__,
		 "%d %s\n", (int)elapsed, ur_id3_title(e));

	ur_id3_set_current_playtime(e, elapsed);
	urmp_scrobble(e);
}

void urmp_hook_start(ur_id3_t e)
{
	id3 = e;
	time(&start);
	elapsed = 0;
	paused = false;

	ur_id3_set_current_playtime(e, elapsed);
	urmp_scrobble(e);
	urmp_lyrics(e);
}

void urmp_hook_pause(ur_id3_t e)
{
	time_t now;

	if (!e || !id3 || e != id3) {
		urmp_hook_start(e);
		return;
	}
	if (paused) {
		time(&start);
		paused = false;
		return;
	}

	time(&now);
	elapsed += now - start;
	paused = true;
	ur_id3_set_current_playtime(e, elapsed);
}
