/* urmpguiabout.c -- 
 * Created: Sun May 17 15:38:01 2009 by faith@acm.org
 * Revised: Wed May 27 17:09:37 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmpgui.h"
#include "version.h"

void urmp_gui_about_build(GtkWidget *notebook)
{
	GtkWidget              *scrolled;
	GtkWidget              *text;
	GtkWidget              *label;
	GtkTextBuffer          *buffer;
	char                   message[4096];

	snprintf(message, sizeof(message),
		 "urmp %d.%d.%d (%s)\n"
		 "Ur Music Player\n"
		 "Copyright \xc2\xa9 2008 Rickard E. (Rik) Faith\n"
		 "Released under the MIT License:\n"
		 "http://opensource.org/licenses/mit-license.php\n"
		 "There is NO WARRANTY, to the extent permitted by law.\n"
		 "Some 3rd-party code is under a modified BSD license.\n"
		 "\n"
		 "urmp is built on the ur library: %s\n"
		 "\n"
		 "urmp is linked against other libraries,\n"
		 "each with its own license, including:\n"
		 "GTK+: http://www.gtk.org/\n"
		 "pcre: http://www.pcre.org/\n"
		 "libcurl: http://curl.haxx.se/libcurl/\n"
		 "\n"
		 "urmp makes use of other binaries installed\n"
		 "on the system to decode MP3s, such as:\n"
		 "MPlayer: http://www.mplayerhq.hu\n"
		 "\n"
		 "urmp includes custom ID3 and MP3 header parsing,\n"
		 "based on public documentation:\n"
		 "ID3v1.x: http://id3.org/ID3v\n"
		 "ID3v2.2: http://id3.org/id3v2-00\n"
		 "ID3v2.3: http://id3.org/id3v2.3.0\n"
		 "ID3v2.4: http://id3.org/id3v2.4.0-structure\n"
                 "Lyrics3: http://www.id3.org/lyrics3200.html\n"
		 "MP3 headers:"
		 " http://www.mp3-tech.org/programmer/frame_header.html"
		 , URMP_MAJOR, URMP_MINOR, URMP_PATCH, URMP_DATE,
		 ur_version());

	label    = gtk_label_new("About");
	scrolled = gtk_scrolled_window_new(NULL, NULL);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), scrolled, label);

	buffer = gtk_text_buffer_new(NULL);
	text = gtk_text_view_new_with_buffer(buffer);
	gtk_text_view_set_editable(GTK_TEXT_VIEW(text), FALSE);
	gtk_container_add(GTK_CONTAINER(scrolled), text);

	gtk_text_buffer_set_text(buffer, message, -1);
}
