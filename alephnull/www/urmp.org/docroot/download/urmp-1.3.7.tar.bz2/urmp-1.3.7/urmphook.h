/* urmphook.h -- 
 * Created: Sun May 10 21:01:01 2009 by faith@acm.org
 * Revised: Fri May 15 18:10:55 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMP_HOOK_H_
#define _URMP_HOOK_H_

extern void urmp_hook_stop(ur_id3_t e);
extern void urmp_hook_start(ur_id3_t e);
extern void urmp_hook_pause(ur_id3_t e);

#endif
