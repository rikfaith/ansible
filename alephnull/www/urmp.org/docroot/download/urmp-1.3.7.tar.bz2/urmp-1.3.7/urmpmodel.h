/* urmpmodel.h -- 
 * Created: Fri Dec  5 21:34:23 2008 by faith@acm.org
 * Revised: Sat Dec  6 08:57:17 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPMODEL_H_
#define _URMPMODEL_H_

#include <urmpgui.h>

#define URMP_MODEL_TYPE (urmp_model_get_type())
#define URMP_MODEL(obj) \
	(G_TYPE_CHECK_INSTANCE_CAST((obj), URMP_MODEL_TYPE, urmp_model_t))
#define URMP_MODEL_CLASS(klass) \
	(G_TYPE_CHECK_CLASS_CAST((klass), URMP_MODEL_TYPE, urmp_model_class_t)
#define URMP_MODEL_IS(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj), URMP_MODEL_TYPE))
#define URMP_MODEL_IS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), URMP_MODEL_TYPE))
#define URMP_MODEL_GET_CLASS(obj) \
	(G_TYPE_INSTANCE_GET_CLASS((obj), URMP_MODEL_TYPE, urmp_model_class_t))

typedef struct urmp_model_s {
	GObject         parent;
	urmp_gui_list_t *list;
	gint            n_columns;
	GType           column_types[URMP_COLUMNS];
	gint            stamp;
} urmp_model_t;

typedef struct {
	GObjectClass parent_class;
} urmp_model_class_t;

extern GType        urmp_model_get_type(void);
extern urmp_model_t *urmp_model_new(urmp_gui_list_t *list);

#endif
