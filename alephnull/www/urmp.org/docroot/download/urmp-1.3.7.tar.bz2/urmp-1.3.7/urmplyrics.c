/* urmplyrics.c -- 
 * Created: Sun May 17 13:05:44 2009 by faith@acm.org
 * Revised: Thu Jul  2 07:34:54 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpconfig.h"
#include <curl/curl.h>

static ur_proc_t     urmp_lyrics_proc;
static unsigned long urmp_lyrics_generation;

static int urmp_lyrics_worker(ur_msg_t msg _unused, int type _unused,
			      void *buf, int length, void *arg _unused)
{
	ur_id3_t      e;

	e        = ur_id3_unpack(buf, length);

	ur_trace(URMP_TRACE_LYRICS, __func__,
		 "title=%s\n", ur_id3_title(e));

	return 0;
}

static int urmp_lyrics_cleanup(int pid, int status _unused,
			       int err _unused, void *arg _unused)
{
	ur_trace(URMP_TRACE_LYRICS, __func__, "pid %d died\n", pid);
	urmp_lyrics_proc = NULL;
	return 0;
}

void urmp_lyrics(ur_id3_t e)
{
	int             len;
	char            buf[URMP_MAX_ID3_BUFLEN];

	if (urmp_lyrics_generation != urmp_config_get_lyrics_generation()) {
		urmp_lyrics_generation = urmp_config_get_lyrics_generation();
		ur_trace(URMP_TRACE_LYRICS, __func__,
			 "Generation %lu\n", urmp_lyrics_generation);
		if (urmp_lyrics_proc) ur_proc_destroy(urmp_lyrics_proc);
		urmp_lyrics_proc = NULL;
	}

	if (!urmp_config_get_lyrics_lyricwiki()
	    && !urmp_config_get_lyrics_lyricsfly()) {
		ur_trace(URMP_TRACE_LYRICS, __func__,
			 "No lyric sites selected, urmp_lyrics_proc=%p\n",
			 (void *)urmp_lyrics_proc);
		return;
	}

	if (!urmp_lyrics_proc) {
		urmp_lyrics_proc = ur_proc_create(urmp_lyrics_worker,
						  NULL,
						  urmp_lyrics_cleanup,
						  NULL, NULL, NULL);
	}
	len = ur_id3_pack(e, buf, sizeof(buf));
	if (len <= 0)
		ur_fatal(__func__, "Error packing data\n");
	ur_msg_send(urmp_lyrics_proc, 0, buf, len);
}
