/* urmpguilyrics.c -- 
 * Created: Sun May 17 15:44:19 2009 by faith@acm.org
 * Revised: Sun May 17 15:47:02 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */


#include "urmpgui.h"

void urmp_gui_lyrics_build(urmp_gui_status_t *status _unused,
			   GtkWidget *notebook)
{
	GtkWidget              *scrolled;
	GtkWidget              *text;
	GtkWidget              *label;
	GtkTextBuffer          *buffer;
	char                   message[4096];

	snprintf(message, sizeof(message), "Lyrics");

	label    = gtk_label_new("Lyrics");
	scrolled = gtk_scrolled_window_new(NULL, NULL);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), scrolled, label);

	buffer = gtk_text_buffer_new(NULL);
	text = gtk_text_view_new_with_buffer(buffer);
	gtk_text_view_set_editable(GTK_TEXT_VIEW(text), FALSE);
	gtk_container_add(GTK_CONTAINER(scrolled), text);

	gtk_text_buffer_set_text(buffer, message, -1);
}
