/* dbsplit.c -- 
 * Created: Fri Dec 12 09:01:57 2008 by faith@acm.org
 * Revised: Fri Dec 12 16:54:30 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "config.h"
#include "ur.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

static int trigrams[26*26*26];

static __attribute__((noreturn)) void usage(void)
{
	printf("usage: dbsplit sb\n");
	exit(1);
}

static char *trans(char *d, const char *s, bool filename)
{
	char *start = d;
	bool oldskip = false;
	bool newskip = false;

	for (; *s; s++) {
		oldskip = newskip;
		newskip = false;

		switch (*s) {
		case '\r':
		case '\n':
			newskip = true;
			if (!oldskip) *d++ = '\n';
			break;
		case '&':
			if (!strncmp(s, "&quot;", 6)) {
				if (!filename) *d++ = '"';
				s += 5;
			} else if (!strncmp(s, "&amp;", 5)) {
				if (!filename) *d++ = '&';
				s += 4;
			} else if (!strncmp(s, "&gt;", 4)) {
				if (!filename) *d++ = '>';
				s += 3;
			} else if (!strncmp(s, "&lt;", 4)) {
				if (!filename) *d++ = '<';
				s += 3;
			} else if (!strncmp(s, "& ", 2)) {
				if (!filename) *d++ = '&';
				s += 1;
			} else if (!strncmp(s, "&nbsp;", 6)) {
				*d++ = ' ';
				s += 5;
			} else {
				printf("*** Unknown: %10.10s\n", s);
			}
			break;
		case '<':
			if (!strncmp(s, "<br />", 6)) {
				newskip = true;
				if (!oldskip) *d++ = '\n';
				s += 5;
			} else if (!strncmp(s, "<br>", 4)
				   || !strncmp(s, "<BR>", 4)) {
				newskip = true;
				if (!oldskip) *d++ = '\n';
				s += 3;
			} else if (!strncmp(s, "<i>", 3)
				   || !strncmp(s, "<I>", 3)) {
				s += 2;
			} else if (!strncmp(s, "</i>", 4)
				   || !strncmp(s, "</i>", 4)) {
				s += 3;
			} else {
				printf("*** Unknown: %10.10s\n", s);
			}
			break;
		case ' ':
		case '\t':
			if (filename) {
				if (d != start && d[-1] != '_') *d++ = '_';
			} else {
				if (d != start && d[-1] != ' ') *d++ = ' ';
			}
			break;
		default:
			if (filename) {
				if (isalnum(*s)) *d++ = tolower(*s);
			} else {
				*d++ = *s;
			}
			break;
		}
	}
	return d;
}

static void tri(const char *s)
{
	const char *pt;
	int        tg;

	for (pt = s; *pt; pt++) {
		if (isalpha(pt[0])
		    && pt[1]
		    && isalpha(pt[1])
		    && pt[2]
		    && isalpha(pt[2])) {
			tg = (tolower(pt[0]) - 'a') * 26 * 26
			     + (tolower(pt[1]) - 'a') * 26
			     + tolower(pt[2]) - 'a';
			++trigrams[tg];
		}
	}
}

int main(int argc, char **argv)
{
	FILE *str;
	char buf[64*1024];
	char out[64*1024];
	char filename[1024];
	int  count = 0, total = 0;
	int  i;

	ur_init(argv[0]);
	setlocale(LC_ALL, "C");

	if (argc != 2) usage();

	if (!(str = fopen(argv[1], "r"))) {
		ur_fatal_errno(__func__, "Cannot open %s\n", argv[1]);
	}

	while (fgets(buf, sizeof(buf)-1, str) && count < 100000) {
		ur_list_t  list;
		int        len = strlen(buf);
		const char *prefix;
		int        idx;
		const char *title;
		const char *artist;
		const char *album;
		const char *lyrics;
		char       *d, *pt;

		buf[--len] = '\0';
		if (strncmp(buf, "INSERT INTO lyrics VALUES", 25)) continue;
		list = ur_list_create();
		ur_list_parse(list, buf, ",", "'", "\\", true);

		prefix = ur_list_pop(list);
		pt = strchr(prefix, '(');
		idx = -1;
		if (pt) idx = strtol(pt+1, NULL, 10);
		
		title = ur_list_pop(list);
		artist = ur_list_pop(list);
		album = ur_list_pop(list);
		lyrics = ur_list_pop(list);
		printf("title:  %s\n", title);
		printf("artist: %s\n", artist);
		printf("album:  %s\n", album);
		ur_list_destroy(list);

		d = trans(&filename[3], artist, true);
		*d++ = '/';
		d = trans(d, title, true);
		*d++ = '\0';
		filename[0] = filename[3];
		filename[1] = filename[4];
		filename[2] = '/';

		printf("%5d filename=%s\n", idx, filename);

		d = trans(out, lyrics, false);
		*d++ = '\0';

//		printf("%s\n", out);
		tri(out);
		++count;
	}
	for (count = 0, i = 0; i < 26*26*26; i++) {
		if (trigrams[i]) {
			char name[4];
			name[0] = i/26/26;
			name[1] = (i - name[0]*26*26) / 26;
			name[2] = (i - name[0]*26*26 - name[1]*26);
			name[3] = '\0';
			name[0] += 'a';
			name[1] += 'a';
			name[2] += 'a';
			printf("%d %s %d\n", i, name, trigrams[i]);
			total += trigrams[i];
			++count;
		}
	}
	printf("%d different trigrams found, %d total\n", count, total);
}
