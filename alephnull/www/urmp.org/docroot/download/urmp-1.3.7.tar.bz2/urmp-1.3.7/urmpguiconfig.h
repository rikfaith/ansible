/* urmpguiconfig.h -- 
 * Created: Sun May 17 07:52:41 2009 by faith@acm.org
 * Revised: Sun May 17 15:40:52 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPGUICONFIG_H_
#define _URMPGUICONFIG_H_


#endif
