/* urmpdb.c -- 
 * Created: Sat Sep 27 17:08:14 2008 by faith@acm.org
 * Revised: Thu Jul  2 20:03:14 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpconfig.h"
#include "version.h"
#include <errno.h>
#include <dirent.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef struct {
	ur_timer_t     timer;
	ur_proc_t      *procs;
	ur_msg_t       *msgs;
	int            count;
	int            launched;
	bool           *inflight;
	int            total_launched;
	int            total_new;
	int            total_updated;
	int            total_skipped;
	time_t         last_message;
} urmp_flight_t;

static ur_id3_read_t urmp_ioflags;

static ur_id3_t urmp_db_read(const char *filename)
{
	ur_id3_t new;
	ur_id3_t old = NULL;

	if (urmp_db) old = ur_sl_lookup(urmp_db, filename);
	if (old) {
		ur_trace(URMP_TRACE_WORKER, __func__,
			 "Found match for %s\n", filename);
		return NULL;
	}

	new = ur_id3_read(filename, UR_ID3_READ_BEST|urmp_ioflags,
			  urmp_parse_augment);

	return new;
}

static int urmp_db_worker(ur_msg_t msg, int type, void *buf,
			  int length _unused, void *arg)
{
	int        retval;
	ur_id3_t   id3;
	char       reply[URMP_MAX_ID3_BUFLEN];
	int        len;
	const char *filename = (const char *)buf;

	if (type != URMP_MSG_GET_INFO) {
		ur_fatal(__func__, "Message type %d unexpected\n", type);
	}
	ur_trace(URMP_TRACE_WORKER, __func__,
		 "worker %ld: %s\n", (intptr_t)arg, (char *)buf);

	id3 = urmp_db_read(filename);
	if (!id3) {
		ur_trace(URMP_TRACE_WORKER, __func__,
			 "Returning URMP_MSG_REPLAY_SKIP for %s\n",
			 filename);
		ur_msg_reply(msg, URMP_MSG_REPLY_SKIP, NULL, 0);
		return 0;
	}

	len = ur_id3_pack(id3, reply, sizeof(reply));
	if (len <= 0)
		ur_fatal(__func__, "Error packing data\n");
	retval = ur_msg_reply(msg, URMP_MSG_REPLY_UPDATE, reply, len);
	ur_trace(URMP_TRACE_WORKER, __func__,
		 "reply sent, retval=%d, errno=%d\n", retval, errno);
	ur_id3_destroy(id3);
	return 0;
}

static int urmp_db_worker_cleanup(int pid, int status, int err _unused,
				  void *arg _unused)
{
	if (!ur_trace_test(URMP_TRACE_HANDLER)) return 0;
	printf("%d: got status=%d for pid %d, errno=%d\n",
	       getpid(), status, pid, errno);
	fflush(stdout);
	return 0;
}

static int urmp_db_compare(const void *key1, const void *key2)
{
	const char *a = (const char *)key1;
	const char *b = (const char *)key2;

	return strcmp(a, b);
}

static void urmp_db_print_rate(urmp_flight_t *flight, bool force)
{
	unsigned int count;
	time_t       now, elapsed;

	time(&now);

	if (!flight->last_message) elapsed = 2;
	else                       elapsed = now - flight->last_message;

	count = ur_sl_items(urmp_db);
	if (force || elapsed > 1) {
		ur_timeval_t tv;
		double       rate;

		ur_timer_stop(flight->timer);
		ur_timer_get_elapsed(flight->timer, &tv);

		rate = (double)count/((double)tv.wall.tv_sec
				      + (double)tv.wall.tv_usec/1000000.0);

		/* Cap rate for very short time periods. */
		if (rate > count && tv.wall.tv_sec < 1) rate = count;

		printf("count=%u t=%lu.%03lu rate=%.1f"
		       " files/second total=%u new=%u updated=%u skipped=%u\n",
		       count,
		       (unsigned long)tv.wall.tv_sec,
		       (unsigned long)tv.wall.tv_usec/1000,
		       rate,
		       flight->total_launched,
		       flight->total_new,
		       flight->total_updated,
		       flight->total_skipped);
		flight->last_message = now;
	}
}

int urmp_db_new_entry(ur_id3_t id3)
{
	const char *filename;
	ur_id3_t   old;
	int        retval = 0;

	if (!urmp_db) urmp_db = ur_sl_create(urmp_db_compare);

	if (!ur_id3_search(id3)) ur_id3_search_compute(id3);

	ur_id3_canonify(id3);
	filename = ur_id3_filename(id3);
	if (!filename || filename[0] == '\0') {
		ur_fatal(__func__, "Zero-length filename\n");
	}

	old = ur_sl_lookup(urmp_db, filename);
	if (old) {
		ur_id3_destroy(old);
		old = NULL;
		ur_sl_delete(urmp_db, filename);
		retval = 1;
	}
	ur_sl_insert(urmp_db, filename, id3);
	return retval;
}

static void urmp_db_new_entry_inflight(urmp_flight_t *flight, ur_id3_t id3)
{
	if (urmp_db_new_entry(id3)) ++flight->total_updated;
	else                        ++flight->total_new;
	urmp_db_print_rate(flight, false);
}

static int urmp_db_reap(urmp_flight_t *flight)
{
	int      i;
	ur_msg_t msg;
	char     buf[UR_MSG_MAX_SIZE];
	ur_id3_t id3;

	i = ur_msg_poll(flight->msgs, flight->count);
	ur_trace(URMP_TRACE_MSG, __func__, "ur_msg_poll=%d\n", i);
	msg = ur_msg_wait(flight->msgs[i], buf, sizeof(buf));
	ur_trace(URMP_TRACE_MSG, __func__, "ur_msg_wait=%p\n", (void *)msg);

	if (msg) {
		ur_trace(URMP_TRACE_MSG, __func__,
			 "reply_type=%d\n", ur_msg_reply_type(msg));
		switch (ur_msg_reply_type(msg)) {
		case URMP_MSG_REPLY_UPDATE:
			id3 = ur_id3_unpack(buf, ur_msg_length(msg));
			urmp_db_new_entry_inflight(flight, id3);
			break;
		case URMP_MSG_REPLY_SKIP:
			++flight->total_skipped;
			break;
		default:
			ur_fatal(__func__, "Got unexpected reply type: %d\n",
				 ur_msg_reply_type(msg));
		}
		ur_msg_destroy(msg);
		--flight->launched;
	}
	flight->msgs[i] = NULL;
	return i;
}

static void urmp_db_drain(urmp_flight_t *flight)
{
	while (flight->launched) {
		urmp_db_reap(flight);
	}

	urmp_db_print_rate(flight, true);
}

static void urmp_db_launch(urmp_flight_t *flight, const char *filename)
{
	int i;

	++flight->total_launched;

	if (!flight->count) {
		ur_id3_t id3 = urmp_db_read(filename);
		if (!id3) {
			++flight->total_skipped;
		} else {
			urmp_db_new_entry_inflight(flight, id3);
		}
		return;
	}

	if (flight->launched > flight->count) {
		ur_fatal(__func__, "launched=%d > count=%d\n",
			 flight->launched, flight->count);
	}

	if (flight->launched == flight->count) {
		i = urmp_db_reap(flight);
		if (flight->launched == flight->count) {
			ur_fatal(__func__, "launched=%d count=%d after reap\n",
				 flight->launched, flight->count);
		}
		goto launch;
	}

	for (i = 0; i < flight->count; i++) {
		if (!flight->inflight[i]) goto launch;
	}

	ur_fatal(__func__, "launched=%d <= count=%d, i=%d, but all inflight\n",
		 flight->launched, flight->count, i);

launch:
	ur_trace(URMP_TRACE_MSG, __func__, "%d %s\n", i, filename);
	flight->inflight[i] = true;
	++flight->launched;
	flight->msgs[i] = ur_msg_send(flight->procs[i], URMP_MSG_GET_INFO,
				      (void *)filename, strlen(filename)+1);
	if (!flight->msgs[i]) {
		ur_fatal(__func__, "ur_msg_send returned NULL\n");
	}
}

static void urmp_db_file(urmp_flight_t *flight, const char *filename)
{
	const char *pt;
	
	pt = strrchr(filename, '.');
	if (pt && !strcmp(pt, ".mp3")) {
		urmp_db_launch(flight, filename);
	} else {
		ur_trace(URMP_TRACE_ID3ERR, __func__,
			 "not an mp3: %s\n", filename);
	}
}

static void urmp_db_update(ur_list_t list)
{
	int            i;
	ur_proc_t      procs[urmp_proc_count];
	DIR            *dir;
	char           *path;
	struct dirent  *dirent;
	char           filename[urmp_max_pathlen];
	urmp_flight_t  flight;
	unsigned char  type;

	for (i = 0; i < urmp_proc_count; i++) {
		procs[i] = ur_proc_create(urmp_db_worker, (void *)(intptr_t)i,
					  urmp_db_worker_cleanup, NULL,
					  NULL, NULL);
		ur_trace(URMP_TRACE_PROC, __func__,
			 "Pid %d created\n", ur_proc_pid(procs[i]));
	}

	memset(&flight, 0, sizeof(flight));
	flight.timer    = ur_timer_create(UR_TIMER_ALL);
	flight.procs    = procs;
	flight.count    = urmp_proc_count;
	if (flight.count) {
		flight.inflight = ur_allocz(sizeof(flight.inflight[0])
					    * flight.count);
		flight.msgs     = ur_allocz(sizeof(flight.msgs[0])
					    * flight.count);
	}

	while ((path = ur_list_pop(list))) {
		ur_trace(URMP_TRACE_STACK, __func__, "opening %s\n", path);

		if (!(dir = opendir(path))) {
			urmp_db_file(&flight, path);
			continue;
		}

		while ((dirent = readdir(dir))) {
			snprintf(filename, urmp_max_pathlen-1, "%s/%s",
				 path, dirent->d_name);

			if (dirent->d_type == DT_UNKNOWN
			    || dirent->d_type == DT_LNK) {
				struct stat st;

				if (stat(filename, &st)) {
					ur_warning(__func__,
						   "Cannot stat %s\n",
						   filename);
					continue;
				}
				type = DT_UNKNOWN;
				if (S_ISREG(st.st_mode)) type = DT_REG;
				if (S_ISDIR(st.st_mode)) type = DT_DIR;
			} else {
				type = dirent->d_type;
			}

			switch (type) {
			case DT_DIR:
				if (!strcmp(dirent->d_name, ".")
				    || !strcmp(dirent->d_name, "..")) {
					break;
				}
				ur_trace(URMP_TRACE_STACK, __func__,
					 "pushing %s\n", filename);
				ur_list_push(list, ur_strdup(filename));
				break;
			case DT_REG:
				urmp_db_file(&flight, filename);
				break;
			default:
				ur_trace(URMP_TRACE_ID3ERR, __func__,
					 "ignoring: %s\n", filename);
				break;
			}
		}

		closedir(dir);
		ur_free(path);
	}
	ur_trace(URMP_TRACE_PROC, __func__,
		 "%d items still in list\n", ur_list_depth(list));
	urmp_db_drain(&flight);
	ur_timer_stop(flight.timer);
	ur_timer_destroy(flight.timer);
	flight.timer = NULL;
	ur_proc_destroy_all();
	if (flight.count) {
		ur_free(flight.inflight);
		ur_free(flight.msgs);
	}
}

void urmp_db_build(ur_list_t pathlist, ur_id3_read_t flags)
{
	int          i;
	struct stat  st;
	const char   *pathname;
	ur_list_t    list;

	urmp_ioflags = flags;
	list = ur_list_create();
	for (i = 1; i <= ur_list_depth(pathlist); i++) {
		pathname = ur_list_nth(pathlist, i);
		ur_trace(URMP_TRACE_BUILD, __func__,
			 "checking pathname=%s\n", pathname);
		if (stat(pathname, &st)
		    || (!S_ISDIR(st.st_mode) && !S_ISREG(st.st_mode))) {
			ur_fatal(__func__,
				 "Build path must be a directory"
				 " or a regular file: %s\n",
				 pathname);
		}
		ur_list_push(list, ur_strdup(pathname));
	}
	urmp_db_update(list);
	ur_list_destroy(list);
}
