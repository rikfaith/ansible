#define UR_DATE "20090701"
#define UR_MAJOR 1
#define UR_MINOR 3
#define UR_PATCH 6
