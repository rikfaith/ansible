/* proc.c -- 
 * Created: Sun Aug  3 10:58:28 2008 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#include "urP.h"
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <sys/socket.h>

static unsigned long _ur_msg_sequence;
static unsigned long _ur_proc_created;
static unsigned long _ur_proc_reaped;
static unsigned long _ur_proc_destroyed;

struct ur_proc_s {
	unsigned long     magic;
	pid_t             pid;
	ur_proc_cleanup_t *cleanup;
	void              *cleanup_arg;
	ur_proc_abort_t   *terminate;
	void              *terminate_arg;
	int               fd;
	bool		  killed;
	bool              dead;
};

struct ur_msg_s {
	unsigned long  magic;
        void           *buffer;
	int            fd;
	struct {		/* Isolate wire packet from in-core packet */
		unsigned long  sender_pid;
		int            type;
		struct timeval time_sent;
		struct timeval time_received;
		struct timeval time_replied;
		unsigned long  sequence;
		unsigned long  length;
	} w;
};

struct ur_msg_recv_s {
	unsigned long magic;
	int           fd;
	int           first;
	int           last;
	int           limit;
	int           avail;
	char          buffer[1024];
};

static ur_hash_t ur_proc_hash;

CHECK_FUNCTION(_ur_proc_check, ur_proc_t, UR_PROC_MAGIC)
CHECK_FUNCTION(_ur_msg_check, ur_msg_t, UR_MSG_MAGIC)
CHECK_FUNCTION(_ur_msg_recv_check, ur_msg_recv_t, UR_MSG_RECV_MAGIC)

static void ur_proc_handler(int sig, siginfo_t *info, void *context __unused)
{
	pid_t     pid;
	ur_proc_t proc;
	int       status;

	if (sig != SIGCHLD) {
		ur_fatal(__func__,
			 "Caught sig(%d)=%s instead of SIGCHLD\n",
			 sig, ur_signal_name(sig));
	}

	while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
		ur_trace(UR_TRACE_PROC, __func__,
			 "Have SIGCHLD for pid=%d\n", pid);
		proc = ur_hash_lookup(ur_proc_hash, (void *)(intptr_t)pid);
		ur_trace(UR_TRACE_PROC, __func__,
			 "Have SIGCHLD for pid=%d proc=%p\n",
			 pid, (void *)proc);
		if (!proc) {
			ur_fatal(__func__,
				 "pid %d doesn't exist\n", pid);
		}
		if (proc->cleanup) {
			proc->cleanup(pid, info->si_status, info->si_errno,
				      proc->cleanup_arg);
		}
		proc->dead = true;
		proc = NULL;
		++_ur_proc_reaped;

		if (ur_trace_test(UR_TRACE_CHILD_WAIT)) {
			if (WIFEXITED(status)) {
				printf("exited, status = %d\n",
				       WEXITSTATUS(status));
			} else if (WIFSIGNALED(status)) {
				printf("killed, signal = %d\n",
				       WTERMSIG(status));
			} else if (WIFSTOPPED(status)) {
				printf("stopped, signal = %d\n",
				       WSTOPSIG(status));
			} else if (WIFCONTINUED(status)) {
				printf("continued\n");
			}
		}
	}
}

static void ur_proc_install_handler(void)
{
	struct sigaction a;

	memset(&a, 0, sizeof(a));
	a.sa_sigaction = ur_proc_handler;
	a.sa_flags     = SA_SIGINFO;
	sigemptyset(&a.sa_mask);
	sigaddset(&a.sa_mask, SIGCHLD);
	sigaction(SIGCHLD, &a, 0);
}

ur_msg_recv_t ur_msg_recv_create(int fd)
{
	ur_msg_recv_t state;

	state        = ur_allocz(sizeof(*state));
	state->magic = UR_MSG_RECV_MAGIC;
	state->fd    = fd;
	state->first = 0;
	state->last  = 0;
	state->limit = sizeof(state->buffer);
	return state;
}

void ur_msg_recv_destroy(ur_msg_recv_t state)
{
	_ur_msg_recv_check(state);
	state->magic = ~state->magic;
	ur_free(state);
}

static __attribute__((noreturn)) void ur_proc_mainloop(int fd,
						       ur_proc_work_t worker,
						       void *arg)
{
	ur_msg_t      msg;
	char          buf[UR_MSG_MAX_SIZE];
	bool          started = false;
	int           retval;
	ur_msg_recv_t state;

	state = ur_msg_recv_create(fd);

	for (;;) {
		msg = ur_msg_recv(state, buf, sizeof(buf), 0);
		ur_trace(UR_TRACE_PROC, __func__,
			 "msg=%p fd=%d,%d type=%d length=%lu\n",
			 (void *)msg, state->fd, msg ? msg->fd : -1,
			 msg ? msg->w.type : 0,
			 msg ? msg->w.length : 0);
		if (!msg) {
			exit(0);
		}
		switch (msg->w.type) {
		case UR_MSG_REPLY:
			ur_fatal(__func__,
				 "Received reply instead of message\n");
		case UR_MSG_PING:
			ur_msg_reply(msg, buf, msg->w.length, 0);
			break;
		case UR_MSG_START:
			started = true;
			break;
		default:
			if (!started) {
				ur_fatal(__func__,
					 "Received type %d before start\n",
					 msg->w.type);
			}
			retval = worker(msg, msg->w.type, &buf, msg->w.length,
					arg);
			if (retval) {
				exit(retval);
			}
			break;
		}
	}
}

ur_proc_t ur_proc_create(ur_proc_work_t work, void *work_arg,
			 ur_proc_cleanup_t cleanup, void *cleanup_arg,
			 ur_proc_abort_t terminate, void *terminate_arg)
{
	ur_proc_t proc;
	pid_t     pid;
	int       sockets[2];
	ur_msg_t  msg;

	if (socketpair(AF_UNIX, SOCK_STREAM, AF_LOCAL, sockets) < 0) {
		ur_fatal_errno(__func__, "Cannot create socketpair\n");
	}

	pid = fork();

	if (!pid) {
				/* Child */
		close(sockets[1]);
		if (ur_proc_hash) {
			ur_hash_destroy(ur_proc_hash);
			ur_proc_hash = NULL;
		}
		ur_proc_mainloop(sockets[0], work, work_arg);
	}

				/* Parent */

	ur_trace(UR_TRACE_PROC, __func__, "parent=%d child=%d\n",
		 getpid(), pid);
	if (pid < 0) {
		ur_fatal_errno(__func__, "Cannot fork\n");
	}

	close(sockets[0]);

	if (!ur_proc_hash) {
		ur_proc_hash = ur_hash_create_ulkey();
		ur_proc_install_handler();
	}

	proc = ur_hash_lookup(ur_proc_hash, (void *)(intptr_t)pid);
	if (proc) {
		if (!proc->dead) {
			ur_fatal(__func__,
				 "New pid=%d already exists in undead state\n",
				 pid);
		}
		ur_hash_delete(ur_proc_hash, (void *)(intptr_t)pid);
		ur_free(proc);
	}

	proc = ur_allocz(sizeof(*proc));
	proc->magic         = UR_PROC_MAGIC;
	proc->pid           = pid;
	proc->cleanup       = cleanup;
	proc->cleanup_arg   = cleanup_arg;
	proc->terminate     = terminate;
	proc->terminate_arg = terminate_arg;
	proc->fd            = sockets[1];
	
	ur_hash_insert(ur_proc_hash, (void *)(intptr_t)pid, proc);
	msg = ur_msg_send(proc, UR_MSG_START, NULL, 0, 0);
	ur_msg_destroy(msg);

	++_ur_proc_created;
	return proc;
}

static void _ur_proc_destroy(ur_proc_t proc)
{
	_ur_proc_check(proc);

	if (!proc->dead) {
		ur_fatal(__func__,
			 "Process at pid %d not dead yet\n", proc->pid);
	}

	proc->magic = ~proc->magic;
	ur_hash_delete(ur_proc_hash, (void *)(intptr_t)proc->pid);
	ur_free(proc);
}

void ur_proc_destroy(ur_proc_t proc)
{
	_ur_proc_check(proc);

	if (!ur_proc_hash) {
		return;
	}

	if (proc->killed) {
		ur_warning(__func__, "Killing killed pid=%d\n", proc->pid);
		if (proc->fd > 0) {
			shutdown(proc->fd, SHUT_RDWR);
			proc->fd = -1;
		}
		kill(proc->pid, SIGKILL);
	} else {
		if (proc->terminate) {
			proc->terminate(proc->pid, proc->terminate_arg);
		} else {
			if (proc->fd > 0) {
				shutdown(proc->fd, SHUT_RDWR);
				proc->fd = -1;
			}
			kill(proc->pid, SIGTERM);
		}
	}
	proc->killed = true;
}

void ur_proc_destroy_all(void)
{
	ur_iterator_t iter;
	void          *key;
	ur_proc_t     proc;
	ur_list_t     list;
	int           loops = 0;

	if (!ur_proc_hash) {
		return;
	}

	list = ur_list_create();
	ur_hash_iterator_lock(ur_proc_hash);
	UR_HASH_ITERATE(ur_proc_hash, iter, key, proc) {
		ur_list_push(list, key);
	}
	ur_hash_iterator_unlock(ur_proc_hash);

	UR_LIST_ITERATE(list, iter, key) {
		proc = ur_hash_lookup(ur_proc_hash, key);
		if (proc) ur_proc_destroy(proc);
	}

	while (_ur_proc_reaped != _ur_proc_created) {
		unsigned int remaining;

		if (++loops > 5) {
			ur_warning(__func__, "Processes not terminating:"
				   " loops=%d created=%lu"
				   " reaped=%lu destroyed=%lu\n",
				   loops,
				   _ur_proc_created,
				   _ur_proc_reaped,
				   _ur_proc_destroyed);
			UR_LIST_ITERATE(list, iter, key) {
				proc = ur_hash_lookup(ur_proc_hash, key);
				if (proc) ur_proc_destroy(proc);
			}
		}

		/* This sleep may be interrupted by SIGCHLD signals. */
		while ((remaining = sleep(1)))
			;
	}

	UR_LIST_ITERATE(list, iter, key) {
		proc = ur_hash_lookup(ur_proc_hash, key);
		if (proc) _ur_proc_destroy(proc);
	}

	if (ur_hash_items(ur_proc_hash)) {
		ur_fatal(__func__,
			 "created=%lu reaped=%lu destroyed=%lu items=%lu\n",
			 _ur_proc_created,
			 _ur_proc_reaped,
			 _ur_proc_destroyed,
			 ur_hash_items(ur_proc_hash));
	}

	ur_hash_destroy(ur_proc_hash);
	ur_proc_hash = NULL;
	ur_list_destroy(list);
}

pid_t ur_proc_pid(ur_proc_t proc)
{
	_ur_proc_check(proc);
	return proc->pid;
}


ur_msg_t ur_msg_create(void)
{
	ur_msg_t msg;

	msg = ur_allocz(sizeof(*msg));
	msg->magic = UR_MSG_MAGIC;
	return msg;
}

unsigned long ur_msg_destroy(ur_msg_t msg)
{
	unsigned long ret;

	ret = msg->magic = ~UR_MSG_MAGIC;
	ur_free(msg);
	return ret;
}

static int _ur_msg_send(ur_msg_t msg, int flags __unused)
{
	int           retval;
	int           save;
	struct iovec  iov[2];

	_ur_msg_check(msg);

	iov[0].iov_base = &msg->w;
	iov[0].iov_len  = sizeof(msg->w);
	iov[1].iov_base = (void *)msg->buffer;
	iov[1].iov_len  = msg->w.length;

	errno = 0;
	retval = writev(msg->fd, iov, 2);
	save = errno;

	ur_trace(UR_TRACE_MSG, __func__,
		 "fd=%d sequence=%lu type=%d length=%lu retval=%d errno=%d\n",
		 msg->fd, msg->w.sequence, msg->w.type,
		 msg->w.length, retval, save);

	return retval;
}

ur_msg_t ur_msg_send(ur_proc_t proc, int type, void *buf, size_t len,
		     int flags)
{
	ur_msg_t msg;
	int      retval;

	_ur_proc_check(proc);

	msg = ur_msg_create();
	msg->w.sender_pid = proc->pid;
	msg->w.type       = type;
	gettimeofday(&msg->w.time_sent, NULL);
	msg->w.sequence   = ++_ur_msg_sequence;
	msg->w.length     = len;

	msg->buffer     = buf;
	msg->fd         = proc->fd;

	retval = _ur_msg_send(msg, flags);

	if (retval < 0) {
		ur_msg_destroy(msg);
		return NULL;
	}

	return msg;
}

int ur_msg_reply(ur_msg_t msg, void *buf, size_t len, int flags)
{
	int      retval;

	_ur_msg_check(msg);

	msg->buffer   = buf;
	msg->w.length = len;
	msg->w.type   = UR_MSG_REPLY;
	gettimeofday(&msg->w.time_replied, NULL);

	retval = _ur_msg_send(msg, flags);
	ur_msg_destroy(msg);
	return retval;
}

static void _ur_msg_recv_copy(void *buf, int length, ur_msg_recv_t state,
			      bool copy, bool update)
{
	int len1, len2;

	if (!length) return;
	if (state->avail < length) {
		ur_internal(__func__,
			    "avail=%d length=%d\n", state->avail, length);
	}
	if (state->first == state->last) {
		ur_internal(__func__,
			    "first=%d last=%d length=%d\n",
			    state->first, state->last, length);
	}

	if (state->first < state->last
	    || length < state->limit - state->first) {
		ur_trace(UR_TRACE_MSG, __func__,
			 "copy=%d update=%d avail=%d"
			 " first=%d last=%d length=%d\n",
			 copy, update, state->avail,
			 state->first, state->last, length);
		if (copy) {
			memcpy(buf, &state->buffer[state->first], length);
		}
		if (update) {
			state->avail -= length;
			state->first += length;
		}
		return;
	}

	len1 = state->limit - state->first;
	len2 = length - len1;

	if (len2 < 0 || len2 > state->last || len1 <= 0) {
		ur_internal(__func__,
			    "first=%d last=%d limit=%d"
			    " len1=%d len2=%d length=%d\n",
			    state->first, state->last, state->limit,
			    len1, len2, length);
	}

	ur_trace(UR_TRACE_MSG, __func__,
		 "copy=%d update=%d avail=%d first=%d length=%d len=%d,%d\n",
		 copy, update, state->avail, state->first, length, len1, len2);
	if (copy) {
		memcpy(buf, &state->buffer[state->first], len1);
		if (len2) memcpy((char *)buf+len1, &state->buffer[0], len2);
	}
	if (update) {
		state->avail -= length;
		state->first = len2;
	}
}

static bool ur_msg_recv_copy(ur_msg_recv_t state, ur_msg_t msg)
{
	if (!state->avail || state->avail < sizeof(msg->w)) {
		ur_trace(UR_TRACE_MSG, __func__,
			 "returning false: avail=%d sizeof=%lu\n",
			 state->avail, sizeof(msg->w));
		return false;
	}

	_ur_msg_recv_copy(&msg->w, sizeof(msg->w), state, true, false);

	if (state->avail < msg->w.length + sizeof(msg->w)) {
		ur_trace(UR_TRACE_MSG, __func__,
			 "returning false: avail=%d length=%lu sizeof=%lu\n",
			 state->avail, msg->w.length, sizeof(msg->w));
		return false;
	}

	_ur_msg_recv_copy(&msg->w, sizeof(msg->w), state, false, true);
	_ur_msg_recv_copy(msg->buffer, msg->w.length, state, true, true);
	ur_trace(UR_TRACE_MSG, __func__,
		 "returning true: length=%lu\n", msg->w.length);
	return true;
}

static ur_msg_t _ur_msg_recv(ur_msg_recv_t state, ur_msg_t msg)
{
	int           retval;
	int           save;
	struct iovec  iov[2];
	int           count;

	_ur_msg_check(msg);

start:
	if (ur_msg_recv_copy(state, msg)) return msg;

	if (state->first == state->last) {
		iov[0].iov_base = &state->buffer[state->last];
		iov[0].iov_len  = state->limit - state->last;
		count           = 1;
	} else {
		if (state->first < state->last) {
			iov[0].iov_base = &state->buffer[state->last];
			iov[0].iov_len  = state->limit - state->last;
			count           = 1;
			if (state->first) {
				iov[1].iov_base = &state->buffer[0];
				iov[1].iov_len  = state->first;
				count           = 2;
			}
		} else {
			iov[0].iov_base = &state->buffer[state->last];
			iov[0].iov_len  = state->first - state->last;
			count           = 1;
		}
	}

	ur_trace(UR_TRACE_MSG, __func__,
		 "fd=%d,%d first=%d last=%d limit=%d avail=%d buffer=%p\n",
		 state->fd, msg->fd,
		 state->first, state->last, state->limit, state->avail,
		 state->buffer);
	ur_trace(UR_TRACE_MSG, __func__,
		 "iov[0].iov_base=%p iov[0].iov_len=%lu\n",
		 iov[0].iov_base, (unsigned long)iov[0].iov_len);
	if (state->last >= state->limit
	    || state->last < 0
	    || ((char *)iov[0].iov_base + iov[0].iov_len - 1
		> &state->buffer[state->limit-1])) {
		ur_internal(__func__,
			    "iov[0] overflow: last=%d limit=%d"
			    " base=%p len=%lu -> %p,"
			    " buffer=%p-%p\n",
			    state->last, state->limit,
			    iov[0].iov_base,
			    (unsigned long)iov[0].iov_len,
			    (char *)iov[0].iov_base + iov[0].iov_len - 1,
			    &state->buffer[0],
			    &state->buffer[state->limit-1]);
	}
	if (count == 2) {
		ur_trace(UR_TRACE_MSG, __func__,
			 "iov[1].iov_base=%p iov[1].iov_len=%lu\n",
			 iov[1].iov_base, (unsigned long)iov[1].iov_len);
		if ((char *)iov[1].iov_base + iov[1].iov_len - 1
		    > &state->buffer[state->limit-1]) {
			ur_internal(__func__,
				    "iov[1] overflow: base=%p len=%lu -> %p,"
				    " buffer=%p-%p\n",
				    iov[1].iov_base,
				    (unsigned long)iov[1].iov_len,
				    (char *)iov[1].iov_base + iov[1].iov_len-1,
				    &state->buffer[1],
				    &state->buffer[state->limit-1]);
		}
	}

	do {
		errno = 0;
		retval = readv(state->fd, iov, count);
		save = errno;
		ur_trace(UR_TRACE_MSG, __func__,
			 "fd=%d,%d retval=%d errno=%d\n",
			 state->fd, msg->fd, retval, save);
		if (retval > 0) {
			state->avail += retval;
			if (state->last + retval > state->limit) {
				state->last = retval - (state->limit
							- state->last);
			} else {
				state->last  += retval;
			}
			if (state->last > state->limit) {
				ur_internal(__func__, "last=%d limit=%d\n",
					    state->last, state->limit);
			}
			if (state->last == state->limit) state->last=0;
		}
	} while (retval == -1 && save == EINTR);

	if (retval <= 0) {	/* 0 means socket shutdown */
		ur_msg_destroy(msg);
		return NULL;
	}

	goto start;
}

ur_msg_t ur_msg_recv(ur_msg_recv_t state, void *buf, size_t len,
		     int flags __unused)
{
	ur_msg_t msg;

	msg = ur_msg_create();

	msg->w.length = len;
	msg->buffer   = buf;
	msg->fd       = state->fd;

	msg = _ur_msg_recv(state, msg);

	if (msg) {
		gettimeofday(&msg->w.time_received, NULL);
	}
	return msg;
}

ur_msg_t ur_msg_wait(ur_msg_t msg, void *buf, size_t len, int flags __unused)
{
	int need;
	int have;
	int save;
	int retval;

	_ur_msg_check(msg);
	msg->buffer   = buf;
	msg->w.length = len;

	need = sizeof(msg->w);
	have = 0;
	do {
		errno = 0;
		retval = read(msg->fd, (char *)&msg->w + have, need);
		if (!retval) goto eof;
		save = errno;
		if (retval > 0) {
			need -= retval;
			have += retval;
		}
	} while (need > 0);

	if (msg->w.length > len) {
		ur_internal(__func__,
			    "w.length=%lu > len=%lu: errno=%d\n",
			    msg->w.length, (unsigned long)len, save);
	}

	need = msg->w.length;
	have = 0;
	do {
		errno = 0;
		retval = read(msg->fd, (char *)buf + have, need);
		if (!retval) goto eof;
		save = errno;
		if (retval > 0) {
			need -= retval;
			have += retval;
		}
	} while (need > 0);
	msg->buffer = buf;
	return msg;
eof:
	ur_msg_destroy(msg);
	return NULL;
}

int ur_msg_poll(ur_msg_t *msgs, int count)
{
	fd_set rfds;
	int    nfds;
	int    i;
	int    retval;

	FD_ZERO(&rfds);

	for (nfds = 0, i = 0; i < count; i++) {
		if (msgs[i]) {
			FD_SET(msgs[i]->fd, &rfds);
			if (msgs[i]->fd > nfds) {
				nfds = msgs[i]->fd;
			}
		}
	}

	retval = select(nfds+1, &rfds, NULL, NULL, NULL);

	if (retval < 0) {
		ur_fatal_errno(__func__, "select failed\n");
	}

	for (i = 0; i < count; i++) {
		if (msgs[i] && FD_ISSET(msgs[i]->fd, &rfds)) {
			return i;
		}
	}
	ur_fatal(__func__, "select returned, but not data\n");
}

unsigned long ur_msg_length(ur_msg_t msg)
{
	_ur_msg_check(msg);
	return msg->w.length;
}

unsigned long ur_msg_sequence(ur_msg_t msg)
{
	_ur_msg_check(msg);
	return msg->w.sequence;
}

uint64_t ur_msg_time_sent(ur_msg_t msg)
{
	_ur_msg_check(msg);
	return msg->w.time_sent.tv_sec * 1000
		+ msg->w.time_sent.tv_usec / 1000;
}

uint64_t ur_msg_time_received(ur_msg_t msg)
{
	_ur_msg_check(msg);
	return msg->w.time_received.tv_sec * 1000
		+ msg->w.time_received.tv_usec / 1000;
}

uint64_t ur_msg_time_replied(ur_msg_t msg)
{
	_ur_msg_check(msg);
	return msg->w.time_replied.tv_sec * 1000
		+ msg->w.time_replied.tv_usec / 1000;
}
