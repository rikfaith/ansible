/* urmpgui.h -- 
 * Created: Sat Sep 27 23:26:59 2008 by faith@acm.org
 * Revised: Sun May 17 15:46:04 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPGUI_H_
#define _URMPGUI_H_

#include "urmp.h"
#include "urmpplayer.h"
#include <gtk/gtk.h>

extern const char *urmp_column_name[];

typedef enum {	/* Make sure this matches urmp_column_name in urmpgui.c */
	URMP_TRACK,
	URMP_TITLE,
	URMP_ARTIST,
	URMP_ALBUM,
	URMP_DURATION,
	URMP_RATE,
	URMP_COLUMNS
} urmp_column_t;

typedef enum {
	URMP_LEFT_PANE,
	URMP_RIGHT_PANE,
	URMP_PANES
} urmp_pane_t;

typedef struct {
//	GtkWidget              *vbox;
//	GtkWidget              *hbox;
	GtkWidget              *title;
	GtkWidget              *artist;
	GtkWidget              *album;
	GtkWidget              *elapsed;
	GtkWidget              *volume;
	GtkWidget              *progress;
	GtkWidget	       *combo;
	GtkWidget              *loop_button;
	GtkListStore           *list_store;
	ur_id3_t               id3;
	ur_id3_t               prev_id3;
	ur_id3_t               next_id3;
	const char             *prev_title;
	const char             *prev_artist;
	const char             *prev_album;
	urmp_player_status_t   current;
	urmp_player_status_t   previous;

	bool                   volume_pending;
	int                    volume_pending_value;
	bool                   progress_pending;
	int                    progress_pending_value;

	bool                   stopped;
	bool                   play_random;
	bool                   play_repeat;
	int                    idx_playing;
	struct urmp_gui_list_s *playlist;
	uint64_t               generation;

	GtkWidget              *config;
} urmp_gui_status_t;

typedef struct urmp_gui_list_s {
	GtkWidget              *toplevel;
	GtkWidget              *popup;
	ur_id3_t               popup_entry;
	int                    popup_index;
	ur_id3_t               loop_entry;
	int                    loop_index;
	
	GtkWidget              *vbox;
	GtkWidget              *hbox;
	GtkWidget              *scrolled;
	GtkWidget              *display;
	GtkTreeViewColumn      *column[URMP_COLUMNS];
	GtkCellRenderer        *renderer;
	GtkWidget              *search;
	GtkWidget              *name;
	GtkWidget              *label;
	GtkObject              *vadjustment;

	bool                   initialized;
	bool                   randomized_computed;
	int                    count_max, count_orig, count_filtered;
	ur_id3_t               *orig;
	ur_id3_t               *filtered;
	ur_id3_t               *randomized;
	struct urmp_gui_list_s *playlist;
	struct urmp_model_s    *model;
	urmp_gui_status_t      *status;
} urmp_gui_list_t;

extern void urmp_quit(GtkObject *object, gpointer user_data);
extern void urmp_searchc(GtkEditable *editable, gpointer user_data);

extern void urmp_search_cb(GtkEditable *editable, gpointer user_data);
extern void urmp_scroll_cb(GtkRange *range, gpointer user_data);

extern void urmp_gui_config_build(urmp_gui_status_t *status,
				  GtkWidget *notebook);
extern void urmp_gui_lyrics_build(urmp_gui_status_t *status,
				  GtkWidget *notebook);
extern void urmp_gui_about_build(GtkWidget *notebook);

#endif
