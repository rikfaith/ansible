/* urmpio.c -- 
 * Created: Sat Nov 15 05:42:41 2008 by faith@acm.org
 * Revised: Sat Apr 11 20:25:53 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpconfig.h"
#include <ctype.h>
#include <time.h>

void urmp_read_db(void)
{
	FILE     *str;
	char     buf[1024];
	char     buf2[1024];
	ur_id3_t e = NULL;
	
	if (!(str = fopen(urmp_config_db_path, "r"))) {
		return;
	}

	while (fgets(buf, sizeof(buf)-1, str)) {
		char       tag    = buf[0];
		const char *datum;
		int        len;

		if (buf[0] == '\0' || buf[1] == '\0') continue;

		if (buf[1] != ' ') {
			ur_fatal(__func__, "Must have space after tag: %s\n",
				 buf);
		}

		buf[sizeof(buf)-1] = '\0';
		len = strlen(buf);
		while (len >= 1 && isspace(buf[len-1])) {
			buf[len-1] = '\0';
			--len;
		}

		if (1 || tag == 'F') {
			datum = ur_atom_string(&buf[2]);
		} else {
			ur_id3_utf8ify(buf2, &buf[2], strlen(&buf[2]));
			datum = ur_atom_string(buf2);
		}
		switch (tag) {
		case '#':
			break;
		case 'F':
			if (e) urmp_process_new_entry(e);
			e = ur_id3_create();
			ur_id3_set_filename(e, datum);
			break;
		case 'I': ur_id3_set_valid(e, !!atoi(datum)); break;
		case 'S':
			ur_id3_set_source(e, ur_id3_source_decode(datum));
			break;
		case 'A': ur_id3_set_artist(e, datum); break;
		case 'a': ur_id3_set_album(e, datum); break;
		case 'T': ur_id3_set_title(e, datum); break;
		case 'Y': ur_id3_set_year(e, datum); break;
		case 't': ur_id3_set_track(e, atoi(datum)); break;
		case 'V':
			ur_id3_set_mpeg_version(
				e,
				ur_id3_mpeg_version_decode(datum));
			break;
		case 'L':
			ur_id3_set_mpeg_layer(
				e,
				ur_id3_mpeg_layer_decode(datum));
			break;
		case 'M':
			ur_id3_set_mpeg_mode(
				e,
				ur_id3_mpeg_mode_decode(datum));
			break;
		case 'B': ur_id3_set_mpeg_sample_rate(e, atoi(datum)); break;
		case 'c': ur_id3_set_mpeg_cbr(e, atoi(datum)); break;
		case 'v': ur_id3_set_mpeg_vbr(e, atoi(datum)); break;
		case 'D': ur_id3_set_mpeg_duration(e, atoi(datum)); break;
		case 's': ur_id3_set_search(e, datum); break;
		default:
			ur_fatal(__func__, "Unknown tag: %s\n", buf);
		}
	}
	if (e) urmp_process_new_entry(e);
	
	fclose(str);
}

static void urmp_writes(FILE *str, const char *format, const char *string)

{
	if (string && *string != '\0') fprintf(str, "%s %s\n", format, string);
}

static void urmp_writei(FILE *str, const char *format, int d)
{
	if (d) fprintf(str, "%s %d\n", format, d);
}

void urmp_write_db(void)
{
	ur_iterator_t iter;
	const char    *key;
	ur_id3_t      *datum;
	FILE          *str;
	time_t        t;

	rename(urmp_config_db_path, urmp_config_backup_db_path);

	if (!(str = fopen(urmp_config_db_path, "w"))) {
		ur_fatal_errno(__func__, "Cannot open %s for write\n",
			       urmp_config_db_path);
	}

	time(&t);
	fprintf(str, "# version 1\n");
	fprintf(str, "# entries %u\n", ur_sl_items(urmp_db));
	fprintf(str, "# written %25.25s\n", ctime(&t));

	UR_SL_ITERATE(urmp_db, iter, key, datum) {
		ur_id3_t e = (ur_id3_t)datum;
		
		fprintf(str, "\nF %s\n", ur_id3_filename(e));
		fprintf(str, "I %d\n", ur_id3_valid(e) ? 1 : 0);
		if (ur_id3_valid(e)) {
			urmp_writes(str, "S", ur_id3_source(e));
			urmp_writes(str, "A", ur_id3_artist(e));
			urmp_writes(str, "a", ur_id3_album(e));
			urmp_writes(str, "T", ur_id3_title(e));
			urmp_writes(str, "Y", ur_id3_year(e));
			urmp_writei(str, "t", ur_id3_track(e));
			urmp_writes(str, "V", ur_id3_mpeg_version(e));
			urmp_writes(str, "L", ur_id3_mpeg_layer(e));
			urmp_writes(str, "M", ur_id3_mpeg_mode(e));
			urmp_writei(str, "B", ur_id3_mpeg_sample_rate(e));
			urmp_writei(str, "c", ur_id3_mpeg_cbr(e));
			urmp_writei(str, "v", ur_id3_mpeg_vbr(e));
			urmp_writei(str, "D", ur_id3_mpeg_duration(e));
			urmp_writes(str, "s", ur_id3_search(e));
		}
	}
	fclose(str);
}
