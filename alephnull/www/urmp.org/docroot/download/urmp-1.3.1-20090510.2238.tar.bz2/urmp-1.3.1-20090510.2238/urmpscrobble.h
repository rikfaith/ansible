/* urmpscrobble.h -- 
 * Created: Sun May 10 21:01:01 2009 by faith@acm.org
 * Revised: Sun May 10 21:16:23 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMP_SCROBBLE_H_
#define _URMP_SCROBBLE_H_

extern void urmp_scrobble_stop(ur_id3_t e);
extern void urmp_scrobble_start(ur_id3_t e);
extern void urmp_scrobble_pause(ur_id3_t e);

#endif
