/* urmpscrobble.c -- 
 * Created: Sun May 10 21:00:17 2009 by faith@acm.org
 * Revised: Sun May 10 22:05:04 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpscrobble.h"
#include <curl/curl.h>

static ur_id3_t id3;
static ur_id3_t last_scrobbled;
static time_t   start;
static time_t   elapsed;
static bool     paused = false;

void urmp_scrobble_stop(ur_id3_t e)
{
	time_t now;
	int    duration;
	int    playtime = 240;

	if (!e || !id3 || e != id3) {
		return;
	}

	if (!paused) {
		time(&now);
		elapsed += now - start;
	}

	id3 = NULL;

	printf("%d %s\n", (int)elapsed, ur_id3_title(e));

	duration = ur_id3_mpeg_duration(e);
	
	if (duration < 30) return;

	if (duration / 2 < playtime) playtime = duration / 2;

	if (elapsed < playtime) return;
	printf("WOULD SCROBBLE %s\n", ur_id3_title(e));
}

void urmp_scrobble_start(ur_id3_t e)
{
	id3 = e;
	time(&start);
	elapsed = 0;
	paused = false;
}

void urmp_scrobble_pause(ur_id3_t e)
{
	time_t now;

	if (!e || !id3 || e != id3) {
		urmp_scrobble_start(e);
		return;
	}
	if (paused) {
		time(&start);
		paused = false;
		return;
	}

	time(&now);
	elapsed += now - start;
	paused = true;
}
