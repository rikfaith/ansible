/* urmp.c -- 
 * Created: Sat Sep 27 17:08:14 2008 by faith@acm.org
 * Revised: Sun May 10 20:47:30 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpconfig.h"
#include "version.h"
#include <errno.h>
#include <dirent.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#if HAVE_GNU_LIBC_VERSION_H
#include <gnu/libc-version.h>
#endif
#include <pcre.h>

int                  urmp_proc_count  = URMP_PROC_COUNT;
int                  urmp_max_pathlen = URMP_MAX_PATHLEN;
ur_sl_t              urmp_db;
static ur_id3_read_t urmp_dio;

typedef struct {
	ur_timer_t     timer;
	ur_proc_t      *procs;
	ur_msg_t       *msgs;
	int            count;
	int            launched;
	bool           *inflight;
	int            total_launched;
	time_t         last_message;
} urmp_flight_t;


static void urmp_dump_info(ur_list_t pathlist)
{
	const char  *path;
	ur_id3_t    e;
	struct stat st;
	bool        first = true;
	
	while ((path = ur_list_pop(pathlist))) {
		if (stat(path, &st)) {
			printf("Cannot stat: %s\n", path);
			continue;
		}
		if (!S_ISREG(st.st_mode)) {
			printf("Cannot handle: %s\n", path);
			continue;
		}
		e = ur_id3_read(path, UR_ID3_READ_BEST|urmp_dio,
				urmp_parse_augment);
		if (e) {
			if (!first) printf("==========\n");
			first = false;
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		} else {
			printf("Cannot parse: %s\n", path);
		}
	}
}

static int urmp_db_worker(ur_msg_t msg, int type, void *buf,
			  int length _unused, void *arg)
{
	int      retval;
	ur_id3_t id3;
	char     reply[URMP_MAX_ID3_BUFLEN];
	int      len;

	if (type != URMP_MSG_GET_INFO) {
		ur_fatal(__func__, "Message type %d unexpected\n", type);
	}
	ur_trace(URMP_TRACE_WORKER, __func__,
		 "worker %ld: %s\n", (intptr_t)arg, (char *)buf);
	id3 = ur_id3_read((const char *)buf, UR_ID3_READ_BEST|urmp_dio,
			  urmp_parse_augment);

	len = ur_id3_pack(id3, reply, sizeof(reply));
	if (len <= 0)
		ur_fatal(__func__, "Error packing data\n");
	retval = ur_msg_reply(msg, reply, len, 0);
	ur_trace(URMP_TRACE_WORKER, __func__,
		 "reply sent, retval=%d, errno=%d\n", retval, errno);
	ur_id3_destroy(id3);
	return 0;
}

static int urmp_db_worker_cleanup(int pid, int status, int err _unused,
				  void *arg __attribute__((unused)))
{
	if (!ur_trace_test(URMP_TRACE_HANDLER)) return 0;
	printf("%d: got status=%d for pid %d, errno=%d\n",
	       getpid(), status, pid, errno);
	fflush(stdout);
	return 0;
}

static int urmp_file_compare(const void *key1, const void *key2)
{
	const char *a = (const char *)key1;
	const char *b = (const char *)key2;

	return strcmp(a, b);
}

static void urmp_print_rate(urmp_flight_t *flight, bool force)
{
	unsigned int count;
	time_t       now, elapsed;

	time(&now);

	if (!flight->last_message) elapsed = 2;
	else                       elapsed = now - flight->last_message;

	count = ur_sl_items(urmp_db);
	if (force || elapsed > 1) {
		ur_timeval_t tv;

		ur_timer_stop(flight->timer);
		ur_timer_get_elapsed(flight->timer, &tv);
		printf("count=%u t=%lu.%03lu rate=%.1f"
		       " entries/second total_launched=%u\n",
		       count, (unsigned long)tv.wall.tv_sec,
		       (unsigned long)tv.wall.tv_usec/1000,
		       (double)count/((double)tv.wall.tv_sec
				      + (double)tv.wall.tv_usec/1000000.0),
			flight->total_launched);
		flight->last_message = now;
	}
}

void urmp_process_new_entry(ur_id3_t id3)
{
	const char *filename;

	if (!urmp_db) urmp_db = ur_sl_create(urmp_file_compare);

	if (!ur_id3_search(id3)) ur_id3_search_compute(id3);

	ur_id3_canonify(id3);
	filename = ur_id3_filename(id3);
	if (!filename || filename[0] == '\0') {
		ur_fatal(__func__, "Zero-length filename\n");
	}
	ur_sl_insert(urmp_db, ur_id3_filename(id3), id3);
}

static void urmp_process_new_entry_inflight(urmp_flight_t *flight,
					    ur_id3_t id3)
{
	urmp_process_new_entry(id3);
	urmp_print_rate(flight, false);
}

static int urmp_reap(urmp_flight_t *flight)
{
	int      i;
	ur_msg_t msg;
	char     buf[UR_MSG_MAX_SIZE];
	ur_id3_t id3;

	i = ur_msg_poll(flight->msgs, flight->count);

	msg = ur_msg_wait(flight->msgs[i], buf, sizeof(buf), 0);
	if (msg) {
		ur_trace(URMP_TRACE_MSG, __func__, "%d\n", i);
		id3 = ur_id3_unpack(buf, ur_msg_length(msg));
		urmp_process_new_entry_inflight(flight, id3);
		ur_msg_destroy(msg);
		--flight->launched;
	}
	flight->msgs[i] = NULL;
	return i;
}

static void urmp_drain(urmp_flight_t *flight)
{
	while (flight->launched) {
		urmp_reap(flight);
	}

	urmp_print_rate(flight, true);
}

static void urmp_launch(urmp_flight_t *flight, const char *filename)
{
	int i;

	++flight->total_launched;

	if (!flight->count) {
		ur_id3_t id3 = ur_id3_read(filename,
					   UR_ID3_READ_BEST|urmp_dio,
					   urmp_parse_augment);
		urmp_process_new_entry_inflight(flight, id3);
		return;
	}

	if (flight->launched > flight->count) {
		ur_fatal(__func__, "launched=%d > count=%d\n",
			 flight->launched, flight->count);
	}

	if (flight->launched == flight->count) {
		i = urmp_reap(flight);
		if (flight->launched == flight->count) {
			ur_fatal(__func__, "launched=%d count=%d after reap\n",
				 flight->launched, flight->count);
		}
		goto launch;
	}

	for (i = 0; i < flight->count; i++) {
		if (!flight->inflight[i]) goto launch;
	}

	ur_fatal(__func__, "launched=%d <= count=%d, i=%d, but all inflight\n",
		 flight->launched, flight->count, i);

launch:
	ur_trace(URMP_TRACE_MSG, __func__, "%d %s\n", i, filename);
	flight->inflight[i] = true;
	++flight->launched;
	flight->msgs[i] = ur_msg_send(flight->procs[i], URMP_MSG_GET_INFO,
				      (void *)filename, strlen(filename)+1, 0);
	if (!flight->msgs[i]) {
		ur_fatal(__func__, "ur_msg_send returned NULL\n");
	}
}

static void urmp_update_db(const char *pathname)
{
	int            i;
	ur_proc_t      procs[urmp_proc_count];
	DIR            *dir;
	ur_list_t      list;
	char           *path;
	struct dirent  *dirent;
	char           filename[urmp_max_pathlen];
	const char     *pt;
	urmp_flight_t  flight;
	unsigned char  type;

	ur_trace(URMP_TRACE_BUILD, __func__, "building from pathname=%s\n",
		 pathname);

				/* Bail early, if error */
	list = ur_list_create();
	ur_list_push(list, ur_strdup(pathname));

	for (i = 0; i < urmp_proc_count; i++) {
		procs[i] = ur_proc_create(urmp_db_worker, (void *)(intptr_t)i,
					  urmp_db_worker_cleanup, NULL,
					  NULL, NULL);
		ur_trace(URMP_TRACE_PROC, __func__,
			 "Pid %d created\n", ur_proc_pid(procs[i]));
	}

	memset(&flight, 0, sizeof(flight));
	flight.timer    = ur_timer_create(UR_TIMER_ALL);
	flight.procs    = procs;
	flight.count    = urmp_proc_count;
	if (flight.count) {
		flight.inflight = ur_allocz(sizeof(flight.inflight[0])
					    * flight.count);
		flight.msgs     = ur_allocz(sizeof(flight.msgs[0])
					    * flight.count);
	}

	ur_timer_start(flight.timer);
	while ((path = ur_list_pop(list))) {
		ur_trace(URMP_TRACE_STACK, __func__, "opening %s\n", path);

		if (!(dir = opendir(path))) {
			ur_fatal_errno(__func__,
				       "Cannot open directory %s\n", path);
		}

		while ((dirent = readdir(dir))) {
			snprintf(filename, urmp_max_pathlen-1, "%s/%s",
				 path, dirent->d_name);

			if (dirent->d_type == DT_UNKNOWN
			    || dirent->d_type == DT_LNK) {
				struct stat st;

				if (stat(filename, &st)) {
					ur_warning(__func__,
						   "Cannot stat %s\n",
						   filename);
					continue;
				}
				type = DT_UNKNOWN;
				if (S_ISREG(st.st_mode)) type = DT_REG;
				if (S_ISDIR(st.st_mode)) type = DT_DIR;
			} else {
				type = dirent->d_type;
			}

			switch (type) {
			case DT_DIR:
				if (!strcmp(dirent->d_name, ".")
				    || !strcmp(dirent->d_name, "..")) {
					break;
				}
				ur_trace(URMP_TRACE_STACK, __func__,
					 "pushing %s\n", filename);
				ur_list_push(list, ur_strdup(filename));
				break;
			case DT_REG:
				pt = strrchr(dirent->d_name, '.');
				if (pt && !strcmp(pt, ".mp3")) {
					urmp_launch(&flight, filename);
				} else {
					ur_trace(URMP_TRACE_ID3ERR, __func__,
						 "not an mp3: %s\n", filename);
				}
				break;
			default:
				ur_trace(URMP_TRACE_ID3ERR, __func__,
					 "ignoring: %s\n", filename);
				break;
			}
		}

		closedir(dir);
		ur_free(path);
	}
	ur_trace(URMP_TRACE_PROC, __func__,
		 "%d items still in list\n", ur_list_depth(list));
	urmp_drain(&flight);
	ur_timer_stop(flight.timer);
	ur_timer_destroy(flight.timer);
	ur_list_destroy(list);
	ur_proc_destroy_all();
	if (flight.count) {
		ur_free(flight.inflight);
		ur_free(flight.msgs);
	}
}

static void urmp_build_db(ur_list_t list)
{
	const char   *pathname;
	int          i;
	struct stat  st;

	for (i = 1; i <= ur_list_depth(list); i++) {
		pathname = ur_list_nth(list, i);
		ur_trace(URMP_TRACE_BUILD, __func__,
			 "checking pathname=%s\n", pathname);
		if (stat(pathname, &st) || !S_ISDIR(st.st_mode)) {
			ur_fatal(__func__,
				 "Build path must be a directory: %s\n",
				 pathname);
		}
	}

	while ((pathname = ur_list_pop(list))) {
		urmp_update_db(pathname);
	}
}

static void __attribute__((noreturn)) version(void)
{
	printf("urmp %d.%d.%d (%s)\n", URMP_MAJOR, URMP_MINOR, URMP_PATCH,
	       URMP_DATE);
	printf("Copyright (C) 2008 Rickard E. (Rik) Faith\n");
	printf("This is open source software,"
	       " released under the MIT License:\n");
	printf("http://opensource.org/licenses/mit-license.php\n");
	printf("There is NO WARRANTY, to the extent permitted by law\n");
	printf("\n");
	exit(0);
}

static void __attribute__((noreturn)) usage(void)
{
        ur_list_t  list;
        const char *str;

        printf("usage: %s [OPTION] [PATHS]\n", ur_program_name());
	printf("\nCommon options:\n");
	printf("  -b, --build      Build using PATHS\n");
	printf("  -i, --ignore     Do not read the existing database\n");
	printf("                   The default database is %s/%s\n",
	       URMP_DEFAULT_CONFIG, URMP_DEFAULT_DB);
	printf("  -n, --dry-run    Do not write a new database\n");
	printf("  -g, --gui        Start gui\n");
	printf("  --default        Do not read existing config file\n");
	printf("                   The default config file is %s/%s\n",
	       URMP_DEFAULT_CONFIG, URMP_DEFAULT_RC);
	printf("\nLess common options:\n");
	printf("  --help           Display this help and exit\n");
	printf("  --version        Display version & copyright information\n");
	printf("  -c, --config     DIRECTORY for configuration information\n");
	printf("                   The default DIRECTORY is %s\n",
	       URMP_DEFAULT_CONFIG);
	printf("  --procs          Run with NUM processes when building\n");
	printf("  --directio       Use direct I/O (may help NFS speed)\n");
	printf("\nDebuging options:\n");
	printf("  --info           Print best id3 information for PATHS\n");
	printf("  --parse          Debug id3 parsing for FILE\n");
	printf("  --rewrite        Debug reading adn writing database\n");
	printf("  -t, --trace      TRACE-LIST is a list of trace names:\n");
        if ((list = ur_trace_names())) {
		int i = 0;
                while ((str = ur_list_pop(list))) {
			if (!i) {
				printf("                   %s", str);
			} else {
				printf(" %s", str);
			}
			if (++i > 3) {
				printf("\n");
				i = 0;
			}
                }
		if (i) printf("\n");
        }
	printf("  -d, --debug      DEBUG-LIST is a list of debug names:\n");
        if ((list = ur_debug_names())) {
		int i = 0;
                while ((str = ur_list_pop(list))) {
			if (!i) {
				printf("                   %s", str);
			} else {
				printf(" %s", str);
			}
			if (++i > 3) {
				printf("\n");
				i = 0;
			}
                }
		if (i) printf("\n");
        }
	
        exit(1);
}

static void urmp_trailer(void)
{
	int pagesize = 4096;

	ur_log_backtrace("Urmp Version:      urmp %d.%d.%d (%s)\n",
			 URMP_MAJOR, URMP_MINOR, URMP_PATCH, URMP_DATE);
	ur_log_backtrace("PCRE Version:      %s\n", pcre_version());
	urmp_gui_trailer();
}

static void __attribute__((noreturn)) urmp_handler(int sig)
{
	ur_trace(URMP_TRACE_HANDLER, __func__,
		 "%d:caught sig(%d)=%s, terminating\n",
		 getpid(), sig, ur_signal_name(sig));
	ur_proc_destroy_all();
	exit(0);
}

static void urmp_init(void)
{
	int              sig[] = { SIGHUP, SIGINT, SIGQUIT, SIGILL,
				   SIGBUS, SIGFPE, SIGSEGV, SIGTERM };
	size_t           i;
	struct sigaction a;

	for (i = 0; i < sizeof(sig)/sizeof(sig[0]); i++) {
		memset(&a, 0, sizeof(a));
		a.sa_handler = urmp_handler;
		sigemptyset(&a.sa_mask);
		sigaddset(&a.sa_mask, sig[i]);
		sigaction(sig[i], &a, NULL);
	}
}

int main(int argc, const char **argv)
{
	bool             do_gui       = false;
	bool             do_ignore    = false;
	bool             do_dry_run   = false;
	bool             do_rewrite   = false;
	bool             use_defaults = false;
	bool             do_build     = false;
	bool             do_info      = false;
	ur_list_t        pathlist     = NULL;
	int              c;
	const char       *str;
	const char       *config      = NULL;
	const char       *parsefile   = NULL;
	ur_option_t      opt;
	ur_option_list_t optlist[] = {
		{ "build",   'b', UR_OPTION_NONE },
		{ "gui",     'g', UR_OPTION_NONE },
		{ "trace",   't', UR_OPTION_LIST },
		{ "debug",   'd', UR_OPTION_LIST },
		{ "config",  'c', UR_OPTION_ARG  },
		{ "ignore",  'i', UR_OPTION_NONE },
		{ "dry-run", 'n', UR_OPTION_NONE },
		{ "help",    500, UR_OPTION_NONE },
		{ "version", 501, UR_OPTION_NONE },
		{ "procs",   502, UR_OPTION_ARG  },
		{ "parse",   503, UR_OPTION_ARG  },
		{ "info",    504, UR_OPTION_NONE },
		{ "default", 505, UR_OPTION_NONE },
		{ "rewrite", 506, UR_OPTION_NONE },
		{ "directio",507, UR_OPTION_NONE },
		{ NULL, 0, 0 },
	};

	ur_init(argv[0]);
	urmp_init();
	ur_add_trailer(urmp_trailer);
	ur_trace_register(URMP_TRACE_CONFIG,    "config");
	ur_trace_register(URMP_TRACE_BUILD,     "build");
	ur_trace_register(URMP_TRACE_PROC,      "proc");
	ur_trace_register(URMP_TRACE_MSG,       "msg");
	ur_trace_register(URMP_TRACE_STACK,     "stack");
	ur_trace_register(URMP_TRACE_WORKER,    "worker");
	ur_trace_register(URMP_TRACE_ID3ERR,    "id3err");
	ur_trace_register(URMP_TRACE_PLAYER,    "player");
	ur_trace_register(URMP_TRACE_PLAYERINT, "playerint");
	ur_trace_register(URMP_TRACE_SLAVE,     "slave");
	ur_trace_register(URMP_TRACE_SWITCH,    "switch");
	ur_trace_register(URMP_TRACE_RANDOM,    "random");
	ur_trace_register(URMP_TRACE_EVENTS,    "events");
	ur_trace_register(URMP_TRACE_SEARCH,    "search");
	ur_trace_register(URMP_TRACE_PLAYLIST,  "playlist");
	ur_trace_register(URMP_TRACE_HANDLER,   "handler");

	opt = ur_option_create(optlist);
	ur_option_parse_argv(opt, argc, argv);
	while ((c = ur_option_get(opt)) != EOF) {
		switch (c) {
		case 'b':
			do_build = true;
			break;
		case 't':
		{
			ur_list_t list;
			list = ur_option_list(opt, NULL);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_trace_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		}
		case 'd':
		{
			ur_list_t list;
			list = ur_option_list(opt, NULL);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_debug_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		}
		case 'i':
			do_ignore = true;
			break;
		case 'n':
			do_dry_run = true;
			break;
		case 'g':
			do_gui = true;
			break;
		case 'c':
			config = ur_option_string(opt);
			break;
		case 507:
			urmp_dio = UR_ID3_READ_DIRECT;
			break;
		case 506:
			do_rewrite = true;
			break;
		case 505:
			use_defaults = true;
			break;
		case 504:
			do_info = true;
			break;
		case 503:
			parsefile = ur_option_string(opt);
			break;
		case 502:
			urmp_proc_count = ur_option_int(opt);
			break;
		case 501:
			version();
		case 500:
		default:
			usage();
		}
	}

	if (do_build || do_info) pathlist = ur_option_other(opt, NULL);

	urmp_config_setup(config, use_defaults);

	if (parsefile) {
		ur_id3_t e;

		ur_trace_set_by_name("ur-id3", NULL);
		ur_trace_set_by_name("ur-parse", NULL);

		printf("===== Reading id3v1 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_V1|urmp_dio, NULL);
		if (e) {
			ur_id3_print(e, stdout, false);
			ur_id3_destroy(e);
		}

		printf("===== Reading id3v2 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_V2|urmp_dio, NULL);
		if (e) {
			ur_id3_print(e, stdout, false);
			ur_id3_destroy(e);
		}

		printf("===== Reading mp3 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_MP3|urmp_dio, NULL);
		if (e) {
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		}

		printf("===== Parsing =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_CUSTOM|urmp_dio,
				urmp_parse_augment);
		if (e) {
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		}
		
		return 0;
	}

	if (do_dry_run) urmp_config_readonly();

	if (!do_build && !do_info && !do_gui && !do_rewrite) usage();

	if ((do_build || do_info) && !pathlist) usage();

	if (!do_build && !do_info && pathlist) usage();

	if (do_build && do_info) {
		printf("--build not compatible with --info\n");
		usage();
	}

	if (do_info) {
		urmp_dump_info(pathlist);
		return 0;
	}

	if (do_rewrite) {
		if (do_ignore || do_gui) {
			printf("--rewrite not compatible with"
			       " --build and/or --gui\n");
			usage();
		}
		urmp_read_db();
		urmp_write_db();
		return 0;
	}

	if (!do_ignore) urmp_read_db();

	if (do_build) {
		urmp_build_db(pathlist);
		ur_list_destroy(pathlist);
		if (!do_dry_run) urmp_write_db();
	}

	if (do_gui) {
		urmp_player_start();
		urmp_gui(&argc, &argv);
	}

	return 0;
}
