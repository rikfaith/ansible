/* urmpconfig.h -- 
 * Created: Tue Dec 30 10:29:35 2008 by faith@acm.org
 * Revised: Sat May 16 09:01:54 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPCONFIG_H_
#define _URMPCONFIG_H_

#include "urmp.h"

extern const char *urmp_config_dir_path;
extern const char *urmp_config_db_path;
extern const char *urmp_config_backup_db_path;
extern ur_parse_t urmp_parse_use;
extern ur_parse_t urmp_parse_augment;
extern ur_parse_t urmp_parse_priority;

extern void urmp_config_setup(const char *config_path, bool use_defaults);
extern void urmp_config_readonly(void);

extern void urmp_config_set_geometry(int width, int height);
extern int  urmp_config_get_width(void);
extern int  urmp_config_get_height(void);

extern void urmp_config_set_division(int division);
extern int  urmp_config_get_division(void);

extern void urmp_config_set_column_width(int pane, int column, int width);
extern int  urmp_config_get_column_width(int pane, int column);

extern unsigned long urmp_config_get_lastfm_generation(void);

extern void urmp_config_set_lastfm_nowplaying(bool nowplaying);
extern bool urmp_config_get_lastfm_nowplaying(void);

extern void urmp_config_set_lastfm_scrobbling(bool scrobbling);
extern bool urmp_config_get_lastfm_scrobbling(void);

extern void urmp_config_set_lastfm_store_password(bool store);
extern bool urmp_config_get_lastfm_store_password(void);

extern void       urmp_config_set_lastfm_username(const char *value);
extern const char *urmp_config_get_lastfm_username(void);

extern void       urmp_config_set_lastfm_password(const char *value);
extern const char *urmp_config_get_lastfm_password(void);


#endif
