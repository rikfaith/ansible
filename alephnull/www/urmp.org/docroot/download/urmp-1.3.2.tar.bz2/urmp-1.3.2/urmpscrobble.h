/* urmpscrobble.h -- 
 * Created: Fri May 15 18:13:57 2009 by faith@acm.org
 * Revised: Sat May 16 07:29:43 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMP_SCROBBLE_H_
#define _URMP_SCROBBLE_H_

extern void urmp_scrobble(ur_id3_t e);

#endif
