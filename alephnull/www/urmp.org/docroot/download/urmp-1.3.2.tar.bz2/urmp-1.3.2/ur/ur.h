/* ur.h -- Public header for ur
 * Created: Sun Jul  4 09:27:58 1999 by faith@dict.org
 * Revised: Sat May 16 10:44:31 2009 by faith@dict.org
 * Copyright 1999-2003, 2008, 2009 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#ifndef _UR_H_
#define _UR_H_

#if !defined(__GNUC__) && !defined(__LCLINT__)
#define __attribute__(x)
#endif

#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>

				/* ur support and error management */
typedef struct ur_list_s *ur_list_t;
typedef struct ur_iterator_s {
    void          *a;
    void          *b;
    unsigned long c;
    int           d;
    int           e;
} ur_iterator_t;

typedef enum {
    UR_ERROR_TRACE    = 0x00000001, /* Continues */
    UR_ERROR_WARN     = 0x00000002, /* Continues */
    UR_ERROR_INFO     = 0x00000004, /* Continues */
    UR_ERROR_FATAL    = 0x00000008, /* Exits */
    UR_ERROR_INTERNAL = 0x00000010, /* Exits */
    
    UR_ERROR_ERRNO    = 0x10000000, /* Uses errno */
    UR_ERROR_ABORT    = 0x20000000  /* Exits with abort */
} ur_error_t;

extern void          ur_init(const char *programName);
extern void          ur_add_trailer(void (*f)(void));
extern void          ur_signal(int sig, const char *program_name);
extern const char    *ur_program_name(void);
extern const char    *ur_signal_name(int sig);
extern void          ur_shutdown(void);
extern const char    *ur_version(void);
extern int           ur_version_major(void);
extern int           ur_version_minor(void);
extern int           ur_version_patch(void);
extern const char    *ur_version_date(void);

extern void          ur_trace_register(unsigned long flag, const char *name);
extern void          ur_trace_set(unsigned long flag);
extern void          ur_trace_unset(unsigned long flag);
extern void          ur_trace_set_by_name(const char *name,
					  int (*f)(const char *));
extern void          ur_trace_unset_by_name(const char *name,
					    int (*f)(const char *));
extern int           ur_trace_test_by_name(const char *name,
					   int (*f)(const char *));
extern int           ur_trace_test(unsigned long flag); /* FIXME -- inline */
extern ur_list_t     ur_trace_names(void);

extern void          ur_debug_register(unsigned long flag, const char *name);
extern void          ur_debug_set(unsigned long flag);
extern void          ur_debug_unset(unsigned long flag);
extern void          ur_debug_set_by_name(const char *name,
					  int (*f)(const char *));
extern void          ur_debug_unset_by_name(const char *name,
					    int (*f)(const char *));
extern int           ur_debug_test_by_name(const char *name,
					   int (*f)(const char *));
extern int           ur_debug_test(unsigned long flag); /* FIXME -- inline */
extern ur_list_t     ur_debug_names(void);

extern void          ur_error(ur_error_t mask, int error,
			      const char *routine, const char *format,
			      va_list ap);
extern void          ur_trace(unsigned long flag, const char *routine,
			      const char *format,
			      ...) __attribute__((format(printf,3,4)));
extern void          ur_warning(const char *routine, const char *format,
				...) __attribute__((format(printf,2,3)));
extern void          ur_fatal(const char *routine, const char *format,
			      ...) __attribute__((noreturn,
						  format(printf,2,3)));
extern void          ur_fatal_abort(const char *routine, const char *format,
                                   ...) __attribute__((noreturn,
                                                       format(printf,2,3)));
extern void          ur_fatal_errno(const char *routine, const char *format,
				   ...) __attribute__((noreturn,
						       format(printf,2,3)));
extern void          ur_internal(const char *routine, const char *format,
				 ... ) __attribute__((noreturn,
						      format(printf,2,3)));
extern void          ur_error_callback(int (*f)(int severity,
					       const char *message));
extern void          ur_log_file(const char *filename);
extern void          ur_log_syslog(void);
extern void          ur_log_close(void);
extern void          ur_log_error(const char *routine, const char *format,
				 ...) __attribute__((format(printf,2,3)));
extern void          ur_log_error_v(const char *routine, const char *format,
				  va_list ap);
extern void          ur_log_info(const char *routine, const char *format,
				...) __attribute__((format(printf,2,3)));
extern void          ur_log_info_v(const char *routine, const char *format,
				 va_list ap);
extern int           ur_log_backtrace(const char *format, ...);

				/* simple stack */

typedef struct ur_stack_s *ur_stack_t;

extern ur_stack_t    ur_stack_create(void);
extern unsigned long ur_stack_destroy(ur_stack_t stack);
extern void          ur_stack_push(ur_stack_t stack, const void *datum);
extern void          *ur_stack_pop(ur_stack_t stack);
extern const void    *ur_stack_top(ur_stack_t stack);
extern void          *ur_stack_pick(ur_stack_t stack, unsigned int n);
extern unsigned int  ur_stack_depth(ur_stack_t stack);
extern void          ur_stack_swap(ur_stack_t stack);
extern void          ur_stack_dup(ur_stack_t stack);
extern void          ur_stack_iterator_init(ur_stack_t stack, ur_iterator_t *iter);
extern int           ur_stack_iterator_next(ur_iterator_t *iter);
extern void          *ur_stack_iterator_datum(ur_iterator_t *iter);

#define UR_STACK_INIT(L,I)  ur_stack_iterator_init(L,&(I))
#define UR_STACK_GET(I,D)   ((D) = ur_stack_iterator_datum(&(I)))
#define UR_STACK_NEXT(I)    ur_stack_iterator_next(&(I))
#define UR_STACK_ITERATE(L,I,D) \
    for (UR_STACK_INIT(L,I); UR_STACK_GET(I,D); UR_STACK_NEXT(I))

				/* dynamic arrays */

#if 0
typedef struct ur_array_s *ur_array_t;

extern ur_array_t    ur_array_create(void);
extern unsigned long ur_array_destroy(ur_stack_t stack);
extern void          ur_array_push(ur_stack_t stack, const void *datum);
extern const void    *ur_array_pop(ur_stack_t stack);

extern const void    *ur_array_top(ur_stack_t stack);
extern const void    *ur_array_pick(ur_stack_t stack, unsigned int n);
extern unsigned int  ur_array_depth(ur_stack_t stack);
extern void          ur_array_swap(ur_stack_t stack);
extern void          ur_array_rotate(ur_stack_t stack, signed int n);
extern void          ur_array_dup(ur_stack_t stack);
#endif


				/* hash tables */

typedef struct ur_hash_s *ur_hash_t;

typedef unsigned long (*ur_hash_hash_t)(const void *key);
typedef int           (*ur_hash_compare_t)(const void *key1, const void *key2);

extern ur_hash_t     ur_hash_create(ur_hash_hash_t hash,
				    ur_hash_compare_t compare);
extern ur_hash_t     ur_hash_create_ulkey(void);
extern unsigned long ur_hash_destroy(ur_hash_t table);
extern void          *ur_hash_lookup(ur_hash_t table, const void *key);
extern unsigned long ur_hash_lookup_ul(ur_hash_t table, const void *key);
extern int           ur_hash_insert(ur_hash_t table, const void *key,
				   const void *datum);
extern int           ur_hash_insert_ul(ur_hash_t table, const void *key,
				     unsigned long datum);
extern int           ur_hash_delete(ur_hash_t table, const void *key);
extern unsigned long ur_hash_items(ur_hash_t table);
extern int           ur_hash_print_stats(ur_hash_t table,
					 FILE *str, int flags);
extern void          ur_hash_iterator_init(ur_hash_t table,
					   ur_iterator_t *iter);
extern int           ur_hash_iterator_next(ur_iterator_t *iter);
extern void          *ur_hash_iterator_key(ur_iterator_t *iter);
extern void          *ur_hash_iterator_datum(ur_iterator_t *iter);
extern unsigned long ur_hash_iterator_datum_ul(ur_iterator_t *iter);
extern void          ur_hash_iterator_lock(ur_hash_t table);
extern void          ur_hash_iterator_unlock(ur_hash_t table);

#define UR_HASH_INIT(L,I)  ur_hash_iterator_init(L,&(I))
#define UR_HASH_GET(I,K,D)    (((K) = ur_hash_iterator_key(&(I))) \
		     	        && ((D) = ur_hash_iterator_datum(&(I))))
#define UR_HASH_GET_NODATUM(I,K) (((K) = ur_hash_iterator_key(&(I))) \
		     	          && ur_hash_iterator_datum(&(I)))
#define UR_HASH_GET_UL(I,K,D) (((K) = ur_hash_iterator_key(&(I))) \
		     	        && ((D)                          \
                                    = (unsigned long)ur_hash_iterator_datum( \
                                                     &(I))))
#define UR_HASH_GET_UL_NODATUM(I,K) (((K) = ur_hash_iterator_key(&(I))) \
 		     	             && ur_hash_iterator_datum(&(I)))
#define UR_HASH_NEXT(I)    ur_hash_iterator_next(&(I))
#define UR_HASH_ITERATE(L,I,K,D) \
    for (UR_HASH_INIT(L,I); UR_HASH_GET(I,K,D); UR_HASH_NEXT(I))
#define UR_HASH_ITERATE_NODATUM(L,I,K) \
    for (UR_HASH_INIT(L,I); UR_HASH_GET_NODATUM(I,K); UR_HASH_NEXT(I))
#define UR_HASH_ITERATE_UL(L,I,K,D) \
    for (UR_HASH_INIT(L,I); UR_HASH_GET_UL(I,K,D); UR_HASH_NEXT(I))
#define UR_HASH_ITERATE_UL_NODATUM(L,I,K) \
    for (UR_HASH_INIT(L,I); UR_HASH_GET_UL_NODATUM(I,K); UR_HASH_NEXT(I))



				/* skiplists */

typedef struct ur_sl_s *ur_sl_t;

typedef int (*ur_sl_compare_t)(const void *key1, const void *key2);

extern ur_sl_t       ur_sl_create(ur_sl_compare_t compare);
extern unsigned long ur_sl_destroy(ur_sl_t list);
extern void          *ur_sl_lookup(ur_sl_t list, const void *key);
extern unsigned int  ur_sl_items(ur_sl_t list);
extern int           ur_sl_insert(ur_sl_t list,
				       const void *key,
				       const void *datum);
extern int           ur_sl_delete(ur_sl_t list, const void *key);
extern int           ur_sl_print_stats(ur_sl_t list, FILE *str,
					   int flags);
extern void          ur_sl_iterator_init(ur_sl_t list,
					     ur_iterator_t *iter);
extern int           ur_sl_iterator_next(ur_iterator_t *iter);
extern void          *ur_sl_iterator_key(ur_iterator_t *iter);
extern void          *ur_sl_iterator_datum(ur_iterator_t *iter);

#define UR_SL_INIT(L,I)  ur_sl_iterator_init(L,&(I))
#define UR_SL_GET(I,K,D) (((K) = ur_sl_iterator_key(&(I))) \
		     	         && ((D) = ur_sl_iterator_datum(&(I))))
#define UR_SL_NEXT(I)    ur_sl_iterator_next(&(I))
#define UR_SL_ITERATE(L,I,K,D) \
    for (UR_SL_INIT(L,I); UR_SL_GET(I,K,D); UR_SL_NEXT(I))


				/* AVL trees */

typedef struct ur_avl_s *ur_avl_t;

typedef int (*ur_avl_compare_t)(const void *key1, const void *key2);

extern ur_avl_t      ur_avl_create(ur_avl_compare_t compare);
extern unsigned long ur_avl_destroy(ur_avl_t tree);
extern void          *ur_avl_lookup(ur_avl_t tree, const void *key);
extern int           ur_avl_insert(ur_avl_t tree, const void *key,
				   const void *datum);
extern int           ur_avl_delete(ur_avl_t tree, const void *key);
extern int           ur_avl_print_stats(ur_avl_t tree, FILE *str,
					int flags);

				/* unordered lists */
#define UR_LIST_DELIM   " \t\n\r\v\f"
#define UR_LIST_QUOTE   "\"'"
#define UR_LIST_ESCAPE  "\\"

extern ur_list_t     ur_list_create(void);
extern unsigned long ur_list_destroy(ur_list_t list);
extern unsigned int  ur_list_depth(ur_list_t list);
extern void          ur_list_append(ur_list_t list, const void *datum);
extern void          ur_list_push(ur_list_t list, const void *datum);
extern void          *ur_list_pop(ur_list_t list);
extern void          *ur_list_top(ur_list_t list);
extern void          *ur_list_last(ur_list_t list);
extern void          *ur_list_bot(ur_list_t list);
extern void          *ur_list_nth(ur_list_t list, int n);
extern void          ur_list_make_argv(ur_list_t list, int *argc,
				     const char ***argv);
extern void          ur_list_parse(ur_list_t list, const char *string,
				   const char *delim, const char *quote,
				   const char *escape, bool escapes);
extern void          ur_list_parse_string(ur_list_t list, const char *string);

extern void          ur_list_iterator_init(ur_list_t list, ur_iterator_t *iter);
extern int           ur_list_iterator_next(ur_iterator_t *iter);
extern void          *ur_list_iterator_datum(ur_iterator_t *iter);

#define UR_LIST_INIT(L,I)  ur_list_iterator_init(L,&(I))
#define UR_LIST_GET(I,D)   ((D) = ur_list_iterator_datum(&(I)))
#define UR_LIST_NEXT(I)    ur_list_iterator_next(&(I))
#define UR_LIST_ITERATE(L,I,D) \
    for (UR_LIST_INIT(L,I); UR_LIST_GET(I,D); UR_LIST_NEXT(I))
	     
				/* trees */

typedef struct ur_tree_s *ur_tree_t;
typedef enum {
    UR_TREE_INORDER,
    UR_TREE_PREORDER,
    UR_TREE_POSTORDER
}                       ur_tree_walk_t;
typedef struct ur_tree_attrib_s {
    const char *name;
    const char *value;
} *ur_tree_attrib_t;

extern ur_tree_t     ur_tree_create(int id);
extern ur_tree_t     ur_tree_make(int id, ...);
extern unsigned long ur_tree_destroy_node(ur_tree_t node);
extern unsigned long ur_tree_destroy_tree(ur_tree_t root);
extern ur_tree_t     ur_tree_disconnect(ur_tree_t node);
extern ur_tree_t     ur_tree_append(ur_tree_t parent, ur_tree_t child);
extern ur_tree_t     ur_tree_prepend(ur_tree_t parent, ur_tree_t child);
extern ur_tree_t     ur_tree_insert_before(ur_tree_t sibling, ur_tree_t child);
extern ur_tree_t     ur_tree_insert_after(ur_tree_t sibling, ur_tree_t child);
extern ur_tree_t     ur_tree_insert_last(ur_tree_t sibling, ur_tree_t child);
extern ur_tree_t     ur_tree_insert_first(ur_tree_t sibling, ur_tree_t child);

extern void          ur_tree_set_string(ur_tree_t node, const char *string);
extern void          ur_tree_set_integer(ur_tree_t node, int i);
extern void          ur_tree_set_real(ur_tree_t node, double r);
extern void          ur_tree_set_attrib(ur_tree_t node, const char *name,
				      const char *value);
extern int           ur_tree_has_string(ur_tree_t node);
extern int           ur_tree_has_integer(ur_tree_t node);
extern int           ur_tree_has_real(ur_tree_t node);
extern int           ur_tree_has_attrib(ur_tree_t node);
extern int           ur_tree_has_list(ur_tree_t node);
extern int           ur_tree_id(ur_tree_t node);
extern ur_tree_t     ur_tree_parent(ur_tree_t node);
extern ur_tree_t     ur_tree_child(ur_tree_t node);
extern ur_tree_t     ur_tree_sibling(ur_tree_t node);
extern const char    *ur_tree_string(ur_tree_t node);
extern int           ur_tree_integer(ur_tree_t node);
extern double        ur_tree_real(ur_tree_t node);
extern const char    *ur_tree_attrib(ur_tree_t node, const char *name);
extern ur_list_t     ur_tree_attrib_list(ur_tree_t node);
extern void          ur_tree_iterator_init(ur_tree_t node, ur_iterator_t *iter,
					 ur_tree_walk_t walk);
extern int           ur_tree_iterator_next(ur_iterator_t *iter);
extern ur_tree_t     ur_tree_iterator_datum(ur_iterator_t *iter, int *position);
extern void          ur_tree_print(ur_tree_t root, FILE *stream);

#define UR_TREE_INIT(L,I,T) ur_tree_iterator_init(L,&(I),(T))
#define UR_TREE_GET(I,D,P)  ((D) = ur_tree_iterator_datum(&(I),&(P)))
#define UR_TREE_NEXT(I)     ur_tree_iterator_next(&(I))
#define UR_TREE_ITERATE(L,I,D,T,P) \
    for (UR_TREE_INIT(L,I,T); UR_TREE_GET(I,D,P); UR_TREE_NEXT(I))

				/* debug flags */
typedef struct ur_flag_s *ur_flag_t;

extern ur_flag_t     ur_flag_create(void);
extern unsigned long ur_flag_destroy(ur_flag_t flags);
extern void          ur_flag_register(ur_flag_t flags, unsigned long flag,
				     const char *name);
       
extern void          ur_flag_set(ur_flag_t flags, unsigned long flag);
extern void          ur_flag_unset(ur_flag_t flags, unsigned long flag);
extern int           ur_flag_test(ur_flag_t flags, unsigned long flag);
extern void          ur_flag_set_by_name(ur_flag_t flags, const char *name,
                                      int (*f)(const char *));
extern void          ur_flag_unset_by_name(ur_flag_t flags, const char *name,
                                        int (*f)(const char *));
extern int           ur_flag_test_by_name(ur_flag_t flags, const char *name,
                                       int (*f)(const char *));
extern const char    *ur_flag_name(ur_flag_t flags, unsigned long flag);
extern ur_list_t     ur_flag_names(ur_flag_t flags);


				/* arenas */
typedef struct ur_arena_s *ur_arena_t;

extern ur_arena_t    ur_arena_create(size_t alignment);
extern void          ur_arena_clear(ur_arena_t arena);
extern unsigned long ur_arena_destroy(ur_arena_t arena);
extern void          *ur_arena_alloc(ur_arena_t arena, size_t size)
	__attribute__((malloc));
extern void          *ur_arena_alloc_z(ur_arena_t arena, size_t size)
	__attribute__((malloc));
extern const char    *ur_arena_string(ur_arena_t arena, const char *datum);
extern const char    *ur_arena_string_n(ur_arena_t arena, const char *datum, int len);

				/* block allocator */

typedef struct ur_block_s *ur_block_t;
			   
extern ur_block_t    ur_block_create(size_t blocksize);
extern unsigned long ur_block_destroy(ur_block_t block);
extern void          *ur_block_alloc(ur_block_t block);
extern void          *ur_block_alloc_z(ur_block_t block);
extern void          ur_block_free(ur_block_t block, void *area);



				/* memory management */

extern void          *ur_alloc(size_t size) __attribute__((malloc));
extern void          *ur_allocz(size_t size) __attribute__((malloc));
extern void          *ur_realloc(void *old, size_t size);
extern void          *ur_reallocz(void *old, size_t oldsize, size_t newsize);
extern void          ur_free(void *object);
extern char          *ur_strdup(const char *s);

#ifdef DMALLOC_FUNC_CHECK
#define ur_alloc(s)     _malloc_leap(__FILE__, __LINE__, s)
#define ur_allocz(s)    _calloc_leap(__FILE__, __LINE__, 1, s)
#define ur_realloc(o,s) _realloc_leap(__FILE__, __LINE__, o, s)
#define ur_free(o)      _free_leap(__FILE__, __LINE__, o)
#endif


				/* global atoms */

extern const void    *ur_atom_new(const void *datum, int len);
extern const char    *ur_atom_string(const char *datum);
extern const char    *ur_atom_string_n(const char *datum, int len);
extern void          ur_atom_destroy(void);



				/* pseudorandom number generation */

typedef struct ur_random_s *ur_random_t;
typedef enum {
    UR_RANDOM_STD,
    UR_RANDOM_ALT0,
    UR_RANDOM_ALT1,
    UR_RANDOM_ALT2,
    UR_RANDOM_LONG
}                    ur_random_type_t;
typedef enum {
    UR_RANDOM_UNIFORM,
    UR_RANDOM_SHUFFLE
}                    ur_random_modifier_t;

extern ur_random_t   ur_random_create(ur_random_type_t type,
				     ur_random_modifier_t mo);
extern unsigned long ur_random_destroy(ur_random_t prng);
extern void          ur_random_seed(ur_random_t prng,
				   unsigned long seed0,
				   unsigned long seed1);
extern unsigned long ur_random(ur_random_t prng);
extern unsigned long ur_random_max(ur_random_t prng);
extern unsigned long ur_random_range(ur_random_t prng,
				    unsigned long min,
				    unsigned long max);
extern double        ur_random_real(ur_random_t prng);



				/* timers */

typedef struct ur_timer_s *ur_timer_t;
typedef enum {
    UR_TIMER_WALL  = 0x01,
    UR_TIMER_CPU   = 0x02,
    UR_TIMER_CYCLE = 0x04,
    UR_TIMER_ALL   = ~0
}                    ur_timer_type_t;

typedef struct ur_timeval_s {
    struct timeval   wall;
    struct timeval   user;
    struct timeval   system;
    struct timeval   children_user;
    struct timeval   children_system;
    unsigned long    cycle_hi;
    unsigned long    cycle_lo;
} ur_timeval_t;

extern ur_timer_t    ur_timer_create(ur_timer_type_t type);
extern unsigned long ur_timer_destroy(ur_timer_t timer);
extern void          ur_timer_start(ur_timer_t timer);
extern void          ur_timer_stop(ur_timer_t timer);
extern void          ur_timer_get_start(ur_timer_t timer, ur_timeval_t *timeval);
extern void          ur_timer_get_stop(ur_timer_t timer, ur_timeval_t *timeval);
extern void          ur_timer_set_start(ur_timer_t timer, ur_timeval_t *timeval);
extern void          ur_timer_set_stop(ur_timer_t timer, ur_timeval_t *timeval);
extern void          ur_timer_get_elapsed(ur_timer_t timer, ur_timeval_t *timeval);


				/* option parsing */
typedef struct ur_option_s *ur_option_t;

typedef enum {
    UR_OPTION_NONE,
    UR_OPTION_ARG,
    UR_OPTION_LIST
}                    ur_option_type_t;

typedef struct ur_option_list_s {
    const char       *longname;
    int              shortname;
    ur_option_type_t   type;
} ur_option_list_t;

extern ur_option_t   ur_option_create(ur_option_list_t *list);
extern void          ur_option_parse_argv(ur_option_t opt,
					int argc, const char **argv);
extern void          ur_option_parse_string(ur_option_t opt, const char *string);
extern void          ur_option_parse_list(ur_option_t opt, ur_list_t list);
extern unsigned long ur_option_destroy(ur_option_t opt);
extern int           ur_option_get(ur_option_t opt);
extern long          ur_option_int(ur_option_t opt);
extern double        ur_option_real(ur_option_t opt);
extern const char    *ur_option_string(ur_option_t opt);
extern ur_list_t     ur_option_list(ur_option_t opt, ur_list_t current_list);
extern ur_list_t     ur_option_other(ur_option_t opt, ur_list_t current_list);
extern int           ur_option_in_range(const char *range, unsigned long val);

				/* base encoding and decoding */
extern const char    *ur_base26_encode(unsigned long val);
extern unsigned long ur_base26_decode(const char *val);
extern const char    *ur_base64_encode(unsigned long val);
extern unsigned long ur_base64_decode(const char *val);
extern const char    *ur_base85_encode(unsigned long val);
extern unsigned long ur_base85_decode(const char *val);

                                /* file support (mmap) */
typedef struct ur_file_s *ur_file_t;

extern ur_file_t     ur_file_open(const char *filename);
extern const void    *ur_file_start(ur_file_t file);
extern const void    *ur_file_end(ur_file_t file);
extern unsigned long ur_file_size(ur_file_t file);
extern time_t        ur_file_mtime(ur_file_t file);
extern const void    *ur_file_set(ur_file_t file, void *pos);
extern const void    *ur_file_get(ur_file_t file);
extern unsigned long  ur_file_close(ur_file_t file);

                                /* mail support */
typedef struct ur_mail_s *ur_mail_t;

extern ur_mail_t     ur_mail_create(const void *buffer,
                                   unsigned long len);
extern unsigned long ur_mail_destroy(ur_mail_t mail);
extern const void    *ur_mail_next(ur_mail_t mail, unsigned long *len);
extern const void    *ur_mail_header(ur_mail_t mail, unsigned long *len,
                                    const char *re);
extern ur_list_t     ur_mail_headers(ur_mail_t mail);
extern const char    *ur_mail_header_find(ur_mail_t mail, const char *name,
                                        int idx);
extern const void    *ur_mail_body(ur_mail_t mail, unsigned long *len);
extern int           ur_mail_parts(ur_mail_t mail);
extern const void    *ur_mail_part(ur_mail_t mail, int part, unsigned long *len);

                                /* ngram support */
typedef struct ur_ngram_s *ur_ngram_t;
typedef enum {
    UR_NGRAM_MATCHES,
    UR_NGRAM_DOT,
    UR_NGRAM_COSINE
}                        ur_ngram_alg_t;

extern ur_ngram_t    ur_ngram_create(int n);
extern unsigned long ur_ngram_destroy(ur_ngram_t ng);
extern void          ur_ngram_add(ur_ngram_t ng, const void *buf, int len);
extern void          ur_ngram_print(ur_ngram_t ng, FILE *stream);
extern double        ur_ngram_compare(ur_ngram_t a, ur_ngram_t b,
                                     ur_ngram_alg_t alg);
extern int           ur_ngram_put(ur_ngram_t ng, const char *filename);
extern ur_ngram_t    ur_ngram_get(const char *filename);

                                /* trigram support */
typedef struct ur_trigram_s *ur_trigram_t;
typedef enum {
    UR_TRIGRAM_MATCHES,
    UR_TRIGRAM_COSINE
}                        ur_trigram_alg_t;

extern ur_trigram_t  ur_trigram_create(void);
extern unsigned long ur_trigram_destroy(ur_trigram_t tg);
extern void          ur_trigram_add(ur_trigram_t tg, const void *buf, int len);
extern void          ur_trigram_print(ur_trigram_t tg, FILE *stream);
extern double        ur_trigram_compare(ur_trigram_t a, ur_trigram_t b,
                                     ur_trigram_alg_t alg);
extern int           ur_trigram_put(ur_trigram_t tg, const char *filename);
extern ur_trigram_t  ur_trigram_get(const char *filename);
extern void          ur_trigram_subtract(ur_trigram_t a, ur_trigram_t b);
extern unsigned long ur_trigram_matches(ur_trigram_t a, ur_trigram_t b);

                                /* network support */
typedef struct ur_net_s *ur_net_t;

typedef enum {
    UR_NET_IN   = 0x01,
    UR_NET_OUT  = 0x02,
    UR_NET_ERR  = 0x04,
    UR_NET_HUP  = 0x08,
    UR_NET_NVAL = 0x10
} ur_net_event_t;

typedef int (*ur_net_callback_t)(int fd, ur_net_event_t events, void *closure);

extern ur_net_t      ur_net_create(void);
extern unsigned long ur_net_destroy(ur_net_t net);
extern void          ur_net_add_port(ur_net_t net, int port,
                                   ur_net_callback_t cb, void *closure);
extern void          ur_net_del_port(ur_net_t net, int port);
extern void          ur_net_add_fd(ur_net_t net, int fd,
                                 ur_net_callback_t cb, void *closure);
extern void          ur_net_del_fd(ur_net_t net, int fd);
extern void          ur_net_set_read(ur_net_t net, int fd);
extern void          ur_net_set_write(ur_net_t net, int fd);
extern void          ur_net_set_read_write(ur_net_t net, int fd);
extern void          ur_net_server(ur_net_t net);

                                /* networking helper functions */
extern int           ur_net_open_tcp(int port);

                                /* reference counting buffers */
typedef struct ur_r_c_s *ur_r_c_t;
extern ur_r_c_t       ur_r_c_create(void);
                                /* buffered i/o */
typedef struct ur_buf_s *ur_buf_t;

extern ur_buf_t      ur_buf_create(void);
extern unsigned long ur_buf_destroy(ur_buf_t buf);
extern int           ur_buf_read(ur_buf_t buf, int fd, int len);
extern int           ur_buf_write(ur_buf_t buf, int fd, int len);
extern ur_buf_t      ur_buf_get_line(ur_buf_t buf);
extern void          ur_buf_iterator_init(ur_buf_t buf, ur_iterator_t iter,
                                        const char *delim, const char *quote,
                                        const char *escape);
extern ur_buf_t      ur_buf_iterator_string(ur_iterator_t iter);
extern void          ur_buf_iterator_next(ur_iterator_t iter);
extern void          ur_buf_free(ur_buf_t buf);
extern void          ur_buf_append(ur_buf_t buf, ur_buf_t s);
extern void          ur_buf_append_s(ur_buf_t buf, const char *s);
extern void          ur_buf_append_s_n(ur_buf_t buf, const char *s, int len);
extern void          ur_buf_printf(ur_buf_t buf, const char *format, ...);

#define UR_BUF_INIT(N,I,D,Q,E) ur_buf_iterator_init(L,&(I),(D),(Q),(E))
#define UR_BUF_GET(I,S)        ((S) = ur_buf_iterator_string(&(I)))
#define UR_BUF_NEXT(I)         ur_buf_iterator_next(&(I))
#define UR_BUF_ITERATE(B,I,D,S) \
    for (UR_BUF_INIT(B,I,D); UR_BUF_GET(I,S); UR_BUF_NEXT(I))

typedef enum {
	UR_PR_USE_STDIN        = 0x00000001,
	UR_PR_USE_STDOUT       = 0x00000002,
	UR_PR_USE_STDERR       = 0x00000004,
	UR_PR_CREATE_STDIN     = 0x00000010,
	UR_PR_CREATE_STDOUT    = 0x00000020,
	UR_PR_CREATE_STDERR    = 0x00000040,
	UR_PR_STDERR_TO_STDOUT = 0x00000100
} ur_pr_flags_t;

extern int  ur_pr_open(const char *command, ur_pr_flags_t flags,
		       int *infd, int *outfd, int *errfd);
extern int  ur_pr_close_nowait(int fd);
extern int  ur_pr_close(int fd);
extern int  ur_pr_wait(int pid);
extern void ur_pr_shutdown(void);
extern int  ur_pr_spawn(const char *command);
extern int  ur_pr_readwrite(int in, int out,
			    const char *inBuffer, int inLen,
			    char *outBuffer, int outMaxLen);
extern int ur_pr_filter(const char *command,
			const char *inBuffer, int inLen,
			char *outBuffer, int outMaxLen);


typedef struct ur_proc_s *ur_proc_t;
typedef struct ur_msg_s *ur_msg_t;
typedef struct ur_msg_recv_s *ur_msg_recv_t;

typedef int ur_proc_work_t(ur_msg_t msg, int type, void *buf, int length,
			   void *arg);
typedef int ur_proc_cleanup_t(pid_t pid, int status, int err, void *arg);
typedef int ur_proc_abort_t(pid_t pid, void *arg);
extern ur_proc_t     ur_proc_create(ur_proc_work_t work, void *work_arg,
				    ur_proc_cleanup_t cleanup,
				    void *cleanup_arg,
				    ur_proc_abort_t abort,
				    void *abort_arg);
extern void          ur_proc_destroy(ur_proc_t proc);
extern void          ur_proc_destroy_all(void);
extern pid_t         ur_proc_pid(ur_proc_t proc);

extern ur_msg_t      ur_msg_create(void);
extern unsigned long ur_msg_destroy(ur_msg_t msg);
extern ur_msg_t      ur_msg_send(ur_proc_t proc, int type,
				 void *buf, size_t len, int flags);

extern ur_msg_recv_t ur_msg_recv_create(int fd);
extern ur_msg_t      ur_msg_recv(ur_msg_recv_t state,
				 void *buf, size_t len, int flags);
extern void          ur_msg_recv_destroy(ur_msg_recv_t state);

extern int           ur_msg_reply(ur_msg_t msg, void *buf, size_t len,
				  int flags);
extern ur_msg_t      ur_msg_wait(ur_msg_t msg, void *buf, size_t len,
				 int flags);
extern int           ur_msg_poll(ur_msg_t *msgs, int count);
extern unsigned long ur_msg_length(ur_msg_t msg);
extern unsigned long ur_msg_sequence(ur_msg_t msg);
extern uint64_t      ur_msg_time_sent(ur_msg_t msg);
extern uint64_t      ur_msg_time_received(ur_msg_t msg);
extern uint64_t      ur_msg_time_replied(ur_msg_t msg);

enum {
	UR_MSG_REPLY = -1,
	UR_MSG_PING  = -2,
	UR_MSG_START = -3,
};

#define UR_MSG_MAX_SIZE (1024*64)

typedef struct ur_elf_s *ur_elf_t;
extern ur_elf_t ur_elf_create(const char *filename);

typedef struct ur_parse_s *ur_parse_t;
extern ur_parse_t    ur_parse_create(void);
extern unsigned long ur_parse_destroy(ur_parse_t parse);
extern void          ur_parse_filter_add(ur_parse_t parse, const char *filter);
extern void          ur_parse_item_add(ur_parse_t parse, const char *item);
extern ur_list_t     ur_parse(ur_parse_t parse, const char *string,
			      int *v0, const char **v1);
extern void          ur_parse_attribute_int(ur_parse_t parse, int v0);
extern void          ur_parse_attribute_string(ur_parse_t parse,
					       const char *v1);
extern int           ur_parse_get_attribute_int(ur_parse_t parse, int filter);
extern const char    *ur_parse_get_attribute_string(ur_parse_t parse,
						    int filter);
extern const char    *ur_parse_get_filter(ur_parse_t parse, int filter);
extern const char    *ur_parse_get_item(ur_parse_t parse, int filter,
					int item);

typedef struct ur_id3_s *ur_id3_t;
typedef struct ur_id3_custom_s *ur_id3_custom_t;

typedef enum {
	UR_ID3_UNKNOWN,
	UR_ID3_PATH,
	UR_ID3_V1,
	UR_ID3_V1_1,
	UR_ID3_V1_AUGMENTED,
	UR_ID3_V1_1_AUGMENTED,
	UR_ID3_LYRICS3_V2,
	UR_ID3_LYRICS3_V2_AUGMENTED,
	UR_ID3_V2_UNKNOWN,
	UR_ID3_V2_2,
	UR_ID3_V2_3,
	UR_ID3_V2_4,
	UR_ID3_WEBSTREAM,
} ur_id3_source_t;

typedef enum {
	UR_ID3_MPEG_V_UNKNOWN,
	UR_ID3_MPEG_V2_5,
	UR_ID3_MPEG_V2,
	UR_ID3_MPEG_V1
} ur_id3_mpeg_version_t;

typedef enum {
	UR_ID3_MPEG_L_UNKNOWN,
	UR_ID3_MPEG_L_III,
	UR_ID3_MPEG_L_II,
	UR_ID3_MPEG_L_I
} ur_id3_mpeg_layer_t;

typedef enum {
	UR_ID3_MPEG_UNKNOWN,
	UR_ID3_MPEG_STEREO,
	UR_ID3_MPEG_JOINT_STEREO,
	UR_ID3_MPEG_DUAL,
	UR_ID3_MPEG_MONO
} ur_id3_mpeg_mode_t;

typedef enum {
	UR_ID3_READ_V1     = 0x0001,
	UR_ID3_READ_V2     = 0x0002,
	UR_ID3_READ_MP3    = 0x0003,
	UR_ID3_READ_BEST   = 0x0004,
	UR_ID3_READ_CUSTOM = 0x0005,
	UR_ID3_READ_MASK   = 0x000f,
	UR_ID3_READ_DIRECT = 0x1000
} ur_id3_read_t;

extern void           ur_id3_shutdown(void);
extern ur_id3_t       ur_id3_create(void);
extern ur_id3_t       ur_id3_read(const char *filename, ur_id3_read_t flags,
				  ur_parse_t p);
extern unsigned long  ur_id3_destroy(ur_id3_t e);
extern void           ur_id3_print(ur_id3_t e, FILE *str, bool mpeg);
extern int            ur_id3_pack(ur_id3_t e, char *buf, int len);
extern ur_id3_t       ur_id3_unpack(char *buf, int len);
extern int            ur_id3_utf8ify(char *dest, const char *src, int n);
extern int            ur_id3_searchify(char *dest, const char *src);
extern void           ur_id3_search_compute(ur_id3_t e);
extern void           ur_id3_canonify(ur_id3_t e);

extern bool           ur_id3_valid(ur_id3_t e);
extern const char     *ur_id3_source(ur_id3_t e);
extern const char     *ur_id3_filename(ur_id3_t e);
extern const char     *ur_id3_title(ur_id3_t e);
extern const char     *ur_id3_artist(ur_id3_t e);
extern const char     *ur_id3_album(ur_id3_t e);
extern const char     *ur_id3_year(ur_id3_t e);
extern int            ur_id3_track(ur_id3_t e);
extern const char     *ur_id3_track_string(ur_id3_t e);
extern const char     *ur_id3_mpeg_version(ur_id3_t e);
extern const char     *ur_id3_mpeg_layer(ur_id3_t e);
extern const char     *ur_id3_mpeg_mode(ur_id3_t e);
extern int            ur_id3_mpeg_sample_rate(ur_id3_t e);
extern int            ur_id3_mpeg_cbr(ur_id3_t e);
extern int            ur_id3_mpeg_vbr(ur_id3_t e);
extern int            ur_id3_mpeg_duration(ur_id3_t e);
extern const char     *ur_id3_duration_string(ur_id3_t e);
extern const char     *ur_id3_rate_string(ur_id3_t e);
extern const char     *ur_id3_search(ur_id3_t e);
extern int            ur_id3_iattr(ur_id3_t e);
extern const char     *ur_id3_sattr(ur_id3_t e);
extern int            ur_id3_current_playtime(ur_id3_t e);
extern time_t         ur_id3_current_starttime(ur_id3_t e);

extern void ur_id3_set_valid(ur_id3_t e, bool);
extern void ur_id3_set_source(ur_id3_t e, ur_id3_source_t);
extern void ur_id3_set_filename(ur_id3_t e, const char *);
extern void ur_id3_set_title(ur_id3_t e, const char *);
extern void ur_id3_set_artist(ur_id3_t e, const char *);
extern void ur_id3_set_album(ur_id3_t e, const char *);
extern void ur_id3_set_year(ur_id3_t e, const char *);
extern void ur_id3_set_track(ur_id3_t e, int);
extern void ur_id3_set_mpeg_version(ur_id3_t e, ur_id3_mpeg_version_t);
extern void ur_id3_set_mpeg_layer(ur_id3_t e, ur_id3_mpeg_layer_t);
extern void ur_id3_set_mpeg_mode(ur_id3_t e, ur_id3_mpeg_mode_t);
extern void ur_id3_set_mpeg_sample_rate(ur_id3_t e, int);
extern void ur_id3_set_mpeg_cbr(ur_id3_t e, int);
extern void ur_id3_set_mpeg_vbr(ur_id3_t e, int);
extern void ur_id3_set_mpeg_duration(ur_id3_t e, int);
extern void ur_id3_set_search(ur_id3_t e, const char *);
extern void ur_id3_set_current_playtime(ur_id3_t e, int playtime);

extern ur_id3_source_t       ur_id3_source_decode(const char *s);
extern ur_id3_mpeg_version_t ur_id3_mpeg_version_decode(const char *s);
extern ur_id3_mpeg_layer_t   ur_id3_mpeg_layer_decode(const char *);
extern ur_id3_mpeg_mode_t    ur_id3_mpeg_mode_decode(const char *s);

extern char           *ur_pack_int(char *buf, int *len, int value);
extern char           *ur_pack_time(char *buf, int *len, time_t value);
extern char           *ur_pack_string(char *buf, int *len, const char *value);
extern char           *ur_unpack_int(char *buf, int *len, int *value);
extern char           *ur_unpack_time(char *buf, int *len, time_t *value);
extern char           *ur_unpack_string(char *buf, int *len,
					const char **value);

#endif
