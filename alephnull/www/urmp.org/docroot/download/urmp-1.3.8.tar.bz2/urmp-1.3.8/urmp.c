/* urmp.c -- 
 * Created: Sat Sep 27 17:08:14 2008 by faith@acm.org
 * Revised: Mon Jul 20 11:57:34 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "urmpconfig.h"
#include "version.h"
#include <signal.h>
#include <sys/stat.h>
#include <pcre.h>

int                  urmp_proc_count  = URMP_PROC_COUNT;
int                  urmp_max_pathlen = URMP_MAX_PATHLEN;

static void urmp_dump_info(ur_list_t pathlist, ur_id3_read_t flags)
{
	const char  *path;
	ur_id3_t    e;
	struct stat st;
	bool        first = true;
	
	while ((path = ur_list_pop(pathlist))) {
		if (stat(path, &st)) {
			printf("Cannot stat: %s\n", path);
			continue;
		}
		if (!S_ISREG(st.st_mode)) {
			printf("Cannot handle: %s\n", path);
			continue;
		}
		e = ur_id3_read(path, UR_ID3_READ_BEST | flags,
				urmp_parse_augment);
		if (e) {
			if (!first) printf("==========\n");
			first = false;
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		} else {
			printf("Cannot parse: %s\n", path);
		}
	}
}

static void __attribute__((noreturn)) version(void)
{
	printf("urmp %d.%d.%d (%s)\n", URMP_MAJOR, URMP_MINOR, URMP_PATCH,
	       URMP_DATE);
	printf("Copyright (C) 2008 Rickard E. (Rik) Faith\n");
	printf("This is open source software,"
	       " released under the MIT License:\n");
	printf("http://opensource.org/licenses/mit-license.php\n");
	printf("There is NO WARRANTY, to the extent permitted by law\n");
	printf("\n");
	exit(0);
}

static void __attribute__((noreturn)) usage(void)
{
        ur_list_t  list;
        const char *str;

        printf("usage: %s [OPTION] [PATHS]\n", ur_program_name());
	printf("\nCommon options:\n");
	printf("  -b, --build      Build using PATHS\n");
	printf("  -i, --ignore     Do not read the existing database\n");
	printf("                   The default database is %s/%s\n",
	       URMP_DEFAULT_CONFIG, URMP_DEFAULT_DB);
	printf("  -n, --dry-run    Do not write a new database\n");
	printf("  -g, --gui        Start gui\n");
	printf("  --default        Do not read existing config file\n");
	printf("                   The default config file is %s/%s\n",
	       URMP_DEFAULT_CONFIG, URMP_DEFAULT_RC);
	printf("\nLess common options:\n");
	printf("  --help           Display this help and exit\n");
	printf("  --version        Display version & copyright information\n");
	printf("  -c, --config     DIRECTORY for configuration information\n");
	printf("                   The default DIRECTORY is %s\n",
	       URMP_DEFAULT_CONFIG);
	printf("  --procs          Run with NUM processes when building\n");
	printf("  --nommap         Use mmap'd file I/O\n");
	printf("  --directio       Use direct I/O (requires --nommap)n");
	printf("\nDebuging options:\n");
	printf("  --info           Print best id3 information for PATHS\n");
	printf("  --parse          Debug id3 parsing for FILE\n");
	printf("  --rewrite        Debug reading adn writing database\n");
	printf("  -t, --trace      TRACE-LIST is a list of trace names:\n");
        if ((list = ur_trace_names())) {
		int i = 0;
                while ((str = ur_list_pop(list))) {
			if (!i) {
				printf("                   %s", str);
			} else {
				printf(" %s", str);
			}
			if (++i > 3) {
				printf("\n");
				i = 0;
			}
                }
		if (i) printf("\n");
        }
	printf("  -d, --debug      DEBUG-LIST is a list of debug names:\n");
        if ((list = ur_debug_names())) {
		int i = 0;
                while ((str = ur_list_pop(list))) {
			if (!i) {
				printf("                   %s", str);
			} else {
				printf(" %s", str);
			}
			if (++i > 3) {
				printf("\n");
				i = 0;
			}
                }
		if (i) printf("\n");
        }
	
        exit(1);
}

static void urmp_trailer(void)
{
	ur_log_backtrace("Urmp Version:      urmp %d.%d.%d (%s)\n",
			 URMP_MAJOR, URMP_MINOR, URMP_PATCH, URMP_DATE);
	ur_log_backtrace("PCRE Version:      %s\n", pcre_version());
	urmp_gui_trailer();
}

static void __attribute__((noreturn)) urmp_handler(int sig)
{
	ur_trace(URMP_TRACE_HANDLER, __func__,
		 "%d:caught sig(%d)=%s, terminating\n",
		 getpid(), sig, ur_signal_name(sig));
	ur_proc_destroy_all();
	exit(0);
}

static void urmp_init(void)
{
	int              sig[] = { SIGHUP, SIGINT, SIGQUIT, SIGILL,
				   SIGBUS, SIGFPE, SIGSEGV, SIGTERM };
	size_t           i;
	struct sigaction a;

	for (i = 0; i < sizeof(sig)/sizeof(sig[0]); i++) {
		memset(&a, 0, sizeof(a));
		a.sa_handler = urmp_handler;
		sigemptyset(&a.sa_mask);
		sigaddset(&a.sa_mask, sig[i]);
		sigaction(sig[i], &a, NULL);
	}
}

int main(int argc, const char **argv)
{
	bool             do_gui       = false;
	bool             do_ignore    = false;
	bool             do_dry_run   = false;
	bool             do_rewrite   = false;
	bool             use_defaults = false;
	bool             do_build     = false;
	bool             do_info      = false;
	ur_list_t        pathlist     = NULL;
	int              c;
	const char       *str;
	const char       *config      = NULL;
	const char       *parsefile   = NULL;
	ur_id3_read_t    flags;
	ur_option_t      opt;
	ur_option_list_t optlist[] = {
		{ "build",   'b', UR_OPTION_NONE },
		{ "gui",     'g', UR_OPTION_NONE },
		{ "trace",   't', UR_OPTION_LIST },
		{ "debug",   'd', UR_OPTION_LIST },
		{ "config",  'c', UR_OPTION_ARG  },
		{ "ignore",  'i', UR_OPTION_NONE },
		{ "dry-run", 'n', UR_OPTION_NONE },
		{ "help",    500, UR_OPTION_NONE },
		{ "version", 501, UR_OPTION_NONE },
		{ "procs",   502, UR_OPTION_ARG  },
		{ "parse",   503, UR_OPTION_ARG  },
		{ "info",    504, UR_OPTION_NONE },
		{ "default", 505, UR_OPTION_NONE },
		{ "rewrite", 506, UR_OPTION_NONE },
		{ "directio",507, UR_OPTION_NONE },
		{ "nommap",  508, UR_OPTION_NONE },
		{ NULL, 0, 0 },
	};

	ur_init(argv[0]);
	urmp_init();
	ur_add_trailer(urmp_trailer);
	ur_trace_register(URMP_TRACE_CONFIG,    "config");
	ur_trace_register(URMP_TRACE_BUILD,     "build");
	ur_trace_register(URMP_TRACE_PROC,      "proc");
	ur_trace_register(URMP_TRACE_MSG,       "msg");
	ur_trace_register(URMP_TRACE_STACK,     "stack");
	ur_trace_register(URMP_TRACE_WORKER,    "worker");
	ur_trace_register(URMP_TRACE_ID3ERR,    "id3err");
	ur_trace_register(URMP_TRACE_PLAYER,    "player");
	ur_trace_register(URMP_TRACE_PLAYERINT, "playerint");
	ur_trace_register(URMP_TRACE_SLAVE,     "slave");
	ur_trace_register(URMP_TRACE_SWITCH,    "switch");
	ur_trace_register(URMP_TRACE_RANDOM,    "random");
	ur_trace_register(URMP_TRACE_EVENTS,    "events");
	ur_trace_register(URMP_TRACE_SEARCH,    "search");
	ur_trace_register(URMP_TRACE_PLAYLIST,  "playlist");
	ur_trace_register(URMP_TRACE_HANDLER,   "handler");
	ur_trace_register(URMP_TRACE_SCROB,     "scrob");
	ur_trace_register(URMP_TRACE_LYRICS,    "lyrics");
	ur_trace_register(URMP_TRACE_REINIT,    "reinit");

	flags = UR_ID3_READ_MMAP;

	opt = ur_option_create(optlist);
	ur_option_parse_argv(opt, argc, argv);
	while ((c = ur_option_get(opt)) != EOF) {
		switch (c) {
		case 'b':
			do_build = true;
			break;
		case 't':
		{
			ur_list_t list;
			list = ur_option_list(opt, NULL);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_trace_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		}
		case 'd':
		{
			ur_list_t list;
			list = ur_option_list(opt, NULL);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_debug_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		}
		case 'i':
			do_ignore = true;
			break;
		case 'n':
			do_dry_run = true;
			break;
		case 'g':
			do_gui = true;
			break;
		case 'c':
			config = ur_option_string(opt);
			break;
		case 508:
			flags &= ~UR_ID3_READ_MMAP;
			break;
		case 507:
			flags |= UR_ID3_READ_DIRECT;
			break;
		case 506:
			do_rewrite = true;
			break;
		case 505:
			use_defaults = true;
			break;
		case 504:
			do_info = true;
			break;
		case 503:
			parsefile = ur_option_string(opt);
			break;
		case 502:
			urmp_proc_count = ur_option_int(opt);
			break;
		case 501:
			version();
		case 500:
		default:
			usage();
		}
	}

	if (do_build || do_info) pathlist = ur_option_other(opt, NULL);

	urmp_config_setup(config, use_defaults);

	if (parsefile) {
		ur_id3_t e;

		ur_trace_set_by_name("ur-id3", NULL);
		ur_trace_set_by_name("ur-parse", NULL);

		printf("===== Reading id3v1 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_V1 | flags, NULL);
		if (e) {
			ur_id3_print(e, stdout, false);
			ur_id3_destroy(e);
		}

		printf("===== Reading id3v2 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_V2 | flags, NULL);
		if (e) {
			ur_id3_print(e, stdout, false);
			ur_id3_destroy(e);
		}

		printf("===== Reading mp3 information =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_MP3 | flags, NULL);
		if (e) {
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		}

		printf("===== Parsing =====\n");
		e = ur_id3_read(parsefile, UR_ID3_READ_CUSTOM | flags,
				urmp_parse_augment);
		if (e) {
			ur_id3_print(e, stdout, true);
			ur_id3_destroy(e);
		}
		
		return 0;
	}

	if (do_dry_run) urmp_config_readonly();

	if (!do_build && !do_info && !do_gui && !do_rewrite) usage();

	if ((do_build || do_info) && !pathlist) usage();

	if (!do_build && !do_info && pathlist) usage();

	if (do_build && do_info) {
		printf("--build not compatible with --info\n");
		usage();
	}

	if (do_info) {
		urmp_dump_info(pathlist, flags);
		return 0;
	}

	if (do_rewrite) {
		if (do_ignore || do_gui) {
			printf("--rewrite not compatible with"
			       " --build and/or --gui\n");
			usage();
		}
		urmp_read_db();
		urmp_write_db();
		return 0;
	}

	if (!do_ignore) urmp_read_db();

	if (do_build) {
		int i;

		for (i = 0; i < URMP_ARCHIVE_ROOTS; i++)
			urmp_config_set_archive_root(NULL, i);
		for (i = 1; i <= ur_list_depth(pathlist); i++)
			urmp_config_set_archive_root(ur_list_nth(pathlist, i),
						     i-1);
		urmp_db_set_keep_existing(false);
		urmp_db_build(flags);
		if (!do_dry_run) urmp_write_db();
	}

	if (do_gui) {
		if (do_dry_run) {
			printf("--dry-run not compatible with --gui\n");
			usage();
		}
		urmp_player_start();
		urmp_gui(&argc, &argv);
	}

	if (pathlist) ur_list_destroy(pathlist);
	return 0;
}
