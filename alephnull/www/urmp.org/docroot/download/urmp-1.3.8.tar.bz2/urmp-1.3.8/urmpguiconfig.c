/* urmpgui.c -- 
 * Created: Sat Sep 27 17:08:37 2008 by faith@acm.org
 * Revised: Sun Jul 19 11:19:18 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#define _GNU_SOURCE
#include "urmpgui.h"
#include "urmpguiconfig.h"
#include "urmpmodel.h"
#include "urmpconfig.h"
#include "urmpplaylist.h"
#include "urmphook.h"
#include "version.h"
#include <string.h>
#include <sys/stat.h>
#include <gdk/gdkkeysyms.h>

typedef struct {
	GtkWidget *cb_time;
	GtkWidget *cb_count;
	GtkWidget *cb_elapsed;
	GtkWidget *cb_rate;
	GtkWidget *cb_launched;
	GtkWidget *cb_new;
	GtkWidget *cb_updated;
	GtkWidget *cb_skipped;
} urmp_gui_callback_t;

typedef enum {
	URMP_E_LASTFM_USERNAME,
	URMP_E_LASTFM_PASSWORD,
	URMP_E_LASTFM_NOWPLAYING,
	URMP_E_LASTFM_SCROBBLING,
	URMP_E_LASTFM_STORE_PASSWORD,
	URMP_E_LYRICS_LYRICWIKI,
	URMP_E_LYRICS_LYRICSFLY,
	URMP_E_LYRICS_FILES,
	URMP_E_LYRICS_SQL,
	URMP_E_ARCHIVE_ROOT,
	URMP_E_REBUILD,
	URMP_E_UPDATE,
	URMP_E_HALT,
} urmp_gui_config_type_t;

typedef struct {
	urmp_gui_config_type_t type;
	int                    idx;
} urmp_gui_config_button_t;

#define URMP_GUI_MAX_SENSITIVE 10

typedef enum {
	URMP_GUI_GROUP_INPUT,
	URMP_GUI_GROUP_STATUS,
	URMP_GUI_GROUPS		/* Must be last */
} urmp_gui_sensitive_group_t;

static GtkWidget *urmp_gui_sensitives[URMP_GUI_GROUPS][URMP_GUI_MAX_SENSITIVE];
static int       urmp_gui_sensitive_count[URMP_GUI_GROUPS];

static void urmp_gui_add_sensitive(GtkWidget *widget,
				   urmp_gui_sensitive_group_t group)
{
	if (group >= URMP_GUI_GROUPS) {
		ur_fatal(__func__, "Group %d out of range 0-%d\n",
			 group, URMP_GUI_GROUPS-1);
	}
	if (urmp_gui_sensitive_count[group] >= URMP_GUI_MAX_SENSITIVE) {
		ur_fatal(__func__,
			 "Too many slots in use for group %d\n", group);
	}
	    
	urmp_gui_sensitives[group][urmp_gui_sensitive_count[group]++] = widget;
}

static void urmp_gui_set_sensitive(bool sensitive,
				   urmp_gui_sensitive_group_t group)
{
	int i;

	if (group >= URMP_GUI_GROUPS) {
		ur_fatal(__func__, "Group %d out of range 0-%d\n",
			 group, URMP_GUI_GROUPS-1);
	}
	for (i = 0; i < urmp_gui_sensitive_count[group]; i++) {
		gtk_widget_set_sensitive(urmp_gui_sensitives[group][i],
					 sensitive);
	}
}

static void urmp_gui_config_add_pair(GtkWidget *box, GtkWidget *widget,
				     const char *text)
{
	GtkWidget     *label;
	GtkWidget     *hbox;

	hbox = gtk_hbox_new(FALSE, 1);

	if (text) {
		label = gtk_label_new(text ? text : " ");
		gtk_label_set_width_chars(GTK_LABEL(label), 20);
		gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
		gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
		gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
	}
	if (GTK_IS_LABEL(widget)) {
		gtk_box_pack_start(GTK_BOX(hbox), widget, FALSE, FALSE, 0);
		gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 0);
	} else {
		gtk_box_pack_start(GTK_BOX(hbox), widget, TRUE, TRUE, 0);
		gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 0);
	}
}

static void urmp_gui_config_toggle(GtkToggleButton *button,
				   gpointer data)
{
	urmp_gui_config_button_t *bdata = (urmp_gui_config_button_t *)data;
	urmp_gui_config_type_t   entry = bdata->type;
	bool                     value;

	value = gtk_toggle_button_get_active(button);
	switch (entry) {
	case URMP_E_LASTFM_NOWPLAYING:
		urmp_config_set_lastfm_nowplaying(value);
		break;
	case URMP_E_LASTFM_SCROBBLING:
		urmp_config_set_lastfm_scrobbling(value);
		break;
	case URMP_E_LASTFM_STORE_PASSWORD:
		urmp_config_set_lastfm_store_password(value);
		break;
	case URMP_E_LYRICS_LYRICWIKI:
		urmp_config_set_lyrics_lyricwiki(value);
		break;
	case URMP_E_LYRICS_LYRICSFLY:
		urmp_config_set_lyrics_lyricsfly(value);
		break;
	default:
		ur_fatal(__func__, "Have entry type %d\n", entry);
	}
}

static void urmp_gui_callback(urmp_db_status_t *db, void *data)
{
	urmp_gui_callback_t *cbdata = (urmp_gui_callback_t *)data;
	char                buf[256];

	if (db) {
		time_t now;
		int hours, mins, secs;

		time(&now);

		snprintf(buf, sizeof(buf)-1, "%-24.24s", ctime(&now));
		gtk_label_set_text(GTK_LABEL(cbdata->cb_time), buf);

		snprintf(buf, sizeof(buf)-1, "%d", db->db_count);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_count), buf);

		hours = db->db_secs / 3600;
		mins  = (db->db_secs - (hours * 3600)) / 60;
		secs  = (db->db_secs - (hours * 3600) - (mins * 60));
		snprintf(buf, sizeof(buf)-1, "%02d:%02d:%02d",
			 hours, mins, secs);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_elapsed), buf);

		snprintf(buf, sizeof(buf)-1, "%0.1f files/s", db->db_rate);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_rate), buf);

		snprintf(buf, sizeof(buf)-1, "%d", db->db_launched);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_launched), buf);

		snprintf(buf, sizeof(buf)-1, "%d", db->db_new);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_new), buf);

		snprintf(buf, sizeof(buf)-1, "%d", db->db_updated);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_updated), buf);

		snprintf(buf, sizeof(buf)-1, "%d", db->db_skipped);
		gtk_label_set_text(GTK_LABEL(cbdata->cb_skipped), buf);

	}

	while (g_main_context_iteration(NULL, FALSE))
		;
}

static void urmp_gui_config_button(GtkButton *button _unused,
				   gpointer data)
{
	urmp_gui_config_button_t *bdata = (urmp_gui_config_button_t *)data;
	urmp_gui_config_type_t   entry = bdata->type;

	switch (entry) {
	case URMP_E_REBUILD:
		urmp_db_set_keep_existing(false);
		break;
	case URMP_E_UPDATE:
		urmp_db_set_keep_existing(true);
		break;
	case URMP_E_HALT:
		break;
	default:
		ur_fatal(__func__, "Have entry type %d\n", entry);
	}

	urmp_gui_set_sensitive(URMP_GUI_GROUP_INPUT, false);
	urmp_gui_set_sensitive(URMP_GUI_GROUP_STATUS, true);
	urmp_db_build(UR_ID3_READ_MMAP);
	urmp_write_db();
	urmp_gui_set_sensitive(URMP_GUI_GROUP_STATUS, false);
	urmp_gui_set_sensitive(URMP_GUI_GROUP_INPUT, true);
}

static void urmp_gui_config_entry(GtkEditable *editable, gpointer data)
{
	urmp_gui_config_button_t *bdata = (urmp_gui_config_button_t *)data;
	urmp_gui_config_type_t   entry = bdata->type;
	const char               *value;
	struct stat              sb;
	GdkColor                 color;

	value = gtk_entry_get_text(GTK_ENTRY(editable));
	switch (entry) {
	case URMP_E_LASTFM_USERNAME:
		urmp_config_set_lastfm_username(value);
		break;
	case URMP_E_LASTFM_PASSWORD:
		urmp_config_set_lastfm_password(value);
		break;
	case URMP_E_LYRICS_FILES:
		urmp_config_set_lyrics_tree(value);
		break;
	case URMP_E_LYRICS_SQL:
		urmp_config_set_lyrics_sql(value);
		break;
	case URMP_E_ARCHIVE_ROOT:
		if (!stat(value, &sb) && S_ISDIR(sb.st_mode)) {
			gdk_color_parse("darkgreen", &color);
			urmp_config_set_archive_root(value, bdata->idx);
		} else {
			gdk_color_parse("red", &color);
			urmp_config_set_archive_root(NULL, bdata->idx);
		}
  	        gtk_widget_modify_text(GTK_WIDGET(editable),
				       GTK_STATE_NORMAL, &color);
		break;
	default:
		ur_fatal(__func__, "Have entry type %d\n", entry);
	}
}

static GtkWidget *urmp_gui_config_add_entry(GtkWidget *parent,
					    const char *text,
					    const char *initial,
					    urmp_gui_config_type_t type,
					    int idx)
{
	GtkWidget                *entry;
	urmp_gui_config_button_t *bdata;

	bdata = ur_alloc(sizeof(*bdata)); /* FIXME - never freed */
	bdata->type = type;
	bdata->idx  = idx;

	entry = gtk_entry_new();
	if (initial) gtk_entry_set_text(GTK_ENTRY(entry), initial);
	g_signal_connect(G_OBJECT(entry), "changed",
			 G_CALLBACK(urmp_gui_config_entry),
			 (gpointer)bdata);
	urmp_gui_config_add_pair(parent, entry, text);

	return entry;
}

static GtkWidget *urmp_gui_config_add_toggle(GtkWidget *parent,
					     const char *text,
					     bool initial,
					     urmp_gui_config_type_t type)
{
	GtkWidget                *toggle;
	urmp_gui_config_button_t *bdata;

	bdata = ur_alloc(sizeof(*bdata)); /* FIXME - never freed */
	bdata->type = type;
	bdata->idx  = 0;

	toggle = gtk_check_button_new_with_label(text);
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggle), initial);
	g_signal_connect(G_OBJECT(toggle), "toggled",
			 G_CALLBACK(urmp_gui_config_toggle),
			 (gpointer)bdata);
	urmp_gui_config_add_pair(parent, toggle, NULL);
	return toggle;
}

static GtkWidget *urmp_gui_config_add_button(GtkWidget *parent,
					     const char *text,
					     urmp_gui_config_type_t type)
{
	GtkWidget                *button;
	urmp_gui_config_button_t *bdata;

	bdata = ur_alloc(sizeof(*bdata)); /* FIXME - never freed */
	bdata->type = type;
	bdata->idx  = 0;

	button = gtk_button_new_with_label(text);
	g_signal_connect(G_OBJECT(button), "clicked",
			 G_CALLBACK(urmp_gui_config_button),
			 (gpointer)bdata);
	urmp_gui_config_add_pair(parent, button, NULL);
	return button;
}

static void urmp_gui_config_build_database(urmp_gui_status_t *status)
{
	GtkWidget           *label;
 	GtkWidget           *vbox, *vbox_top, *vbox_mid, *vbox_bot;
	GtkWidget           *tmp;
	urmp_gui_callback_t *cbdata;

	label    = gtk_label_new("database");
	vbox     = gtk_vbox_new(FALSE, 15);
	vbox_top = gtk_vbox_new(FALSE, 3);
	vbox_mid = gtk_vbox_new(FALSE, 3);
	vbox_bot = gtk_vbox_new(FALSE, 3);
	gtk_box_pack_start(GTK_BOX(vbox), vbox_top, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(vbox), vbox_mid, FALSE, FALSE, 0);
	gtk_box_pack_start(GTK_BOX(vbox), vbox_bot, FALSE, FALSE, 0);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	for (int i = 0; i < URMP_ARCHIVE_ROOTS; i++) {
		tmp = urmp_gui_config_add_entry(
			vbox_top,
			"Archive root",
			urmp_config_get_archive_root(i),
			URMP_E_ARCHIVE_ROOT,
			i);
		urmp_gui_add_sensitive(tmp, URMP_GUI_GROUP_INPUT);
	}

	tmp = urmp_gui_config_add_button(vbox_mid,
					 "Rebuild whole database",
					 URMP_E_REBUILD);
	urmp_gui_add_sensitive(tmp, URMP_GUI_GROUP_INPUT);

	tmp = urmp_gui_config_add_button(vbox_mid,
					 "Update existing database",
					 URMP_E_UPDATE);
	urmp_gui_add_sensitive(tmp, URMP_GUI_GROUP_INPUT);

#if 0
	tmp = urmp_gui_config_add_button(vbox_mid,
					 "Halt rebuild",
					 URMP_E_HALT);
	urmp_gui_add_sensitive(tmp, URMP_GUI_GROUP_STATUS);
#endif

	cbdata = ur_allocz(sizeof(* cbdata)); /* XXX FIXME Never freed */

	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_time = gtk_label_new(""),
				 "Current time");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_count = gtk_label_new(""),
				 "Total files available");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_elapsed = gtk_label_new(""),
				 "Indexing time");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_rate = gtk_label_new(""),
				 "Indexing rate");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_launched = gtk_label_new(""),
				 "Total files examined");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_new = gtk_label_new(""),
				 "New files");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_updated = gtk_label_new(""),
				 "Updated files");
	urmp_gui_config_add_pair(vbox_bot,
				 cbdata->cb_skipped = gtk_label_new(""),
				 "Skipped files");
				 
	urmp_gui_add_sensitive(cbdata->cb_time, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_count, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_elapsed, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_rate, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_launched, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_new, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_updated, URMP_GUI_GROUP_STATUS);
	urmp_gui_add_sensitive(cbdata->cb_skipped, URMP_GUI_GROUP_STATUS);

	urmp_db_register_callback(urmp_gui_callback, cbdata);
}

static void urmp_gui_config_build_lastfm(urmp_gui_status_t *status)
{
	GtkWidget     *label;
	GtkWidget     *vbox;

	label = gtk_label_new("last.fm");
	vbox  = gtk_vbox_new(FALSE, 3);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	urmp_gui_config_add_toggle(
		vbox, 
		"Do last.fm now-playing notification?",
		urmp_config_get_lastfm_nowplaying(),
		URMP_E_LASTFM_NOWPLAYING);

	urmp_gui_config_add_toggle(
		vbox, 
		"Do last.fm audio scrobbling?",
		urmp_config_get_lastfm_scrobbling(),
		URMP_E_LASTFM_SCROBBLING);

	urmp_gui_config_add_toggle(
		vbox, 
		"Save last.fm password (stored as cleartext)?",
		urmp_config_get_lastfm_scrobbling(),
		URMP_E_LASTFM_STORE_PASSWORD);

	urmp_gui_config_add_entry(vbox, "Username",
				  urmp_config_get_lastfm_username(),
				  URMP_E_LASTFM_USERNAME, 0);

	urmp_gui_config_add_entry(vbox, "Password",
				  urmp_config_get_lastfm_password(),
				  URMP_E_LASTFM_PASSWORD, 0);
}

static void urmp_gui_config_build_lyrics(urmp_gui_status_t *status)
{
	GtkWidget     *label;
	GtkWidget     *vbox;

	label = gtk_label_new("lyrics");
	vbox  = gtk_vbox_new(FALSE, 3);
	gtk_notebook_append_page(GTK_NOTEBOOK(status->config), vbox, label);

	urmp_gui_config_add_entry(vbox, "Path to lyrics file tree",
				  "*NOT IMPLEMENTED*",
				  URMP_E_LYRICS_FILES, 0);

	urmp_gui_config_add_entry(vbox, "Path to lyrics SQL dump",
				  "*NOT IMPLEMENTD*",
				  URMP_E_LYRICS_SQL, 0);

	urmp_gui_config_add_toggle(vbox,
				   "Get lyrics from lyricwiki.org?",
				   FALSE,
				   URMP_E_LYRICS_LYRICWIKI);

	urmp_gui_config_add_toggle(vbox,
				   "Get lyrics from lyricsfly.com?",
				   FALSE,
				   URMP_E_LYRICS_LYRICSFLY);
}

void urmp_gui_config_build(urmp_gui_status_t *status, GtkWidget *notebook)
{
	GtkWidget     *label;

	label    = gtk_label_new("Config");
	status->config = gtk_notebook_new();
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook),
				 status->config, label);

	urmp_gui_config_build_database(status);
	urmp_gui_config_build_lastfm(status);
	urmp_gui_config_build_lyrics(status);
}
