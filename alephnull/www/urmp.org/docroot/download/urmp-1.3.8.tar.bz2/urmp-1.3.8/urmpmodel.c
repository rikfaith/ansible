/* urmpmodel.c -- 
 * Created: Fri Dec  5 20:53:36 2008 by faith@acm.org
 * Revised: Sun Jul 19 12:17:48 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmpmodel.h"
#include "urmpgui.h"

static GObjectClass *parent_class = NULL;

static GtkTreeModelFlags urmp_model_get_flags(GtkTreeModel *tree_model)
{
	g_return_val_if_fail(URMP_MODEL_IS(tree_model), 0);
	return (GTK_TREE_MODEL_LIST_ONLY | GTK_TREE_MODEL_ITERS_PERSIST);
}

static gint urmp_model_get_n_columns(GtkTreeModel *tree_model)
{
	g_return_val_if_fail(URMP_MODEL_IS(tree_model), 0);
	return URMP_MODEL(tree_model)->n_columns;
}

static GType urmp_model_get_column_type(GtkTreeModel *tree_model, gint idx)
{
	g_return_val_if_fail(URMP_MODEL_IS(tree_model), G_TYPE_INVALID);
	g_return_val_if_fail(idx < URMP_MODEL(tree_model)->n_columns
			     && idx >= 0,
			     G_TYPE_INVALID);
	return URMP_MODEL(tree_model)->column_types[idx];
}

static gboolean urmp_model_get_iter(GtkTreeModel *tree_model,
				    GtkTreeIter *iter,
				    GtkTreePath *path)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;
	gint            *indices, n, depth;

	g_assert(URMP_MODEL_IS(tree_model));
	g_assert(path);

	m       = URMP_MODEL(tree_model);
	l       = m->list;
	indices = gtk_tree_path_get_indices(path);
	depth   = gtk_tree_path_get_depth(path);

	g_assert(depth == 1);
	n = indices[0];
	if (n >= l->count_filtered || n < 0) return FALSE;

	iter->stamp      = m->stamp;
	iter->user_data  = (gpointer)(intptr_t)n;
	iter->user_data2 = NULL;
	iter->user_data3 = NULL;
	return TRUE;
}

static GtkTreePath *urmp_model_get_path(GtkTreeModel *tree_model,
					GtkTreeIter *iter)
{
	GtkTreePath     *path;
	urmp_model_t    *m;
	urmp_gui_list_t *l;

	g_return_val_if_fail(URMP_MODEL_IS(tree_model), NULL);
	g_return_val_if_fail(!iter, NULL);
	g_return_val_if_fail(iter->user_data, NULL);

	m    = URMP_MODEL(tree_model);
	l    = m->list;
	path = gtk_tree_path_new();
	gtk_tree_path_append_index(path, (intptr_t)iter->user_data);
	return path;
}

static void urmp_model_get_value(GtkTreeModel *tree_model,
				 GtkTreeIter *iter,
				 gint column,
				 GValue *value)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;
	gint            n;

	g_return_if_fail(URMP_MODEL_IS(tree_model));
	g_return_if_fail(iter);

	m = URMP_MODEL(tree_model);
	l = m->list;
	n = (intptr_t)iter->user_data;

	g_return_if_fail(column < m->n_columns);
	g_value_init(value, m->column_types[column]);

	g_return_if_fail(n >= 0);
	if (n >= l->count_filtered) g_return_if_reached();

	switch ((urmp_column_t)column) {
	case URMP_ARTIST:
		g_value_set_static_string(value,
					  ur_id3_artist(l->filtered[n]));
		break;
	case URMP_ALBUM:
		g_value_set_static_string(value,
					  ur_id3_album(l->filtered[n]));
		break;
	case URMP_TITLE:
		g_value_set_static_string(value, ur_id3_title(l->filtered[n]));
		break;
	case URMP_TRACK:
		g_value_set_static_string(value,
					  ur_id3_track_string(l->filtered[n]));
		break;
	case URMP_DURATION:
		g_value_set_static_string(value,
					  ur_id3_duration_string(
						  l->filtered[n]));
		break;
	case URMP_RATE:
		g_value_set_static_string(value,
					  ur_id3_rate_string(l->filtered[n]));
		break;
	default:
		ur_fatal(__func__, "Column %d out of range\n", column);
	}
}

static gboolean urmp_model_iter_next(GtkTreeModel *tree_model,
				     GtkTreeIter *iter)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;
	gint            n;

	g_return_val_if_fail(URMP_MODEL_IS(tree_model), FALSE);
	if (!iter) return FALSE;

	m = URMP_MODEL(tree_model);
	l = m->list;
	n = (intptr_t)iter->user_data;

	if (n + 1 >= l->count_filtered) return FALSE;

	iter->stamp = m->stamp;
	iter->user_data = (gpointer)(intptr_t)(n + 1);
	return TRUE;
}

static gboolean urmp_model_iter_children(GtkTreeModel *tree_model,
					 GtkTreeIter *iter,
					 GtkTreeIter *parent)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;

	g_return_val_if_fail(!parent || parent->user_data, FALSE);
	if (parent) return FALSE;
	g_return_val_if_fail(URMP_MODEL_IS(tree_model), FALSE);

	m = URMP_MODEL(tree_model);
	l = m->list;

	if (!l->count_filtered) return FALSE;

	iter->stamp = m->stamp;
	iter->user_data = (gpointer)0;
	return TRUE;
}

static gboolean urmp_model_iter_has_child(GtkTreeModel *tree_model _unused,
					  GtkTreeIter *iter _unused)
{
	return FALSE;
}

static gint urmp_model_iter_n_children(GtkTreeModel *tree_model,
				       GtkTreeIter *iter)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;

	g_return_val_if_fail(URMP_MODEL_IS(tree_model), -1);
	g_return_val_if_fail(!iter || iter->user_data, FALSE);

	m = URMP_MODEL(tree_model);
	l = m->list;

	if (!iter) return l->count_filtered;
	return 0;
}

static gboolean urmp_model_iter_nth_child(GtkTreeModel *tree_model,
					  GtkTreeIter *iter,
					  GtkTreeIter *parent,
					  gint n)
{
	urmp_model_t    *m;
	urmp_gui_list_t *l;

	g_return_val_if_fail(URMP_MODEL_IS(tree_model), FALSE);

	m = URMP_MODEL(tree_model);
	l = m->list;
	
	if (parent) return FALSE;

	if (n >= l->count_filtered) return FALSE;

	iter->stamp = m->stamp;
	iter->user_data = (gpointer)(intptr_t)n;
	return TRUE;
}

static gboolean urmp_model_iter_parent(GtkTreeModel *tree_model _unused,
				       GtkTreeIter *iter _unused,
				       GtkTreeIter *child _unused)
{
	return FALSE;
}

static void urmp_model_finalize(GObject *object)
{
	(*parent_class->finalize)(object);
}
	
static void urmp_model_class_init(urmp_model_class_t *klass)
{
	GObjectClass *object_class;

	parent_class = (GObjectClass *)g_type_class_peek_parent(klass);
	object_class = (GObjectClass *)klass;
	object_class->finalize = urmp_model_finalize;
}

static void urmp_model_interface_init(GtkTreeModelIface *iface)
{
	iface->get_flags       = urmp_model_get_flags;
	iface->get_n_columns   = urmp_model_get_n_columns;
	iface->get_column_type = urmp_model_get_column_type;
	iface->get_iter        = urmp_model_get_iter;
	iface->get_path        = urmp_model_get_path;
	iface->get_value       = urmp_model_get_value;
	iface->iter_next       = urmp_model_iter_next;
	iface->iter_children   = urmp_model_iter_children;
	iface->iter_has_child  = urmp_model_iter_has_child;
	iface->iter_n_children = urmp_model_iter_n_children;
	iface->iter_nth_child  = urmp_model_iter_nth_child;
	iface->iter_parent     = urmp_model_iter_parent;
}

static void urmp_model_init(urmp_model_t *m)
{
	int i;

	m->n_columns = URMP_COLUMNS;
	for (i = 0; i < URMP_COLUMNS; i++) {
		m->column_types[i] = G_TYPE_STRING;
	}
	m->stamp = g_random_int();
}

GType urmp_model_get_type(void)
{
	static GType urmp_model_type = 0;

	if (!urmp_model_type) {
		static const GTypeInfo urmp_model_info = {
			sizeof(urmp_model_class_t),
			NULL,
			NULL,
			(GClassInitFunc)urmp_model_class_init,
			NULL,
			NULL,
			sizeof(urmp_model_t),
			0,
			(GInstanceInitFunc)urmp_model_init,
			NULL
		};
		static const GInterfaceInfo urmp_model_interface_info = {
			(GInterfaceInitFunc)urmp_model_interface_init,
			NULL,
			NULL
		};
		urmp_model_type = g_type_register_static(G_TYPE_OBJECT,
							 "urmp_model",
							 &urmp_model_info,
							 (GTypeFlags)0);
		g_type_add_interface_static(urmp_model_type,
					    GTK_TYPE_TREE_MODEL,
					    &urmp_model_interface_info);
	}
	return urmp_model_type;
}


urmp_model_t *urmp_model_new(urmp_gui_list_t *list)
{
	urmp_model_t *m;

	m = (urmp_model_t *)g_object_new(URMP_MODEL_TYPE, NULL);
	g_assert(m);
	m->list = list;
	return m;
}
