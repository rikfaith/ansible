/* urmp.h -- 
 * Created: Tue Mar 18 13:19:44 2008 by faith@acm.org
 * Revised: Mon Jul 20 11:57:35 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMP_H_
#define _URMP_H_

#define _POSIX_C_SOURCE 200112L
#define _BSD_SOURCE
#define _XOPEN_SOURCE
#define _XOPEN_SOURCE_EXTENDED
#include "config.h"
#include "ur.h"
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#ifndef USE_GTK
#define USE_GTK 0
#endif

#if defined(__GNUC__) && !defined(__LCLINT__)
#define _unused __attribute__((unused))
#else
#define _unused
#endif

#define URMP_ENV_DEFAULT_CONFIG "URMP_DEFAULT_CONFIG"

#define URMP_DEFAULT_CONFIG "~/.urmp"
#define URMP_DEFAULT_DB     "db"
#define URMP_DEFAULT_RC     "config"

#define URMP_DEFAULT_WIDTH  1000
#define URMP_DEFAULT_HEIGHT 600

#define URMP_PROC_COUNT 5
#define URMP_MAX_PATHLEN 4096
#define URMP_ARCHIVE_ROOTS 5

#define URMP_MAX_ID3_BUFLEN (16*1024)

#define URMP_TRACE_CONFIG    0x00000001UL
#define URMP_TRACE_BUILD     0x00000002UL
#define URMP_TRACE_PROC      0x00000004UL
#define URMP_TRACE_MSG       0x00000008UL
#define URMP_TRACE_STACK     0x00000010UL
#define URMP_TRACE_WORKER    0x00000020UL
#define URMP_TRACE_ID3ERR    0x00000040UL
#define URMP_TRACE_PLAYER    0x00000080UL
#define URMP_TRACE_PLAYERINT 0x00000100UL
#define URMP_TRACE_SLAVE     0x00000200UL
#define URMP_TRACE_SWITCH    0x00000400UL
#define URMP_TRACE_RANDOM    0x00000800UL
#define URMP_TRACE_EVENTS    0x00001000UL
#define URMP_TRACE_SEARCH    0x00002000UL
#define URMP_TRACE_PLAYLIST  0x00004000UL
#define URMP_TRACE_HANDLER   0x00008000UL
#define URMP_TRACE_SCROB     0x00010000UL
#define URMP_TRACE_LYRICS    0x00020000UL
#define URMP_TRACE_REINIT    0x00040000UL

/* For urmp_db_worker */
#define URMP_MSG_GET_INFO     1
#define URMP_MSG_REPLY_UPDATE 100
#define URMP_MSG_REPLY_SKIP   101

/* For urmp_player_worker */
#define URMP_MSG_PLAY_FILE    2
#define URMP_MSG_SET_VOLUME   3
#define URMP_MSG_SET_POSITION 4
#define URMP_MSG_GET_STATUS   5
#define URMP_MSG_PAUSE        6
#define URMP_MSG_CONTINUE     7
#define URMP_MSG_STOP         8

typedef struct {
	int    db_count;
	int    db_secs;
	int    db_usecs;
	double db_rate;
	int    db_launched;
	int    db_new;
	int    db_updated;
	int    db_skipped;
} urmp_db_status_t;

extern int     urmp_proc_count;
extern int     urmp_max_pathlen;
extern ur_sl_t urmp_db;

extern void urmp_gui(int *argc, const char ***argv);
extern void urmp_gui_trailer(void);

extern void urmp_player_start(void);

extern void urmp_read_db(void);
extern void urmp_write_db(void);

typedef void urmp_db_callback_t(urmp_db_status_t *db, void *data);
extern void  urmp_db_register_callback(urmp_db_callback_t *func, void *data);

typedef void urmp_db_promotion_hook_t(ur_id3_t *e);
extern void  urmp_db_add_promotion(ur_id3_t *ep);
extern void  urmp_db_del_promotion(ur_id3_t *ep);

extern void urmp_db_build(ur_id3_read_t flags);
extern int  urmp_db_new_entry(ur_id3_t id3);
extern void urmp_db_set_keep_existing(bool keep_existing);
extern void urmp_db_promote(void);
extern unsigned long urmp_db_get_generation(void);

extern void urmp_scrobble(ur_id3_t e);
extern void urmp_lyrics(ur_id3_t e);

#endif
