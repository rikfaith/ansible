/* urmpscrobble.c -- 
 * Created: Fri May 15 18:12:00 2009 by faith@acm.org
 * Revised: Sat May 16 20:47:28 2009 by faith@acm.org
 * Copyright 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmp.h"
#include "version.h"
#include "urmpscrobble.h"
#include "urmpconfig.h"
#include <curl/curl.h>
#include <openssl/md5.h>

static ur_proc_t     urmp_scrobble_proc;
static int           urmp_scrobble_delay;
static time_t        urmp_scrobble_time_next;
static time_t        urmp_scrobble_time_last;
static int           urmp_scrobble_hard_errors;
static const char    *urmp_scrobble_session_id;
static const char    *urmp_scrobble_now_playing_url;
static const char    *urmp_scrobble_submission_url;
static unsigned long urmp_scrobble_generation;

static size_t urmp_scrobble_handshake(void *ptr, size_t size, size_t nmemb,
				      void *data _unused)
{
	size_t len = size * nmemb;
	size_t i;
	char   *buf, *pt;
	int    state = 0;
	time_t t;

	urmp_scrobble_session_id      = NULL;
	urmp_scrobble_now_playing_url = NULL;
	urmp_scrobble_submission_url  = NULL;

	time(&t);

	for (i = 0, buf = pt = ptr; i < len; i++, pt++) {
		if (*pt != '\n') continue;
		*pt = '\0';
		ur_trace(URMP_TRACE_SCROB, __func__, "Got %s\n", buf);
		switch (state) {
		case 0:
			if (!strncmp(buf, "OK", 2)) {
				urmp_scrobble_hard_errors = 0;
				state = 1;
				break;
			}
			if (!urmp_scrobble_hard_errors) {
				urmp_scrobble_delay = 60;
			} else {
				urmp_scrobble_delay *= 2;
			}
			if (urmp_scrobble_delay > 60 * 12) {
				urmp_config_set_lastfm_nowplaying(false);
				urmp_config_set_lastfm_scrobbling(false);
			}
			urmp_scrobble_time_next = t + urmp_scrobble_delay;
			ur_warning(__func__, "errorcount=%d delay=%d: %s\n",
				   urmp_scrobble_hard_errors,
				   urmp_scrobble_delay,
				   buf);
			return len;
		case 1:
			urmp_scrobble_session_id = ur_atom_string(buf);
			ur_trace(URMP_TRACE_SCROB, __func__,
				 "Got session id: %s\n", buf);
			state = 2;
			break;
		case 2:
			urmp_scrobble_now_playing_url = ur_atom_string(buf);
			ur_trace(URMP_TRACE_SCROB, __func__,
				 "Got now-playing url: %s\n", buf);
			state = 3;
			break;
		case 3:
			urmp_scrobble_submission_url = ur_atom_string(buf);
			ur_trace(URMP_TRACE_SCROB, __func__,
				 "Got submission url: %s\n", buf);
			urmp_scrobble_time_last = 0;
			return len;
		}
		buf = pt + 1;
	}

	return len;
}

static size_t urmp_scrobble_response(void *ptr, size_t size, size_t nmemb,
				     void *data _unused)
{
	size_t len = size * nmemb;
	char   *pt;
	time_t t;

	pt = ptr;
	pt[len-1] = '\0';
	ur_trace(URMP_TRACE_SCROB, __func__, "Got %s\n", pt);
	if (!strncmp(pt, "OK", 2)) {
		urmp_scrobble_hard_errors = 0;
		urmp_scrobble_time_last = 0;
		return len;
	}
	time(&t);
	urmp_scrobble_time_last  = t;
	urmp_scrobble_session_id = NULL;
	return len;
}

static int urmp_md5(const char *s, char *buf, int len)
{
	MD5_CTX           ctx;
	unsigned char     digest[16];
	char              *pt;
	int               i;

	if (len < 33) return 0;

	len = strlen(s);
	MD5_Init(&ctx);
	MD5_Update(&ctx, s, len);
	MD5_Final(digest, &ctx);

	for (i = 0, pt = buf; i < 16; i++) {
		snprintf(pt + 2 * i, 3, "%02x", digest[i]);
	}
	pt[32] ='\0';

	return 32;
}

static void urmp_scrobble_get_session_id(void)
{
	time_t     t;
	const char *username;
	const char *password;
	CURL       *c;
	int        retcode;
	char       url[1024];
	char       checksum[128];

	username = urmp_config_get_lastfm_username();
	password = urmp_config_get_lastfm_password();

	ur_trace(URMP_TRACE_SCROB, __func__,
		 "Getting session id: username=%s password=%s\n",
		 username ? username : "", password ? password : "");

	if (!username || !username[0] || !password || !password[0]) return;
	
	time(&t);
	urmp_md5(password, checksum, sizeof(checksum));
	snprintf(checksum + 32, sizeof(checksum)-33, "%lu", (unsigned long)t);
	urmp_md5(checksum, checksum, sizeof(checksum));

	snprintf(url, sizeof(url)-1,
		 "http://post.audioscrobbler.com/"
		 "?hs=true"
		 "&p=1.2.1"
		 "&c=urm"
		 "&v=%d.%d.%d"
		 "&u=%s"
		 "&t=%lu"
		 "&a=%s",
		 URMP_MAJOR, URMP_MINOR, URMP_PATCH,
		 username,
		 (unsigned long)t,
		 checksum);

	if (urmp_scrobble_time_last && t - urmp_scrobble_time_last < 30) {
		ur_trace(URMP_TRACE_SCROB, __func__, "Delaying: %s\n", url);
		return;
	}
	urmp_scrobble_time_last = t;

	ur_trace(URMP_TRACE_SCROB, __func__, "Sending: %s\n", url);
	c = curl_easy_init();
	curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, urmp_scrobble_handshake);
	curl_easy_setopt(c, CURLOPT_URL, url);
	retcode = curl_easy_perform(c);
	curl_easy_cleanup(c);
}

static void urmp_scrobble_now_playing(ur_id3_t e)
{
	CURL       *c;
	char       data[1024];
	const char *artist;
	const char *title;
	const char *album;
	int        duration;
	char       dstring[64] = { 0, };
	int        retcode;
	time_t     t;
	int        offset;
	char       *escaped;

	artist   = ur_id3_artist(e);
	title    = ur_id3_title(e);
	album    = ur_id3_album(e);
	duration = ur_id3_mpeg_duration(e);

	if (duration)
		snprintf(dstring, sizeof(dstring)-1, "%d", duration);

	if (!artist || !artist[0] || !title || !title[0]) {
		ur_trace(URMP_TRACE_SCROB, __func__,
			 "Artist or title empty\n");
		return;
	}

	c = curl_easy_init();

	offset = 0;
	offset += snprintf(data + offset, sizeof(data)-1-offset, "s=%s",
			   urmp_scrobble_session_id);

	escaped = curl_easy_escape(c, artist, strlen(artist));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&a=%s",
			   escaped);
	curl_free(escaped);

	escaped = curl_easy_escape(c, title, strlen(title));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&t=%s",
			   escaped);
	curl_free(escaped);

	escaped = curl_easy_escape(c, album, strlen(album));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&b=%s",
			   escaped);
	curl_free(escaped);

	offset += snprintf(data + offset, sizeof(data)-1-offset,
			   "&l=%s"
			   "&n=%s"
			   "&m=%s",
			   dstring,
			   ur_id3_track_string(e),
			   "");

	time(&t);
	if (urmp_scrobble_time_last && t - urmp_scrobble_time_last < 30) {
		ur_trace(URMP_TRACE_SCROB, __func__, "Delaying: %s %s\n",
			 urmp_scrobble_now_playing_url, data);
		return;
	}
	urmp_scrobble_time_last = t;

	ur_trace(URMP_TRACE_SCROB, __func__, "Sending: %s %s\n",
		 urmp_scrobble_now_playing_url, data);

	curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, urmp_scrobble_response);
	curl_easy_setopt(c, CURLOPT_URL, urmp_scrobble_now_playing_url);
	curl_easy_setopt(c, CURLOPT_POSTFIELDS, data);
	retcode = curl_easy_perform(c);
	curl_easy_cleanup(c);
}

static void urmp_scrobble_submission(ur_id3_t e)
{
	CURL       *c;
	char       data[1024];
	const char *artist;
	const char *title;
	const char *album;
	int        duration;
	char       dstring[64] = { 0, };
	int        retcode;
	time_t     t;
	int        offset;
	char       *escaped;

	artist   = ur_id3_artist(e);
	title    = ur_id3_title(e);
	album    = ur_id3_album(e);
	duration = ur_id3_mpeg_duration(e);

	if (duration)
		snprintf(dstring, sizeof(dstring)-1, "%d", duration);

	if (!artist || !artist[0] || !title || !title[0]) {
		ur_trace(URMP_TRACE_SCROB, __func__,
			 "Artist or title empty\n");
		return;
	}

	c = curl_easy_init();

	offset = 0;
	offset += snprintf(data + offset, sizeof(data)-1-offset, "s=%s",
			   urmp_scrobble_session_id);

	escaped = curl_easy_escape(c, artist, strlen(artist));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&a[0]=%s",
			   escaped);
	curl_free(escaped);

	escaped = curl_easy_escape(c, title, strlen(title));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&t[0]=%s",
			   escaped);
	curl_free(escaped);

	offset += snprintf(data + offset, sizeof(data)-1-offset, "&i[0]=%lu",
			   (unsigned long)ur_id3_current_starttime(e));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&o[0]=%s",
			   ur_id3_source_decode(ur_id3_source(e))
			   == UR_ID3_WEBSTREAM
			   ? "R"
			   : "P");
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&r[0]=");
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&l[0]=%s",
			   dstring);

	escaped = curl_easy_escape(c, album, strlen(album));
	offset += snprintf(data + offset, sizeof(data)-1-offset, "&b[0]=%s",
			   escaped);
	curl_free(escaped);

	offset += snprintf(data + offset, sizeof(data)-1-offset, "&n[0]=%s",
			   ur_id3_track_string(e));

	offset += snprintf(data + offset, sizeof(data)-1-offset, "&m[0]=%s");

	time(&t);
	if (urmp_scrobble_time_last && t - urmp_scrobble_time_last < 30) {
		ur_trace(URMP_TRACE_SCROB, __func__, "Delaying: %s %s\n",
			 urmp_scrobble_submission_url, data);
		return;
	}
	urmp_scrobble_time_last = t;

	ur_trace(URMP_TRACE_SCROB, __func__, "Sending: %s %s\n",
		 urmp_scrobble_submission_url, data);

	curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, urmp_scrobble_response);
	curl_easy_setopt(c, CURLOPT_URL, urmp_scrobble_submission_url);
	curl_easy_setopt(c, CURLOPT_POSTFIELDS, data);
	retcode = curl_easy_perform(c);
	curl_easy_cleanup(c);
}

static int urmp_scrobble_worker(ur_msg_t msg _unused, int type _unused,
				void *buf, int length, void *arg _unused)
{
	ur_id3_t      e;
	int           duration;
	int           playtime;
	int           min_playtime = 240;

	e        = ur_id3_unpack(buf, length);
	duration = ur_id3_mpeg_duration(e);
	playtime = ur_id3_current_playtime(e);

	/* Sometimes are can't parse an mp3's time, but we can rely on
	 * the playtime to be an indicator of a minimal duration. */
	if (duration < playtime) duration = playtime;

	ur_trace(URMP_TRACE_SCROB, __func__,
		 "duration=%d playtime=%d starttime=%lu title=%s\n",
		 duration,
		 playtime,
		 (unsigned long)ur_id3_current_starttime(e),
		 ur_id3_title(e));

	if (!urmp_scrobble_session_id) urmp_scrobble_get_session_id();
	if (!urmp_scrobble_session_id) return 0;

	if (!playtime && urmp_config_get_lastfm_nowplaying()) {
		urmp_scrobble_now_playing(e);
		return 0;
	}

	if (duration < 30) return 0;
	if (duration / 2 < min_playtime) min_playtime = duration / 2;
	if (playtime < min_playtime) return 0;
	urmp_scrobble_submission(e);

	return 0;
}

static int urmp_scrobble_cleanup(int pid, int status _unused,
				 int err _unused, void *arg _unused)
{
	ur_trace(URMP_TRACE_SCROB, __func__, "pid %d died\n", pid);
	urmp_scrobble_proc = NULL;
	return 0;
}

void urmp_scrobble(ur_id3_t e)
{
	int             len;
	char            buf[URMP_MAX_ID3_BUFLEN];

	if (urmp_scrobble_generation != urmp_config_get_lastfm_generation()) {
		urmp_scrobble_generation = urmp_config_get_lastfm_generation();
		ur_trace(URMP_TRACE_SCROB, __func__,
			 "Generation %lu\n", urmp_scrobble_generation);
		if (urmp_scrobble_proc) ur_proc_destroy(urmp_scrobble_proc);
		urmp_scrobble_proc = NULL;
	}

	if (!urmp_config_get_lastfm_nowplaying()
	    && !urmp_config_get_lastfm_scrobbling()) {
		ur_trace(URMP_TRACE_SCROB, __func__,
			 "No scrobbling, urmp_scrobble_proc=%p\n",
			 (void *)urmp_scrobble_proc);
		return;
	}

	if (!urmp_scrobble_proc) {
		urmp_scrobble_proc = ur_proc_create(urmp_scrobble_worker,
						    NULL,
						    urmp_scrobble_cleanup,
						    NULL, NULL, NULL);
	}
	len = ur_id3_pack(e, buf, sizeof(buf));
	if (len <= 0)
		ur_fatal(__func__, "Error packing data\n");
	ur_msg_send(urmp_scrobble_proc, 0, buf, len, 0);
}
