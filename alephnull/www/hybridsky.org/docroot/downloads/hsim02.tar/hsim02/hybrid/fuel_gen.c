/*
  This file is a portion of Hsim 0.2
 
  Hsim is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published
  by the Free Software Foundation; either version 2 of the License,
  or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

 */

/*
 * This program creates the fuel.csv data file used by hsim.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *myname;

static double fuel_n, fuel_a, fuel_k, fuel_density;
static char *fuel_name;

/*
 * These fuel parameters are taken from HDAS 1.5, which
 * gives the following numbers for PVC pipe:
 *
 * r=1.0
 * rhof=1.28 // g/cm**3
 * rhof=1.28*0.0361272920000001
 * a=.0052
 * a-english=a*10/2.54
 * n=.65
 *
 * I don't claim to understand all of this, but
 * the following should get the same answers has HDAS.
 */

static void
fuel_PVC()
{
	fuel_name = "pvc";

	fuel_n = 0.65;

	fuel_a = .0052 * 10. / 2.54;  // units are 1/(lbm/sec/in**2)
	fuel_a /= 10000. / 2.2046226  / 2.54 / 2.54; // now 1/(kg/sec/m**2)

	fuel_k = 1.;	// units are in/sec
	fuel_k = 2.54/100.;	// units are m/sec

	fuel_density = 1.28;
	fuel_density *= 1000.;	// from g/cc to kg/m**3
}

static void
fuel_Acrylic()
{
	fuel_name = "acrylic";

	fuel_n = 0.65;

	fuel_a = .011176 * 10. / 2.54;  // units are 1/(lbm/sec/in**2)
	fuel_a /= 10000. / 2.2046226  / 2.54 / 2.54; // now 1/(kg/sec/m**2)

	fuel_k = 1.;	// units are in/sec
	fuel_k = 2.54/100.;	// units are m/sec

	fuel_density = 1.683;
	fuel_density *= 1000.;	// from g/cc to kg/m**3
}

static void
fuel_Polypropylene()
{
	fuel_name = "polypropylene";

	fuel_n = 0.62;

	fuel_a = .0015 * 10. / 2.54;  // units are 1/(lbm/sec/in**2)
	fuel_a /= 10000. / 2.2046226  / 2.54 / 2.54; // now 1/(kg/sec/m**2)

	fuel_k = 1.;	// units are in/sec
	fuel_k = 2.54/100.;	// units are m/sec

	fuel_density = 1.0;
	fuel_density *= 1000.;	// from g/cc to kg/m**3
}

static void
fuel_PBAN()
{
	fuel_name = "pban";

	fuel_n = 0.65;

	fuel_a = .0127 * 10. / 2.54;  // units are 1/(lbm/sec/in**2)
	fuel_a /= 10000. / 2.2046226  / 2.54 / 2.54; // now 1/(kg/sec/m**2)

	fuel_k = 1.;	// units are in/sec
	fuel_k = 2.54/100.;	// units are m/sec

	fuel_density = 0.98;
	fuel_density *= 1000.;	// from g/cc to kg/m**3
}

static void
set_defaults()
{
}

static void
usage()
{
	fprintf(stderr, "Usage: %s > fuel.csv\n", myname);
	exit(1);
}

static void
fuel_print(FILE *output)
{
	fprintf(output, "%s,%.6e,%.6e,%.6e,%.6e\n",
		fuel_name, fuel_n, fuel_a, fuel_k, fuel_density);
}

static void
doit(FILE *output)
{
	fprintf(output, "fuel,N,A,K,Density\n");
	fuel_PVC();
	fuel_print(output);
	fuel_PBAN();
	fuel_print(output);
	fuel_Polypropylene();
	fuel_print(output);
	fuel_Acrylic();
	fuel_print(output);
	fflush(output);
}

int
main(int argc, char **argv)
{
	myname = *argv;

	set_defaults();

	if (argc != 1)
		usage();

	doit(stdout);
	exit(0);
}
