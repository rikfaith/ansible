/* urmpgui.c -- 
 * Created: Sat Sep 27 17:08:37 2008 by faith@acm.org
 * Revised: Sat Jan  3 16:58:13 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#define _GNU_SOURCE
#include "urmpgui.h"
#include "urmpmodel.h"
#include "urmpconfig.h"
#include "version.h"
#include <string.h>
#include <gdk/gdkkeysyms.h>

static ur_random_t urmp_gui_prng;

const char *urmp_column_name[] = {
	"Title",
	"Artist",
	"Album"
};

typedef struct {
	bool              ascending;
	int               colno;
} urmp_method_t;

typedef enum {
	URMP_B_REWIND,
	URMP_B_PLAY,
	URMP_B_PAUSE,
	URMP_B_STOP,
	URMP_B_FORWARD,
	URMP_B_RANDOM,
	URMP_B_REPEAT
} urmp_button_t;

typedef struct {
	urmp_button_t     button;
	urmp_gui_status_t *status;
} urmp_button_data_t;

static void urmp_gui_status_update(urmp_gui_status_t *s);

void urmp_gui_trailer(void)
{
	ur_log_backtrace("Glib Version:      %d.%d.%d\n",
			 glib_major_version, glib_minor_version,
			 glib_micro_version);
	ur_log_backtrace("GTK Version:       %d.%d.%d\n",
			 gtk_major_version, gtk_minor_version,
			 gtk_micro_version);
}

static void urmp_list_init(urmp_gui_list_t *l, ur_sl_t list)
{
	int           items;
	char          *key, *datum;
	ur_iterator_t iter;
	int           i;

	if (list) {		/* Initialize orig and filtered */
		items = ur_sl_items(list);
		if (l->initialized && items <= l->count_max) return;
		if (l->randomized) {
			ur_internal(__func__,
				    "Randomized list initialized for main\n");
		}
		if (l->orig) ur_free(l->orig);
		if (l->filtered) ur_free(l->filtered);
		
		l->orig = ur_alloc(items * sizeof(*l->orig));
		l->filtered  = ur_alloc(items * sizeof(*l->filtered));

		for (i = 0, UR_SL_INIT(list, iter);
		     UR_SL_GET(iter, key, datum);
		     i++, UR_SL_NEXT(iter)) {

			l->orig[i] = (ur_id3_t)datum;
			l->filtered[i] = (ur_id3_t)datum;
		}

		l->count_orig     = items;
		l->count_filtered = items;
		l->count_max      = items;
		l->initialized    = true;
		return;
	}

	/* Since no "list" was provided, this is a playlist.  Preserve
	 * filtered and random, and leave orig empty. */

	items = l->count_filtered * 2 + 16;
	if (l->initialized && items <= l->count_max) return;
	printf("initializing playlist\n");

	if (l->orig)
		ur_fatal(__func__, "Orig list initialized for playlist\n");

	if (l->randomized) {
		ur_free(l->randomized);
	}
	l->randomized          = ur_alloc(items * sizeof(*l->randomized));
	l->randomized_computed = false;

	if (l->filtered) {
		l->filtered = ur_realloc(l->filtered,
					 items * sizeof(*l->filtered));
	} else {
		if (l->count_filtered)
			ur_fatal(__func__,
				 "Filtered list uninitialized, but count=%d\n",
				 l->count_filtered);
		l->filtered = ur_alloc(items * sizeof(*l->filtered));
	}

	l->count_max   = items;
	l->initialized = true;
}

static void urmp_fill(urmp_gui_list_t *l)
{
	char           message[64];
	struct timeval s, e;
	uint64_t       elapsed;

	if (!l->initialized) urmp_list_init(l, urmp_db); 

	gettimeofday(&s, NULL);
	gtk_tree_view_set_model(GTK_TREE_VIEW(l->display), NULL);
	gtk_tree_view_set_model(GTK_TREE_VIEW(l->display),
				GTK_TREE_MODEL(l->model));

	gettimeofday(&e, NULL);
	elapsed = e.tv_sec * 1000000 + e.tv_usec
		  - s.tv_sec * 1000000 - s.tv_usec;

	if (l->count_filtered == 1)
		snprintf(message, sizeof(message)-1,
			 "%d track (%llu us)", l->count_filtered,
			 (long long unsigned)elapsed);
	else
		snprintf(message, sizeof(message)-1,
			 "%d tracks (%llu us)", l->count_filtered,
			 (long long unsigned)elapsed);

	printf("%s", message);
	gtk_label_set(GTK_LABEL(l->label), message);
}

static void urmp_search(const char *text, urmp_gui_list_t *l)
{
	int  i, j, k;
	char *needle;
	char **fingers;
	char *pt;
	int  count;

	printf("search for \"%s\"\n", text);

	needle = alloca(strlen(text)*2 + 1);
	ur_id3_searchify(needle, text);
	fingers = alloca(strlen(needle) * sizeof(*fingers));

	for (pt = needle, count = 0; pt && *pt; pt++) {
		if (pt == needle) {
			fingers[count++] = pt;
		} else if (*pt == ' ') {
			*pt = '\0';
			if (pt[1]) fingers[count++] = ++pt;
		}
	}
	
	if (!l->initialized) urmp_list_init(l, urmp_db);
	for (i = 0, j = 0; i < l->count_orig; i++) {
		const char *haystack = ur_id3_search(l->orig[i]);

		for (k = 0; k < count; k++) {
			if (!haystack || !strstr(haystack, fingers[k])) {
				if (k > 1) {
					printf("nomatch: \"%s\" in \"%s\"\n",
					       fingers[k], haystack);
				}
				goto nomatch;
			}
			printf("match: \"%s\" in \"%s\"\n",
			       fingers[k], haystack);
		}
		l->filtered[j] = l->orig[i];
		j++;
nomatch:
		continue;
	}
	l->count_filtered = j;

	urmp_fill(l);
}

void urmp_search_cb(GtkEditable *editable, gpointer user_data)
{
	urmp_gui_list_t *l = (urmp_gui_list_t *)user_data;

	urmp_search(gtk_entry_get_text(GTK_ENTRY(editable)), l);
}

static void urmp_gui_quit(void)
{
	if (urmp_gui_prng) ur_random_destroy(urmp_gui_prng);
	urmp_gui_prng = NULL;
	ur_proc_destroy_all();
	gtk_main_quit();
}

static gboolean urmp_configure_cb(GtkWidget *widget _unused,
				  GdkEventConfigure *event,
				  gpointer data _unused)
{
	printf("GEOMETRY: width=%d height=%d x=%d y=%d\n",
	       event->width, event->height, event->x, event->y);
	urmp_config_set_geometry(event->width, event->height);
	return FALSE;
}

static gboolean urmp_delete_cb(GtkWidget *widget _unused,
			       GdkEvent *event _unused,
			       gpointer data _unused)
{
	ur_warning(__func__, "exiting due to window event\n");
	urmp_gui_quit();
	return FALSE;
}

static void urmp_destroy_cb(GtkObject *object _unused,
			    gpointer user_data _unused)
{
	urmp_gui_quit();
}

static urmp_method_t   global_method;

#if 0
static int urmp_sort(const void *aa, const void *bb, void *arg)
#else
static int urmp_sort(const void *aa, const void *bb)
#endif
{
	ur_id3_t      *a      = (ur_id3_t *)aa;
	ur_id3_t      *b      = (ur_id3_t *)bb;
//	urmp_method_t *method = (urmp_method_t *)arg;
	urmp_method_t *method = &global_method;
	const char    *aval;
	const char    *bval;

	switch (method->colno) {
	case 0:
		aval = ur_id3_title(*a);
		bval = ur_id3_title(*b);
		break;
	case 1:
		aval = ur_id3_artist(*a);
		bval = ur_id3_artist(*b);
		break;
	case 2:
		aval = ur_id3_album(*a);
		bval = ur_id3_album(*b);
		break;
	default:
		ur_fatal(__func__, "Sorting on column %d\n", method->colno);
	}

	if (!aval || !*aval) aval = "ZZZ";
	if (!bval || !*bval) bval = "ZZZ";
	if (method->ascending) return strcasecmp(aval, bval);
	return strcasecmp(bval, aval);
}

static void urmp_column_notify_cb(GObject *gobject, GParamSpec *pspec _unused,
				  gpointer user_data)
{
	urmp_gui_list_t *l = (urmp_gui_list_t *)user_data;
	int             colno;
	int             width;

	colno = (uintptr_t)gtk_object_get_data(GTK_OBJECT(gobject), "column");
	width = gtk_tree_view_column_get_width(GTK_TREE_VIEW_COLUMN(gobject));
	urmp_config_set_column_width(l->search
				     ? URMP_LEFT_PANE
				     : URMP_RIGHT_PANE,
				     colno,
				     width);
}

static void urmp_column_clicked_cb(GtkTreeViewColumn *column,
				   gpointer user_data)
{
	urmp_gui_list_t *l = (urmp_gui_list_t *)user_data;
	int             colno;
	bool            indicator;
	GtkSortType     type;
	int             i;

	colno = (uintptr_t)gtk_object_get_data(GTK_OBJECT(column), "column");

	indicator = gtk_tree_view_column_get_sort_indicator(column);
	type      = gtk_tree_view_column_get_sort_order(column);

	printf("%s (column %d) sorted, indicator=%d type=%d\n",
	       gtk_tree_view_column_get_title(column), colno,
	       indicator, type);

	if (!indicator || type == GTK_SORT_DESCENDING) {
		type = GTK_SORT_ASCENDING;
	} else {
		type = GTK_SORT_DESCENDING;
	}

	for (i = 0; i < URMP_COLUMNS; i++) {
		gtk_tree_view_column_set_sort_indicator(l->column[i], FALSE);
	}

	if (type == GTK_SORT_ASCENDING) global_method.ascending = true;
	else                            global_method.ascending = false;
	global_method.colno = colno;
	printf("ascending=%d colno=%d\n",
	       global_method.ascending, global_method.colno);
#if 0
	qsort_r(l->filtered, l->count_filtered,
		sizeof(l->filtered), urmp_sort, &method);
#else
	qsort(l->filtered, l->count_filtered,
	      sizeof(l->filtered), urmp_sort);
#endif

	urmp_fill(l);
	gtk_tree_view_column_set_sort_indicator(column, TRUE);
	gtk_tree_view_column_set_sort_order(column, type);
}

static void urmp_gui_play(urmp_gui_status_t *s, ur_id3_t e, int idx)
{
	GtkTreePath     *path;
	urmp_gui_list_t *l = s->playlist;

	if (!s) ur_internal(__func__, "s == NULL\n");

	ur_trace(URMP_TRACE_RANDOM|URMP_TRACE_SLAVE, __func__,
		 "vp:%d,%d PLAY \"%s\"\n",
		 s->volume_pending, s->volume_pending_value,
		 e ? ur_id3_title(e) : NULL);

	s->id3 = s->next_id3 = e;

	if (!e) {
		if (!s->stopped) {
			s->stopped    = true;
			s->generation = urmp_player_stop();
		}
		urmp_fill(l);
		return;
	}

	s->idx_playing = idx;
	s->stopped     = false;
	s->generation  = urmp_player_loadfile(ur_id3_filename(e));

	if (s->volume_pending) {
		s->generation = urmp_player_set_volume(
			s->volume_pending_value);
		s->volume_pending = false;
	}

	if (!s->play_random) {	/* XXX FIXME track random too */
		path = gtk_tree_path_new();
		gtk_tree_path_append_index(path, (intptr_t)idx);
		gtk_tree_view_set_cursor(GTK_TREE_VIEW(l->display),
					 path,
					 NULL,
					 FALSE);
		gtk_tree_path_free(path);
	}
}

static int urmp_gui_find_idx(ur_id3_t e, int idx, ur_id3_t *list, int count)
{
	int i;

	if (idx < count && e == list[idx]) {
		ur_trace(URMP_TRACE_RANDOM, __func__,
			 "FOUND match at idx=%d\n", idx);
		return idx;
	}

	for (i = 0; i < count; i++) {
		if (e == list[i]) {
			ur_trace(URMP_TRACE_RANDOM, __func__,
				 "SEARCHED list until %d\n", i);
			return i;
		}
	}
	ur_trace(URMP_TRACE_RANDOM, __func__, "NOT FOUND e=%p\n", (void *)e);
	return -1;
}

static void urmp_gui_compute_random(urmp_gui_list_t *l)
{
	int                i;

	ur_trace(URMP_TRACE_RANDOM, __func__, "count=%d\n",
		 l->count_filtered);

	if (!urmp_gui_prng) {
		urmp_gui_prng = ur_random_create(UR_RANDOM_STD,
						 UR_RANDOM_UNIFORM);
	}

	if (!l->randomized) {
		ur_internal(__func__, "Randomized list not initialized\n");
	}

	for (i = 0; i < l->count_filtered; i++) {
		l->randomized[i] = l->filtered[i];
	}
	for (i = 0; i < l->count_filtered; i++) {
		ur_id3_t tmp;

		int s = ur_random_range(urmp_gui_prng, 0, l->count_filtered-1);
		int d = ur_random_range(urmp_gui_prng, 0, l->count_filtered-1);

		tmp              = l->randomized[s];
		l->randomized[s] = l->randomized[d];
		l->randomized[d] = tmp;
	}

	if (ur_trace_test(URMP_TRACE_RANDOM)) {
		for (i = 0; i < l->count_filtered; i++) {
			printf("RANDOM %03d %s\n",
			       i, ur_id3_title(l->randomized[i]));
		}
	}
	l->randomized_computed = true;
}

static void urmp_gui_play_next(urmp_gui_status_t *s, bool previous)
{
	urmp_gui_list_t *playlist = s->playlist;
	ur_id3_t        *list;
	int             idx = -1;
	bool            at_end = false;
	int             next;

	if (!playlist || !playlist->count_filtered || s->stopped) {
		ur_trace(URMP_TRACE_SLAVE, __func__,
			 "playlist=%p stopped=%d random=%d repeat=%d\n",
			 (void *)playlist, s->stopped, s->play_random,
			 s->play_repeat);
		return;
	}

	ur_trace(URMP_TRACE_RANDOM, __func__,
		 "playlist=%p stopped=%d random=%d repeat=%d\n",
		 (void *)playlist, s->stopped, s->play_random,
		 s->play_repeat);

	if (s->play_random) {
		list = playlist->randomized;
		if (!playlist->randomized_computed) at_end = true;
	} else {
		list = playlist->filtered;
	}

	if (!at_end) {
		idx = urmp_gui_find_idx(s->id3 ? s->id3 : s->prev_id3,
					s->idx_playing,
					list,
					playlist->count_filtered);
		if (idx < 0) {
			at_end = true;
		} else {
			if (previous) {
				next = idx - 1;
				if (idx <= 0) at_end = true;
			} else {
				next = idx + 1;
				if (idx >= playlist->count_filtered - 1) {
					at_end = true;
				}
			}
		}
	}

	if (at_end) {
		if (!s->play_repeat || previous) {
			ur_trace(URMP_TRACE_RANDOM, __func__, "At end\n");
			urmp_gui_play(s, NULL, 0);
			return;
		}
		next = 0;
		if (s->play_random) urmp_gui_compute_random(playlist);
	}

	ur_trace(URMP_TRACE_RANDOM, __func__, "Selected %d\n", next);
	urmp_gui_play(s, list[next], next);
}

static gboolean urmp_keypress_cb(GtkWidget *widget _unused,
				 GdkEventKey *event,
				 gpointer data)
{
	urmp_gui_status_t *s = (urmp_gui_status_t *)data;

	printf("KEYPRESS: state=0x%0x keyval=%d\n",
	       event->state, event->keyval);
	if ((event->state & GDK_CONTROL_MASK) == GDK_CONTROL_MASK) {
		switch (event->keyval) {
		case GDK_q:
		case GDK_Q:
			urmp_gui_quit();
			break;
		case GDK_E:
			s->generation = urmp_player_set_position(97);
			break;
		case GDK_N:
			urmp_gui_play_next(s, false);
			break;
		case GDK_P:
			urmp_gui_play_next(s, true);
			break;
		}
	}
	
	return FALSE;
}

static void urmp_button_cb(GtkToolButton *button _unused,
			   gpointer user_data)
{
	urmp_button_data_t *data = (urmp_button_data_t *)user_data;
	urmp_gui_status_t  *s    = data->status;

	switch (data->button) {
	case URMP_B_REWIND:
		s->generation
			= urmp_player_set_position(s->current.percent_pos - 5);
		break;
	case URMP_B_PLAY:
		s->stopped = false;
		urmp_gui_play_next(s, false);
		break;
	case URMP_B_FORWARD:
		s->generation
			= urmp_player_set_position(s->current.percent_pos + 5);
		break;
	case URMP_B_PAUSE:
		s->generation = urmp_player_pause();
		break;
	case URMP_B_STOP:
		s->stopped    = true;
		s->generation = urmp_player_stop();
		urmp_gui_play(s, NULL, 0);
		break;
	default:
		break;
	}
}

static void urmp_toggle_cb(GtkToggleButton *button, gpointer user_data)
{
	urmp_button_data_t *data = (urmp_button_data_t *)user_data;
	urmp_gui_status_t  *s    = data->status;

	switch (data->button) {
	case URMP_B_RANDOM:
		s->play_random = gtk_toggle_button_get_active(button);
		break;
	case URMP_B_REPEAT:
		s->play_repeat = gtk_toggle_button_get_active(button);
		break;
	default:
		break;
	}
}

static void urmp_update_elapsed(GtkWidget *elapsed, int total)
{
	char buf[128];
	int  minutes;
	int  seconds;

	minutes = total / 60;
	seconds = total - minutes * 60;
	snprintf(buf, sizeof(buf)-1,
		 "<b>%02d:%02d</b>", minutes, seconds);
	gtk_label_set_markup(GTK_LABEL(elapsed), buf);
}

static void urmp_gui_status_update(urmp_gui_status_t *s)
{
	const char *title;
	const char *artist;
	const char *album;
	uint64_t   generation;

	generation = urmp_player_get_status(&s->current);
	ur_trace(URMP_TRACE_SWITCH, __func__,
		 "generation=%llu target generation=%llu\n",
		 (long long unsigned)generation,
		 (long long unsigned)s->generation);
	if (generation <= s->generation) {
		ur_trace(URMP_TRACE_SLAVE, __func__,
			 "generation=%llu <= target generation=%llu\n",
			 (long long unsigned)generation,
			 (long long unsigned)s->generation);
		return;
	}

	if (!s->current.playing) {
		if (s->id3) s->prev_id3 = s->id3;
		s->id3      = s->next_id3;
		s->next_id3 = NULL;
		if (s->id3) {
			ur_trace(URMP_TRACE_SLAVE, __func__,
				 "playing=%d => true\n", s->current.playing);
			s->current.playing = true;
		} else {
			urmp_gui_play_next(s, false);
		}
	}

	title  = s->id3 ? ur_id3_title(s->id3)  : "...";
	artist = s->id3 ? ur_id3_artist(s->id3) : "...";
	album  = s->id3 ? ur_id3_album(s->id3)  : "...";
	if (title != s->prev_title
	    || artist != s->prev_artist
	    || album != s->prev_album) {
		ur_trace(URMP_TRACE_RANDOM, __func__,
			 "Updating, title=%s\n", title);
		gtk_label_set_label(GTK_LABEL(s->title), title);
		gtk_label_set_label(GTK_LABEL(s->artist), artist);
		gtk_label_set_label(GTK_LABEL(s->album), album);
	}
	s->prev_title  = title;
	s->prev_artist = artist;
	s->prev_album  = album;

	if (!s->id3) {
		s->current.time_pos = 0;
		s->current.percent_pos = 0;
	}

	if (!s->volume_pending
	    && (int)s->current.volume != (int)s->previous.volume) {
		gtk_scale_button_set_value(GTK_SCALE_BUTTON(s->volume),
					   s->current.volume/100.0);
	}
	if ((int)s->current.time_pos != (int)s->previous.time_pos) {
		urmp_update_elapsed(s->elapsed, s->current.time_pos);
	}
	if (s->current.percent_pos != s->previous.percent_pos) {
		gtk_range_set_value(GTK_RANGE(s->progress),
				    (int)s->current.percent_pos);
	}
	memcpy(&s->previous, &s->current, sizeof(s->current));
}

static void urmp_activated_cb(GtkTreeView *display, GtkTreePath *path _unused,
			      GtkTreeViewColumn *column _unused,
			      gpointer user_data _unused)
{
	urmp_gui_list_t   *l = (urmp_gui_list_t *)user_data;
	urmp_gui_status_t *s = l->status;
	GList             *selected;
	GList             *item;

	selected = gtk_tree_selection_get_selected_rows(
		gtk_tree_view_get_selection(display), NULL);
	for (item = g_list_first(selected);
	     item;
	     item = g_list_next(selected)) {
		
		gint *idx = gtk_tree_path_get_indices(item->data);
		if (l->playlist) {
			urmp_gui_list_t *pl = l->playlist;

			urmp_list_init(l->playlist, NULL);
			pl->filtered[pl->count_filtered++] = l->filtered[*idx];
			pl->randomized_computed = false;
			urmp_fill(l->playlist);
		} else {
			urmp_gui_play(s, l->filtered[*idx], *idx);

		}
	}
	g_list_foreach(selected, (GFunc)gtk_tree_path_free, NULL);
	g_list_free(selected);
}

static void urmp_cursor_cb(GtkTreeView *display, gpointer user_data _unused)
{
	GList           *selected;
	GList           *item;
	GtkTreePath     *path;
	gint            *idx;

	gtk_tree_view_get_cursor(display, &path, NULL);
	if (path) {
		idx = gtk_tree_path_get_indices(path);
		printf("cursor on %d\n", idx ? idx[0] : -1);
		gtk_tree_path_free(path);
	}

	selected = gtk_tree_selection_get_selected_rows(
		gtk_tree_view_get_selection(display), NULL);
	for (item = g_list_first(selected); item; item = item->next) {
		idx = gtk_tree_path_get_indices(item->data);
		printf("%d selected\n", *idx);
	}
	g_list_foreach(selected, (GFunc)gtk_tree_path_free, NULL);
	g_list_free(selected);
}

static void urmp_br_cb(GtkWidget *widget _unused,
		       GdkEventButton *event _unused, gpointer user_data)
{
	urmp_gui_list_t *l    = (urmp_gui_list_t *)user_data;
	GList           *selected;
	GList           *item;
	GtkTreePath     *path;
	gint            *idx;
	GtkWidget       *display = l->display;

	gtk_tree_view_get_cursor(GTK_TREE_VIEW(display), &path, NULL);
	if (path) {
		idx = gtk_tree_path_get_indices(path);
		printf("BUTON RELEASE on %d\n", idx ? idx[0] : -1);
		gtk_tree_path_free(path);
	}

	selected = gtk_tree_selection_get_selected_rows(
		gtk_tree_view_get_selection(GTK_TREE_VIEW(display)), NULL);
	for (item = g_list_first(selected); item; item = item->next) {
		idx = gtk_tree_path_get_indices(item->data);
		printf("%d selected\n", *idx);
	}
	g_list_foreach(selected, (GFunc)gtk_tree_path_free, NULL);
	g_list_free(selected);
}

static gboolean urmp_volume_cb(GtkScaleButton *button _unused,
			       gdouble value,
			       gpointer user_data)
{
	urmp_gui_status_t *s     = (urmp_gui_status_t *)user_data;
	int               volume = (int)(value * 100.0);

	s->volume_pending        = true;
	s->volume_pending_value  = volume;
	s->generation            = urmp_player_set_volume(volume);
	printf("VOLUME %f = %d\n", value, volume);
	return FALSE;
}

static gboolean urmp_position_cb(GtkRange *range _unused,
				 GtkScrollType scroll _unused,
				 gdouble value,
				 gpointer user_data)
{
	urmp_gui_status_t *s      = (urmp_gui_status_t *)user_data;

	s->progress_pending       = true; /* XXX FIXME Needed? */
	s->progress_pending_value = (int)value;
	s->generation             = urmp_player_set_position((int)value);
	printf("POSITION %f\n", value);
	return FALSE;
}

static void urmp_status_build(urmp_gui_status_t *s, GtkWidget *container)
{
	GtkWidget *vbox;
	GtkWidget *hbox;

	memset(s, 0, sizeof(*s));

	s->stopped = true;

	vbox = gtk_vbox_new(FALSE, 4);
	gtk_box_pack_start(GTK_BOX(container), vbox, FALSE, FALSE, 0);

	s->title = gtk_label_new("title");
	gtk_label_set_justify(GTK_LABEL(s->title), GTK_JUSTIFY_LEFT);
	gtk_label_set_single_line_mode(GTK_LABEL(s->title), TRUE);
	gtk_box_pack_start(GTK_BOX(vbox), s->title, FALSE, FALSE, 0);

	s->artist = gtk_label_new("artist");
	gtk_label_set_justify(GTK_LABEL(s->artist), GTK_JUSTIFY_LEFT);
	gtk_label_set_single_line_mode(GTK_LABEL(s->artist), TRUE);
	gtk_box_pack_start(GTK_BOX(vbox), s->artist, FALSE, FALSE,  0);

	s->album = gtk_label_new("album");
	gtk_label_set_justify(GTK_LABEL(s->album), GTK_JUSTIFY_LEFT);
	gtk_label_set_single_line_mode(GTK_LABEL(s->album), TRUE);
	gtk_box_pack_start(GTK_BOX(vbox), s->album, FALSE, FALSE,  0);

	hbox = gtk_hbox_new(FALSE, 2);
	gtk_box_pack_start(GTK_BOX(container), hbox, FALSE, FALSE, 0);

	s->elapsed = gtk_label_new(NULL);
	urmp_update_elapsed(s->elapsed, 0);
	gtk_label_set_justify(GTK_LABEL(s->elapsed), GTK_JUSTIFY_LEFT);
	gtk_label_set_single_line_mode(GTK_LABEL(s->elapsed), TRUE);
	gtk_box_pack_start(GTK_BOX(hbox), s->elapsed, FALSE, FALSE, 0);

	s->progress = gtk_hscale_new_with_range(0, 100, 10);
	g_signal_connect(G_OBJECT(s->progress), "change-value",
			 G_CALLBACK(urmp_position_cb), s);
//	gtk_scale_set_value_pos(GTK_SCALE(s->progress), GTK_POS_LEFT);
	gtk_scale_set_draw_value(GTK_SCALE(s->progress), FALSE);
	gtk_scale_set_digits(GTK_SCALE(s->progress), 0);
	gtk_box_pack_end(GTK_BOX(hbox), s->progress, TRUE, TRUE, 0);
}

static void urmp_about_build(GtkWidget *notebook)
{
	GtkWidget     *scrolled;
	GtkWidget     *text;
	GtkWidget     *label;
	GtkTextBuffer *buffer;
	char          message[4096];

	snprintf(message, sizeof(message),
		 "urmp %d.%d.%d (%s)\n"
		 "Ur Music Player\n"
		 "Copyright \xc2\xa9 2008 Rickard E. (Rik) Faith\n"
		 "Released under the MIT License:\n"
		 "http://opensource.org/licenses/mit-license.php\n"
		 "There is NO WARRANTY, to the extent permitted by law\n"
		 "\n"
		 "urmp is build on the ur library: %s\n"
		 "Copyright \xc2\xa9 1999-2008 Rickard E. (Rik) Faith\n"
		 "Copyright \xc2\xa9 1999 Julian E. C. Squires\n"
		 "Released under the MIT License:\n"
		 "http://opensource.org/licenses/mit-license.php\n"
		 "There is NO WARRANTY, to the extent permitted by law\n"
		 "\n"
		 "urmp is linked against other libraries,\n"
		 "each with its own license, including:\n"
		 "GTK+: http://www.gtk.org/\n"
		 "pcre: http://www.pcre.org/\n"
		 "\n"
		 "urmp makes use of other binaries installed\n"
		 "on the system to decode MP3s, such as:\n"
		 "MPlayer: http://www.mplayerhq.hu\n"
		 "\n"
		 "urmp includes custom ID3 and MP3 header parsing,\n"
		 "based on public documentation:\n"
		 "ID3v1.x: http://id3.org/ID3v\n"
		 "ID3v2.2: http://id3.org/id3v2-00\n"
		 "ID3v2.3: http://id3.org/id3v2.3.0\n"
		 "ID3v2.4: http://id3.org/id3v2.4.0-structure\n"
                 "Lyrics3: http://www.id3.org/lyrics3200.html\n"
		 "MP3 headers:"
		 " http://www.mp3-tech.org/programmer/frame_header.html"
		 , URMP_MAJOR, URMP_MINOR, URMP_PATCH, URMP_DATE,
		 ur_version());

	label    = gtk_label_new("About");
	scrolled = gtk_scrolled_window_new(NULL, NULL);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), scrolled, label);

	buffer = gtk_text_buffer_new(NULL);
	text = gtk_text_view_new_with_buffer(buffer);
	gtk_container_add(GTK_CONTAINER(scrolled), text);

	gtk_text_buffer_set_text(buffer, message, -1);
}

static void urmp_list_build(urmp_gui_list_t *l, GtkWidget *notebook,
			    const char *name, bool search,
			    urmp_gui_status_t *s)
{
	int          i;

	/*
	 * Notebook
	 *   Vbox with Label (name)
	 *     Search
	 *     Label
	 *     Hbox
	 *       Scrolled with TreeView with Columns and Renderer
	 *       Scroll
	 */

	memset(l, 0, sizeof(*l));
	l->status = s;

	/* VBox */

	l->vbox = gtk_vbox_new(FALSE, 3);
	l->name = gtk_label_new(name);
	gtk_notebook_append_page(GTK_NOTEBOOK(notebook), l->vbox, l->name);

	if (search) {
		l->search = gtk_entry_new();
		gtk_box_pack_start(GTK_BOX(l->vbox), l->search,
				   FALSE, FALSE, 0);
		g_signal_connect(G_OBJECT(l->search), "changed",
				 G_CALLBACK(urmp_search_cb), l);
	}

	l->label = gtk_label_new(NULL);
	gtk_box_pack_start(GTK_BOX(l->vbox), l->label, FALSE, FALSE, 0);

	l->hbox = gtk_hbox_new(FALSE, 2);
	gtk_box_pack_end(GTK_BOX(l->vbox), l->hbox, TRUE, TRUE, 0);

	/* HBox */

	l->scrolled = gtk_scrolled_window_new(NULL, NULL);
	gtk_box_pack_start(GTK_BOX(l->hbox), l->scrolled, TRUE, TRUE, 0);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(l->scrolled),
				       GTK_POLICY_AUTOMATIC,
				       GTK_POLICY_AUTOMATIC);

	l->model = urmp_model_new(l);
	l->display  = gtk_tree_view_new_with_model(GTK_TREE_MODEL(l->model));
	gtk_container_add(GTK_CONTAINER(l->scrolled), l->display);
	gtk_tree_view_set_rubber_banding(GTK_TREE_VIEW(l->display), TRUE);
	gtk_tree_view_set_enable_search(GTK_TREE_VIEW(l->display), FALSE);
	gtk_tree_view_set_grid_lines(GTK_TREE_VIEW(l->display),
				     GTK_TREE_VIEW_GRID_LINES_BOTH);
	g_signal_connect_after(G_OBJECT(l->display), "row-activated",
			       G_CALLBACK(urmp_activated_cb), l);
//	g_signal_connect_after(G_OBJECT(l->display), "cursor-changed",
//	                       G_CALLBACK(urmp_cursor_cb), l);
	g_signal_connect_after(G_OBJECT(l->display), "button-release-event",
			       G_CALLBACK(urmp_br_cb), l);


	l->renderer = gtk_cell_renderer_text_new();
	g_object_set(G_OBJECT(l->renderer), "ellipsize",
		     PANGO_ELLIPSIZE_MIDDLE, NULL);
#if 0
	g_object_set(G_OBJECT(l->renderer), "wrap-mode",
                   PANGO_WRAP_WORD_CHAR, NULL);
	g_object_set(G_OBJECT(l->renderer), "wrap-width",
		     urmp_config_get_width()/2/4, NULL);
#endif
	gtk_tree_selection_set_mode(
		gtk_tree_view_get_selection(GTK_TREE_VIEW(l->display)),
		GTK_SELECTION_MULTIPLE);
	for (i = 0; i < URMP_COLUMNS; i++) {
		l->column[i] = gtk_tree_view_column_new_with_attributes(
			urmp_column_name[i], l->renderer, "text", i, NULL);
		gtk_object_set_data(GTK_OBJECT(l->column[i]), "column",
				    (gpointer)(uintptr_t)i);
		gtk_tree_view_column_set_sizing(l->column[i],
						GTK_TREE_VIEW_COLUMN_FIXED);
		gtk_tree_view_column_set_fixed_width(
			l->column[i],
			urmp_config_get_column_width(search
						     ? URMP_LEFT_PANE
						     : URMP_RIGHT_PANE,
						     i));
		gtk_tree_view_column_set_resizable(l->column[i], TRUE);
		gtk_tree_view_column_set_clickable(l->column[i], TRUE);
		gtk_tree_view_column_set_reorderable(l->column[i], TRUE);
		g_signal_connect(G_OBJECT(l->column[i]), "clicked",
				 G_CALLBACK(urmp_column_clicked_cb), l);
		g_signal_connect(G_OBJECT(l->column[i]), "notify::width",
				 G_CALLBACK(urmp_column_notify_cb), l);
		gtk_tree_view_append_column(GTK_TREE_VIEW(l->display),
					    l->column[i]);
	}
}

static void urmp_add_button(GtkWidget *container, urmp_gui_status_t *s,
			    urmp_button_t type)
{
	GtkWidget          *button;
	const gchar        *stock_id = NULL;
	urmp_button_data_t *data;

	switch (type) {
	case URMP_B_REWIND:
		stock_id = GTK_STOCK_MEDIA_REWIND;
		goto button;
	case URMP_B_PLAY:
		stock_id = GTK_STOCK_MEDIA_PLAY;
		goto button;
	case URMP_B_PAUSE:
		stock_id = GTK_STOCK_MEDIA_PAUSE;
		goto button;
	case URMP_B_STOP:
		stock_id = GTK_STOCK_MEDIA_STOP;
		goto button;
	case URMP_B_FORWARD:
		stock_id = GTK_STOCK_MEDIA_FORWARD;
		goto button;
	case URMP_B_RANDOM:
		button = gtk_toggle_button_new_with_mnemonic("_Random");
		goto toggle;
	case URMP_B_REPEAT:
		button = gtk_toggle_button_new_with_mnemonic("_Cycle");
		goto toggle;
	}

button:
	data = ur_alloc(sizeof(*data)); /* XXX FIXME Never freed */
	data->button = type;
	data->status = s;
	button = gtk_button_new_from_stock(stock_id);
	g_signal_connect(G_OBJECT(button), "clicked",
			 G_CALLBACK(urmp_button_cb), data);
	goto insert;
toggle:
	data = ur_alloc(sizeof(*data)); /* XXX FIXME Never freed */
	data->button = type;
	data->status = s;
	g_signal_connect(G_OBJECT(button), "toggled",
			 G_CALLBACK(urmp_toggle_cb), data);
	goto insert;
insert:
	gtk_box_pack_start(GTK_BOX(container), button, FALSE, FALSE, 0);
}

static gboolean ur_gui_tick(gpointer data)
{
	urmp_gui_status_t *status = (urmp_gui_status_t *)data;
	urmp_gui_status_update(status);
	return true;
}

static gboolean urmp_paned_cb(GtkWidget *widget,
			      GtkAllocation *allocation _unused,
			      gpointer user_data _unused)
{
	urmp_config_set_division(gtk_paned_get_position(GTK_PANED(widget)));
	return FALSE;
}

void urmp_gui(int *argc, const char ***argv)
{
	GtkWidget *window;
	GtkWidget *container_top;
	GtkWidget *container_paned;
	GtkWidget *container_left;
	GtkWidget *container_right;
	GtkWidget *notebook_0;
	GtkWidget *notebook_1;
	GtkWidget *buttons_1;
	urmp_gui_list_t   list_0;
	urmp_gui_list_t   list_1;
	urmp_gui_status_t status_1;
	
        if (URMP_COLUMNS != (sizeof(urmp_column_name)
			     /sizeof(urmp_column_name[0]))) {
		ur_fatal(__func__,
			 "Size mismatch in urmp_colum_name and urmp_column_t:"
			 " %d and %lu",
			 URMP_COLUMNS,
			 sizeof(urmp_column_name)/sizeof(urmp_column_name[0]));
	}

	gtk_init(argc, (char ***)argv);	/* XXX FIXME - remove cast */

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window), "urmp: Ur Music Player");
	gtk_window_set_default_size(GTK_WINDOW(window),
				    urmp_config_get_width(),
				    urmp_config_get_height());
	g_signal_connect(G_OBJECT(window), "delete_event",
			 G_CALLBACK(urmp_delete_cb), NULL);
	g_signal_connect(G_OBJECT(window), "destroy",
			 G_CALLBACK(urmp_destroy_cb), NULL);
	g_signal_connect(G_OBJECT(window), "configure-event",
			 G_CALLBACK(urmp_configure_cb), NULL);
	
	gtk_container_set_border_width(GTK_CONTAINER(window), 0);

	container_top = gtk_hbox_new(FALSE, 2);
	gtk_container_add(GTK_CONTAINER(window), container_top);

	container_paned = gtk_hpaned_new();
	gtk_paned_set_position(GTK_PANED(container_paned),
			       urmp_config_get_division());
	gtk_box_pack_start(GTK_BOX(container_top), container_paned,
			   TRUE, TRUE, 0);
	g_signal_connect(G_OBJECT(container_paned), "size_allocate",
			 G_CALLBACK(urmp_paned_cb), NULL);

	container_left = gtk_vbox_new(FALSE, 2);
	gtk_paned_pack1(GTK_PANED(container_paned), container_left,
			TRUE, TRUE);
#if 0
	gtk_widget_set_default_size_request(container_left,
				    urmp_config_get_width()/2,
				    urmp_config_get_height());
#endif

	container_right = gtk_vbox_new(FALSE, 2);
	gtk_paned_pack2(GTK_PANED(container_paned), container_right,
			TRUE, TRUE);
#if 0
	gtk_widget_set_size_request(container_right,
				    urmp_config_get_width()/2,
				    urmp_config_get_height());
#endif

	notebook_0   = gtk_notebook_new();
	gtk_box_pack_end(GTK_BOX(container_left), notebook_0, TRUE, TRUE, 0);
	urmp_list_build(&list_0, notebook_0, "Search", true, NULL);
	urmp_about_build(notebook_0);

	urmp_status_build(&status_1, container_right);
	g_signal_connect(G_OBJECT(window), "key-press-event",
			 G_CALLBACK(urmp_keypress_cb), &status_1);
	
	notebook_1   = gtk_notebook_new();
	gtk_box_pack_end(GTK_BOX(container_right), notebook_1, TRUE, TRUE, 0);
	urmp_list_build(&list_1, notebook_1, "Playlist 1", false, &status_1);

	buttons_1 = gtk_hbox_new(FALSE, 2);
	gtk_box_pack_start(GTK_BOX(container_right), buttons_1,
			   FALSE, FALSE, 0);

	urmp_add_button(buttons_1, &status_1, URMP_B_REWIND);
	urmp_add_button(buttons_1, &status_1, URMP_B_PLAY);
	urmp_add_button(buttons_1, &status_1, URMP_B_PAUSE);
	urmp_add_button(buttons_1, &status_1, URMP_B_STOP);
	urmp_add_button(buttons_1, &status_1, URMP_B_FORWARD);
	urmp_add_button(buttons_1, &status_1, URMP_B_RANDOM);
	urmp_add_button(buttons_1, &status_1, URMP_B_REPEAT);

	status_1.volume = gtk_volume_button_new();
	g_signal_connect(G_OBJECT(status_1.volume), "value-changed",
			 G_CALLBACK(urmp_volume_cb), &status_1);
	gtk_box_pack_end(GTK_BOX(buttons_1), status_1.volume, FALSE, FALSE, 0);

	status_1.playlist = list_0.playlist = &list_1;
	
	gtk_widget_show_all(window);
	urmp_fill(&list_0);
	urmp_list_init(&list_1, NULL);
	urmp_fill(&list_1);
	g_timeout_add(1000, ur_gui_tick, (gpointer)&status_1);
	gtk_main();
}
