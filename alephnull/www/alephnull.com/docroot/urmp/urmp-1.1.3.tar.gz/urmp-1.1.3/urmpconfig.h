/* urmpconfig.h -- 
 * Created: Tue Dec 30 10:29:35 2008 by faith@acm.org
 * Revised: Fri Jan  2 22:31:19 2009 by faith@acm.org
 * Copyright 2008, 2009 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#ifndef _URMPCONFIG_H_
#define _URMPCONFIG_H_

#include "urmp.h"

extern const char *urmp_config_db_path;
extern const char *urmp_config_backup_db_path;

extern void urmp_config_setup(const char *config_path, bool use_defaults);
extern void urmp_config_readonly(void);

extern void urmp_config_set_geometry(int width, int height);
extern int  urmp_config_get_width(void);
extern int  urmp_config_get_height(void);

extern void urmp_config_set_division(int division);
extern int  urmp_config_get_division(void);

extern void urmp_config_set_column_width(int pane, int column, int width);
extern int  urmp_config_get_column_width(int pane, int column);

#endif
