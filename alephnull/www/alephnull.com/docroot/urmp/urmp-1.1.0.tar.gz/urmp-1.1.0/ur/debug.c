/* debug.c -- 
 * Created: Mon Jul  5 13:25:50 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: debug.c,v 1.11 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "urP.h"

struct ur_flag_s {
    unsigned long magic;
    unsigned long setFlags[4];
    unsigned long usedFlags[4];
    ur_hash_t      hash;
};

#define FLAGSET(x) (((x) & 0xc0000000) >> 30)
#define FLAGVAL(x) ((x) &  0x3fffffff)

CHECK_FUNCTION(_ur_flag_check, ur_flag_t, UR_FLAG_MAGIC)

ur_flag_t ur_flag_create(void)
{
    ur_flag_t flags = ur_allocz(sizeof(*flags));

    flags->magic = UR_FLAG_MAGIC;
    flags->hash  = ur_hash_create(NULL, NULL);
    return flags;
}

unsigned long ur_flag_destroy(ur_flag_t flags)
{
    unsigned long ret;
    
    _ur_flag_check(flags);
    ret = flags->magic = ~UR_FLAG_MAGIC;
    ur_hash_destroy(flags->hash);
    ur_free(flags);
    return ret;
}

void ur_flag_register(ur_flag_t flags, unsigned long flag, const char *name)
{
    _ur_flag_check(flags);
    ur_hash_insert_ul(flags->hash, name, flag);
    flags->usedFlags[FLAGSET(flag)] &= FLAGVAL(flag);
}
    
void ur_flag_set(ur_flag_t flags, unsigned long flag)
{
    _ur_flag_check(flags);
    flags->setFlags[FLAGSET(flag)] |= FLAGVAL(flag);
}

void ur_flag_unset(ur_flag_t flags, unsigned long flag)
{
    _ur_flag_check(flags);
    flags->setFlags[FLAGSET(flag)] &= ~FLAGVAL(flag);
}

				/* FIXME: move to a header for inlining */
int ur_flag_test(ur_flag_t flags, unsigned long flag)
{
    return flags->setFlags[FLAGSET(flag)] & FLAGVAL(flag);
}

void ur_flag_set_by_name(ur_flag_t flags, const char *name, int (*f)(const char *))
{
    unsigned long flag = 0;
    
    _ur_flag_check(flags);
    if (name) {
        flag = ur_hash_lookup_ul(flags->hash, name);
        if (!flag && name[0] == 'n' && name[1] == 'o') {
            if ((flag = ur_hash_lookup_ul(flags->hash, name + 2))) {
                ur_flag_unset(flags, flag);
                return;
            }
        }
    }
    if (!flag || !name) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) ur_internal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    ur_flag_set(flags, flag);
}

void ur_flag_unset_by_name(ur_flag_t flags, const char *name,
                        int (*f)(const char *))
{
    unsigned long flag;
    
    _ur_flag_check(flags);
    flag = ur_hash_lookup_ul(flags->hash, name);
    if (!flag) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) ur_internal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    ur_flag_unset(flags, flag);
}

int  ur_flag_test_by_name(ur_flag_t flags, const char *name,
                       int (*f)(const char *))
{
    unsigned long flag;
    
    _ur_flag_check(flags);
    flag = ur_hash_lookup_ul(flags->hash, name);
    if (!flag) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) ur_internal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    return ur_flag_test(flags, flag);
}

const char *ur_flag_name(ur_flag_t flags, unsigned long flag)
{
    ur_iterator_t  iter;

    ur_hash_iterator_init(flags->hash, &iter);
    do {
	if (ur_hash_iterator_datum_ul(&iter) == flag)
	    return ur_hash_iterator_key(&iter);
    } while (ur_hash_iterator_next(&iter));
    return NULL;
}

ur_list_t ur_flag_names(ur_flag_t flags)
{
    ur_list_t     list = ur_list_create();
    ur_iterator_t iter;
    const char   *key;
    
    UR_HASH_ITERATE_NODATUM(flags->hash, iter, key) ur_list_append(list, key);
    return list;
}
