#define UR_DATE "20090102"
#define UR_MAJOR 1
#define UR_MINOR 1
#define UR_PATCH 0
