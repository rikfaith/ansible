/* urP.h -- Private header for ur
 * Created: Sun Jul  4 11:25:37 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003, 2008 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: ur_p.h,v 1.23 2003-09-06 03:03:52 faith Exp $
 * 
 */

#ifndef _URP_H_
#define _URP_H_

#include "standard.h"
#include "ur.h"
#include "version.h"
#include "config.h"

#if defined(__GNUC__) && !defined(__LCLINT__)
#define __unused __attribute__((unused))
#else
#define __unused
#endif

#define UR_ARENA_MAGIC        0x12345678LU
#define UR_AVLTREE_MAGIC      0x0ea1b33fLU
#define UR_BLOCK_MAGIC        0xb10cb10cLU
#define UR_BLOCK_NEXT_MAGIC   0xc21dc21dLU
#define UR_FLAG_MAGIC         0xdeadbeefLU
#define UR_HASH_MAGIC         0x0daa3456LU
#define UR_LIST_MAGIC         0x11511151LU
#define UR_OPTION_MAGIC       0x010f5a45LU
#define UR_RANDOM_MAGIC       0xf33dbe3fLU
#define UR_SKIPLIST_MAGIC     0x1234fedcLU
#define UR_STACK_MAGIC        0x514c514cLU
#define UR_TIMER_MAGIC        0xb3eff00dLU
#define UR_TREE_MAGIC         0x31415926LU
#define UR_FILE_MAGIC         0xf113f113LU
#define UR_MAIL_MAGIC         0x8411a411LU
#define UR_NGRAM_MAGIC        0x479beb3eLU
#define UR_TRIGRAM_MAGIC      0x373b3b30LU
#define UR_NET_MAGIC          0x16a8b430LU
#define UR_BUF_MAGIC          0xd0e0f36aLU
#define UR_BUF_CHUNK_MAGIC    0xc1900127LU
#define UR_BUF_BUFFER_MAGIC   0xf0724d03LU
#define UR_PROC_MAGIC	      0xf712aabbLU
#define UR_MSG_MAGIC	      0xf712deffLU
#define UR_ELF_MAGIC	      0x546bc36fLU
#define UR_ID3_MAGIC          0x32423948LU

#define UR_TRACE_CHILD_WAIT   0xc0000001UL
#define UR_TRACE_PROC         0xc0000002UL
#define UR_TRACE_MSG          0xc0000004UL
#define UR_TRACE_ELF          0xc0000010UL
#define UR_TRACE_PACK         0xc0000020UL
#define UR_TRACE_PR	      0xc0000040UL
#define UR_TRACE_ID3	      0xc0000080UL
#define UR_TRACE_ID3_AUGMENT  0xc0000100UL

#define UR_USE_BLOCK          1	/* Use block allocator internally */

#define UR_ARENA_CHUNK        (16*1024)
#define UR_BUF_CHUNK          1024
#define UR_MAIL_CHUNK         4096
#define UR_MAIL_FUDGE         32       /* Guess at malloc overhead */

#define UR_HASH_SEGMENT_COUNT 1024
#define UR_HASH_BUCKET_COUNT  64
#define UR_HASH_BUCKET_MASK   (UR_HASH_BUCKET_COUNT - 1)
#define UR_HASH_MIN_BUCKETS   1
#define UR_HASH_BUCKET_LOAD   5.0
#define UR_HASH_BUCKET_MARK   0.25

#define UR_SKIPLIST_MAXLEVEL  15

#define CHECK_FUNCTION(name,type,magicvalue)                      \
static __inline__ void name(type object)                          \
{                                                                 \
    if (!object) ur_fatal(__FUNCTION__, "Null object\n");         \
    if (object->magic != magicvalue)                              \
	ur_fatal(__FUNCTION__,                                    \
		 "Bad magic (found 0x%08lx instead of 0x%08lx\n", \
		 object->magic,                                   \
		 magicvalue);                                     \
}

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#endif
