/* test-proc.c -- 
 * Created: Sun Aug  3 11:02:44 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 */

#include "standard.h"
#include "ur.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int domsg(int fd, void *arg)
{
	ur_msg_t msg;
	char buf[4096];
	int val;

	msg = ur_msg_recv(fd, buf, sizeof(buf), 0);
	val = strtol(buf, NULL, 0);
	printf("Received msg=%p from fd=%d, val=%d\n", (void *)msg, fd, val);
	snprintf(buf, sizeof(buf), "%d", val * 2);
	ur_msg_reply(msg, buf, strlen(buf)+1, 0);
	printf("Reply sent...\n");
	return 0;
}

static int work(int fd, void *arg)
{
	char *string = (char *)arg;
	int i;

	for (i = 0; i < 3; i++) {
		printf("CHILD: %s, fd=%d\n", string, fd);
		sleep(1);
	}
	return 0;
}

static int cleanup(int pid, int status, int err,
		   void *arg __attribute__((unused)))
{
	if (status > 0) {
		printf("caught %s for pid=%d, status=%d, errno=%d\n",
		       ur_signal_name(status), pid, status, err);
	} else {
		printf("got %d for pid %d, errno=%d\n",
		       status, pid, errno);
	}
		
	return 0;
}

static void __attribute__((noreturn)) usage(void)
{
	ur_list_t list;
	const char *str;

	printf("usage: test-proc [-t trace-list]\n");
	if ((list = ur_trace_names())) {
		printf("       trace-list in:\n");
		while ((str = ur_list_pop(list))) {
			printf("           %s\n", str);
		}
	}
	exit(1);
}

int main(int argc, const char **argv)
{
	ur_proc_t        proc;
	ur_msg_t         msg;
	ur_list_t        list = NULL;
	ur_option_t      opt;
	ur_option_list_t optlist[] = {
		{ "trace", 't', UR_OPTION_LIST },
		{ NULL, 0, 0 }
	};
	int c;
	char *str;
	char buf[4096];
	int val;

	ur_init(argv[0]);

	opt = ur_option_create(optlist);
	ur_option_parse_argv(opt, argc, argv);
	while ((c = ur_option_get(opt)) != EOF) {
		switch (c) {
		case 't':
			list = ur_option_list(opt, list);
			if (!list) usage();
			while ((str = ur_list_pop(list))) {
				ur_trace_set_by_name(str, NULL);
			}
			ur_list_destroy(list);
			break;
		default:
			usage();
		}
		
	}

	test("L", "Message passing");
	ok(0);
	proc = ur_proc_create(domsg, NULL, cleanup, NULL, NULL, NULL);
	snprintf(buf, sizeof(buf), "%d", 37);
	msg = ur_msg_send(proc, UR_MSG_PING, buf, strlen(buf)+1, 0);
	if (!msg) {
		fail("Message not sent");
		return 1;
	}
	msg = ur_msg_wait(msg, buf, sizeof(buf), 0);
	if (!msg) {
		fail("Message reply not received");
		return 1;
	}
	val = strtol(buf, NULL, 0);
	printf("Value:         %d\n", val);
	printf("Sequence:      %lu\n", ur_msg_sequence(msg));
	printf("Time sent:     %lu\n", ur_msg_time_sent(msg));
	printf("Time received: %lu\n", ur_msg_time_received(msg));
	printf("Time replied:  %lu\n", ur_msg_time_replied(msg));
	ur_msg_destroy(msg);
	ur_proc_destroy(proc);
		    
	return EXIT_SUCCESS;

	test("L", "Process creation");
	ok(0);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	sleep(5);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	ur_proc_create(work, (void *)"test", cleanup, NULL, NULL, NULL);
	sleep(1);
	ur_proc_destroy_all();

	return EXIT_SUCCESS;
}
