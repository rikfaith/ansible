/* urmpconfig.c -- 
 * Created: Tue Dec 30 10:30:44 2008 by faith@acm.org
 * Revised: Wed Dec 31 08:19:03 2008 by faith@acm.org
 * Copyright 2008 Rickard E. Faith (faith@acm.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id$
 * 
 */

#include "urmpconfig.h"
#include "urmpgui.h"
#include <wordexp.h>
#include <time.h>
#include <sys/stat.h>

static const char *urmp_config_dir_path;
const        char *urmp_config_db_path;
const        char *urmp_config_backup_db_path;
const        char *urmp_config_file_path;

static struct {
	int width;
	int height;
	int division;
	int widths[URMP_PANES][URMP_COLUMNS];
} urmp_config;

static void urmp_config_set_defaults(void)
{
	int i, j;

	urmp_config.width    = URMP_DEFAULT_WIDTH;
	urmp_config.height   = URMP_DEFAULT_HEIGHT;
	urmp_config.division = URMP_DEFAULT_WIDTH / 2;

	for (i = 0; i < URMP_PANES; i++) {
		for (j = 0; j < URMP_COLUMNS; j++) {
			urmp_config.widths[i][j]
				= URMP_DEFAULT_WIDTH/2/(URMP_COLUMNS+1);
		}
	}
}

static void urmp_config_read(const char *filename)
{
	FILE      *str;
	char      buf[1024];
	char      *field;
	char      *value;
	ur_list_t list;

	if (!(str = fopen(filename, "r"))) return;
	while (fgets(buf, sizeof(buf)-1, str)) {
		if (buf[0] == '#' || buf[0] == '!') continue;

		list = ur_list_create();
		ur_list_parse_string(list, buf);
		field = ur_list_pop(list);
		value = ur_list_pop(list);
		if (!field || !value) {
			ur_list_destroy(list);
			continue;
		}
		if (!strcmp(field, "width")) {
			urmp_config.width = strtol(value, NULL, 0);
		}
		if (!strcmp(field, "height")) {
			urmp_config.height = strtol(value, NULL, 0);
		}
		if (!strcmp(field, "division")) {
			urmp_config.division = strtol(value, NULL, 0);
		}
		if (!strcmp(field, "column")) {
			int pane   = strtol(value, NULL, 0);
			int column = strtol(ur_list_pop(list), NULL, 0);
			int v      = strtol(ur_list_pop(list), NULL, 0);
			if (pane < 0
			    || pane > URMP_PANES
			    || column < 0
			    || column > URMP_COLUMNS) {
				ur_internal(__func__,
					    "pane=%d column=%d width=%d\n",
					    pane, column, v);
			}
			urmp_config.widths[pane][column] = v;
		}
		ur_list_destroy(list);
	}
	fclose(str);
}

static void urmp_config_write(const char *filename)
{
	FILE   *str;
	time_t t;
	int    i, j;

	if (!(str = fopen(filename, "w"))) {
		ur_fatal_errno(__func__,
			       "Cannot open %s for write\n", filename);
	}
	time(&t);
	fprintf(str, "# Automatically generated %24.24s\n", ctime(&t));
	fprintf(str, "width %d\n", urmp_config.width);
	fprintf(str, "height %d\n", urmp_config.height);
	fprintf(str, "division %d\n", urmp_config.division);
	for (i = 0; i < URMP_PANES; i++) {
		for (j = 0; j < URMP_COLUMNS; j++) {
			fprintf(str, "column %d %d %d\n", i, j,
				urmp_config.widths[i][j]);
		}
	}
	fclose(str);
}

void urmp_config_set_column_width(int pane, int column, int width)
{
	if (pane < 0
	    || pane > 1
	    || column < 0
	    || column > URMP_COLUMNS) {
		ur_internal(__func__, "pane=%d column=%d width=%d\n",
			    pane, column, width);
	}
	if (urmp_config.widths[pane][column] == width) return;
	urmp_config.widths[pane][column] = width;
	urmp_config_write(urmp_config_file_path);
}

int urmp_config_get_column_width(int pane, int column)
{
	if (pane < 0
	    || pane > URMP_PANES
	    || column < 0
	    || column > URMP_COLUMNS) {
		ur_internal(__func__, "pane=%d column=%d\n",
			    pane, column);
	}
	return urmp_config.widths[pane][column];
}

void urmp_config_set_division(int division)
{
	if (urmp_config.division == division) return;
	urmp_config.division = division;
	urmp_config_write(urmp_config_file_path);
}

int urmp_config_get_division(void)
{
	return urmp_config.division;
}

void urmp_config_set_geometry(int width, int height)
{
	bool changed = false;

	if (urmp_config.width != width
	    || urmp_config.height != height) {
		changed = true;
	}
	if (!changed) return;

	urmp_config.width = width;
	urmp_config.height = height;
	urmp_config_write(urmp_config_file_path);
}

int urmp_config_get_width(void)
{
	return urmp_config.width;
}

int urmp_config_get_height(void)
{
	return urmp_config.height;
}

void urmp_config_setup(const char *config_path, bool use_defaults)
{
	const char  *config;
	wordexp_t   p;
	struct stat st;
	int         len;
	char        path[urmp_max_pathlen+1];
	char        backup_path[urmp_max_pathlen+1];

	if (config_path) {
		config = config_path;
	} else if (!(config = getenv(URMP_ENV_DEFAULT_CONFIG))) {
		config = URMP_DEFAULT_CONFIG;
	}

	ur_trace(URMP_TRACE_CONFIG, __func__,
		 "Config directory: %s\n", config);

	len = strlen(config);

	wordexp(config, &p, 0);
	if (!p.we_wordv)
		ur_fatal(__func__,
			 "Invalid configuration specification: %s\n", config);
	urmp_config_dir_path = ur_atom_string(p.we_wordv[0]);
	wordfree(&p);

	if (stat(urmp_config_dir_path, &st)) {
		if (mkdir(urmp_config_dir_path, 0755))
			ur_fatal_errno(__func__, "Cannot create %s\n",
				       urmp_config_dir_path);
	} else if (!S_ISDIR(st.st_mode)) {
		ur_fatal(__func__,
			 "Configuration directory not a directory: %s\n",
			 urmp_config_dir_path);
	}

	if (!urmp_config_db_path) {
		snprintf(path, urmp_max_pathlen,
			 "%s/%s", config, URMP_DEFAULT_DB);
	}
	wordexp(path, &p, 0);
	if (!p.we_wordc)
		ur_fatal(__func__, "Invalid db path: %s\n", path);
	urmp_config_db_path = ur_atom_string(p.we_wordv[0]);

	snprintf(backup_path, urmp_max_pathlen, "%s.bak", p.we_wordv[0]);
	urmp_config_backup_db_path = ur_atom_string(backup_path);
	wordfree(&p);

	if (!urmp_config_file_path) {
		snprintf(path, urmp_max_pathlen,
			 "%s/%s", config, URMP_DEFAULT_RC);
	}
	wordexp(path, &p, 0);
	if (!p.we_wordc)
		ur_fatal(__func__, "Invalid config file path: %s\n", path);
	urmp_config_file_path = ur_atom_string(p.we_wordv[0]);

	urmp_config_set_defaults();
	if (!use_defaults) urmp_config_read(urmp_config_file_path);
}
