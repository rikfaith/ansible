/* timer.c -- 
 * Created: Mon Jul  5 13:33:05 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: timer.c,v 1.9 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"

struct maaTimerS {
    unsigned long   magic;
    maaTimerTypeT   type;
    maaTimevalT     start;
    maaTimevalT     stop;
};

CHECK_FUNCTION(_maaTimerCheck, maaTimerT, MAA_TIMER_MAGIC)

maaTimerT maaTimerCreate(maaTimerTypeT type)
{
    maaTimerT timer = maaAllocZ(sizeof(*timer));

    timer->magic = MAA_TIMER_MAGIC;
    timer->type  = type ? type : MAA_TIMER_ALL;
    maaTimerStart(timer);

    return timer;
}

unsigned long maaTimerDestroy(maaTimerT timer)
{
    unsigned long ret;
    
    _maaTimerCheck(timer);
    ret = timer->magic = ~timer->magic;
    maaFree(timer);
    return ret;
}

static void _maaTimerSnap(maaTimerTypeT type, maaTimevalT *val)
{
    struct rusage ru;
    
    if (type & MAA_TIMER_WALL) gettimeofday(&val->wall, NULL);

    if (type & MAA_TIMER_CPU) {
	getrusage(RUSAGE_SELF, &ru);
	val->user.tv_sec    = ru.ru_utime.tv_sec;
	val->user.tv_usec   = ru.ru_utime.tv_usec;
	val->system.tv_sec  = ru.ru_stime.tv_sec;
	val->system.tv_usec = ru.ru_stime.tv_usec;
	getrusage(RUSAGE_CHILDREN, &ru);
	val->children_user.tv_sec    = ru.ru_utime.tv_sec;
	val->children_user.tv_usec   = ru.ru_utime.tv_usec;
	val->children_system.tv_sec  = ru.ru_stime.tv_sec;
	val->children_system.tv_usec = ru.ru_stime.tv_usec;
    }
}

void maaTimerStart(maaTimerT timer)
{
    _maaTimerCheck(timer);
    _maaTimerSnap(timer->type, &timer->start);
}

void maaTimerStop(maaTimerT timer)
{
    _maaTimerCheck(timer);
    _maaTimerSnap(timer->type, &timer->stop);
}

static __inline__ void _maaTimerCopy(maaTimevalT *d, maaTimevalT *s)
{
    memcpy((void *)d, (void *)s, sizeof(*d));
}

void maaTimerGetStart(maaTimerT timer, maaTimevalT *timeval)
{
    _maaTimerCheck(timer);
    if (!timeval) maaFatal(__FUNCTION__, "NULL pointer\n");
    _maaTimerCopy(timeval, &timer->start);
}

void maaTimerGetStop(maaTimerT timer, maaTimevalT *timeval)
{
    _maaTimerCheck(timer);
    if (!timeval) maaFatal(__FUNCTION__, "NULL pointer\n");
    _maaTimerCopy(timeval, &timer->stop);
}

void maaTimerSetStart(maaTimerT timer, maaTimevalT *timeval)
{
    _maaTimerCheck(timer);
    if (!timeval) maaFatal(__FUNCTION__, "NULL pointer\n");
    _maaTimerCopy(&timer->start, timeval);
}

void maaTimerSetStop(maaTimerT timer, maaTimevalT *timeval)
{
    _maaTimerCheck(timer);
    if (!timeval) maaFatal(__FUNCTION__, "NULL pointer\n");
    _maaTimerCopy(&timer->stop, timeval);
}

static void _maaTimerDiff(struct timeval *result,
                          struct timeval *stop,
                          struct timeval *start)
{
    memcpy((void *)result, (void *)stop, sizeof(*result));
    
    if (result->tv_usec < start->tv_usec) {
	if (!result->tv_sec)
	    maaInternal(__FUNCTION__,
			"(%lu,%lu) -> (%lu,%lu)\n",
			start->tv_sec,
			start->tv_usec,
			stop->tv_sec,
			stop->tv_usec);
	result->tv_usec += 1000000;
	--result->tv_sec;
    }
    if (result->tv_usec < start->tv_usec
	|| result->tv_sec < start->tv_sec) {
	    maaInternal(__FUNCTION__,
			"(%lu,%lu) -> (%lu,%lu)\n",
			start->tv_sec,
			start->tv_usec,
			stop->tv_sec,
			stop->tv_usec);
    }
    result->tv_sec  -= start->tv_sec;
    result->tv_usec -= start->tv_usec;
}

void maaTimerGetElapsed(maaTimerT timer, maaTimevalT *timeval)
{
    _maaTimerCheck(timer);
    if (!timeval) maaFatal(__FUNCTION__, "NULL pointer\n");
    _maaTimerDiff(&timeval->wall, &timer->stop.wall, &timer->start.wall);
    _maaTimerDiff(&timeval->user, &timer->stop.user, &timer->start.user);
    _maaTimerDiff(&timeval->system, &timer->stop.system, &timer->start.system);
    _maaTimerDiff(&timeval->children_user,
		  &timer->stop.children_user, &timer->start.children_user);
    _maaTimerDiff(&timeval->children_system,
		  &timer->stop.children_system, &timer->start.children_system);
}
