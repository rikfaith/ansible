/* udataconv.c -- Convert UnicodeCharacterDatabase to C struct
 * Created: Sun Jan 14 10:14:02 2001 by faith@dict.org
 * Revised: Sat Jan 27 17:04:14 2001 by faith@dict.org
 * Copyright 2001 Rickard E. Faith (faith@dict.org)
 * This program comes with ABSOLUTELY NO WARRANTY.
 * 
 * $Id: udataconv.c,v 1.3 2001-01-29 19:12:40 faith Exp $
 * 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "maaP.h"

#define MAA_UNI_DEBUG 0

typedef unsigned int maaUniT;
#define MAA_UNI_CHARS (64*1024)
#define MAA_UNI_NORMS (16000)	/* Maximum number of normalization tests */


				/* General Category */
typedef enum {
				/* Normative Categories */
    MAA_UNI_LU, /* Letter, Uppercase */
    MAA_UNI_LL, /* Letter, Lowercase */
    MAA_UNI_LT, /* Letter, Titlecase */
    MAA_UNI_MN, /* Mark, Non-Spacing */
    MAA_UNI_MC, /* Mark, Spacing Combining */
    MAA_UNI_ME, /* Mark, Enclosing */
    MAA_UNI_ND, /* Number, Decimal Digit */
    MAA_UNI_NL, /* Number, Letter */
    MAA_UNI_NO, /* Number, Other */
    MAA_UNI_ZS, /* Seperator, Space */
    MAA_UNI_ZL, /* Seperator, Line */
    MAA_UNI_ZP, /* Seperator, Paragraph */
    MAA_UNI_CC, /* Other, Control */
    MAA_UNI_CF, /* Other, Format */
    MAA_UNI_CS, /* Other, Surrogate */
    MAA_UNI_CO, /* Other, Private Use */
    MAA_UNI_CN, /* Other, Not Assigned */

				/* Informative Categories */
    MAA_UNI_LM,	/* Latter, Modifier */
    MAA_UNI_LO, /* Letter, Other */
    MAA_UNI_PC, /* Punctuation, Connector */
    MAA_UNI_PD, /* Punctuation, Dash */
    MAA_UNI_PS, /* Punctuation, Open */
    MAA_UNI_PE, /* Punctuation, Close */
    MAA_UNI_PI, /* Punctuation, Initial quote */
    MAA_UNI_PF, /* Punctuation, Final quote */
    MAA_UNI_PO, /* Punctuation, Other */
    MAA_UNI_SM, /* Symbol, Math */
    MAA_UNI_SC, /* Symbol, Currency */
    MAA_UNI_SK, /* Symbol, Modifier */
    MAA_UNI_SO, /* Symbol, Other */
} maaUniGenCatT;

				/* Canonical Combining Classes */
typedef int maaUniCCCT;

				/* Bidirectional Category */
typedef enum {
    MAA_UNI_L,   /* Left-to-Right */
    MAA_UNI_LRE, /* Left-to-Right Embedding */
    MAA_UNI_LRO, /* Left-to-Right Override */
    MAA_UNI_R,   /* Right-to-Left */
    MAA_UNI_AL,  /* Right-to-Left Arabic */
    MAA_UNI_RLE, /* Right-to-Left Embedding */
    MAA_UNI_RLO, /* Right-to-Left Override */
    MAA_UNI_PDF, /* Pop Directional Format */
    MAA_UNI_EN,  /* European Number */
    MAA_UNI_ES,  /* European Number Separator */
    MAA_UNI_ET,  /* European Number Terminator */
    MAA_UNI_AN,  /* Arabic Number */
    MAA_UNI_CNS, /* Common Number Separator */
    MAA_UNI_NSM, /* Non-Spacing Mark */
    MAA_UNI_BN,  /* Boundary Neutral */
    MAA_UNI_B,   /* Paragraph Separator */
    MAA_UNI_S,   /* Segment Separator */
    MAA_UNI_WS,  /* Whitespace */
    MAA_UNI_ON,  /* Other Neutrals */
} maaUniBidCatT;

typedef enum {
    MAA_UNI_LOWERCASE, /* Lowercase */
    MAA_UNI_EXCEPTION  /* Exception */
} maaUniStatusT;

typedef enum {
    MAA_UNI_NFD,		/* Normalization Form D */
    MAA_UNI_NFC,		/* Normalization Form C */
    MAA_UNI_NFKD,		/* Normalization Form KD */
    MAA_UNI_NFKC		/* Normalization Form Kc */
} maaUniFormT;

struct genCatS {
    const char    *code;
    maaUniGenCatT value;
} genCatTable[] = {
    { "Lu", MAA_UNI_LU },
    { "Ll", MAA_UNI_LL },
    { "Lt", MAA_UNI_LT },
    { "Mn", MAA_UNI_MN },
    { "Mc", MAA_UNI_MC },
    { "Me", MAA_UNI_ME },
    { "Nd", MAA_UNI_ND },
    { "Nl", MAA_UNI_NL },
    { "No", MAA_UNI_NO },
    { "Zs", MAA_UNI_ZS },
    { "Zl", MAA_UNI_ZL },
    { "Zp", MAA_UNI_ZP },
    { "Cc", MAA_UNI_CC },
    { "Cf", MAA_UNI_CF },
    { "Cs", MAA_UNI_CS },
    { "Co", MAA_UNI_CO },
    { "Cn", MAA_UNI_CN },
    { "Lm", MAA_UNI_LM },
    { "Lo", MAA_UNI_LO },
    { "Pc", MAA_UNI_PC },
    { "Pd", MAA_UNI_PD },
    { "Ps", MAA_UNI_PS },
    { "Pe", MAA_UNI_PE },
    { "Pi", MAA_UNI_PI },
    { "Pf", MAA_UNI_PF },
    { "Po", MAA_UNI_PO },
    { "Sm", MAA_UNI_SM },
    { "Sc", MAA_UNI_SC },
    { "Sk", MAA_UNI_SK },
    { "So", MAA_UNI_SO },
    { NULL, 0 }
};

struct bidCatS {
    const char    *code;
    maaUniGenCatT value;
} bidCatTable[] = {
    { "L",   MAA_UNI_L },
    { "LRE", MAA_UNI_LRE },
    { "LRO", MAA_UNI_LRO },
    { "R",   MAA_UNI_R },
    { "AL",  MAA_UNI_AL },
    { "RLE", MAA_UNI_RLE },
    { "RLO", MAA_UNI_RLO },
    { "PDF", MAA_UNI_PDF },
    { "EN",  MAA_UNI_EN },
    { "ES",  MAA_UNI_ES },
    { "ET",  MAA_UNI_ET },
    { "AN",  MAA_UNI_AN },
    { "CS",  MAA_UNI_CNS },
    { "NSM", MAA_UNI_NSM },
    { "BN",  MAA_UNI_BN },
    { "B",   MAA_UNI_B },
    { "S",   MAA_UNI_S },
    { "WS",  MAA_UNI_WS },
    { "ON",  MAA_UNI_ON },
    { NULL,  0 }
};

typedef struct maaUniCharS {
				/* From UnicodeData-*.txt */
    maaUniT       codepoint;    /* Code point */
    const char    *name;	/* Character name */
    maaUniGenCatT gencat;	/* General Category */
    maaUniCCCT    ccc;		/* Canonical Combining Classes */
    maaUniBidCatT bidcat;	/* Bidirectional Category */
    const char    *tag;		/* Compatibility tag; NULL = canonical */
    maaUniT       *decomp;	/* Character Decomposition Mapping */
    int           decomplen;	/* Length of decomp */
    int           hasDecimal;	/* Decimal digit value preset */
    int           decimal;	/* Decimal digit value */
    int           hasDigit;	/* Digit value present */
    int           digit;	/* Digit value */
    const char    *numeric;	/* Numeric value */
    int           mirrored;	/* Mirrored */
    const char    *oldname;	/* Unicode 1.0 Name */
    const char    *comment;	/* 10646 comment field */
    maaUniT       *uppercase;	/* Uppercase Mapping */
    maaUniT       *lowercase;	/* Lowercase Mapping */
    maaUniT       *titlecase;	/* Titlecase Mapping */

				/* From CaseFolding-*.txt */
    maaUniStatusT status;
    maaUniT       *folding;

				/* Composition support */
    int           compose;	/* Part of a composeable pair */
    int           exclude;	/* Never a composition target */
    int           trie[2];
} maaUniCharT;

typedef struct maaUniDataS {
    maaUniCharT   u[MAA_UNI_CHARS];
    
				 /* Composition trie support */
    int           dims[2];	 /* Dimensions of trie */
    maaUniT       **composition; /* Composition table */
} *maaUniDataT;

typedef struct maaUniNormTestS {
    maaUniT       *c[5];
    const char    *comment;
} maaUniNormTestT;

typedef struct maaUniNormS {
    int             count;
    maaUniNormTestT t[MAA_UNI_NORMS];
} *maaUniNormT;

int maaUniLen(maaUniT *s)
{
    int i;

    for (i = 0; *s; ++i, ++s);
    return i;
}

maaUniDataT maaUniDataCreate(void)
{
    maaUniDataT ud = maaAllocZ(sizeof(*ud));
    int         i;

    for (i = 0; i < MAA_UNI_CHARS; i++) ud->u[i].gencat = MAA_UNI_CN;

    return ud;
}

maaUniNormT maaUniNormCreate(void)
{
    maaUniNormT norm = maaAllocZ(sizeof(*norm));
    return norm;
}

void maaUniDataDestroy(maaUniDataT ud)
{
    int i;
    
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	if (ud->u[i].name)    maaFree((void *)ud->u[i].name);
	if (ud->u[i].decomp)  maaFree(ud->u[i].decomp);
	if (ud->u[i].oldname) maaFree((void *)ud->u[i].oldname);
	if (ud->u[i].comment) maaFree((void *)ud->u[i].comment);
    }
    if (ud->composition) maaFree(ud->composition);
    maaFree(ud);
}

void maaUniNormDestroy(maaUniNormT norm)
{
    int i;
    
    for (i = 0; i < MAA_UNI_NORMS; i++) {
	if (norm->t[i].comment) maaFree((void *)norm->t[i].comment);
    }
    maaFree(norm);
}

maaUniT *maaUniFromHex(const char *s)
{
    char       *endptr;
    const char *pt;
    maaUniT    *buf, *d;

    buf = maaAlloc((strlen(s)/4 + 1) * sizeof(*buf));

    for (pt = s, d = buf; *pt; pt = endptr) *d++ = strtol(pt, &endptr, 16);
    *d = 0;

    return buf;
}

int maaUniDataReadDatabase(maaUniDataT ud, FILE *str) {
    char          buf[1024];
    int           codeValue;
    char          *f[16];
    int           i;
    maaUniCharT   *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	f[0] = buf;
	for (i = 1; i < 16; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}
	if ((codeValue = strtol(f[0], NULL, 16)) > MAA_UNI_CHARS) return 0;

	pt = &ud->u[codeValue];

	pt->codepoint  = codeValue;              /* Code Point */
	pt->name       = maaStrDup(f[1]);        /* Character Name */
	pt->ccc        = strtol(f[3], NULL, 10); /* Canonical Comb. Classes */
	pt->hasDecimal = (f[6][0] != '\0');
	pt->decimal    = strtol(f[6], NULL, 10); /* Decimal digit value */
	pt->hasDigit   = (f[7][0] != '\0');
	pt->digit      = strtol(f[7], NULL, 10); /* Digit value */
	pt->numeric    = maaAtomString(f[8]);    /* Numeric value */
	pt->mirrored   = (*f[9] == 'Y') ? 1 : 0; /* Mirrored */
	pt->oldname    = maaStrDup(f[10]);       /* Unicode 1.0 Name */
	pt->comment    = maaStrDup(f[11]);       /* 10646 comment field */
	pt->uppercase  = maaUniFromHex(f[12]);   /* Uppercase Mapping */
	pt->lowercase  = maaUniFromHex(f[13]);   /* Lowercase Mapping */
	pt->titlecase  = maaUniFromHex(f[14]);   /* Titlecase Mapping */

				/* General Category */
	if (*f[2]) {
	    struct genCatS *p;

	    for (p = &genCatTable[0]; p->code; ++p) {
		if (!strcmp(f[2], p->code)) {
		    pt->gencat = p->value;
		    break;
		}
	    }
	}

				/* Bidirectional Category */
	if (*f[4]) {
	    struct bidCatS *p;

	    for (p = &bidCatTable[0]; p->code; ++p) {
		if (!strcmp(f[4], p->code)) {
		    pt->bidcat = p->value;
		    break;
		}
	    }
	    
	}

				/* Compatibility tag */
	if (*f[5]) {
	    const char *decomp = f[5];
	    
	    if (*f[5] == '<') {
		pt->tag = maaAtomString(strtok(f[5]+1, ">"));
		decomp  = strtok(NULL, "");
	    }
	    pt->decomp    = maaUniFromHex(decomp);
	    pt->decomplen = maaUniLen(pt->decomp);
	}
    }
    
    return 0;
}

void maaUniPrintHex(FILE *str, const maaUniT *s)
{
    const maaUniT *pt;
    
    if (!s) return;
    for (pt = s; *pt; pt++) {
	if (pt != s) fprintf(str, " %04X", *pt);
	else         fprintf(str, "%04X", *pt);
    }
}

static void _maaUniPrintHex(maaUniDataT ud, FILE *str, const maaUniT *s)
{
    const maaUniT *pt;
    
    if (!s) return;
    for (pt = s; *pt; pt++) {
	if (pt != s) fprintf(str, " %04X/%d", *pt, ud->u[*pt].ccc);
	else         fprintf(str, "%04X/%d", *pt, ud->u[*pt].ccc);
    }
}

int maaUniDataComputeComposition(maaUniDataT ud, FILE *str)
{
    int  i, j;
    char buf[1024];

				/* Remove old trie and exclusion data*/
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	ud->u[i].trie[0] = ud->u[i].trie[1] = 0;
	ud->u[i].compose = 0;
	ud->u[i].exclude = 1;
    }
    ud->dims[0] = ud->dims[1] = 0;
    if (ud->composition) maaFree(ud->composition);

				/* Determine trie indices */
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	maaUniCharT *pt  = &ud->u[i];
	
	if (pt->tag || !pt->decomp) continue; /* No canonical decomp. */
	if (pt->decomplen != 2)     continue; /* Singleton */
	if (ud->u[*pt->decomp].ccc) continue; /* Not starter */

	for (j = 0; j < 2; j++) {
	    maaUniCharT *p = &ud->u[ pt->decomp[j] ];
	    if (!p->trie[j]) p->trie[j] = ++ud->dims[j];
	    ++p->compose;
	}
    }

				/* Allocate trie */
    printf("Trie[%d,%d]\n", ud->dims[0], ud->dims[1]);
    ud->composition = maaAlloc((ud->dims[0] + 1) * sizeof(*ud->composition));
    for (i = 0; i <= ud->dims[0]; i++)
	ud->composition[i] = maaAllocZ((ud->dims[1] + 1)
				       * sizeof(*ud->composition[0]));

				/* Fill composition table */
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	maaUniCharT *pt  = &ud->u[i];
	
	if (!pt->tag && pt->decomp) {
	    int i0, i1;
	    
	    if (pt->decomplen != 2) continue;
	    if (ud->u[*pt->decomp].ccc) continue;

	    i0 = ud->u[ pt->decomp[0] ].trie[0];
	    i1 = ud->u[ pt->decomp[1] ].trie[1];
	    ud->composition[i0][i1] = i;
	    pt->exclude             = 0;
	}
    }

				/* Read special exclusion table */
    while (fgets(buf, sizeof(buf)-1, str)) {
	maaUniT codepoint;
	
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	codepoint  = strtol(buf, NULL, 16);
	ud->u[codepoint].exclude = 1;
    }
    
    return 0;
}

int maaUniDataReadFolding(maaUniDataT ud, FILE *str) {
    char          buf[1024];
    int           codeValue;
    char          *f[4];
    int           i;
    maaUniCharT   *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	f[0] = buf;
	for (i = 1; i < 4; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}
	if ((codeValue = strtol(f[0], NULL, 16)) > MAA_UNI_CHARS) return 0;

	pt = &ud->u[codeValue];

	pt->status  = f[1][1] == 'L' ? MAA_UNI_LOWERCASE : MAA_UNI_EXCEPTION;
	pt->folding = maaUniFromHex(f[2]);
    }
    
    return 0;
}

int maaUniNormRead(maaUniNormT norm, FILE *str) {
    char            buf[1024];
    char            *f[6];
    int             i;
    maaUniNormTestT *pt;

    while (fgets(buf, sizeof(buf)-1, str)) {
	if (!*buf || *buf == '\n' || *buf == '#') continue;
	f[0] = buf;
	for (i = 1; i < 6; i++) {
	    char *p;
	    
	    for (p = f[i-1]; *p && *p != ';' && *p != '\n'; ++p);
	    *p = '\0';
	    f[i] = p + 1;
	}

	if (norm->count >= MAA_UNI_NORMS)
	    maaFatal(__FUNCTION__,
		     "More than %d normalization tests\n", norm->count);

	pt = &norm->t[norm->count++];
	for (i = 0; i < 5; i++) pt->c[i] = maaUniFromHex(f[i]);
	pt->comment = maaStrDup(f[5]);
    }
    
    return 0;
}

const char *_maaUniGenCatName(maaUniGenCatT gencat)
{
    switch (gencat) {
    case MAA_UNI_LU: return "Lu";
    case MAA_UNI_LL: return "Ll";
    case MAA_UNI_LT: return "Lt";
    case MAA_UNI_MN: return "Mn";
    case MAA_UNI_MC: return "Mc";
    case MAA_UNI_ME: return "Me";
    case MAA_UNI_ND: return "Nd";
    case MAA_UNI_NL: return "Nl";
    case MAA_UNI_NO: return "No";
    case MAA_UNI_ZS: return "Zs";
    case MAA_UNI_ZL: return "Zl";
    case MAA_UNI_ZP: return "Zp";
    case MAA_UNI_CC: return "Cc";
    case MAA_UNI_CF: return "Cf";
    case MAA_UNI_CS: return "Cs";
    case MAA_UNI_CO: return "Co";
    case MAA_UNI_CN: return "Cn";
    case MAA_UNI_LM: return "Lm";
    case MAA_UNI_LO: return "Lo";
    case MAA_UNI_PC: return "Pc";
    case MAA_UNI_PD: return "Pd";
    case MAA_UNI_PS: return "Ps";
    case MAA_UNI_PE: return "Pe";
    case MAA_UNI_PI: return "Pi";
    case MAA_UNI_PF: return "Pf";
    case MAA_UNI_PO: return "Po";
    case MAA_UNI_SM: return "Sm";
    case MAA_UNI_SC: return "Sc";
    case MAA_UNI_SK: return "Sk";
    case MAA_UNI_SO: return "So";
    default: maaFatal(__FUNCTION__, "Unknown category = %d\n", gencat);
    }
}

const char *_maaUniBidCatName(maaUniBidCatT bidcat)
{
    switch (bidcat) {
    case MAA_UNI_L:   return "L";
    case MAA_UNI_LRE: return "LRE";
    case MAA_UNI_LRO: return "LRO";
    case MAA_UNI_R:   return "R";
    case MAA_UNI_AL:  return "AL";
    case MAA_UNI_RLE: return "RLE";
    case MAA_UNI_RLO: return "RLO";
    case MAA_UNI_PDF: return "PDF";
    case MAA_UNI_EN:  return "EN";
    case MAA_UNI_ES:  return "ES";
    case MAA_UNI_ET:  return "ET";
    case MAA_UNI_AN:  return "AN";
    case MAA_UNI_CNS: return "CS";
    case MAA_UNI_NSM: return "NSM";
    case MAA_UNI_BN:  return "BN";
    case MAA_UNI_B:   return "B";
    case MAA_UNI_S:   return "S";
    case MAA_UNI_WS:  return "WS";
    case MAA_UNI_ON:  return "ON";
    default: maaFatal(__FUNCTION__, "Unknown category = %d\n", bidcat);
    }
}

void maaUniDataDumpDatabase(maaUniDataT ud, FILE *str)
{
    int i;
    
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	maaUniCharT *pt = &ud->u[i];

	if (pt->name) {
	    fprintf(str, "%04X", pt->codepoint);
	    fprintf(str, ";%s",  pt->name);
	    fprintf(str, ";%s", _maaUniGenCatName(pt->gencat));
	    fprintf(str, ";%d", pt->ccc);
	    fprintf(str, ";%s", _maaUniBidCatName(pt->bidcat));

	    fprintf(str, ";");
	    if (pt->tag) fprintf(str, "<%s> ", pt->tag);
	    maaUniPrintHex(str, pt->decomp);

	    fprintf(str, ";");
	    if (pt->hasDecimal) fprintf(str, "%d", pt->decimal);
	    fprintf(str, ";");
	    if (pt->hasDigit)   fprintf(str, "%d", pt->digit);
	    
	    fprintf(str, ";%s", pt->numeric ? pt->numeric : "");
	    fprintf(str, ";%c", pt->mirrored ? 'Y' : 'N');
	    fprintf(str, ";%s", pt->oldname ? pt->oldname : "");
	    fprintf(str, ";%s", pt->comment ? pt->comment : "");
	    
	    fprintf(str, ";"); maaUniPrintHex(str, pt->uppercase);
	    fprintf(str, ";"); maaUniPrintHex(str, pt->lowercase);
	    fprintf(str, ";"); maaUniPrintHex(str, pt->titlecase);
	    fprintf(str, "\n");
	}
    }
}

void maaUniDataDumpFolding(maaUniDataT ud, FILE *str)
{
    int i;
    
    for (i = 0; i < MAA_UNI_CHARS; i++) {
	maaUniCharT *pt = &ud->u[i];

	if (pt->folding) {
	    fprintf(str, "%04X", i);
	    fprintf(str, "; %c", pt->status == MAA_UNI_LOWERCASE ? 'L' : 'E');
	    fprintf(str, "; ");
	    maaUniPrintHex(str, pt->folding);
	    fprintf(str, ";\t#%s\n", pt->name);
	}
    }
}

void maaUniNormDump(maaUniNormT norm, FILE *str)
{
    int i, j;
    
    for (i = 0; i < norm->count; i++) {
	maaUniNormTestT *pt = &norm->t[i];

	for (j = 0; j < 5; j++) {
	    maaUniPrintHex(str, pt->c[j]);
	    fprintf(str, ";");
	}
	fprintf(str, "%s", pt->comment);
    }
}

maaUniT *maaUniCpy(maaUniT *dst, const maaUniT *src)
{
    maaUniT       *d;
    const maaUniT *s;

				/* FIXME: this can be optimized */
    for (s = src, d = dst; *s; s++, d++) *d = *s;
    *d = 0;
    return dst;
}

int maaUniCmp(const maaUniT *s1, const maaUniT *s2)
{
    for (;*s1 && *s2; s1++, s2++) {
	if (*s1 < *s2) return -1;
	if (*s1 > *s2) return 1;
    }
    if (*s1 < *s2) return -1;
    if (*s1 > *s2) return 1;
    return 0;
}

static void _maaUniCanonicalOrdering(maaUniDataT ud, maaUniT *src)
{
    maaUniCharT   *a, *b;
    maaUniT       *s, tmp;
    int           changed;

    do {
	for (changed = 0, s = src; *s; s++) {
	    a = &ud->u[s[0]];
	    b = &ud->u[s[1]];
	    if (b->ccc && a->ccc > b->ccc) {
		changed = 1;
		tmp     = s[1];
		s[1]    = s[0];
		s[0]    = tmp;
	    }
	}
    } while (changed);
}

static int _maaUniComposeHangul(maaUniT *dst, const maaUniT *src)
{
    const int     SBase  = 0xac00;
    const int     LBase  = 0x1100;
    const int     VBase  = 0x1161;
    const int     TBase  = 0x11a7;
    const int     LCount = 19;
    const int     VCount = 21;
    const int     TCount = 28;
    maaUniT       *d;
    const maaUniT *s;
    int           LIndex;
    int           VIndex;
    int           TIndex;
    int           len;

    for (d = dst, s = src; *s;) {
	if (!s[0] || !s[1]) {
	    *d++ = *s++;
	    continue;
	}
	if ((LIndex = s[0] - LBase) < 0 || LIndex >= LCount) {
	    *d++ = *s++;
	    continue;
	}
	if ((VIndex = s[1] - VBase) < 0 || VIndex >= VCount) {
	    *d++ = *s++;
	    continue;
	}
	if (!s[2] || (TIndex = s[2] - TBase) < 0 || TIndex >= TCount) {
	    TIndex = 0;
	    len    = 2;
	} else {
	    len    = 3;
	}

	*d++ = (LIndex * VCount + VIndex) * TCount + TIndex + SBase;
	s   += len;
    }
    *d = 0;
    return 0;
}

static int _maaUniDecomposeHangul(maaUniT *d, maaUniT s)
{
    const int SBase  = 0xac00;
    const int LBase  = 0x1100;
    const int VBase  = 0x1161;
    const int TBase  = 0x11a7;
    const int SCount = 11172;
/*     const int LCount = 19; */
    const int VCount = 21;
    const int TCount = 28;
    const int NCount = VCount * TCount;
    int       SIndex;
    int       L, V, T;

    if ((SIndex = s - SBase) < 0 || SIndex >= SCount) {
	*d = s;
	return 1;
    }

    L    = LBase + SIndex / NCount;
    V    = VBase + (SIndex % NCount) / TCount;
    T    = TBase + SIndex % TCount;
    *d++ = L;
    *d++ = V;
    if (T == TBase) return 2;
    *d++ = T;
    return 3;
}

static void maaUniDecompose(maaUniDataT ud, int compatibility,
			    maaUniT *dst, int len, const maaUniT *src)
{
    maaUniT       *d;
    const maaUniT *s;
    const maaUniT *p;
    int           changed = 0;
    maaUniT       *buf;
    maaUniCharT   *pt;

#if MAA_UNI_DEBUG
    printf("  Decomp. src[%p]=", src);
    _maaUniPrintHex(ud, stdout, src);
    printf("\n");
#endif

    buf = maaAlloc(len);
    for (s = src, d = buf; *s; s++) {
	pt = &ud->u[*s];
	if ((compatibility || !pt->tag) && pt->decomp) {
	    for (p = pt->decomp; *p;) *d++ = *p++;
	    ++changed;
	} else {
	    d += _maaUniDecomposeHangul(d, *s);
	}
    }
    *d = 0;
    if (changed) maaUniDecompose(ud, compatibility, dst, len, buf);
    else         maaUniCpy(dst, buf);
    _maaUniCanonicalOrdering(ud, dst);
    maaFree(buf);
    
#if MAA_UNI_DEBUG
    printf("  Decomp. res[%p]=", src);
    _maaUniPrintHex(ud, stdout, dst);
    printf("\n");
#endif
}

static void maaUniCompose(maaUniDataT ud, maaUniT *dst, int len,
			  const maaUniT *src)
{
    maaUniT       *d;
    int           idx;
    const maaUniT *s;
    int           changed = 0;
    maaUniT       *buf;
    maaUniCharT   *p0, *p1;
    int           i0, i1;
    maaUniT       codepoint;

#if MAA_UNI_DEBUG
    printf("  Compose src[%p]=", src);
    _maaUniPrintHex(ud, stdout, src);
    printf("\n");
#endif
    
    buf = maaAlloc(len);
    for (s = src, d = buf; *s; ++d) {
	p0 = &ud->u[*s];
	p1 = s[1] ? &ud->u[s[1]] : NULL;
	if (!p1 || p0->ccc || !p0->compose) {
	    *d = *s++;
	    continue;
	}

	idx = 0;
	++s;
	do {
	    i0        = p0->trie[0];
	    i1        = p1->trie[1];
	    codepoint = ud->composition[i0][i1];
	    if (codepoint && !ud->u[codepoint].exclude) {
		*d = ud->composition[i0][i1];
		++s;
		++changed;
#if MAA_UNI_DEBUG
		printf("    %04X (%d, %d) %04X (%d, %d) -> %04X\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d);
#endif
	    } else if (!p1->ccc) { /* Starter */
		*d = p0->codepoint;
#if MAA_UNI_DEBUG
		printf("    %04X (%d, %d) %04X (%d, %d) -> %04X %04X\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d, *s);
#endif
		break;
	    } else {
		*d       = p0->codepoint;
		d[++idx] = p1->codepoint;
		++s;
#if MAA_UNI_DEBUG
		printf("    %04X (%d,%d) %04X (%d,%d) -> %04X ? %04X [%04X]\n",
		       p0->codepoint, i0, p0->ccc,
		       p1->codepoint, i1, p1->ccc,
		       *d, d[idx], *s);
#endif
		while (*s && ud->u[*s].ccc == p1->ccc) {
#if MAA_UNI_DEBUG
		    printf("    Skip %04X (%d) [%04X]\n",
			   *s, ud->u[*s].ccc, s[1]);
#endif
		    d[++idx] = *s++;
		}
	    }

	    p0   = &ud->u[*d];
	    p1   = *s ? &ud->u[*s] : NULL;
#if MAA_UNI_DEBUG
	    printf("    p0 = %04X, p1 = %04X\n", p0->codepoint,
		   p1 ? p1->codepoint : 0);
#endif
	} while (p1 && p0->compose);
	d += idx;
    }
    *d = 0;

#if MAA_UNI_DEBUG
    printf("  Compose res[%p]=", buf);
    _maaUniPrintHex(ud, stdout, buf);
    printf(" (%d)\n", changed);
#endif

#if 1
    changed = 0;
#endif
    if (changed) maaUniCompose(ud, dst, len, buf);
    else         _maaUniComposeHangul(dst, buf);
    maaFree(buf);
}

void maaUniNormalize(maaUniDataT ud,
		     maaUniT *d, int len, const maaUniT *s, maaUniFormT form)
{
    maaUniT *tmp;
    
    switch (form) {
    case MAA_UNI_NFD:  maaUniDecompose(ud, 0, d, len, s); break;
    case MAA_UNI_NFKD: maaUniDecompose(ud, 1, d, len, s); break;
    case MAA_UNI_NFC:
	tmp = maaAlloc(len * sizeof(*tmp));
	maaUniDecompose(ud, 0, tmp, len, s);
	maaUniCompose(ud, d, len, tmp);
	maaFree(tmp);
	break;
    case MAA_UNI_NFKC:
	tmp = maaAlloc(len * sizeof(*tmp));
	maaUniDecompose(ud, 1, tmp, len, s);
	maaUniCompose(ud, d, len, tmp);
	maaFree(tmp);
	break;
    }
}

static void _maaUniNormFail(maaUniDataT ud, int test, const char *desc,
			    const maaUniT *got, const maaUniT *source,
			    const maaUniT *target)
{
    printf("Test %5d (%s) failed:\n           ", test, desc);
    _maaUniPrintHex(ud, stdout, source);
    printf("\n        -> ");
    _maaUniPrintHex(ud, stdout, target);
    printf("\n        != ");
    _maaUniPrintHex(ud, stdout, got);
    printf("\n");
}

static void _maaUniNormOneTest(maaUniDataT ud, maaUniNormT norm,
			       int test, maaUniFormT form,
			       int target, int source)
{
    maaUniNormTestT *pt = &norm->t[test];
    maaUniT         buf[1024];

#if MAA_UNI_DEBUG
    printf("Test %d ======================================\n", test);
#endif
    
    maaUniNormalize(ud, buf, sizeof(buf)-1, pt->c[source-1], form);

#if MAA_UNI_DEBUG
    printf("   Test %d: ", test);
    maaUniPrintHex(stdout, pt->c[source-1]);
    printf(" -> ");
    maaUniPrintHex(stdout, buf);
    printf("\n");
#endif
    
    if (maaUniCmp(buf, pt->c[target-1])) {
	char       desc[64];
	const char *formname = "?";
	
	switch (form) {
	case MAA_UNI_NFD:  formname = "NFD";  break;
	case MAA_UNI_NFC:  formname = "NFC";  break;
	case MAA_UNI_NFKD: formname = "NFKD"; break;
	case MAA_UNI_NFKC: formname = "NFKC"; break;
	}

	sprintf(desc, "c%d == %s(c%d)", target, formname, source);
	_maaUniNormFail(ud, test, desc, buf, pt->c[source-1], pt->c[target-1]);
	exit(1);
    }
}

void maaUniNormTest(maaUniDataT ud, maaUniNormT norm)
{
    int             i;

    for (i = 0; i < norm->count; i++) {
	/* NFD
	   c3 == NFD(c1) == NFD(c2) == NFD(c3)
	   c5 == NFD(c4) == NFD(c5) */
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFD, 3, 1);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFD, 3, 2);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFD, 3, 3);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFD, 5, 4);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFD, 5, 5);
	
	/* NFKD
	   c5 == NFKD(c1) == NFKD(c2) == NFKD(c3) == NFKD(c4) == NFKD(c5) */
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKD, 5, 1);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKD, 5, 2);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKD, 5, 3);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKD, 5, 4);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKD, 5, 5);

	/* NFC
	   c2 == NFC(c1) == NFC(c2) == NFC(c3)
	   c4 == NFC(c4) == NFC(c5) */
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFC, 2, 1);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFC, 2, 2);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFC, 2, 3);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFC, 4, 4);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFC, 4, 5);

	/* NFKC
	   c4 == NFKC(c1) == NFKC(c2) == NFKC(c3) == NFKC(c4) == NFKC(c5) */
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKC, 4, 1);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKC, 4, 2);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKC, 4, 3);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKC, 4, 4);
	_maaUniNormOneTest(ud, norm, i, MAA_UNI_NFKC, 4, 5);
    }
}

int main(int argc, char **argv)
{
    maaUniDataT ud;
    maaUniNormT norm;
    FILE        *str;
    
    ud = maaUniDataCreate();
    norm = maaUniNormCreate();

    if (!(str = fopen("unicode/UnicodeData-3.0.1.txt", "r"))) {
	fprintf(stderr, "Cannot open database\n");
	exit(1);
    }
    maaUniDataReadDatabase(ud, str);
    fclose(str);
    
    if (!(str = fopen("unicode/CompositionExclusions-2.txt", "r"))) {
	fprintf(stderr, "Cannot open database\n");
	exit(1);
    }
    maaUniDataComputeComposition(ud, str);
    fclose(str);

    if (!(str = fopen("unicode/CaseFolding-2.txt", "r"))) {
	fprintf(stderr, "Cannot open folding information\n");
	exit(1);
    }
    maaUniDataReadFolding(ud, str);
    fclose(str);

    if (!(str = fopen("unicode/NormalizationTest-3.0.1.txt", "r"))) {
	fprintf(stderr, "Cannot open normalization test\n");
	exit(1);
    }
    maaUniNormRead(norm, str);
    fclose(str);
    
    if (!(str = fopen("tmp.database", "w"))) {
	fprintf(stderr, "Cannot open tmp.database\n");
	exit(1);
    }
    maaUniDataDumpDatabase(ud, str);
    fclose(str);

    if (!(str = fopen("tmp.folding", "w"))) {
	fprintf(stderr, "Cannot open tmp.folding\n");
	exit(1);
    }
    maaUniDataDumpFolding(ud, str);
    fclose(str);

    if (!(str = fopen("tmp.norm", "w"))) {
	fprintf(stderr, "Cannot open tmp.norm\n");
	exit(1);
    }
    maaUniNormDump(norm, str);
    fclose(str);

    maaUniNormTest(ud, norm);

    maaUniDataDestroy(ud);
    maaUniNormDestroy(norm);

    return 0;
}
