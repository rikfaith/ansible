/* ngram.c -- 
 * Created: Thu Jun 12 13:08:24 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: ngram.c,v 1.2 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"
#include <math.h>

struct maaNgramS {
    unsigned long magic;
    int           n;
    maaHashT      hash;
    unsigned long unique_ngrams;
    unsigned long total_ngrams;
};

CHECK_FUNCTION(_maaNgramCheck, maaNgramT, MAA_NGRAM_MAGIC)

maaNgramT maaNgramCreate(int n)
{
    maaNgramT ng = maaAllocZ(sizeof(*ng));

    ng->magic = MAA_NGRAM_MAGIC;
    ng->n     = n;
    ng->hash  = maaHashCreate(NULL, NULL);
    return ng;
}

unsigned long maaNgramDestroy(maaNgramT ng)
{
    unsigned long ret;
    
    _maaNgramCheck(ng);
    ret = ng->magic = ~MAA_NGRAM_MAGIC;
    if (ng->hash) maaHashDestroy(ng->hash);
    maaFree(ng);
    return ret;
}

int maaNgramPut(maaNgramT ng, const char *filename)
{
    maaIteratorT     iter;
    const char       *key;
    unsigned long    datum;
    FILE             *str;

    _maaNgramCheck(ng);
    if (!(str = fopen(filename, "w"))) return -1;

    fprintf(str, "0x%08lx %d %d %d %lu %lu\n",
            ng->magic, ng->n, sizeof(datum), sizeof(*key),
            ng->unique_ngrams, ng->total_ngrams);
    MAA_HASH_ITERATE_UL(ng->hash, iter, key, datum) {
        fwrite(key,    sizeof(*key),  ng->n, str);
        fwrite(&datum, sizeof(datum), 1,     str);
    }
    fclose(str);
    return 0;
}

maaNgramT maaNgramGet(const char *filename)
{
    unsigned long  magic;
    unsigned long  dsize, ksize, klen;
    const char     *key;
    unsigned long  datum;
    FILE           *str;
    char           *buf;
    maaNgramT      ng;
    
    if (!(str = fopen(filename, "r"))) return NULL;
    ng = maaNgramCreate(0);
    fscanf(str, "0x%08lx %d %lu %lu %lu %lu\n",
           &magic, &ng->n, &dsize, &ksize,
           &ng->unique_ngrams, &ng->total_ngrams);
    klen = ksize * ng->n;
    buf  = maaAlloc(klen + dsize + 1);
    if (ng->magic        != magic
        || ksize         != sizeof(*key)
        || dsize         != sizeof(datum)) {
        maaNgramDestroy(ng);
        return NULL;
    }
    while (fread(buf, klen + dsize, 1, str)) {
        key       = maaAtomStringN(buf, klen);
        datum     = *(unsigned long *)(buf + klen);
        maaHashInsertUL(ng->hash, key, datum);
    }
    maaFree(buf);
    return ng;
}

void maaNgramAdd(maaNgramT ng, const void *buf, int len)
{
    int           i;
    const char    *pt;
    unsigned long value;
    const void    *ngram;

    _maaNgramCheck(ng);
    if (!len) len = strlen(buf);

    for (i = 0, pt = buf; pt && *pt && i < len - ng->n; ++pt, ++i) {
        ngram = maaAtomStringN(pt, ng->n);
        value = maaHashLookupUL(ng->hash, ngram);
        if (!value) ++ng->unique_ngrams;
        ++ng->total_ngrams;
        maaHashInsertUL(ng->hash, ngram, value + 1);
    }
}

void maaNgramPrint(maaNgramT ng, FILE *stream)
{
    maaIteratorT     iter;
    const char       *key;
    unsigned long    datum;

    _maaNgramCheck(ng);
    MAA_HASH_ITERATE_UL(ng->hash, iter, key, datum) {
        printf("%-20.20s %lu\n", key, datum);
    }
}

static double _maaNgramMatches(maaNgramT a, maaNgramT b)
{
    maaIteratorT     iter;
    const char       *key;
    int              matches = 0;
    int              total;

    maaHashIteratorLock(a->hash);
    MAA_HASH_ITERATE_UL_NODATUM(a->hash, iter, key)
        if (maaHashLookupUL(b->hash, key)) ++matches;
    maaHashIteratorUnlock(a->hash);

    total = a->unique_ngrams + b->unique_ngrams;
    return (double)matches / (double)(total - matches);
}

static double _maaNgramDot(maaNgramT a, maaNgramT b)
{
    maaIteratorT     iter;
    const char       *key;
    unsigned long    datum0, datum1;
    double           product = 0;
    
    maaHashIteratorLock(a->hash);
    MAA_HASH_ITERATE_UL(a->hash, iter, key, datum0)
        if ((datum1 = maaHashLookupUL(b->hash, key))) {
            double partial;
            partial = ((double)datum0/a->total_ngrams
                       *(double)datum1/b->total_ngrams);
            product += partial;
        }
    maaHashIteratorUnlock(a->hash);

    return product;
}

static double _maaNgramCosine(maaNgramT a, maaNgramT b)
{
    maaIteratorT     iter;
    const char       *key;
    unsigned long    datum0, datum1;
    double           num  = 0;
    double           sum0 = 0;
    double           sum1 = 0;
    
    maaHashIteratorLock(a->hash);
    MAA_HASH_ITERATE_UL(a->hash, iter, key, datum0) {
        double f = (double)datum0/a->total_ngrams;
        sum0 += f * f;
        if ((datum1 = maaHashLookupUL(b->hash, key)))
            num += f * (double)datum1/b->total_ngrams;
    }
    maaHashIteratorUnlock(a->hash);

    maaHashIteratorLock(b->hash);
    MAA_HASH_ITERATE_UL(b->hash, iter, key, datum1) {
        double f = (double)datum1/b->total_ngrams;
        sum1 += f * f;
    }
    maaHashIteratorUnlock(b->hash);
    
    return num / (sqrt(sum0) * sqrt(sum1));
}

double maaNgramCompare(maaNgramT a, maaNgramT b, maaNgramAlgT alg)
{
    _maaNgramCheck(a);
    _maaNgramCheck(b);
    switch (alg) {
    case MAA_NGRAM_MATCHES: return _maaNgramMatches(a, b);
    case MAA_NGRAM_DOT:     return _maaNgramDot(a, b);
    case MAA_NGRAM_COSINE:  return _maaNgramCosine(a, b);
    }
    return 0;
}
