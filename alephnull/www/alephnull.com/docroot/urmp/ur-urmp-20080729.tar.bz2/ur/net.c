/* net.c -- 
 * Created: Sat Aug 02 12:59:48 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: net.c,v 1.2 2003-09-06 03:03:52 faith Exp $
 * 
 */

#include "maaP.h"
#include <netdb.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <netinet/in.h>

typedef struct maaNetInfoS {
    int             port;
    maaNetCallbackT cb;
    void            *closure;
} *maaNetInfoT;

struct maaNetS {
    unsigned long   magic;

    int             fdsUsed;
    int             fdsTotal;
    int             fdsDeleted;
    int             lastDeleted;
    struct pollfd   *ufds;
    maaNetInfoT     info;
    int             slot;
};

CHECK_FUNCTION(_maaNetCheck, maaNetT, MAA_NET_MAGIC)

maaNetT maaNetCreate(void)
{
    maaNetT net = maaAllocZ(sizeof(*net));

    net->magic = MAA_NET_MAGIC;
    return net;
}

int maaNetOpenTcp(int port)
{
    struct protoent    *protocolEntry;
    struct sockaddr_in ssin;
    int                s;
    const int          one = 1;
    
    memset(&ssin, 0, sizeof(ssin));
    ssin.sin_family      = AF_INET;
    ssin.sin_addr.s_addr = INADDR_ANY;
    ssin.sin_port        = htons(port);
    
    if (!(protocolEntry = getprotobyname("tcp")))
        maaFatal(__func__, "Cannot get \"tcp\" protocol entry\n");
    
    if ((s = socket(PF_INET, SOCK_STREAM, protocolEntry->p_proto)) < 0)
        maaFatalErrno(__func__, "Cannot open socket on port %d\n",
                      ntohs(ssin.sin_port));
    
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    
    if (bind(s, (struct sockaddr *)&ssin, sizeof(ssin)) < 0)
        maaFatalErrno(__func__, "Cannot bind port %d\n", ntohs(ssin.sin_port));
    
    if (listen(s, 10) < 0)
        maaFatalErrno(__func__, "Cannot listen to port %d\n",
                      ntohs(ssin.sin_port));
    
    return s;
}

unsigned long maaNetDestroy(maaNetT net)
{
    unsigned long ret;
    
    _maaNetCheck(net);
    ret = net->magic = ~MAA_NET_MAGIC;
    if (net->ufds) maaFree(net->ufds);
    if (net->info) maaFree(net->info);
    maaFree(net);
    return ret;
}

static int maaNetGetSlot(maaNetT net)
{
    int oldtotal = net->fdsTotal;

                                /* Reuse? */
    if (net->info && net->fdsDeleted) {
        int i;
        
        for (i = net->lastDeleted; i < net->fdsTotal; i++) {
            if (net->ufds[i].fd < 0) {
                net->lastDeleted = i;
                --net->fdsDeleted;
                return i;
            }
        }
        for (i = 0; i < net->lastDeleted; i++) {
            if (net->ufds[i].fd < 0) {
                net->lastDeleted = i;
                --net->fdsDeleted;
                return i;
            }
        }
        if (net->fdsDeleted < 0)
            maaFatal(__func__, "deleted = %d\n", net->fdsDeleted);
    }

                                /* Get a new one */
    if (net->fdsUsed + 1 >= net->fdsTotal) {
        net->fdsTotal *= 2;
        if (!net->fdsTotal) net->fdsTotal = 128;
        net->ufds = maaReallocZ(net->ufds,
                                oldtotal * sizeof(*net->ufds),
                                net->fdsTotal * sizeof(*net->ufds));
        net->info = maaReallocZ(net->info,
                                oldtotal * sizeof(*net->info),
                                net->fdsTotal * sizeof(*net->info));
    }
    return net->fdsUsed++;
}

void maaNetAddPort(maaNetT net, int port, maaNetCallbackT cb, void *closure)
{
    int slot;
    
    _maaNetCheck(net);
    slot                    = maaNetGetSlot(net);
    net->info[slot].port    = port;
    net->info[slot].cb      = cb;
    net->info[slot].closure = closure;

    net->ufds[slot].fd      = maaNetOpenTcp(port);
    net->ufds[slot].events  = POLLIN|POLLPRI;
    net->ufds[slot].revents = 0;
}

void maaNetDelPort(maaNetT net, int port)
{
    int i;

    _maaNetCheck(net);
    for (i = 0; i < net->fdsUsed; i++)
        if (net->info[i].port == port) {
            close(net->ufds[i].fd);
            net->slot = i;
            maaNetDelFd(net, net->ufds[i].fd);
        }
}

void maaNetAddFd(maaNetT net, int fd, maaNetCallbackT cb, void *closure)
{
    int slot;
    
    _maaNetCheck(net);
    slot                    = maaNetGetSlot(net);
    net->info[slot].cb      = cb;
    net->info[slot].closure = closure;

    net->ufds[slot].fd      = fd;
    net->ufds[slot].events  = POLLIN|POLLPRI;
    net->ufds[slot].revents = 0;
}

static int maaNetFindSlot(maaNetT net, int fd)
{
    int i;
    
    if (net->slot < net->fdsUsed && net->ufds[net->slot].fd == fd)
        return net->slot;
    
    for (i = 0; i < net->fdsUsed; i++) if (net->ufds[i].fd == fd) return i;

    return -1;
}

void maaNetDelFd(maaNetT net, int fd)
{
    int slot;

    _maaNetCheck(net);
    if ((slot = maaNetFindSlot(net, fd)) >= 0) {
        if (net->info[slot].port) close(net->ufds[slot].fd);
        net->ufds[slot].fd = -1;
        ++net->fdsDeleted;
        net->lastDeleted = slot;
    }
}

static void maaNetSet(maaNetT net, int fd, short events)
{
    int slot = maaNetFindSlot(net, fd);
    if (slot >= 0) net->ufds[slot].events = events;
}

void maaNetSetRead(maaNetT net, int fd)
{
    _maaNetCheck(net);
    maaNetSet(net, fd, POLLIN|POLLPRI);
}

void maaNetSetWrite(maaNetT net, int fd)
{
    _maaNetCheck(net);
    maaNetSet(net, fd, POLLOUT);
}

void maaNetSetReadWrite(maaNetT net, int fd)
{
    _maaNetCheck(net);
    maaNetSet(net, fd, POLLIN|POLLPRI|POLLOUT);
}

void maaNetServer(maaNetT net)
{
    int i;
    int ret;
    
    _maaNetCheck(net);

    for (;;) {
        ret = poll(net->ufds, net->fdsUsed, -1);
        if (ret < 0 && errno != EINTR)
            maaFatalErrno(__func__, "poll failed\n");
        for (i = 0; i < net->fdsUsed && ret; i++) {
            if (net->ufds[i].revents) {
                --ret;
                if (net->info[i].cb) {
                    int events = 0;
                    net->slot  = i; /* cache current slot */
                    if (net->ufds[i].events & POLLIN)   events |= MAA_NET_IN;
                    if (net->ufds[i].events & POLLPRI)  events |= MAA_NET_IN;
                    if (net->ufds[i].events & POLLOUT)  events |= MAA_NET_OUT;
                    if (net->ufds[i].events & POLLERR)  events |= MAA_NET_ERR;
                    if (net->ufds[i].events & POLLHUP)  events |= MAA_NET_HUP;
                    if (net->ufds[i].events & POLLNVAL) events |= MAA_NET_NVAL;
                    
                    if (net->info[i].cb(net->ufds[i].fd, events,
                                        net->info[i].closure)) return;
                }
                net->ufds[i].revents = 0;
            }
        }
    }
}
