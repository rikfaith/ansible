/* arena.c -- 
 * Created: Mon Jul  5 13:29:22 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003, 2004 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: arena.c,v 1.13 2004-02-09 02:36:27 faith Exp $
 *
 * Based on the arena implementation in:
 *     Hanson, David R. C Interfaces and Implementations: Techniques for
 *     Creating Reusable Software.  Reading, Massachusetts: Addison-Wesley,
 *     1997.  Chapter 6, pp. 89-102.
 */

#include "maaP.h"

typedef struct maaArenaChunkS {
    int                   magic;
    size_t                size;
    struct maaArenaChunkS *prev;
    char                  *avail;
    char                  *limit;
} *maaArenaChunkT;

struct maaArenaS {
    unsigned long         magic;
    size_t                alignment;
    maaArenaChunkT        head;
    size_t                allocated;
    size_t                used;
    size_t                wasted;
};

typedef union maaArenaAlignU {
    int         i,  *ip;
    long        l,  *lp;
    void        *v, **vp;
    float       f,  *fp;
    double      d,  *dp;
    long double D,  *Dp;
    void        (*funct)(void);
} maaArenaAlignT;

typedef union maaArenaHeaderU {
    struct maaArenaS arena;
    maaArenaAlignT   alignment;
} *maaArenaHeaderT;

CHECK_FUNCTION(_maaArenaCheck, maaArenaT, MAA_ARENA_MAGIC)

maaArenaT maaArenaCreate(size_t alignment)
{
    maaArenaT arena = maaAlloc(sizeof(*arena));

    arena->magic     = MAA_ARENA_MAGIC;
    arena->head      = NULL;
    arena->allocated = 0;
    arena->used      = 0;
    arena->wasted    = 0;
    arena->alignment = alignment ? alignment : sizeof(maaArenaAlignT);

    return arena;
}

void maaArenaClear(maaArenaT arena)
{
    maaArenaChunkT chunk;
    maaArenaChunkT prev;

    for (chunk = arena->head; chunk; chunk = prev) {
	prev = chunk->prev;
	maaFree(chunk);
    }

    arena->head      = NULL;
    arena->allocated = 0;
    arena->used      = 0;
    arena->wasted    = 0;
}

unsigned long maaArenaDestroy(maaArenaT arena)
{
    unsigned long ret;
    
    _maaArenaCheck(arena);
    maaArenaClear(arena);
    ret = arena->magic = ~MAA_ARENA_MAGIC;
    maaFree(arena);
    return ret;
}

static void _maaArenaGetChunk(maaArenaT arena, size_t needed)
{
    maaArenaChunkT chunk;
    size_t         size;

    size              = sizeof(maaArenaHeaderT) + needed + MAA_ARENA_CHUNK;
    chunk             = maaAlloc(size);

    if (arena->head) {
	arena->wasted = arena->head->limit - arena->head->avail;
    }

    chunk->magic      = MAA_ARENA_MAGIC;
    chunk->size       = size;
    chunk->prev       = arena->head;
    chunk->avail      = (char *)(chunk + 1);
    chunk->limit      = (char *)chunk + size;

    arena->head       = chunk;
    arena->allocated += size;
}

void *maaArenaAlloc(maaArenaT arena, size_t size)
{
    maaArenaChunkT chunk = arena->head;
    size_t         s;
    
    _maaArenaCheck(arena);
    if (size <= 0) maaFatal(__FUNCTION__, "Size = %lu\n", (unsigned long)size);

    s = ((size + arena->alignment - 1) / arena->alignment) * arena->alignment;

    if (!chunk || s > (size_t)(chunk->limit - chunk->avail))
	_maaArenaGetChunk(arena, s); /* Get new chunk */

    arena->used        += s;
    if (!arena->head) maaInternal(__FUNCTION__, "NULL Head\n");
    arena->head->avail += s;
    
    return arena->head->avail - s;
}

void *maaArenaAllocZ(maaArenaT arena, size_t size)
{
    void *pt = maaArenaAlloc(arena, size);

    memset(pt, 0, size);
    return pt;
}
