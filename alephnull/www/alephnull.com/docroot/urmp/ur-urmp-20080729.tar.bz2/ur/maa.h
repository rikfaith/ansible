/* maa.h -- Public header for maa
 * Created: Sun Jul  4 09:27:58 1999 by faith@dict.org
 * Copyright 1999-2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: maa.h,v 1.43 2003-09-12 13:15:17 faith Exp $
 * 
 */

#ifndef _MAA_H_
#define _MAA_H_

#if !defined(__GNUC__) && !defined(__LCLINT__)
#define __attribute__(x)
#endif

#include <stdio.h>
#include <stdarg.h>

				/* maa support and error management */
typedef struct maaListS *maaListT;
typedef struct maaIteratorS {
    void          *a;
    void          *b;
    unsigned long c;
    int           d;
    int           e;
} maaIteratorT;

typedef enum {
    MAA_ERROR_TRACE    = 0x00000001, /* Continues */
    MAA_ERROR_WARN     = 0x00000002, /* Continues */
    MAA_ERROR_INFO     = 0x00000004, /* Continues */
    MAA_ERROR_FATAL    = 0x00000008, /* Exits */
    MAA_ERROR_INTERNAL = 0x00000010, /* Exits */
    
    MAA_ERROR_ERRNO    = 0x10000000, /* Uses errno */
    MAA_ERROR_ABORT    = 0x20000000  /* Exits with abort */
} maaErrorT;

extern void          maaInit(const char *programName);
extern const char    *maaProgramName(void);
extern void          maaShutdown(void);
extern const char    *maaVersion(void);
extern int           maaVersionMajor(void);
extern int           maaVersionMinor(void);
extern int           maaVersionPatch(void);
extern const char    *maaVersionDate(void);

extern void          maaTraceRegister(unsigned long flag, const char *name);
extern void          maaTraceSet(unsigned long flag);
extern void          maaTraceUnset(unsigned long flag);
extern void          maaTraceSetByName(const char *name,
                                       int (*f)(const char *));
extern void          maaTraceUnsetByName(const char *name,
                                         int (*f)(const char *));
extern int           maaTraceTestByName(const char *name,
                                        int (*f)(const char *));
extern int           maaTraceTest(unsigned long flag); /* FIXME -- inline */
extern maaListT      maaTraceNames(void);

extern void          maaError(maaErrorT mask, int error,
			      const char *routine, const char *format,
			      va_list ap);
extern void          maaTrace(unsigned long flag, const char *routine,
			      const char *format,
			      ...) __attribute__((format(printf,3,4)));
extern void          maaWarning(const char *routine, const char *format,
				...) __attribute__((format(printf,2,3)));
extern void          maaFatal(const char *routine, const char *format,
			      ...) __attribute__((noreturn,
						  format(printf,2,3)));
extern void          maaFatalAbort(const char *routine, const char *format,
                                   ...) __attribute__((noreturn,
                                                       format(printf,2,3)));
extern void          maaFatalErrno(const char *routine, const char *format,
				   ...) __attribute__((noreturn,
						       format(printf,2,3)));
extern void          maaInternal(const char *routine, const char *format,
				 ... ) __attribute__((noreturn,
						      format(printf,2,3)));
extern void          maaErrorCallback(int (*f)(int severity,
					       const char *message));
extern void          maaLogFile(const char *filename);
extern void          maaLogSyslog(void);
extern void          maaLogClose(void);
extern void          maaLogError(const char *routine, const char *format,
				 ...) __attribute__((format(printf,2,3)));
extern void          maaLogErrorV(const char *routine, const char *format,
				  va_list ap);
extern void          maaLogInfo(const char *routine, const char *format,
				...) __attribute__((format(printf,2,3)));
extern void          maaLogInfoV(const char *routine, const char *format,
				 va_list ap);
extern int           maaLogBacktrace(const char *format, ...);

				/* simple stack */

typedef struct maaStackS *maaStackT;

extern maaStackT     maaStackCreate(void);
extern unsigned long maaStackDestroy(maaStackT stack);
extern void          maaStackPush(maaStackT stack, const void *datum);
extern void          *maaStackPop(maaStackT stack);
extern const void    *maaStackTop(maaStackT stack);
extern void          *maaStackPick(maaStackT stack, unsigned int n);
extern unsigned int  maaStackDepth(maaStackT stack);
extern void          maaStackSwap(maaStackT stack);
extern void          maaStackDup(maaStackT stack);
extern void          maaStackIteratorInit(maaStackT stack, maaIteratorT *iter);
extern int           maaStackIteratorNext(maaIteratorT *iter);
extern void          *maaStackIteratorDatum(maaIteratorT *iter);

#define MAA_STACK_INIT(L,I)  maaStackIteratorInit(L,&(I))
#define MAA_STACK_GET(I,D)   ((D) = maaStackIteratorDatum(&(I)))
#define MAA_STACK_NEXT(I)    maaStackIteratorNext(&(I))
#define MAA_STACK_ITERATE(L,I,D) \
    for (MAA_STACK_INIT(L,I); MAA_STACK_GET(I,D); MAA_STACK_NEXT(I))

				/* dynamic arrays */

#if 0
typedef struct maaArrayS *maaArrayT;

extern maaArrayT     maaArrayCreate(void);
extern unsigned long maaArrayDestroy(maaStackT stack);
extern void          maaArrayPush(maaStackT stack, const void *datum);
extern const void    *maaArrayPop(maaStackT stack);

extern const void    *maaArrayTop(maaStackT stack);
extern const void    *maaArrayPick(maaStackT stack, unsigned int n);
extern unsigned int  maaArrayDepth(maaStackT stack);
extern void          maaArraySwap(maaStackT stack);
extern void          maaArrayRotate(maaStackT stack, signed int n);
extern void          maaArrayDup(maaStackT stack);
#endif


				/* hash tables */

typedef struct maaHashS *maaHashT;

typedef unsigned long (*maaHashHashT)(const void *key);
typedef int           (*maaHashCompareT)(const void *key1, const void *key2);

extern maaHashT      maaHashCreate(maaHashHashT hash, maaHashCompareT compare);
extern unsigned long maaHashDestroy(maaHashT table);
extern void          *maaHashLookup(maaHashT table, const void *key);
extern unsigned long maaHashLookupUL(maaHashT table, const void *key);
extern int           maaHashInsert(maaHashT table, const void *key,
				   const void *datum);
extern int           maaHashInsertUL(maaHashT table, const void *key,
				     unsigned long datum);
extern int           maaHashDelete(maaHashT table, const void *key);
extern unsigned long maaHashItems(maaHashT table);
extern int           maaHashPrintStats(maaHashT table, FILE *str, int flags);
extern void          maaHashIteratorInit(maaHashT table, maaIteratorT *iter);
extern int           maaHashIteratorNext(maaIteratorT *iter);
extern void          *maaHashIteratorKey(maaIteratorT *iter);
extern void          *maaHashIteratorDatum(maaIteratorT *iter);
extern unsigned long maaHashIteratorDatumUL(maaIteratorT *iter);
extern void          maaHashIteratorLock(maaHashT table);
extern void          maaHashIteratorUnlock(maaHashT table);

#define MAA_HASH_INIT(L,I)  maaHashIteratorInit(L,&(I))
#define MAA_HASH_GET(I,K,D)    (((K) = maaHashIteratorKey(&(I))) \
		     	        && ((D) = maaHashIteratorDatum(&(I))))
#define MAA_HASH_GET_NODATUM(I,K) (((K) = maaHashIteratorKey(&(I))) \
		     	          && maaHashIteratorDatum(&(I)))
#define MAA_HASH_GET_UL(I,K,D) (((K) = maaHashIteratorKey(&(I))) \
		     	        && ((D)                          \
                                    = (unsigned long)maaHashIteratorDatum( \
                                                     &(I))))
#define MAA_HASH_GET_UL_NODATUM(I,K) (((K) = maaHashIteratorKey(&(I))) \
 		     	             && maaHashIteratorDatum(&(I)))
#define MAA_HASH_NEXT(I)    maaHashIteratorNext(&(I))
#define MAA_HASH_ITERATE(L,I,K,D) \
    for (MAA_HASH_INIT(L,I); MAA_HASH_GET(I,K,D); MAA_HASH_NEXT(I))
#define MAA_HASH_ITERATE_NODATUM(L,I,K) \
    for (MAA_HASH_INIT(L,I); MAA_HASH_GET_NODATUM(I,K); MAA_HASH_NEXT(I))
#define MAA_HASH_ITERATE_UL(L,I,K,D) \
    for (MAA_HASH_INIT(L,I); MAA_HASH_GET_UL(I,K,D); MAA_HASH_NEXT(I))
#define MAA_HASH_ITERATE_UL_NODATUM(L,I,K) \
    for (MAA_HASH_INIT(L,I); MAA_HASH_GET_UL_NODATUM(I,K); MAA_HASH_NEXT(I))



				/* skip lists */

typedef struct maaSkipListS *maaSkipListT;

typedef int (*maaSkipListCompareT)(const void * key1, const void *key2);

extern maaSkipListT  maaSkipListCreate(maaSkipListCompareT compare);
extern unsigned long maaSkipListDestroy(maaSkipListT list);
extern void          *maaSkipListLookup(maaSkipListT list, const void *key);
extern int           maaSkipListInsert(maaSkipListT list,
				       const void *key,
				       const void *datum);
extern int           maaSkipListDelete(maaSkipListT list, const void *key);
extern int           maaSkipListPrintStats(maaSkipListT list, FILE *str,
					   int flags);
extern void          maaSkipListIteratorInit(maaSkipListT list,
					     maaIteratorT *iter);
extern int           maaSkipListIteratorNext(maaIteratorT *iter);
extern void          *maaSkipListIteratorKey(maaIteratorT *iter);
extern void          *maaSkipListIteratorDatum(maaIteratorT *iter);

#define MAA_SKIPLIST_INIT(L,I)  maaSkipListIteratorInit(L,&(I))
#define MAA_SKIPLIST_GET(I,K,D) (((K) = maaSkipListIteratorKey(&(I))) \
		     	         && ((D) = maaSkipListIteratorDatum(&(I))))
#define MAA_SKIPLIST_NEXT(I)    maaSkipListIteratorNext(&(I))
#define MAA_SKIPLIST_ITERATE(L,I,K,D) \
    for (MAA_SKIPLIST_INIT(L,I); MAA_SKIPLIST_GET(I,K,D); MAA_SKIPLIST_NEXT(I))


				/* AVL trees */

typedef struct maaAVLTreeS *maaAVLTreeT;

typedef int (*maaAVLTreeCompareT)(const void *key1, const void *key2);

extern maaAVLTreeT   maaAVLTreeCreate(maaAVLTreeCompareT compare);
extern unsigned long maaAVLTreeDestroy(maaAVLTreeT tree);
extern void          *maaAVLTreeLookup(maaAVLTreeT tree, const void *key);
extern int           maaAVLTreeInsert(maaAVLTreeT tree, const void *key,
				      const void *datum);
extern int           maaAVLTreeDelete(maaAVLTreeT tree, const void *key);
extern int           maaAVLTreePrintStats(maaAVLTreeT tree, FILE *str,
					  int flags);

				/* unordered lists */
#define MAA_LIST_DELIM   " \t\n\r\v\f"
#define MAA_LIST_QUOTE   "\"'"
#define MAA_LIST_ESCAPE  "\\"

extern maaListT      maaListCreate(void);
extern unsigned long maaListDestroy(maaListT list);
extern unsigned int  maaListDepth(maaListT list);
extern void          maaListAppend(maaListT list, const void *datum);
extern void          maaListPush(maaListT list, const void *datum);
extern void          *maaListPop(maaListT list);
extern void          *maaListTop(maaListT List);
extern void          *maaListLast(maaListT list);
extern void          *maaListBot(maaListT list);
extern void          *maaListNth(maaListT list, int n);
extern void          maaListMakeArgv(maaListT list, int *argc,
				     const char ***argv);
extern void          maaListParse(maaListT list, const char *string,
				  const char *delim, const char *quote,
				  const char *escape);
extern void          maaListParseString(maaListT list, const char *string);

extern void          maaListIteratorInit(maaListT list, maaIteratorT *iter);
extern int           maaListIteratorNext(maaIteratorT *iter);
extern void          *maaListIteratorDatum(maaIteratorT *iter);

#define MAA_LIST_INIT(L,I)  maaListIteratorInit(L,&(I))
#define MAA_LIST_GET(I,D)   ((D) = maaListIteratorDatum(&(I)))
#define MAA_LIST_NEXT(I)    maaListIteratorNext(&(I))
#define MAA_LIST_ITERATE(L,I,D) \
    for (MAA_LIST_INIT(L,I); MAA_LIST_GET(I,D); MAA_LIST_NEXT(I))
	     
				/* trees */

typedef struct maaTreeS *maaTreeT;
typedef enum {
    MAA_TREE_INORDER,
    MAA_TREE_PREORDER,
    MAA_TREE_POSTORDER
}                       maaTreeWalkT;
typedef struct maaTreeAttribS {
    const char *name;
    const char *value;
} *maaTreeAttribT;

extern maaTreeT      maaTreeCreate(int id);
extern maaTreeT      maaTreeMake(int id, ...);
extern unsigned long maaTreeDestroyNode(maaTreeT node);
extern unsigned long maaTreeDestroyTree(maaTreeT root);
extern maaTreeT      maaTreeDisconnect(maaTreeT node);
extern maaTreeT      maaTreeAppend(maaTreeT parent, maaTreeT child);
extern maaTreeT      maaTreePrepend(maaTreeT parent, maaTreeT child);
extern maaTreeT      maaTreeInsertBefore(maaTreeT sibling, maaTreeT child);
extern maaTreeT      maaTreeInsertAfter(maaTreeT sibling, maaTreeT child);
extern maaTreeT      maaTreeInsertLast(maaTreeT sibling, maaTreeT child);
extern maaTreeT      maaTreeInsertFirst(maaTreeT sibling, maaTreeT child);

extern void          maaTreeSetString(maaTreeT node, const char *string);
extern void          maaTreeSetInteger(maaTreeT node, int i);
extern void          maaTreeSetReal(maaTreeT node, double r);
extern void          maaTreeSetAttrib(maaTreeT node, const char *name,
				      const char *value);
extern int           maaTreeHasString(maaTreeT node);
extern int           maaTreeHasInteger(maaTreeT node);
extern int           maaTreeHasReal(maaTreeT node);
extern int           maaTreeHasAttrib(maaTreeT node);
extern int           maaTreeHasList(maaTreeT node);
extern int           maaTreeId(maaTreeT node);
extern maaTreeT      maaTreeParent(maaTreeT node);
extern maaTreeT      maaTreeChild(maaTreeT node);
extern maaTreeT      maaTreeSibling(maaTreeT node);
extern const char    *maaTreeString(maaTreeT node);
extern int           maaTreeInteger(maaTreeT node);
extern double        maaTreeReal(maaTreeT node);
extern const char    *maaTreeAttrib(maaTreeT node, const char *name);
extern maaListT      maaTreeAttribList(maaTreeT node);
extern void          maaTreeIteratorInit(maaTreeT node, maaIteratorT *iter,
					 maaTreeWalkT walk);
extern int           maaTreeIteratorNext(maaIteratorT *iter);
extern maaTreeT      maaTreeIteratorDatum(maaIteratorT *iter, int *position);
extern void          maaTreePrint(maaTreeT root, FILE *stream);

#define MAA_TREE_INIT(L,I,T) maaTreeIteratorInit(L,&(I),(T))
#define MAA_TREE_GET(I,D,P)  ((D) = maaTreeIteratorDatum(&(I),&(P)))
#define MAA_TREE_NEXT(I)     maaTreeIteratorNext(&(I))
#define MAA_TREE_ITERATE(L,I,D,T,P) \
    for (MAA_TREE_INIT(L,I,T); MAA_TREE_GET(I,D,P); MAA_TREE_NEXT(I))

				/* debug flags */
typedef struct maaFlagS *maaFlagT;

extern maaFlagT      maaFlagCreate(void);
extern unsigned long maaFlagDestroy(maaFlagT flags);
extern void          maaFlagRegister(maaFlagT flags, unsigned long flag,
				     const char *name);
       
extern void          maaFlagSet(maaFlagT flags, unsigned long flag);
extern void          maaFlagUnset(maaFlagT flags, unsigned long flag);
extern int           maaFlagTest(maaFlagT flags, unsigned long flag);
extern void          maaFlagSetByName(maaFlagT flags, const char *name,
                                      int (*f)(const char *));
extern void          maaFlagUnsetByName(maaFlagT flags, const char *name,
                                        int (*f)(const char *));
extern int           maaFlagTestByName(maaFlagT flags, const char *name,
                                       int (*f)(const char *));
extern const char    *maaFlagName(maaFlagT flags, unsigned long flag);
extern maaListT      maaFlagNames(maaFlagT flags);



				/* arenas */
typedef struct maaArenaS *maaArenaT;

extern maaArenaT     maaArenaCreate(size_t alignment);
extern void          maaArenaClear(maaArenaT arena);
extern unsigned long maaArenaDestroy(maaArenaT arena);
extern void          *maaArenaAlloc(maaArenaT arena, size_t size);
extern void          *maaArenaAllocZ(maaArenaT arena,size_t size);


				/* block allocator */

typedef struct maaBlockS *maaBlockT;
			   
extern maaBlockT     maaBlockCreate(size_t blocksize);
extern unsigned long maaBlockDestroy(maaBlockT block);
extern void          *maaBlockAlloc(maaBlockT block);
extern void          *maaBlockAllocZ(maaBlockT block);
extern void          maaBlockFree(maaBlockT block, void *area);



				/* memory management */

extern void          *maaAlloc(size_t size);
extern void          *maaAllocZ(size_t size);
extern void          *maaRealloc(void *old, size_t size);
extern void          *maaReallocZ(void *old, size_t oldsize, size_t newsize);
extern void          maaFree(void *object);
extern char          *maaStrdup(const char *s);

#ifdef DMALLOC_FUNC_CHECK
#define maaAlloc(s)     _malloc_leap(__FILE__, __LINE__, s)
#define maaAllocZ(s)    _calloc_leap(__FILE__, __LINE__, 1, s)
#define maaRealloc(o,s) _realloc_leap(__FILE__, __LINE__, o, s)
#define maaFree(o)      _free_leap(__FILE__, __LINE__, o)
#endif


				/* global atoms */

extern const void    *maaAtomNew(const void *datum, int len);
extern const char    *maaAtomString(const char *datum);
extern const char    *maaAtomStringN(const char *datum, int len);
extern void          maaAtomDestroy(void);



				/* pseudorandom number generation */

typedef struct maaRandomS *maaRandomT;
typedef enum {
    MAA_RANDOM_STD,
    MAA_RANDOM_ALT0,
    MAA_RANDOM_ALT1,
    MAA_RANDOM_ALT2,
    MAA_RANDOM_LONG
}                    maaRandomTypeT;
typedef enum {
    MAA_RANDOM_UNIFORM,
    MAA_RANDOM_SHUFFLE
}                    maaRandomModifierT;

extern maaRandomT    maaRandomCreate(maaRandomTypeT type,
				     maaRandomModifierT mo);
extern unsigned long maaRandomDestroy(maaRandomT prng);
extern void          maaRandomSeed(maaRandomT prng,
				   unsigned long seed0,
				   unsigned long seed1);
extern unsigned long maaRandom(maaRandomT prng);
extern unsigned long maaRandomMax(maaRandomT prng);
extern unsigned long maaRandomRange(maaRandomT prng,
				    unsigned long min,
				    unsigned long max);
extern double        maaRandomReal(maaRandomT prng);



				/* timers */

typedef struct maaTimerS *maaTimerT;
typedef enum {
    MAA_TIMER_WALL  = 0x01,
    MAA_TIMER_CPU   = 0x02,
    MAA_TIMER_CYCLE = 0x04,
    MAA_TIMER_ALL   = ~0
}                    maaTimerTypeT;

typedef struct maaTimevalS {
    struct timeval   wall;
    struct timeval   user;
    struct timeval   system;
    struct timeval   children_user;
    struct timeval   children_system;
    unsigned long    cycle_hi;
    unsigned long    cycle_lo;
} maaTimevalT;

extern maaTimerT     maaTimerCreate(maaTimerTypeT type);
extern unsigned long maaTimerDestroy(maaTimerT timer);
extern void          maaTimerStart(maaTimerT timer);
extern void          maaTimerStop(maaTimerT timer);
extern void          maaTimerGetStart(maaTimerT timer, maaTimevalT *timeval);
extern void          maaTimerGetStop(maaTimerT timer, maaTimevalT *timeval);
extern void          maaTimerSetStart(maaTimerT timer, maaTimevalT *timeval);
extern void          maaTimerSetStop(maaTimerT timer, maaTimevalT *timeval);
extern void          maaTimerGetElapsed(maaTimerT timer, maaTimevalT *timeval);


				/* option parsing */
typedef struct maaOptionS *maaOptionT;

typedef enum {
    MAA_OPTION_NONE,
    MAA_OPTION_ARG,
    MAA_OPTION_LIST
}                    maaOptionTypeT;

typedef struct maaOptionListS {
    const char       *longname;
    int              shortname;
    maaOptionTypeT   type;
} maaOptionListT;

extern maaOptionT    maaOptionCreate(maaOptionListT *list);
extern void          maaOptionParseArgv(maaOptionT opt,
					int argc, const char **argv);
extern void          maaOptionParseString(maaOptionT opt, const char *string);
extern void          maaOptionParseList(maaOptionT opt, maaListT list);
extern unsigned long maaOptionDestroy(maaOptionT opt);
extern int           maaOptionGet(maaOptionT opt);
extern long          maaOptionInt(maaOptionT opt);
extern double        maaOptionReal(maaOptionT opt);
extern const char    *maaOptionString(maaOptionT opt);
extern maaListT      maaOptionList(maaOptionT opt);
extern maaListT      maaOptionOther(maaOptionT opt);
extern int           maaOptionInRange(const char *range, unsigned long val);

				/* base encoding and decoding */
extern const char    *maaBase26Encode(unsigned long val);
extern unsigned long maaBase26Decode(const char *val);
extern const char    *maaBase64Encode(unsigned long val);
extern unsigned long maaBase64Decode(const char *val);
extern const char    *maaBase85Encode(unsigned long val);
extern unsigned long maaBase85Decode(const char *val);

                                /* file support (mmap) */
typedef struct maaFileS *maaFileT;

extern maaFileT      maaFileOpen(const char *filename);
extern const void    *maaFileStart(maaFileT file);
extern const void    *maaFileEnd(maaFileT file);
extern unsigned long maaFileLength(maaFileT file);
extern const void    *maaFileSet(maaFileT file, void *pos);
extern const void    *maaFileGet(maaFileT file);
extern unsigned long maaFileClose(maaFileT file);

                                /* mail support */
typedef struct maaMailS *maaMailT;

extern maaMailT      maaMailCreate(const void *buffer,
                                   unsigned long len);
extern unsigned long maaMailDestroy(maaMailT mail);
extern const void    *maaMailNext(maaMailT mail, unsigned long *len);
extern const void    *maaMailHeader(maaMailT mail, unsigned long *len,
                                    const char *re);
extern maaListT      maaMailHeaders(maaMailT mail);
extern const char    *maaMailHeaderFind(maaMailT mail, const char *name,
                                        int idx);
extern const void    *maaMailBody(maaMailT mail, unsigned long *len);
extern int           maaMailParts(maaMailT mail);
extern const void    *maaMailPart(maaMailT mail, int part, unsigned long *len);

                                /* ngram support */
typedef struct maaNgramS *maaNgramT;
typedef enum {
    MAA_NGRAM_MATCHES,
    MAA_NGRAM_DOT,
    MAA_NGRAM_COSINE
}                        maaNgramAlgT;

extern maaNgramT     maaNgramCreate(int n);
extern unsigned long maaNgramDestroy(maaNgramT ng);
extern void          maaNgramAdd(maaNgramT ng, const void *buf, int len);
extern void          maaNgramPrint(maaNgramT ng, FILE *stream);
extern double        maaNgramCompare(maaNgramT a, maaNgramT b,
                                     maaNgramAlgT alg);
extern int           maaNgramPut(maaNgramT ng, const char *filename);
extern maaNgramT     maaNgramGet(const char *filename);

                                /* trigram support */
typedef struct maaTrigramS *maaTrigramT;
typedef enum {
    MAA_TRIGRAM_MATCHES,
    MAA_TRIGRAM_COSINE
}                        maaTrigramAlgT;

extern maaTrigramT   maaTrigramCreate(void);
extern unsigned long maaTrigramDestroy(maaTrigramT tg);
extern void          maaTrigramAdd(maaTrigramT tg, const void *buf, int len);
extern void          maaTrigramPrint(maaTrigramT tg, FILE *stream);
extern double        maaTrigramCompare(maaTrigramT a, maaTrigramT b,
                                     maaTrigramAlgT alg);
extern int           maaTrigramPut(maaTrigramT tg, const char *filename);
extern maaTrigramT   maaTrigramGet(const char *filename);
extern void          maaTrigramSubtract(maaTrigramT a, maaTrigramT b);
extern unsigned long maaTrigramMatches(maaTrigramT a, maaTrigramT b);

                                /* network support */
typedef struct maaNetS *maaNetT;

typedef enum {
    MAA_NET_IN   = 0x01,
    MAA_NET_OUT  = 0x02,
    MAA_NET_ERR  = 0x04,
    MAA_NET_HUP  = 0x08,
    MAA_NET_NVAL = 0x10
} maaNetEventT;

typedef int (*maaNetCallbackT)(int fd, maaNetEventT events, void *closure);

extern maaNetT       maaNetCreate(void);
extern unsigned long maaNetDestroy(maaNetT net);
extern void          maaNetAddPort(maaNetT net, int port,
                                   maaNetCallbackT cb, void *closure);
extern void          maaNetDelPort(maaNetT net, int port);
extern void          maaNetAddFd(maaNetT net, int fd,
                                 maaNetCallbackT cb, void *closure);
extern void          maaNetDelFd(maaNetT net, int fd);
extern void          maaNetSetRead(maaNetT net, int fd);
extern void          maaNetSetWrite(maaNetT net, int fd);
extern void          maaNetSetReadWrite(maaNetT net, int fd);
extern void          maaNetServer(maaNetT net);

                                /* networking helper functions */
extern int           maaNetOpenTcp(int port);

                                /* reference counting buffers */
typedef struct maaRCS *maaRCT;
extern maaRCT       maaRCCreate(void);
                                /* buffered i/o */
typedef struct maaBufS *maaBufT;

extern maaBufT       maaBufCreate(void);
extern unsigned long maaBufDestroy(maaBufT buf);
extern int           maaBufRead(maaBufT buf, int fd, int len);
extern int           maaBufWrite(maaBufT buf, int fd, int len);
extern maaBufT       maaBufGetLine(maaBufT buf);
extern void          maaBufIteratorInit(maaBufT buf, maaIteratorT iter,
                                        const char *delim, const char *quote,
                                        const char *escape);
extern maaBufT       maaBufIteratorString(maaIteratorT iter);
extern void          maaBufIteratorNext(maaIteratorT iter);
extern void          maaBufFree(maaBufT buf);
extern void          maaBufAppend(maaBufT buf, maaBufT s);
extern void          maaBufAppendS(maaBufT buf, const char *s);
extern void          maaBufAppendSN(maaBufT buf, const char *s, int len);
extern void          maaBufPrintf(maaBufT buf, const char *format, ...);

#define MAA_BUF_INIT(N,I,D,Q,E) maaBufIteratorInit(L,&(I),(D),(Q),(E))
#define MAA_BUF_GET(I,S)        ((S) = maaBufIteratorString(&(I)))
#define MAA_BUF_NEXT(I)         maaBufIteratorNext(&(I))
#define MAA_BUF_ITERATE(B,I,D,S) \
    for (MAA_BUF_INIT(B,I,D); MAA_BUF_GET(I,S); MAA_BUF_NEXT(I))

#endif
