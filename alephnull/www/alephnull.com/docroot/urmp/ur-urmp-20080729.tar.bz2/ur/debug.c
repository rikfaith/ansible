/* debug.c -- 
 * Created: Mon Jul  5 13:25:50 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: debug.c,v 1.11 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"

struct maaFlagS {
    unsigned long magic;
    unsigned long setFlags[4];
    unsigned long usedFlags[4];
    maaHashT      hash;
};

#define TEST(flags,var) (((flags)>>31)                                     \
                         ? (((flags)>>30)                                  \
                            ? ((var[3] & (flags)) << 2)                    \
                            : ((var[2] & (flags)) << 2))                   \
                         : (((flags)>>30)                                  \
                            ? ((var[1] & (flags)) << 2)                    \
                            : ((var[0] & (flags)) << 2)))

#define FLAGSET(x) (((x) & 0xc0000000) >> 30)
#define FLAGVAL(x) ((x) &  0x3fffffff)

CHECK_FUNCTION(_maaFlagCheck, maaFlagT, MAA_FLAG_MAGIC)

maaFlagT maaFlagCreate(void)
{
    maaFlagT flags = maaAllocZ(sizeof(*flags));

    flags->magic = MAA_FLAG_MAGIC;
    flags->hash  = maaHashCreate(NULL, NULL);
    return flags;
}

unsigned long maaFlagDestroy(maaFlagT flags)
{
    unsigned long ret;
    
    _maaFlagCheck(flags);
    ret = flags->magic = ~MAA_FLAG_MAGIC;
    maaHashDestroy(flags->hash);
    maaFree(flags);
    return ret;
}

void maaFlagRegister(maaFlagT flags, unsigned long flag, const char *name)
{
    _maaFlagCheck(flags);
    maaHashInsertUL(flags->hash, name, flag);
    flags->usedFlags[FLAGSET(flag)] &= FLAGVAL(flag);
}
    
void maaFlagSet(maaFlagT flags, unsigned long flag)
{
    _maaFlagCheck(flags);
    flags->setFlags[FLAGSET(flag)] |= FLAGVAL(flag);
}

void maaFlagUnset(maaFlagT flags, unsigned long flag)
{
    _maaFlagCheck(flags);
    flags->setFlags[FLAGSET(flag)] &= ~FLAGVAL(flag);
}

				/* FIXME: move to a header for inlining */
inline int maaFlagTest(maaFlagT flags, unsigned long flag)
{
#if 0
    return TEST(flags->setFlags, flag);
#else
    return flags->setFlags[FLAGSET(flag)] & FLAGVAL(flag);
#endif
}

void maaFlagSetByName(maaFlagT flags, const char *name, int (*f)(const char *))
{
    unsigned long flag = 0;
    
    _maaFlagCheck(flags);
    if (name) {
        flag = maaHashLookupUL(flags->hash, name);
        if (!flag && name[0] == 'n' && name[1] == 'o') {
            if ((flag = maaHashLookupUL(flags->hash, name + 2))) {
                maaFlagUnset(flags, flag);
                return;
            }
        }
    }
    if (!flag || !name) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) maaInternal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    maaFlagSet(flags, flag);
}

void maaFlagUnsetByName(maaFlagT flags, const char *name,
                        int (*f)(const char *))
{
    unsigned long flag;
    
    _maaFlagCheck(flags);
    flag = maaHashLookupUL(flags->hash, name);
    if (!flag) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) maaInternal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    maaFlagUnset(flags, flag);
}

int  maaFlagTestByName(maaFlagT flags, const char *name,
                       int (*f)(const char *))
{
    unsigned long flag;
    
    _maaFlagCheck(flags);
    flag = maaHashLookupUL(flags->hash, name);
    if (!flag) {
        int     rc = 1;
        if (f)  rc = f(name);
        if (rc) maaInternal(__FUNCTION__,
                            "\"%s\" not a registered flag\n", name);
    }
    return maaFlagTest(flags, flag);
}

const char *maaFlagName(maaFlagT flags, unsigned long flag)
{
    maaIteratorT  iter;

    maaHashIteratorInit(flags->hash, &iter);
    do {
	if (maaHashIteratorDatumUL(&iter) == flag)
	    return maaHashIteratorKey(&iter);
    } while (maaHashIteratorNext(&iter));
    return NULL;
}

maaListT maaFlagNames(maaFlagT flags)
{
    maaListT     list = maaListCreate();
    maaIteratorT iter;
    const char   *key;
    
    MAA_HASH_ITERATE_NODATUM(flags->hash, iter, key) maaListAppend(list, key);
    return list;
}
