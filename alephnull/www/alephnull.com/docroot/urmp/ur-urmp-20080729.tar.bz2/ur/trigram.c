/* trigram.c -- 
 * Created: Fri Jun 13 08:47:01 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: trigram.c,v 1.2 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"
#include <math.h>

#define MAA_TRIGRAM_BITS             (256*256*256)
#define MAA_TRIGRAM_ELEMENTS         (MAA_TRIGRAM_BITS/32)
#define MAA_TRIGRAM_BITS_PER_ELEMENT (32)

struct maaTrigramS {
    unsigned long magic;
    unsigned long mask[MAA_TRIGRAM_ELEMENTS];
    unsigned long total;
    unsigned long unique;
};

CHECK_FUNCTION(_maaTrigramCheck, maaTrigramT, MAA_TRIGRAM_MAGIC)

static inline int maaTrigramTest(maaTrigramT tg, unsigned long value)
{
    int element = value / MAA_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * MAA_TRIGRAM_BITS_PER_ELEMENT;
    return tg->mask[element] & (1 << bit);
}

static inline void maaTrigramSet(maaTrigramT tg, unsigned long value)
{
    int element = value / MAA_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * MAA_TRIGRAM_BITS_PER_ELEMENT;
    tg->mask[element] |= (1 << bit);
}

#if 0
static inline void maaTrigramClear(maaTrigramT tg, unsigned long value)
{
    int element = value / MAA_TRIGRAM_BITS_PER_ELEMENT;
    int bit     = value - element * MAA_TRIGRAM_BITS_PER_ELEMENT;
    tg->mask[element] &= ~(1 << bit);
}
#endif

maaTrigramT maaTrigramCreate(void)
{
    maaTrigramT tg = maaAllocZ(sizeof(*tg));

    tg->magic = MAA_TRIGRAM_MAGIC;
    return tg;
}

unsigned long maaTrigramDestroy(maaTrigramT tg)
{
    unsigned long ret;
    
    _maaTrigramCheck(tg);
    ret = tg->magic = ~MAA_TRIGRAM_MAGIC;
    maaFree(tg);
    return ret;
}

int maaTrigramPut(maaTrigramT tg, const char *filename)
{
    FILE             *str;

    _maaTrigramCheck(tg);
    if (!(str = fopen(filename, "w"))) return -1;

    fprintf(str, "0x%08lx %d %d %d %lu %lu\n",
            tg->magic, MAA_TRIGRAM_BITS, MAA_TRIGRAM_ELEMENTS,
            MAA_TRIGRAM_BITS_PER_ELEMENT, tg->total, tg->unique);
    fwrite(tg->mask, sizeof(tg->mask),  1, str);
    fclose(str);
    return 0;
}

maaTrigramT maaTrigramGet(const char *filename)
{
    unsigned long  magic;
    unsigned long  bits, elements, bpe;
    FILE           *str;
    maaTrigramT    tg;
    
    if (!(str = fopen(filename, "r"))) return NULL;
    tg = maaTrigramCreate();
    fscanf(str, "0x%08lx %lu %lu %lu %lu %lu\n",
           &magic, &bits, &elements, &bpe, &tg->total, &tg->unique);
    if (tg->magic   != magic
        || bits     != MAA_TRIGRAM_BITS
        || elements != MAA_TRIGRAM_ELEMENTS
        || bpe      != MAA_TRIGRAM_BITS_PER_ELEMENT) {
        maaTrigramDestroy(tg);
        return NULL;
    }
    fread(tg->mask, sizeof(tg->mask), 1, str);
    return tg;
}

void maaTrigramAdd(maaTrigramT tg, const void *buf, int len)
{
    int                 i;
    const unsigned char *pt;
    unsigned long       tgram;

    _maaTrigramCheck(tg);
    if (!len) len = strlen(buf);

    for (i = 0, pt = buf; pt && *pt && i < len - 3; ++pt, ++i) {
        tgram = pt[0] * 256 * 256 + pt[1] * 256 + pt[2];
        if (maaTrigramTest(tg, tgram)) ++tg->unique;
        maaTrigramSet(tg, tgram);
        ++tg->total;
    }
}

static inline int maaTrigramPrintByte(unsigned char byte, FILE *stream)
{
    if (byte >= ' ' && byte <= 127) {
        fprintf(stream, "%c", byte);
        return 1;
    }
    fprintf(stream, "0x%02x", byte);
    return 4;
}

void maaTrigramPrint(maaTrigramT tg, FILE *stream)
{
    int              i, j, k;
    int              count = 0;
    int              len;

    if (!stream) stream = stdout;
    _maaTrigramCheck(tg);
    for (i = 0; i < 256; i++)
        for (j = 0; j < 256; j++)
            for (k = 0; k < 256; k++) {
                unsigned long tgram = i * 256 * 256 + j * 256 + k;
                if (maaTrigramTest(tg, tgram)) {
                    len  = maaTrigramPrintByte(i, stream);
                    len += maaTrigramPrintByte(j, stream);
                    len += maaTrigramPrintByte(k, stream);
                    if (count && !(count % 7))
                        fprintf(stream, "\n");
                    else
                        fprintf(stream, "%*.*s", 12-len, 12-len, " ");
                    ++count;
                }
            }
}

static inline int maaTrigramBitCount(unsigned long x)
{
    x = (x >> 1  & 0x55555555) + (x & 0x55555555);
    x = ((x >> 2) & 0x33333333) + (x & 0x33333333);
    x = ((x >> 4) + x) & 0x0f0f0f0f;
    x = ((x >> 8) + x);
    return (x + (x >> 16)) & 0xff;
}

unsigned long maaTrigramMatches(maaTrigramT a, maaTrigramT b)
{
    unsigned long matches = 0;
    int           i;

    for (i = 0; i < MAA_TRIGRAM_ELEMENTS; i++)
        matches += maaTrigramBitCount(a->mask[i] & b->mask[i]);
    return matches;
}

static double _maaTrigramMatches(maaTrigramT a, maaTrigramT b)
{
    int              matches = 0;
    int              total;
    int              i;

    for (i = 0; i < MAA_TRIGRAM_ELEMENTS; i++)
        matches += maaTrigramBitCount(a->mask[i] & b->mask[i]);

    total = a->unique + b->unique;
    return (double)matches / (double)(total - matches);
}

static double _maaTrigramCosine(maaTrigramT a, maaTrigramT b)
{
    double           num  = 0;
    double           sum0 = 0;
    double           sum1 = 0;
    
    int              i;

    for (i = 0; i < MAA_TRIGRAM_ELEMENTS; i++) {
        double f = (double)maaTrigramBitCount(a->mask[i])/a->total;
        int same = a->mask[i] & b->mask[i];
        sum0    += f * f;
        if (same)
            num += f * (double)maaTrigramBitCount(same)/b->total;
    }

    for (i = 0; i < MAA_TRIGRAM_ELEMENTS; i++) {
        double f = (double)maaTrigramBitCount(b->mask[i])/b->total;
        sum1    += f * f;
    }
    
    return num / (sqrt(sum0) * sqrt(sum1));
}

double maaTrigramCompare(maaTrigramT a, maaTrigramT b, maaTrigramAlgT alg)
{
    _maaTrigramCheck(a);
    _maaTrigramCheck(b);
    switch (alg) {
    case MAA_TRIGRAM_MATCHES: return _maaTrigramMatches(a, b);
    case MAA_TRIGRAM_COSINE:  return _maaTrigramCosine(a, b);
    }
    return 0;
}

void maaTrigramSubtract(maaTrigramT a, maaTrigramT b)
{
    int i;
    int before, after;
    
    _maaTrigramCheck(a);
    _maaTrigramCheck(b);

    for (i = 0; i < MAA_TRIGRAM_ELEMENTS; i++) {
        before     = maaTrigramBitCount(a->mask[i]);
        a->mask[i] = a->mask[i] & ~b->mask[i];
        after      = maaTrigramBitCount(a->mask[i]);
        a->total  -= before - after;
        a->unique -= before - after;
    }
}
