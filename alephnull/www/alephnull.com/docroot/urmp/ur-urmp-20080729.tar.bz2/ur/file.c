/* file.c -- 
 * Created: Wed Jun 11 10:35:14 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: file.c,v 1.1 2003-06-12 13:58:58 faith Exp $
 * 
 */

#include "maaP.h"
#include <fcntl.h>
#include <sys/mman.h>

struct maaFileS {
    unsigned long magic;
    int           fd;
    struct stat   sb;
    unsigned char *start;
    unsigned char *end;
    unsigned char *current;
};

CHECK_FUNCTION(_maaFileCheck, maaFileT, MAA_FILE_MAGIC)

unsigned long maaFileClose(maaFileT file)
{
    unsigned long ret;

    _maaFileCheck(file);

    if (file->start && file->start != MAP_FAILED) {
        munmap(file->start, file->sb.st_size);
        file->start = NULL;
    }

    if (file->fd >= 0) {
        close(file->fd);
        file->fd = -1;
    }

    ret = file->magic = ~MAA_FILE_MAGIC;
    maaFree(file);
    return ret;
}

maaFileT maaFileOpen(const char *filename)
{
    maaFileT file = maaAllocZ(sizeof(*file));

    file->magic = MAA_FILE_MAGIC;

    if ((file->fd = open(filename, O_RDONLY)) < 0) goto fail;
    if (fstat(file->fd, &file->sb))                goto fail;
    if ((file->start = mmap(NULL,
                            file->sb.st_size,
                            PROT_READ,
                            MAP_SHARED,
                            file->fd,
                            0)) == MAP_FAILED)       goto fail;
    file->current = file->start;
    file->end     = file->start + file->sb.st_size;
    return file;

fail:
    maaFileClose(file);
return NULL;
}

const void *maaFileStart(maaFileT file)
{
    _maaFileCheck(file);
    return file->start;
}

const void *maaFileEnd(maaFileT file)
{
    _maaFileCheck(file);
    return file->end;
}

unsigned long maaFileLength(maaFileT file)
{
    return file->sb.st_size;
}

const void *maaFileSet(maaFileT file, void *pos)
{
    void *old;
    
    _maaFileCheck(file);

    if (pos < (void *)file->start) pos = file->start;
    if (pos > (void *)file->end)   pos = file->end;

    old           = file->current;
    file->current = pos;
    return old;
}

const void *maaFileGet(maaFileT file)
{
    _maaFileCheck(file);
    return file->current;
}
