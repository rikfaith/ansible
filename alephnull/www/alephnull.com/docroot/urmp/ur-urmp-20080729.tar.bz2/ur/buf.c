/* buf.c -- 
 * Created: Sat Aug  2 13:20:42 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: buf.c,v 1.6 2003-09-12 13:15:17 faith Exp $
 *
 */

#include "maaP.h"
#include <sys/uio.h>

typedef struct maaBufBufferS {
    unsigned long magic;
    int           refcount;
    int           size;
    maaBufT       owner;
    unsigned char *buf;
} *maaBufBufferT;

typedef struct maaBufChunkS {
    unsigned long       magic;
    int                 start;
    int                 used;
    maaBufBufferT       buffer;
    struct maaBufChunkS *next;
} *maaBufChunkT;

struct maaBufS {
    unsigned long magic;
    unsigned long len;

    int           count;
    maaBufChunkT  head, tail;

                                /* Statistics */
    unsigned long append;
    unsigned long read1, readn;
    unsigned long write1, writen;
};

CHECK_FUNCTION(_maaBufCheck, maaBufT, MAA_BUF_MAGIC)
CHECK_FUNCTION(_maaBufChunkCheck, maaBufChunkT, MAA_BUF_CHUNK_MAGIC)
CHECK_FUNCTION(_maaBufBufferCheck, maaBufBufferT, MAA_BUF_BUFFER_MAGIC)

maaBufT maaBufCreate(void)
{
    maaBufT buf = maaAllocZ(sizeof(*buf));

    buf->magic = MAA_BUF_MAGIC;
    return buf;
}

unsigned long maaBufDestroy(maaBufT buf)
{
    unsigned long ret;
    _maaBufCheck(buf);
    maaTrace(0, __func__, "r %lu %lu (a%lu); w %lu %lu\n",
             buf->read1, buf->readn, buf->append,
             buf->write1, buf->writen);
    ret = buf->magic = ~MAA_BUF_MAGIC;
    maaFree(buf);
    return ret;
}

static maaBufBufferT maaBufBufferCreate(int size)
{
    maaBufBufferT buffer = maaAllocZ(sizeof(*buffer));

    buffer->magic    = MAA_BUF_BUFFER_MAGIC;
    buffer->size     = size ? size : 4096;
    buffer->buf      = maaAlloc(buffer->size);

    return buffer;
}

static unsigned long maaBufBufferDestroy(maaBufBufferT buffer)
{
    unsigned long ret;
    
    _maaBufBufferCheck(buffer);
    ret = buffer->magic = ~MAA_BUF_BUFFER_MAGIC;
    if (!buffer->refcount) {
        maaFree(buffer->buf);
        maaFree(buffer);
    }
    return ret;
}

static maaBufChunkT maaBufChunkCreate(maaBufBufferT buffer,
                                      maaBufChunkT *head,
                                      maaBufChunkT *tail)
{
    maaBufChunkT chunk = maaAllocZ(sizeof(*chunk));

    if (buffer)        _maaBufBufferCheck(buffer);
    if (head && *head) _maaBufChunkCheck(*head);
    if (tail && *tail) _maaBufChunkCheck(*tail);
    chunk->magic       = MAA_BUF_CHUNK_MAGIC;
    chunk->start       = 0;
    chunk->used        = 0;
    chunk->buffer      = buffer ? buffer : maaBufBufferCreate(0);
    chunk->next        = NULL;

    if (head && !*head) *head = chunk;
    if (tail) {
        if (!*tail) {
            *tail         = chunk;
        } else {
            if ((*tail)->next) maaFatal(__func__, "Tail not tail\n");
            (*tail)->next = chunk;
            *tail         = chunk;
        }
    }

    if (chunk->buffer) ++chunk->buffer->refcount;
    
    return chunk;
}

static unsigned long maaBufChunkDestroy(maaBufChunkT chunk)
{
    unsigned long ret;
    _maaBufChunkCheck(chunk);
    ret = chunk->magic = ~MAA_BUF_CHUNK_MAGIC;
    if (chunk->buffer) {
        --chunk->buffer->refcount;
        maaBufBufferDestroy(chunk->buffer);
    }
    maaFree(chunk);
    return ret;
}

static void maaBufChunkDestroyChain(maaBufChunkT chunk)
{
    maaBufChunkT pt, next;

    if (!chunk) return;
    _maaBufChunkCheck(chunk);
    for (pt = chunk, next = chunk->next; pt; pt = next) {
        next = pt->next;
        maaBufChunkDestroy(pt);
    }
}

#if 0
static int maaBufAddChunk(maaBufT buf)
{
    int offset = buf->chunkCount++;
    
    if (buf->chunkMax < buf->chunkCount) {
        if (!(buf->chunkMax *= 2)) buf->chunkMax = 8;
        buf->chunks = maaRealloc(buf->chunks,
                                 buf->chunkMax * sizeof(*buf->chunks));
    }
    buf->chunks[offset] = maaBufChunkCreate();
    return offset;
}

static void maaBufFreeChunks(maaBufT buf, int start, int end)
{
    int i;

    for (i = start; i <= end && i < buf->chunkCount; i++) {
        maaBufChunkDestroy(buf->chunks[i]);
    }
}

static void maaBufAllocate(maaBufT buf, int len)
{
    int i;
    int total = 0;

    for (i = 0; i < buf->chunkCount; i++) {
        total += buf->chunks[i]->total;
        if (total >= len) {
            maaBufFreeChunks(buf, i+1, buf->chunkCount-1);
            return;
        }
    }
    do {
        i = maaBufAddChunk(buf);
        total += buf->chunks[i]->total;
    } while (total < len);
}
#endif

int maaBufRead(maaBufT buf, int fd, int len)
{
    struct iovec  *vector;
    int           i;
    int           total;
    maaBufChunkT  head = NULL, tail = NULL, pt, prev;
    int           count;
    int           retval = EOF;

    _maaBufCheck(buf);

    if (buf->tail && !buf->tail->buffer->owner) {
        int offset = buf->tail->start + buf->tail->used;

        if (buf->tail->buffer->size - offset >= len) {
            ++buf->append;
            ++buf->read1;
            if ((total = read(fd, buf->tail->buffer->buf + offset, len)) > 0) {
                buf->len        += total;
                buf->tail->used += total;
                if (buf->tail->buffer->refcount > 1)
                    buf->tail->buffer->owner = buf;
                return total;
            }
        }
    }

    for (i = 0, count = 0; i < len; i += tail->buffer->size, ++count)
        maaBufChunkCreate(NULL, &head, &tail);

    vector = maaAlloc(count * sizeof(*vector));
    for (pt = head, i = 0; pt; pt = pt->next, i++) {
        vector[i].iov_base = pt->buffer->buf;
        vector[i].iov_len  = pt->buffer->size;
    }
    ++buf->readn;
    total = readv(fd, vector, count);
    maaFree(vector);

    if (total > 0) {
        retval      = total;
        buf->len   += total;
        buf->count += count;

        for (pt = head, prev = NULL, i = 0;
             pt && total;
             prev = pt, pt = pt->next, i++) {
            int used = 0;

            if (total >= pt->buffer->size) used = pt->buffer->size;
            else                           used = total;
            total    -= used;
            pt->used  = used;
        }
        if (pt) {
            maaBufChunkDestroyChain(pt);
            tail = prev;
        }

        if (!head || !tail)
            maaInternal(__func__, "head = %p, tail = %p\n",
                        (void *)head, (void *)tail);

        if (!buf->head) {
            buf->head = head;
            buf->tail = tail;
        } else {
            buf->tail->next = head;
            buf->tail       = tail;
        }

    } else {
        if (buf->tail) buf->tail->next = NULL;
        else if (buf->head)
            maaInternal(__func__, "Head but no tail\n");
        maaBufChunkDestroyChain(head);
    }
    
    return retval;
}

int maaBufWrite(maaBufT buf, int fd, int len)
{
    int          i;
    struct iovec *vector;
    int          total;
    maaBufChunkT pt, prev;

    vector = maaAlloc(buf->count * sizeof(*vector));
    for (pt = buf->head, i = 0, total = 0; pt; pt = pt->next, i++) {
        vector[i].iov_base = pt->buffer->buf + pt->start;
        if (len && total + pt->used > len) {
            vector[i].iov_len  = len - total;
            break;
        }
        vector[i].iov_len  = pt->used;
        total             =+ pt->used;
    }
    ++buf->writen;
    total = writev(fd, vector, i+1);
    maaFree(vector);

    if (total > 0) {
        buf->len -= total;
        for (pt = buf->head, prev = NULL; pt; prev = pt, pt = pt->next) {
            if (pt->used  >= total) {
                pt->used  -= total;
                pt->start += total;
                break;
            } else {
                pt->used = 0;
            }
            total -= pt->used;
        }
        if (!pt->used) {
            prev = pt;
            pt   = pt->next;
        }
        /* pt is the new head; prev is the last to be removed */
        if (prev) {
            prev->next = NULL;                  /* disconnect */
            maaBufChunkDestroyChain(buf->head); /* free beginning of chain */
        }
        buf->head                 = pt;
        if (!buf->head) buf->tail = NULL;    /* if last block */
    }

    return total;
}

#if 0
extern maaBufT       maaBufGetLine(maaBufT buf);
extern void          maaBufIteratorInit(maaBufT buf, maaIteratorT iter,
                                        const char *delim, const char *quote,
                                        const char *escape);
extern maaBufT       maaBufIteratorString(maaIteratorT iter);
extern void          maaBufIteratorNext(maaIteratorT iter);
extern void          maaBufFree(maaBufT buf);
extern void          maaBufAppend(maaBufT buf, maaBufT s);
extern void          maaBufAppendS(maaBufT buf, const char *s);
extern void          maaBufAppendSN(maaBufT buf, const char *s, int len);
extern void          maaBufPrintf(maaBufT buf, const char *format, ...);

static void _maaArenaGetChunk(maaArenaT arena, size_t needed)
{
    maaArenaChunkT chunk;
    size_t         size;

    size              = sizeof(maaArenaHeaderT) + needed + MAA_ARENA_CHUNK;
    chunk             = maaAlloc(size);

    if (arena->head) {
	arena->wasted = arena->head->limit - arena->head->avail;
    }

    chunk->magic      = MAA_ARENA_MAGIC;
    chunk->size       = size;
    chunk->prev       = arena->head;
    chunk->avail      = (char *)(chunk + 1);
    chunk->limit      = (char *)chunk + size;

    arena->head       = chunk;
    arena->allocated += size;
}

void *maaArenaAlloc(maaArenaT arena, size_t size)
{
    maaArenaChunkT chunk = arena->head;
    size_t         s;
    
    _maaArenaCheck(arena);
    if (size <= 0) maaFatal(__FUNCTION__, "Size = %lu\n", (unsigned long)size);

    s = ((size + arena->alignment - 1) / arena->alignment) * arena->alignment;

    if (!chunk || s > (size_t)(chunk->limit - chunk->avail))
	_maaArenaGetChunk(arena, s); /* Get new chunk */

    arena->used        += s;
    if (!arena->head) maaInternal(__FUNCTION__, "NULL Head\n");
    arena->head->avail += s;
    
    return arena->head->avail - s;
}

void *maaArenaAllocZ(maaArenaT arena, size_t size)
{
    void *pt = maaArenaAlloc(arena, size);

    memset(pt, 0, size);
    return pt;
}
#endif
