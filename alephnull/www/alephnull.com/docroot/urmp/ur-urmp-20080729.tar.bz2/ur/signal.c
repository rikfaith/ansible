/* signal.c -- 
 * Created: Sun Feb  9 10:06:01 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: signal.c,v 1.4 2003-03-24 09:45:56 faith Exp $
 *
 * gcc -g -Wall signal.c -o signal -static -L. -lmaa -lelf
 */

#define MAA_IN_MAA 0            /* 0 = standalone; 1 = links with libmaa */
#define MAA_DEMO   0            /* 0 = working; 1 = demo/testing */

#undef _GNU_SOURCE
#define _GNU_SOURCE
#include <signal.h>
#include <fcntl.h>

#if MAA_IN_MAA
#include "maaP.h"
#define MESSAGE(format, ...)   maaWarning(NULL, format, ## __VA_ARGS__)
#define TERMINATE(format, ...) maaInternal(format, ## __VA_ARGS__)
#define FATAL(format, ...)     maaFatal(__FUNCTION__, format, ## __VA_ARGS__)
#define ENTRYPOINT maaSignalInit
#define PROGRAMNAME maaProgramName()
#else
#ifdef XAPPGROUP
#include "scrnintstr.h"
#include <unistd.h>
#include <sys/types.h>
#define MESSAGE(format, ...)   ErrorF(format, ## __VA_ARGS__)
#define TERMINATE(format, ...) \
        do { ErrorF(format, ## __VA_ARGS__); abort(); } while (0)
#define FATAL(format, ...)     TERMINATE(format, ## __VA_ARGS__)
#define ENTRYPOINT maaSignalInit
#define PROGRAMNAME ""
#else
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#define MESSAGE(format, ...)   fprintf(stderr, format, ## __VA_ARGS__)
#define TERMINATE(format, ...) \
        do { fprintf(stderr, format, ## __VA_ARGS__); abort(); } while (0)
#define FATAL(format, ...)     TERMINATE(format, ## __VA_ARGS__)
#define ENTRYPOINT maaSignalInit
#define PROGRAMNAME ""
#endif
#endif

#if defined(__GNUC__) && defined(__linux__)
#define MAA_STACK_BACKTRACE
#endif

#ifdef MAA_STACK_BACKTRACE
#define MAA_SIGNAL_MAP_ENTRIES 32
#define MAA_SIGNAL_MAP_NAMELEN 256
#define MAA_SIGNAL_FILE_ENTRIES 1025
#define MAA_SIGNAL_FILE_SPACE   (64*1024)
typedef struct {
    unsigned long lower;
    unsigned long upper;
    char          name[MAA_SIGNAL_MAP_NAMELEN];
    int           seq;          /* Sequence of entries with same name */

    int           fd;
    int           this;
    unsigned long offset;

    unsigned long ph;
    unsigned long sh;
    unsigned long sym;
    unsigned long symSize;
    unsigned long symEntSize;
    unsigned long str;
    unsigned long strSize;
    unsigned long shStr;
    unsigned long shStrSize;

                                /* DWARF information from ELF header */
    unsigned long line;
    unsigned long lineSize;
} maaSignalMapEntry;

static int               maaSignalMapCount;
static maaSignalMapEntry maaSignalMaps[MAA_SIGNAL_MAP_ENTRIES];

                                /* Keep large buffers off the stack */
static int               maaSignalFileCount;
static char              *maaSignalFileEntries[MAA_SIGNAL_FILE_ENTRIES];
static char              maaSignalFileSpace[MAA_SIGNAL_FILE_SPACE];

static void maaSignalReadMap(void)
{
    FILE        *str;
    char        *pt, *start;
    static char buf[256];       /* not on stack */
    static char filename[256];  /* not on stack */

    snprintf(filename, sizeof(filename), "/proc/%d/maps", getpid());
    if (!(str = fopen(filename, "r"))) return;
    while (fgets(buf, sizeof(buf), str)) {
        int           state = 0;
        unsigned long l = 0, r = 0;
        for (start = pt = buf; pt && *pt && *pt != '\n'; pt++) {
            switch (state) {
            case 0:
                switch (*pt) {
                case '-':
                    l = strtoul(start, NULL, 16);
                    start = pt + 1;
                    break;
                case ' ':
                    r = strtoul(start, NULL, 16);
                    state = 1;
                    break;
                }
                break;
            case 1:
                switch(*pt) {
                case '/':
                    start = pt;
                    state = 2;
                    break;
                }
                break;
            }
        }
        if (*pt == '\n') *pt = '\0';
        if (state == 2) {
            if (maaSignalMapCount < MAA_SIGNAL_MAP_ENTRIES) {
                maaSignalMaps[maaSignalMapCount].fd    = -1;
                maaSignalMaps[maaSignalMapCount].lower = l;
                maaSignalMaps[maaSignalMapCount].upper = r;
                strncpy(maaSignalMaps[maaSignalMapCount].name,
                        start,
                        MAA_SIGNAL_MAP_NAMELEN - 1);
                maaSignalMaps[maaSignalMapCount].name[MAA_SIGNAL_MAP_NAMELEN]
                    = '\0';

                if (maaSignalMapCount
                    && !strcmp(maaSignalMaps[maaSignalMapCount-1].name,
                               maaSignalMaps[maaSignalMapCount].name))
                    maaSignalMaps[maaSignalMapCount].seq
                        = maaSignalMaps[maaSignalMapCount-1].seq + 1;
                
                ++maaSignalMapCount;
            }
        }
    }
}

/* Magic structures and numbers from:
 *
 * EXECUTABLE AND LINKABLE FORMAT (ELF): Portable Formats Specification,
 * Version 1.1; Tool Interface Standards (TIS)
 * A text version from: http://www.muppetlabs.com/~breadbox/software/ELF.txt
 *
 * DWARF Debugging Information Format. UNIX International. Programming
 * Languages SIG. Revision: 2.0.0 (July 27, 1993).
 * Nroff/PostScript: http://reality.sgiweb.org/davea/libdwarf2002Nov22.tar.gz 
 *
 * Note that there are numerous GPL and LGPL ELF and DWARF libraries
 * that these routines could be written to use.  However, for this
 * implementation:
 *    a) I read the specifications (not the code) listed above

 *    b) I asked someone else to look at the gdb sources that processed
 *    __restore_rt and that person told me that glibc uses signal
 *    trampolines called __restore and __restore_rt and that these are
 *    assumed to have the following byte sequences, with instruction
 *    boundaries marked with /, and that the top of the stack may start
 *    on any of the instruction boundaries (although I've only ever seen
 *    it start at the first one):
 *
 *       0x58 / 0xb8 0x77 0x00 0x00 0x00 / 0xcd 0x80
 *              0xb8 0xad 0x00 0x00 0x00 / 0xcd 0x80
 *
 *    We could just punt and assume the last frame is the fault EIP, but
 *    checking for these sequences makes these routines robust when not
 *    called from a signal handler.
 *
 * These routines may not be robust in the face of gcc changes, but they
 * fulfill these design goals:
 *
 *    1) works with gcc3 under Linux 2.4.x
 *    2) independent of non-X11/MIT/BSD licensed code or libraries
 *    3) small
 *    4) doesn't use malloc
 *    5) has relatively small stack footprint
 */

typedef unsigned long  elfAddr;
typedef unsigned short elfHalf;
typedef unsigned long  elfOff;
typedef signed long    elfSword;
typedef unsigned long  elfWord;
typedef unsigned char  elfByte;

typedef unsigned long  uword;
typedef unsigned short uhalf;
typedef unsigned char  ubyte;
typedef signed long    sword;
typedef signed short   shalf;
typedef signed char    sbyte;

typedef struct {
    elfWord magic;
    elfByte class;              /* 1 = 32-bit, 2 = 64-bit */
    elfByte data;               /* 1 = LSB,    2 = MSB */
    elfByte ver;
    elfByte reserved0;
    elfWord reserved1;
    elfWord reserved2;
    elfHalf type;
    elfHalf machine;
    elfWord version;
    elfAddr entry;
    elfOff  phOff;
    elfOff  shOff;
    elfWord flags;
    elfHalf ehSize;
    elfHalf phEntSize;
    elfHalf phNum;
    elfHalf shEntSize;
    elfHalf shNum;
    elfHalf shStrIdx;
} elfHeader;

typedef struct {
    elfWord name;
    elfWord type;
    elfWord flags;
    elfAddr addr;
    elfOff  offset;
    elfWord size;
    elfWord link;
    elfWord info;
    elfWord align;
    elfWord entSize;
} elfSection;

typedef struct {
    elfWord name;               /* Offset into shStrIdx table */
    elfAddr value;
    elfWord size;
    elfByte info;
    elfByte other;
    elfHalf shIdx;
} elfSymbol;

typedef struct {
    elfWord type;
    elfOff  offset;
    elfAddr vaddr;
    elfAddr paddr;
    elfWord fileSize;
    elfWord memSize;
    elfWord flags;
    elfWord align;
} elfProgram;

typedef struct {                /* Warning, this isn't packed.  Argh. */
    uword    totalLength;
    uhalf    version;
    uword    prologueLength;
    ubyte    minimumInstructionLength;
    ubyte    defaultIsStmt;
    sbyte    lineBase;
    ubyte    lineRange;
    ubyte    opcodeBase;
} dwarfHeader;

typedef struct {
    unsigned long address;
    int           file;
    int           line;
} dwarfState;

static __inline__ unsigned char _r1(int fd)
{
    unsigned char x;
    read(fd, &x, sizeof(x));
    return x;
}

static __inline__ unsigned short _r2(int fd)
{
    unsigned short x;
    read(fd, &x, sizeof(x));
    return x;
}

static __inline__ unsigned long _r4(int fd)
{
    unsigned long x;
    read(fd, &x, sizeof(x));
    return x;
}

static __inline__ unsigned long _r128(int fd)
{
    unsigned long result = 0;
    int           shift  = 0;
    unsigned char next;
    int           i;

    for (i = 0; i < 5; i++) {
        next    = _r1(fd);
        result |= (next & 0x7f) << shift;
        shift  += 7;
        if (!(next & 0x80)) break;
    }
    return result;
}

static __inline__ signed long _r128s(int fd)
{
    signed long   result = 0;
    int           shift  = 0;
    int           sign   = 0;
    unsigned char next;
    int           i;

    for (i = 0; i < 5; i++) {
        next    = _r1(fd);
        result |= (next & 0x7f) << shift;
        shift  += 7;
        sign = next & 0x40;
        if (!(next & 0x80)) break;
    }
    /* Sign extend */
    if (shift < 32 && sign) result |= -(1 << shift);
    return result;
}

static void maaSignalDwarf(maaSignalMapEntry *e, unsigned long value,
                           int *line, char **filename)
{
    dwarfHeader   dh;
    dwarfState    ds;
    int           i;
    int           state;
    unsigned long pos = e->line;
    unsigned long dirOffset, fileOffset;
    char          *pt;

    *line     = 0;
    *filename = NULL;

    while (pos < e->line + e->lineSize) {
        lseek(e->fd, pos, SEEK_SET);

        dh.totalLength              = _r4(e->fd);
        dh.version                  = _r2(e->fd);
        dh.prologueLength           = _r4(e->fd);
        dh.minimumInstructionLength = _r1(e->fd);
        dh.defaultIsStmt            = _r1(e->fd);
        dh.lineBase                 = _r1(e->fd);
        dh.lineRange                = _r1(e->fd);
        dh.opcodeBase               = _r1(e->fd);

        pos += dh.totalLength + 4;

        for (i = 1; i < dh.opcodeBase; i++)
            _r1(e->fd); /* Could check lengths of standard opcodes */

        dirOffset = lseek(e->fd, 0, SEEK_CUR);
        for (state = 0; state != 3 && lseek(e->fd, 0, SEEK_CUR) < pos;) {
            ubyte x = _r1(e->fd);
            switch (state) {
            case 0:
                if (!x) state = 3;  /* First byte is a null */
                else    state = 1;  /* Have no 0s */
                break;
            case 1:
                if (!x) state = 2;  /* Have one 0 */
                break;
            case 2:
                if (!x) state = 3;  /* Have two 0s */
                else    state = 1;  /* Have no 0s */
                break;
            }
        }

        if (state != 3) return; /* Punt if we can't parse */
        
        fileOffset = lseek(e->fd, 0, SEEK_CUR);
        maaSignalFileCount = 0;
        pt                 = maaSignalFileSpace;
        for (state = 0; state != 2 && lseek(e->fd, 0, SEEK_CUR) < pos;) {
            ubyte x = _r1(e->fd);
            switch (state) {
            case 0:
                maaSignalFileEntries[maaSignalFileCount++] = pt;
                *pt++ = x;
                if (!x) state = 2; /* Finished */
                else    state = 1; /* Entry */
                break;
            case 1:
                *pt++ = x;
                if (!x) {
                    unsigned long dirIdx = _r128(e->fd);
                    unsigned long t      = _r128(e->fd);
                    unsigned long length = _r128(e->fd);
                    state = 0;
                }
                break;
            }
        }

        for (state = 0; state >= 0 && lseek(e->fd, 0, SEEK_CUR) < pos;) {
            ubyte         x = _r1(e->fd);
            int           len;

#define ADDRESS(new)                                                          \
            do {                                                              \
                unsigned long n = (new); /* evaluate once */                  \
                if (ds.address && value - e->offset >= ds.address             \
                    && value - e->offset < n) {                               \
                    *line     = ds.line;                                      \
                    *filename = maaSignalFileEntries[ds.file-1];              \
                    return;                                                   \
                }                                                             \
                ds.address = n;                                               \
            } while (0)

#define LINE(new)                                                             \
            do {                                                              \
                ds.line = (new);                                              \
            } while (0)

#define FILE(new)                                                             \
            do {                                                              \
                ds.file = (new);                                              \
            } while (0)

            switch (state) {
            case 0:
                ADDRESS(0);
                LINE(1);
                FILE(1);
                state = 1;
                                /* Fall through */
            case 1:
                switch (x) {
                case 0:         /* Extended */
                    len = _r1(e->fd);
                    x   = _r1(e->fd);
                    switch (x) {
                    case 1:     /* DW_LNE_end_sequence */
                        state          = 0;
                        break;
                    case 2:     /* DW_LNE_set_address */
                        ADDRESS(_r4(e->fd));
                        break;
                    case 3:     /* DW_LNE_define_file */
                        state = -1; /* Punt -- gcc doesn't seem to use
                                     * this, and it's painful to
                                     * decode */
                        MESSAGE("Found DW_LNE_define_file\n");
                        break;
                    }
                    break;
                case 1:         /* DW_LNS_copy */
                    break;
                case 2:         /* DW_LNS_advance_pc */
                    ADDRESS(ds.address
                            + _r128(e->fd) * dh.minimumInstructionLength);
                    break;
                case 3:         /* DW_LNS_advance_line */
                    LINE(ds.line + _r128s(e->fd));
                    break;
                case 4:         /* DW_LNS_set_file */
                    FILE(_r128(e->fd));
                    break;
                case 5:         /* DW_LNS_set_column */
                    _r128(e->fd);
                    break;
                case 6:         /* DW_LNS_negate_stmt */
                    break;
                case 7:         /* DW_LNS_set_basic_block */
                    break;
                case 8:         /* DW_LNS_const_add_pc */
                    ADDRESS(ds.address + (255 - dh.opcodeBase) / dh.lineRange);
                    break;
                case 9:         /* DW_LNS_fixed_advance_pc */
                    ADDRESS(ds.address + _r2(e->fd));
                    break;
                default:
                    x = x - dh.opcodeBase;
                    ADDRESS(ds.address + x / dh.lineRange);
                    LINE(ds.line + dh.lineBase + (x % dh.lineRange));
                    break;
                }
                break;
            }
        }
    }
}

static int maaSignalOpen(maaSignalMapEntry *e)
{
    const char  *pt;
    const char  *a;
    const char  *b;
    int         i;
    int         seq    = 0;
    int         strIdx = 0;
    elfHeader   eh;
    elfSection  es;
    elfProgram  ep;
    union {
        elfByte c[4];
        elfWord w;
    }           magic;
    char        buf[64];

    if (e->fd >= 0)                            return 0;
    if ((e->fd = open(e->name, O_RDONLY)) < 0) return -1;

    magic.c[0] = '\x7f';
    magic.c[1] = 'E';
    magic.c[2] = 'L';
    magic.c[3] = 'F';

    memset(&eh, 0, sizeof(eh));
    lseek(e->fd, 0, SEEK_SET);
    read(e->fd, &eh, sizeof(eh));
    if (eh.magic != magic.w) return -1; /* Not ELF magic */
    if (eh.class != 1)       return -1; /* Not 32-bit */
    if (eh.data != 1)        return -1; /* Not little endian */
    if (eh.ver != 1)         return -1; /* Not ELF version 1 */
    if (eh.version != 1)     return -1; /* Not ELF version 1 */
    
                                /* Locate sections we are interested in */
    for (i = 0; i < eh.shNum; i++) {
        lseek(e->fd, eh.shOff + i * eh.shEntSize, SEEK_SET);
        read(e->fd, &es, sizeof(es));
        switch (es.type) {
        case 2:                 /* SYMTAB */
            e->sym        = es.offset;
            e->symSize    = es.size;
            e->symEntSize = es.entSize;
            strIdx        = es.link;
            break;
        case 3:                 /* STRTAB */
            if (i && i == eh.shStrIdx) {
                e->shStr     = es.offset;
                e->shStrSize = es.size;
            }
            break;
        }
    }

    for (i = 0; i < eh.shNum; i++) {
        lseek(e->fd, eh.shOff + i * eh.shEntSize, SEEK_SET);
        read(e->fd, &es, sizeof(es));
        switch (es.type) {
        case 1:                 /* PROGBITS */
            lseek(e->fd, e->shStr + es.name, SEEK_SET);
            memset(buf, 0, sizeof(buf));
            read(e->fd, buf, sizeof(buf));
            buf[sizeof(buf)-1] = '\0';
            if (!strcmp(buf, ".debug_line")) {
                e->line     = es.offset;
                e->lineSize = es.size;
            }
            break;
        case 3:                 /* STRTAB */
            if (i && i == strIdx) {
                e->str       = es.offset;
                e->strSize   = es.size;
            }
            break;
        }
    }

                                /* Compute the relocation offset */
    for (i = 0, seq = 0; i < eh.phNum; i++) {
        lseek(e->fd, eh.phOff + i * eh.phEntSize, SEEK_SET);
        read(e->fd, &ep, sizeof(ep));
        switch (ep.type) {
        case 1:                 /*  LOAD */
            if (seq++ == e->seq) {
                e->offset = e->lower - (ep.vaddr - ep.offset);
            }
            break;
        }
    }

    for (a = pt = e->name; pt && *pt; pt++) if (*pt == '/') a = pt+1;
    for (b = pt = PROGRAMNAME; pt && *pt; pt++) if (*pt == '/') b = pt+1;
    if (!strcmp(a, b)) e->this = 1;
    return 0;
}

static void maaSignalLookup(int frame, elfAddr value)
{
    int         i;
    const char  *name = NULL;
    const char  *from = "";
    const char  *file = "";
    size_t      pos;
    elfSymbol   sym;
    int         line;
    char        *filename;
    static char buf[256]; /* not on stack */
    
    for (i = 0; i < maaSignalMapCount; i++) {
        maaSignalMapEntry *e = &maaSignalMaps[i];
        if (value >= e->lower && value <= e->upper) {
            if (e->fd >= 0 || !maaSignalOpen(e)) {
                lseek(e->fd, e->sym, SEEK_SET);
                for (pos = 0; pos < e->symSize; pos += e->symEntSize) {
                    read(e->fd, &sym, sizeof(sym));
                    if (sym.name
                        && sym.shIdx
                        && value - e->offset >= sym.value
                        && value - e->offset < sym.value + sym.size) {
                        if (sym.name && sym.name < e->strSize) {
                            lseek(e->fd, e->str + sym.name, SEEK_SET);
                            memset(buf, 0, sizeof(buf));
                            read(e->fd, buf, sizeof(buf));
                            buf[sizeof(buf)-1] = '\0';
                            name               = buf;
                        }
                        break;
                    }
                }
            }
            if (!e->this) {
                from = " from ";
                file = e->name;
            }
            maaSignalDwarf(e, value, &line, &filename);
            if (line && filename) {
                if (name)
                    MESSAGE("#%-2d 0x%08lx %s+0x%lx at %s:%d\n",
                            frame, value, name,
                            value - sym.value - e->offset,
                            filename, line);
                else
                    MESSAGE("#%-2d 0x%08lx ?? at %s:%d\n",
                            frame, value, filename, line);
            } else {
                if (name)
                    MESSAGE("#%-2d 0x%08lx %s+0x%lx%s%s\n",
                            frame, value, name,
                            value - sym.value - e->offset,
                            from, file);
                else
                    MESSAGE("#%-2d 0x%08lx ??%s%s\n",
                            frame, value, from, file);
            }
        }
    }
}

static void maaSignalLog(int count, void *addr[], void *eip)
{
    int i;
    
    for (i = 0; i < count; i++) {
        if (i == 0)             /* FIXME: do checking */
            maaSignalLookup(i, (elfAddr)eip);
        else
            maaSignalLookup(i, (elfAddr)addr[i]);
    }
}
#endif

static const char *maaSignalName(int sig)
{
     switch (sig) {
     case SIGHUP:    return "SIGHUP";
     case SIGINT:    return "SIGINT";
     case SIGQUIT:   return "SIGQUIT";
     case SIGILL:    return "SIGILL";
     case SIGTRAP:   return "SIGTRAP";
     case SIGABRT:   return "SIGABRT";
     case SIGBUS:    return "SIGBUS";
     case SIGFPE:    return "SIGFPE";
     case SIGKILL:   return "SIGKILL";
     case SIGUSR1:   return "SIGUSR1";
     case SIGSEGV:   return "SIGSEGV";
     case SIGUSR2:   return "SIGUSR2";
     case SIGPIPE:   return "SIGPIPE";
     case SIGALRM:   return "SIGALRM";
     case SIGTERM:   return "SIGTERM";
     case SIGSTKFLT: return "SIGSTKFLT";
     case SIGCHLD:   return "SIGCHLD";
     case SIGCONT:   return "SIGCONT";
     case SIGSTOP:   return "SIGSTOP";
     case SIGTSTP:   return "SIGTSTP";
     case SIGTTIN:   return "SIGTTIN";
     case SIGTTOU:   return "SIGTTOU";
     case SIGURG:    return "SIGURG";
     case SIGXCPU:   return "SIGXCPU";
     case SIGXFSZ:   return "SIGXFSZ";
     case SIGVTALRM: return "SIGVTALRM";
     case SIGPROF:   return "SIGPROF";
     case SIGWINCH:  return "SIGWINCH";
     case SIGIO:     return "SIGIO";
     case SIGPWR:    return "SIGPWR";
     case SIGSYS:    return "SIGSYS";
     }
     return NULL;
}

static const char *maaSignalDescription(siginfo_t *info)
{
    switch (info->si_code) {
    case SI_KERNEL:     return "kernel";
    case SI_QUEUE:      return "sigqueue";
    case SI_TIMER:      return "timer expired";
    case SI_MESGQ:      return "real time mesq state changed";
    case SI_ASYNCIO:    return "AIO completed";
    case SI_SIGIO:      return "queued SIGIO";
    }
    
    switch (info->si_signo) {
    case SIGILL:
        switch (info->si_code) {
        case ILL_ILLOPC:    return "illegal opcode";
        case ILL_ILLOPN:    return "illegal operand";
        case ILL_ILLADR:    return "illegal addressing mode";
        case ILL_ILLTRP:    return "illegal trap";
        case ILL_PRVOPC:    return "privileged opcode";
        case ILL_PRVREG:    return "privileged register";
        case ILL_COPROC:    return "coprocessor error";
        case ILL_BADSTK:    return "internal stack error";
        }
        break;
    case SIGFPE:
        switch (info->si_code) {
        case FPE_INTDIV:    return "integer divide by zero";
        case FPE_INTOVF:    return "integer overflow";
        case FPE_FLTDIV:    return "floating point divide by zero";
        case FPE_FLTOVF:    return "floating point overflow";
        case FPE_FLTUND:    return "floating point underflow";
        case FPE_FLTRES:    return "floating point inexact result";
        case FPE_FLTINV:    return "floating point invalid operation";
        case FPE_FLTSUB:    return "subscript out of range";
        }
        break;
    case SIGSEGV:
        switch (info->si_code) {
        case SEGV_MAPERR:   return "address not mapped to object";
        case SEGV_ACCERR:   return "invalid perm. for mapped object";
        }
        break;
    case SIGBUS:
        switch (info->si_code) {
        case BUS_ADRALN:    return "invalid address alignment";
        case BUS_ADRERR:    return "non-existent physical address";
        case BUS_OBJERR:    return "object specific hardware error";
        }
        break;
    case SIGTRAP:
        switch (info->si_code) {
        case TRAP_BRKPT:    return "process breakpoint";
        case TRAP_TRACE:    return "process trace trap";
        }
        break;
    case SIGCHLD:
        switch (info->si_code) {
        case CLD_EXITED:    return "child has exited";
        case CLD_KILLED:    return "child was killed";
        case CLD_DUMPED:    return "child terminated abnormally";
        case CLD_TRAPPED:   return "traced child has trapped";
        case CLD_STOPPED:   return "child has stopped";
        case CLD_CONTINUED: return "stopped child has continued";
        }
        break;
    case SIGPOLL:
        switch (info->si_code) {
        case POLL_IN:       return "data input available";
        case POLL_OUT:      return "output buffers available";
        case POLL_MSG:      return "input message available";
        case POLL_ERR:      return "I/O error";
        case POLL_PRI:      return "high priority input available";
        case POLL_HUP:      return "device disconnected";
        }
        break;
    }
    return NULL;
}

static void maaSignalHandler(int sig, siginfo_t *info, void *context)
{
    static int  reentrant = 0;
    const  char *name, *desc, *msg;
    void        *fault = NULL;
#ifdef MAA_STACK_BACKTRACE
    int         count = 0;
    void        *addr[32];
    ucontext_t  *uc = context;
#endif

    if (reentrant++) FATAL("Signal handler called twice\n");

#ifdef MAA_STACK_BACKTRACE
    /* In H, count stays at 0 until the query fails.  Then it is set to
     * that query number, which is 1 greater than the last query that
     * succeeeded.  Checking both the frame address and the return
     * address prevents a segfault on versions of gcc that don't act as
     * documented. */
#define H(X)                                                                \
    do {                                                                    \
        if (!count) {                                                       \
            if (!__builtin_frame_address(X)                                 \
                || !(addr[X] = __builtin_return_address(X))) count = X;     \
        }                                                                   \
    } while (0)

    H(0);  H(1);  H(2);  H(3);  H(4);  H(5);  H(6);  H(7);
    H(8);  H(9);  H(10); H(11); H(12); H(13); H(14); H(15);
    H(16); H(17); H(18); H(19); H(20); H(21); H(22); H(23);
    H(24); H(25); H(26); H(27); H(28); H(29); H(30); H(31);
#endif

    switch (sig) {
    case SIGILL:
    case SIGFPE:
    case SIGSEGV:
    case SIGBUS:
        fault = info->si_addr;
        break;
    }

    name = maaSignalName(sig);
    desc = maaSignalDescription(info);

    if (info->si_errno) {
        msg  = strerror(info->si_errno);
        MESSAGE("Signal %d%s%s%s%s%s, errno = %d%s%s%s\n",
                   sig,
                   name ? " (" : "",
                   name ? name : "",
                   name ? ")" : "",
                   desc ? ": " : "",
                   desc ? desc : "",
                   info->si_errno,
                   msg ? " (" : "",
                   msg ? msg : "",
                   msg ? ")" : "");
    } else {
        MESSAGE("Signal %d%s%s%s%s%s\n",
                   sig,
                   name ? " (" : "",
                   name ? name : "",
                   name ? ")" : "",
                   desc ? ": " : "",
                   desc ? desc : "");
    }
        
    if (fault) MESSAGE("Fault: 0x%08lx\n", (unsigned long)fault);

#ifdef MAA_STACK_BACKTRACE
    maaSignalLog(count, addr, (void *)uc->uc_mcontext.gregs[REG_EIP]);
#endif

    TERMINATE("Terminating\n");
}


void ENTRYPOINT(void)
{
    int              handle[] = { SIGHUP, SIGQUIT, SIGILL,
                                  SIGBUS, SIGFPE, SIGSEGV, SIGTERM };
    int              i;
    struct sigaction a;

    for (i = 0; i < sizeof(handle)/sizeof(handle[0]); i++) {
        memset(&a, 0, sizeof(a));
        a.sa_sigaction = maaSignalHandler;
        a.sa_flags = SA_SIGINFO;
        sigemptyset(&a.sa_mask);
        sigaddset(&a.sa_mask, handle[i]);
        sigaction(handle[i], &a, 0);
    }
#ifdef MAA_STACK_BACKTRACE
    maaSignalReadMap();
#endif
}

#if MAA_DEMO
static int f(int f)
{
    int *y;
    int x = 1;
#if 0
    y = 1/0;
#endif
    return *y;
}

int main(int argc, char **argv)
{
#if MAA_IN_MAA
    maaInit(argv[0]);
#endif
    maaSignalInit();
    strcpy(0, 0);
    return 0;
}
#endif
