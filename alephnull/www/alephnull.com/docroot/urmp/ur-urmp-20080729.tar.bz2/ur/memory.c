/* memory.c -- 
 * Created: Mon Jul  5 13:30:18 1999 by faith@dict.org
 * Copyright 1999, 2001, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: memory.c,v 1.14 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"

#ifdef DMALLOC_FUNC_CHECK
#undef maaAlloc
#undef maaAllocZ
#undef maaRealloc
#undef maaReallocZ
#undef maaFree
#undef maaStrdup
#endif

void *maaAlloc(size_t size)
{
    void *ret;

    if (size <= 0) maaFatal(__FUNCTION__, "Invalid size = %d\n", size);
    ret = malloc(size);
    if (!ret) maaFatal(__FUNCTION__, "Out of memory\n");
    return ret;
}

void *maaAllocZ(size_t size)
{
    void *ret;

    if (size <= 0) maaFatal(__FUNCTION__, "Invalid size = %d\n", size);
    ret = malloc(size);
    if (!ret) maaFatal(__FUNCTION__, "Out of memory\n");
    memset(ret, 0, size);
    return ret;
}

void *maaRealloc(void *old, size_t size)
{
    void *ret;

    if (size <= 0) maaFatal(__FUNCTION__, "Invalid size = %d\n", size);

    if (!old) return maaAlloc(size);
    
    ret = realloc(old, size);
    if (!ret) maaFatal(__FUNCTION__, "Out of memory\n");

    return ret;
}

void *maaReallocZ(void *old, size_t oldsize, size_t newsize)
{
    void *ret;

    if (newsize <= 0) maaFatal(__FUNCTION__, "Invalid size = %d\n", newsize);
    if (!old || !oldsize) return maaAllocZ(newsize);

    ret = realloc(old, newsize);
    if (!ret) maaFatal(__FUNCTION__, "Out of memory\n");
    memset((char *)ret + oldsize, 0, newsize - oldsize);
    return ret;
}

void maaFree(void *object)
{
    if (!object) maaFatal(__FUNCTION__, "Freeing NULL pointer\n");
    free(object);
}

char *maaStrdup(const char *s)
{
    char *d = maaAlloc(strlen(s) + 1);
    strcpy(d, s);
    return d;
}

/* EOF memory.c */
