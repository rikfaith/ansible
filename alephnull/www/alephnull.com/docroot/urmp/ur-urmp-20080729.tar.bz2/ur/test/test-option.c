/* test-option.c -- 
 * Created: Wed Dec 29 05:37:25 1999 by faith@acm.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-option.c,v 1.5 2003-06-14 12:14:33 faith Exp $
 *
 */

#define OBJECTTYPE     maaOptionT
#define OBJECTCREATE   maaOptionCreate
#define OBJECTDESTROY  maaOptionDestroy

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    int            c;
    maaListT       list;
    maaOptionT     opt;
    maaOptionListT optlist[] = {
	{ "arg", 'a', MAA_OPTION_ARG  },
	{ NULL,  'b', MAA_OPTION_ARG  },
	{ "c",   'c', MAA_OPTION_NONE },
	{ "l",   'l', MAA_OPTION_LIST },
	{ NULL, 0 },
    };
    
    test("L", "-a foo");
    opt = maaOptionCreate(optlist);
    maaOptionParseString(opt, "-a foo");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);
    end(opt);
    
    test("L", "-a  foo");
    opt = maaOptionCreate(optlist);
    maaOptionParseString(opt, "  -a  foo");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);
    end(opt);
    
    test("L", "-a ' foo'");
    opt = maaOptionCreate(optlist);
    maaOptionParseString(opt, "-a ' foo'");
    c = maaOptionGet(opt);
    if (c != 'a')                             fail("a");
    if (strcmp(maaOptionString(opt), " foo")) fail("foo");
    ok(0);
    
    test("L", "-afoo");
    maaOptionParseString(opt, "-a foo");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);

    test("L", "--arg foo");
    maaOptionParseString(opt, "--arg foo");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "--argfoo");
    maaOptionParseString(opt, "--argfoo");
    c = maaOptionGet(opt);
    if (c != '?')                            fail("a");
    if (maaOptionString(opt))                fail("arg");
    ok(0);
    
    test("L", "-afoo -bbar");
    maaOptionParseString(opt, "-afoo -bbar");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    c = maaOptionGet(opt);
    if (c != 'b')                            fail("b");
    if (strcmp(maaOptionString(opt), "bar")) fail("bar");
    ok(0);
    
    test("L", "-cafoo");
    maaOptionParseString(opt, "-cafoo");
    c = maaOptionGet(opt);
    if (c != 'c')                            fail("c");
    if (maaOptionString(opt))                fail("arg");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "-c  -afoo");
    maaOptionParseString(opt, "-c  -afoo");
    c = maaOptionGet(opt);
    if (c != 'c')                            fail("c");
    if (maaOptionString(opt))                fail("arg");
    c = maaOptionGet(opt);
    if (c != 'a')                            fail("a");
    if (strcmp(maaOptionString(opt), "foo")) fail("foo");
    ok(0);
    
    test("L", "-c x -afoo");
    maaOptionParseString(opt, "-c x -afoo");
    c = maaOptionGet(opt);
    if (c != 'c')                            fail("c");
    if (maaOptionString(opt))                fail("arg");
    c = maaOptionGet(opt);
    if (c != EOF)                            fail("eof");
    list = maaOptionOther(opt);
    if (maaListDepth(list) != 2)             fail("depth");
    if (strcmp(maaListPop(list), "x"))       fail("x");
    if (strcmp(maaListPop(list), "-afoo"))   fail("-afoo");
    maaListDestroy(list);
    ok(0);
    
    test("L", "-c -- -afoo");
    maaOptionParseString(opt, "-c -- -afoo");
    c = maaOptionGet(opt);
    if (c != 'c')                            fail("c");
    if (maaOptionString(opt))                fail("arg");
    c = maaOptionGet(opt);
    if (c != EOF)                            fail("eof");
    list = maaOptionOther(opt);
    if (maaListDepth(list) != 1)             fail("depth");
    if (strcmp(maaListPop(list), "-afoo"))   fail("-afoo");
    maaListDestroy(list);
    ok(0);
    
    test("L", "-c - -afoo");
    maaOptionParseString(opt, "-c - -afoo");
    c = maaOptionGet(opt);
    if (c != 'c')                            fail("c");
    if (maaOptionString(opt))                fail("arg");
    c = maaOptionGet(opt);
    if (c != EOF)                            fail("eof");
    list = maaOptionOther(opt);
    if (maaListDepth(list) != 2)             fail("depth");
    if (strcmp(maaListPop(list), "-"))       fail("-");
    if (strcmp(maaListPop(list), "-afoo"))   fail("-afoo");
    maaListDestroy(list);
    ok(0);

    test("L", "-l a,b,c - -afoo");
    maaOptionParseString(opt, "-l a,b,c - -afoo");
    c = maaOptionGet(opt);
    if (c != 'l')                              fail("l");
    if (strcmp(maaOptionString(opt), "a,b,c")) fail("string");
    list = maaOptionList(opt);
    if (!list)                                 fail("list");
    if (maaListDepth(list) != 3)               fail("depth");
    if (strcmp(maaListNth(list, 1), "a"))      fail("a");
    if (strcmp(maaListNth(list, 2), "b"))      fail("b");
    if (strcmp(maaListNth(list, 3), "c"))      fail("c");
    if (maaListNth(list, 4))                   fail("too many");
    if (strcmp(maaOptionString(opt),"a,b,c"))  fail("arg");
    c = maaOptionGet(opt);
    if (c != EOF)                              fail("eof");
    maaListDestroy(list);
    list = maaOptionOther(opt);
    if (maaListDepth(list) != 2)               fail("depth");
    if (strcmp(maaListPop(list), "-"))         fail("-");
    if (strcmp(maaListPop(list), "-afoo"))     fail("-afoo");
    maaListDestroy(list);
    ok(0);

    test("L", "maaOptionInRange");
    if (!maaOptionInRange(NULL, 1))            fail("1 not in NULL");
    if (!maaOptionInRange("1", 1))             fail("1 not in 1");
    if (!maaOptionInRange("1-2", 1))           fail("1 not in 1-2");
    if (!maaOptionInRange("1,", 1))            fail("1 not in 1,");
    if (!maaOptionInRange("1,,", 1))           fail("1 not in 1,,");
    if (!maaOptionInRange(",1", 1))            fail("1 not in ,1");
    if (!maaOptionInRange(",,1", 1))           fail("1 not in ,,1");
    if (!maaOptionInRange("1,2", 1))           fail("1 not in 1,2");
    if (!maaOptionInRange("1;2", 1))           fail("1 not in 1;2");
    if (!maaOptionInRange("2,1", 1))           fail("1 not in 2,1");
    if (!maaOptionInRange("2;1", 1))           fail("1 not in 2;1");
    if (!maaOptionInRange("2,1,3", 1))         fail("1 not in 2,1,3");
    if (!maaOptionInRange("0-3", 1))           fail("1 not in 0-3");
    if (!maaOptionInRange("4,0-3", 1))         fail("1 not in 4,0-3");
    if (!maaOptionInRange("0-3,4", 1))         fail("1 not in 0-3,4");
    if (!maaOptionInRange("3-0,4", 1))         fail("1 not in 3-0,4");
    if (!maaOptionInRange("1-", 1))            fail("1 not in 1-");
    if (!maaOptionInRange("-1", 1))            fail("1 not in -1");
    if (!maaOptionInRange("3-", 1))            fail("1 not in 3-");
    if (!maaOptionInRange("-3", 1))            fail("1 not in -3");
    if (!maaOptionInRange("7,1-", 1))          fail("1 not in 7,1-");
    if (!maaOptionInRange("7,-1", 1))          fail("1 not in 7,-1");
    if (!maaOptionInRange("7,3-", 1))          fail("1 not in 7,3-");
    if (!maaOptionInRange("7,-3", 1))          fail("1 not in 7,-3");
    if (!maaOptionInRange("1-,8", 1))          fail("1 not in 1-,8");
    if (!maaOptionInRange("-1,8", 1))          fail("1 not in -1,8");
    if (!maaOptionInRange("3-,8", 1))          fail("1 not in 3-,8");
    if (!maaOptionInRange("-3,8", 1))          fail("1 not in -3,8");
                                /* The -4 becomes unsigned, which may be
                                 * unexpected ... */
    if (!maaOptionInRange("--4,6", 5))         fail("5 not in --4,6");
    if (!maaOptionInRange("0--4,6", 5))        fail("5 not in 0--4,6");
    
    if (maaOptionInRange("0-3", 5))            fail("5 in 0-3");
    if (maaOptionInRange("", 5))               fail("5 in \"\"");
    if (maaOptionInRange("0-3;6", 5))          fail("5 in 0-3;6");
    if (maaOptionInRange("0-", 5))             fail("5 in 0-");
    if (maaOptionInRange("4,6", 5))            fail("5 in 4,6");
    if (maaOptionInRange("-4,6", 5))           fail("5 in -4,6");
    if (maaOptionInRange(",,,", 5))            fail("5 in ,,,");
    if (maaOptionInRange("a,b,e", 5))          fail("5 in a,b,e");
    ok(0);
    
    end(opt);
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
