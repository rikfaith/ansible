/* test-maa.c -- 
 * Created: Thu Dec 23 06:20:17 1999 by faith@acm.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-maa.c,v 1.5 2003-08-30 12:55:42 faith Exp $
 * 
 */

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define FLAG1 0x00000001
#define FLAG2 0x40000010
#define FLAG3 0x80000100
#define FLAG4 0xc0001000

static int testlocal(const char *realprog)
{
    const char *prog;
    char       buf[2048];
    
    test("L", "Version String");
    ok(maaVersion());
    
    test("L", "Version Major");
    sprintf(buf, "%d", maaVersionMajor());
    ok(buf);

    test("L", "Version Minor");
    sprintf(buf, "%d", maaVersionMinor());
    ok(buf);

    test("L", "Version Patch");
    sprintf(buf, "%d", maaVersionPatch());
    ok(buf);
    
    test("L", "Version Date");
    ok(maaVersionDate());

    test("L", "Program Name");
    prog = maaProgramName();
    if (strcmp(realprog, prog)) fail(prog);
    ok(prog);

    test("L", "trace");
    maaTraceRegister(FLAG1, "one");
    maaTraceRegister(FLAG2, "two");
    maaTraceSet(FLAG1);
    if (!maaTraceTest(FLAG1)) fail("1 not set");
    maaTraceUnset(FLAG1);
    if (maaTraceTest(FLAG1)) fail("1 set a");
    if (maaTraceTest(FLAG2)) fail("2 set a");
    if (maaTraceTest(FLAG3)) fail("3 set a");
    if (maaTraceTest(FLAG4)) fail("4 set a");
    maaTraceSet(FLAG1);
    maaTraceSet(FLAG2);
    if (!maaTraceTest(FLAG1)) fail("1 not set b");
    if (!maaTraceTest(FLAG2)) fail("2 not set b");
    if (maaTraceTest(FLAG3)) fail("3 set b");
    if (maaTraceTest(FLAG4)) fail("4 set b");
    maaTraceUnset(FLAG2);
    if (!maaTraceTest(FLAG1)) fail("1 not set c");
    if (maaTraceTest(FLAG2)) fail("2 set c");
    if (maaTraceTest(FLAG3)) fail("3 set c");
    if (maaTraceTest(FLAG4)) fail("4 set c");
    maaTraceUnset(FLAG1);
    if (maaTraceTest(FLAG1)) fail("1 set d");
    if (maaTraceTest(FLAG2)) fail("2 set d");
    if (maaTraceTest(FLAG3)) fail("3 set d");
    if (maaTraceTest(FLAG4)) fail("4 set d");
    ok(0);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testlocal(argv[0])))  return retcode;
    }

    return EXIT_SUCCESS;
}
