/* test-stack.c --
 * Created: Sat Jul 17 21:07:16 1999 by tek@wiw.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-stack.c,v 1.11 2000-08-20 13:16:20 faith Exp $
 *
 */

#define NCASES 421

#define OBJECTNAME       "maaStack"
#define OBJECTTYPE       maaStackT
#define OBJECTCREATEV    maaStackCreate
#define OBJECTDESTROY    maaStackDestroy
#define OBJECTPUSH       maaStackPush
#define OBJECTPOP        maaStackPop
#define OBJECTDEPTH      maaStackDepth
#define OBJECTTOP        maaStackTop
#define OBJECTPICK       maaStackPick
#define OBJECTSWAP       maaStackSwap
#define OBJECTDUP        maaStackDup
#define OBJECTITERATE    MAA_STACK_ITERATE
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = teststack()))  return retcode;
    } else {
	if ((retcode = timestack()))  return retcode;
    }
    
    return EXIT_SUCCESS;
}
