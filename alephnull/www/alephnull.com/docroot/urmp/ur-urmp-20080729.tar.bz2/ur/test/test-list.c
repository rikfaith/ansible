/* test-list.c -- 
 * Created: Sun Dec 26 15:16:58 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-list.c,v 1.8 2000-12-28 20:35:54 faith Exp $
 *
 */

#define NCASES 421

#define OBJECTNAME       "maaList"
#define OBJECTTYPE       maaListT
#define OBJECTCREATEV    maaListCreate
#define OBJECTDESTROY    maaListDestroy
#define OBJECTPUSH       maaListPush
#define OBJECTPOP        maaListPop
#define OBJECTDEPTH      maaListDepth
#define OBJECTTOP        maaListTop
#define OBJECTBOT        maaListBot
#define OBJECTLAST       maaListLast
#define OBJECTAPPEND     maaListAppend
#define OBJECTITERATE    MAA_LIST_ITERATE
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    maaListT      s;
    const char    *datum0  = "datum0 is 42";
    const char    *datum1  = "datum1 is 3.14159265";
    int           c;
    const char    **v;
    
				/* ParseString */
    test("L", "ParseString empty");
    s = maaListCreate();
    maaListParseString(s, "");
    if (maaListDepth(s) != 0)        fail("empty");
    ok(0);
    end(s);
    
    test("L", "ParseString white 1");
    s = maaListCreate();
    maaListParseString(s, " ");
    if (maaListDepth(s) != 0)        fail("empty");
    ok(0);
    test("L", "ParseString white 5");
    maaListParseString(s, " \t\f\n\r");
    if (maaListDepth(s) != 0)        fail("empty");
    ok(0);
    
    test("L", "ParseString a");
    maaListParseString(s, "a");
    if (maaListDepth(s) != 1)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString white a");
    maaListParseString(s, "  a");
    if (maaListDepth(s) != 1)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString a white");
    maaListParseString(s, "a  ");
    if (maaListDepth(s) != 1)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    ok(0);
    test("L", "ParseString white a white");
    maaListParseString(s, "\na  ");
    if (maaListDepth(s) != 1)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    ok(0);

    test("L", "ParseString a b");
    maaListParseString(s, "a b");
    if (maaListDepth(s) != 2)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    if (strcmp(maaListPop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString white a b");
    maaListParseString(s, " a b");
    if (maaListDepth(s) != 2)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    if (strcmp(maaListPop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString a b white");
    maaListParseString(s, "a b ");
    if (maaListDepth(s) != 2)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    if (strcmp(maaListPop(s), "b"))  fail("b");
    ok(0);
    test("L", "ParseString white a b white");
    maaListParseString(s, " a b ");
    if (maaListDepth(s) != 2)        fail("depth");
    if (strcmp(maaListPop(s), "a"))  fail("a");
    if (strcmp(maaListPop(s), "b"))  fail("b");
    ok(0);

    test("L", "ParseString 'a b'");
    maaListParseString(s, "'a b'");
    if (maaListDepth(s) != 1)          fail("depth");
    if (strcmp(maaListPop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString white 'a b'");
    maaListParseString(s, " 'a b'");
    if (maaListDepth(s) != 1)          fail("depth");
    if (strcmp(maaListPop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString 'a b' white");
    maaListParseString(s, " 'a b' ");
    if (maaListDepth(s) != 1)          fail("depth");
    if (strcmp(maaListPop(s), "a b"))  fail("a b");
    ok(0);
    test("L", "ParseString white 'a b' white");
    maaListParseString(s, " 'a b' ");
    if (maaListDepth(s) != 1)          fail("depth");
    if (strcmp(maaListPop(s), "a b"))  fail("a b");
    ok(0);
    
    test("L", "ParseString 'a b\\''");
    maaListParseString(s, "'a b\\''");
    if (maaListDepth(s) != 1)           fail("depth");
    if (strcmp(maaListPop(s), "a b'"))  fail("a b'");
    ok(0);
    
    test("L", "ParseString '\"'");
    maaListParseString(s, "'\"'");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "\""))  fail("\"");
    ok(0);
    
    test("L", "ParseString '\"\"'");
    maaListParseString(s, "'\"\"'");
    if (maaListDepth(s) != 1)           fail("depth");
    if (strcmp(maaListPop(s), "\"\""))  fail("\"\"");
    ok(0);
    
    test("L", "ParseString '\"a\"'");
    maaListParseString(s, "'\"a\"'");
    if (maaListDepth(s) != 1)            fail("depth");
    if (strcmp(maaListPop(s), "\"a\""))  fail("\"a\"");
    ok(0);
    
    test("L", "ParseString 'a\"\"'");
    maaListParseString(s, "'a\"\"'");
    if (maaListDepth(s) != 1)            fail("depth");
    if (strcmp(maaListPop(s), "a\"\""))  fail("a\"\"");
    ok(0);
    
    test("L", "ParseString '\"\"a'");
    maaListParseString(s, "'\"\"a'");
    if (maaListDepth(s) != 1)            fail("depth");
    if (strcmp(maaListPop(s), "\"\"a"))  fail("\"\"a");
    ok(0);
    
    test("L", "ParseString 'a\"b\"'");
    maaListParseString(s, "'a\"b\"'");
    if (maaListDepth(s) != 1)             fail("depth");
    if (strcmp(maaListPop(s), "a\"b\""))  fail("a\"b\"");
    ok(0);
    
    test("L", "ParseString '\"a\"b'");
    maaListParseString(s, "'\"a\"b'");
    if (maaListDepth(s) != 1)             fail("depth");
    if (strcmp(maaListPop(s), "\"a\"b"))  fail("\"a\"b");
    ok(0);
    
    test("L", "ParseString \"'\"");
    maaListParseString(s, "\"'\"");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "'"))   fail("'");
    ok(0);
    
    test("L", "ParseString \"");
    maaListParseString(s, "\"");
    if (maaListDepth(s) != 0)         fail("depth");
    ok(0);
    
    test("L", "ParseString '");
    maaListParseString(s, "'");
    if (maaListDepth(s) != 0)         fail("depth");
    ok(0);
    
    test("L", "ParseString \\");
    maaListParseString(s, "\\");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "\\"))  fail("\\");
    ok(0);
    
    test("L", "ParseString \\\\");
    maaListParseString(s, "\\\\");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "\\"))  fail("\\");
    ok(0);
    
    test("L", "ParseString foo'");
    maaListParseString(s, "foo'");
    if (maaListDepth(s) != 1)          fail("depth");
    if (strcmp(maaListPop(s), "foo"))  fail("foo");
    ok(0);
    test("L", "ParseString 'foo");
    maaListParseString(s, "'foo");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "foo")) fail("foo");
    ok(0);
    test("L", "ParseString foo\"");
    maaListParseString(s, "foo\"");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "foo")) fail("foo");
    ok(0);
    test("L", "ParseString \"foo");
    maaListParseString(s, "foo\"");
    if (maaListDepth(s) != 1)         fail("depth");
    if (strcmp(maaListPop(s), "foo")) fail("foo");
    ok(0);
    
    test("L", "ParseString 'a b\\'' \\\"f \\\"\"fo'\"");
    maaListParseString(s, "'a b\\'' \\\"f \\\"\"fo'\"");
    if (maaListDepth(s) != 3)           fail("depth");
    if (strcmp(maaListPop(s), "a b'"))  fail("a b'");
    if (strcmp(maaListPop(s), "\"f"))   fail("\"f");
    if (strcmp(maaListPop(s), "\"fo'")) fail("\"fo'");
    ok(0);

    end(s);
    
    test("L", "MakeArgv");
    s      = maaListCreate();
    maaListMakeArgv(s, &c, &v);
    if (c != 0)               fail("argc 0");
    if (v[0] != NULL)         fail("argv 0");
    maaFree(v);
    
    maaListPush(s, datum0);
    maaListMakeArgv(s, &c, &v);
    if (c != 1)               fail("argc 1");
    if (v[1] != NULL)         fail("argv 1");
    if (strcmp(datum0, v[0])) fail("datum0 1");
    maaFree(v);
    
    maaListPush(s, datum0);
    maaListMakeArgv(s, &c, &v);
    if (c != 2)               fail("argc 2");
    if (v[2] != NULL)         fail("argv 2");
    if (strcmp(datum0, v[0])) fail("datum0 2a");
    if (strcmp(datum0, v[1])) fail("datum0 2b");
    maaFree(v);
    
    maaListPush(s, datum1);
    maaListMakeArgv(s, &c, &v);
    if (c != 3)               fail("argc 3");
    if (v[3] != NULL)         fail("argv 3");
    if (strcmp(datum1, v[0])) fail("datum1 3");
    if (strcmp(datum0, v[1])) fail("datum0 3a");
    if (strcmp(datum0, v[2])) fail("datum0 3b");
    maaFree(v);

    ok(0);
    end(s);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = teststack()))  return retcode;
	if ((retcode = testlocal()))  return retcode;
    } else {
	if ((retcode = timestack()))  return retcode;
    }
    
    return EXIT_SUCCESS;
}
