/* test-random.c -- 
 * Created: Thu Dec 30 05:20:25 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-random.c,v 1.7 2003-09-12 13:15:19 faith Exp $
 *
 */

#define OBJECTTYPE     maaRandomT
#define OBJECTCREATER  maaRandomCreate
#define OBJECTDESTROY  maaRandomDestroy
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static void rangecheck(maaRandomT r, unsigned long seed, const char *note)
{
    int           i;
    unsigned long v;
    char          buf[2048];
    double        f;
    int           vc0, vc1, fc;
    int           c[10];
    
    sprintf(buf, "RangeCheck %s %lu", note, seed);
    test("L", buf);
    if (!r) fail("create");

    
    maaRandomSeed(r, seed, 0);
    vc0 = vc1 = fc = 0;
    for (i = 0; i < 10; i++) c[i] = 0;
    for (i = 0; i < 100000; i++) {
	v = maaRandomRange(r, 0, 9);
	if (v > 9) {
	    sprintf(buf, "%d 0 9 %lu", i, v);
	    fail(buf);
	}
	++c[v];
    }
    for (i = 0; i < 10; i++) {
	if (c[i] < 9500 || c[i] > 10500) {
	    sprintf(buf, "%d returned %d times", i, c[i]);
	    fail(buf);
	}
    }
#if 0
    sprintf(buf, "0-4: %d %d %d %d %d", c[0], c[1], c[2], c[3], c[4]);
    info(buf);
    sprintf(buf, "5-9: %d %d %d %d %d", c[5], c[6], c[7], c[8], c[9]);
    info(buf);
#endif

    maaRandomSeed(r, seed, 0);
    vc0 = vc1 = fc = 0;
    for (i = 0; i < 100000; i++) {
	v = maaRandomRange(r, 0, 100);
	if (v > 100) {
	    sprintf(buf, "%d 0 100 %lu", i, v);
	    fail(buf);
	}
	if (v > 50) ++vc0;
    }
    for (i = 0; i < 100000; i++) {
	v = maaRandomRange(r, 23, 100000000);
	if (v < 23 || v > 100000000) {
	    sprintf(buf, "%d 23 100000000 %lu", i, v);
	    fail(buf);
	}
	if (v > 50000000) ++vc1;
    }

    for (i = 0; i < 10; i++) c[i] = 0;
    for (i = 0; i < 100000; i++) {
	f = maaRandomReal(r);
	if (f < 0.0 || f >= 1.0) {
	    sprintf(buf, "%d %f", i, f);
	    fail(buf);
	}
	if (f > 0.5) ++fc;
	if (f < 0.1) ++c[0];
	else if (f < 0.2) ++c[1];
	else if (f < 0.3) ++c[2];
	else if (f < 0.4) ++c[3];
	else if (f < 0.5) ++c[4];
	else if (f < 0.6) ++c[5];
	else if (f < 0.7) ++c[6];
	else if (f < 0.8) ++c[7];
	else if (f < 0.9) ++c[8];
	else ++c[9];
    }
    for (i = 0; i < 10; i++) {
	if (c[i] < 9500 || c[i] > 10500) {
	    sprintf(buf, "%.1f-%.1f returned %d times",
		    i * 0.1, i * 0.1 + 0.1, c[i]);
	    fail(buf);
	}
    }
#if 0
    sprintf(buf, "0-4r: %d %d %d %d %d", c[0], c[1], c[2], c[3], c[4]);
    info(buf);
    sprintf(buf, "5-9r: %d %d %d %d %d", c[5], c[6], c[7], c[8], c[9]);
    info(buf);
#endif
    
    sprintf(buf, "%lu %.2f %d %d %d", v, f, vc0, vc1, fc);
    if (vc0 < 45000
	|| vc0 > 55000
	|| vc1 < 45000
	|| vc1 > 55000
	|| fc < 45000
	|| fc > 55000) fail(buf);
    ok(buf);
    end(r);
}

static void check(const char *name,
		  maaRandomTypeT type,
		  maaRandomModifierT modifier,
		  unsigned long check1,
		  unsigned long check256)
{
    unsigned long target;
    unsigned long m;
    unsigned long v;
    maaRandomT    r;
    int           i;
    char          buf[512];
    unsigned long seeds[] = { 0, 1, 2, 256, 314159265 };
#define SEEDS (int)(sizeof(seeds)/sizeof(seeds[0]))

    sprintf(buf, "%s 1", name);
    test("L", buf);
    target = check1;
    if (!(r = maaRandomCreate(type, modifier))) fail("prng");
    m = maaRandomMax(r);
    for (i = 0; i < 10000; i++) v = maaRandom(r);
    if (target && v != target) {
	sprintf(buf, "%lu instead of %lu", v, target);
	fail(buf);
    }
    sprintf(buf, "%lu [%s]", v, target ? "known" : "??");
    ok(buf);
    end(r);
    
    sprintf(buf, "%s 256", name);
    test("L", buf);
    target = check256;
    if (!(r = maaRandomCreate(type, modifier))) fail("prng");
    maaRandomSeed(r, 256, 0);
    m = maaRandomMax(r);
    for (i = 0; i < 10000; i++) v = maaRandom(r);
    if (target && v != target) {
	sprintf(buf, "%lu instead of %lu", v, target);
	fail(buf);
    }
    sprintf(buf, "%lu [%s]", v, target ? "known" : "??");
    ok(buf);
    end(r);
    
    rangecheck(maaRandomCreate(type, modifier), m,    name);
    rangecheck(maaRandomCreate(type, modifier), m+23, name);
    for (i = 0; i < SEEDS; i++)
	rangecheck(maaRandomCreate(type, modifier), seeds[i], name);
}

static void timer(const char *name,
		  maaRandomTypeT type,
		  maaRandomModifierT modifier,
		  unsigned long check1,
		  unsigned long check256)
{
    unsigned long v = 0;
    maaRandomT    r;
    maaTimerT     t;
    maaTimevalT   tv;
    int           i;
    char          buf[2048];
    int           iters;
    int           useconds;

    test("T", "Time setup");
    if (!(t = maaTimerCreate(0))) fail("timer");
    if (!(r = maaRandomCreate(type, modifier)))	fail("prng");
    for (iters = 1000, useconds = 0; useconds < 100000;) {
	iters *= 2;
	maaTimerStart(t);
	for (i = 0; i < iters; i++) v = maaRandom(r);
	maaTimerStop(t);
	maaTimerGetElapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    }
    ok(0);
    end(r);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    sprintf(buf, "%s time", name);
    test("T", buf);
    if (!(r = maaRandomCreate(type, modifier)))	fail("prng");
    maaTimerStart(t);
    for (i = 0; i < iters; i++) v = maaRandom(r);
    maaTimerStop(t);
    maaTimerGetElapsed(t, &tv);
    maaTimerDestroy(t);
    sprintf(buf, "%lu", v);
    ok(buf);
    end(r);
    sprintf(buf, "%ld.%06ld S for %d ops",
	    tv.wall.tv_sec, tv.wall.tv_usec, iters);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [%s]", "maaRandom",
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters,
	    name);
    info(buf);
}
    
static int testlocal(void)
{
    check("STD",  MAA_RANDOM_STD,  MAA_RANDOM_UNIFORM, 1043618065, 878252412);
    check("ALT0", MAA_RANDOM_ALT0, MAA_RANDOM_UNIFORM,  399268537,         0);
    check("ALT1", MAA_RANDOM_ALT1, MAA_RANDOM_UNIFORM,          0,         0);
    check("ALT2", MAA_RANDOM_ALT2, MAA_RANDOM_UNIFORM,          0,         0);
    check("LONG", MAA_RANDOM_LONG, MAA_RANDOM_UNIFORM,          0,         0);
    
    check("STD  SH",  MAA_RANDOM_STD,  MAA_RANDOM_SHUFFLE, 0, 0);
    check("ALT0 SH", MAA_RANDOM_ALT0, MAA_RANDOM_SHUFFLE, 0, 0);
    check("ALT1 SH", MAA_RANDOM_ALT1, MAA_RANDOM_SHUFFLE, 0, 0);
    check("ALT2 SH", MAA_RANDOM_ALT2, MAA_RANDOM_SHUFFLE, 0, 0);
    check("LONG SH", MAA_RANDOM_LONG, MAA_RANDOM_SHUFFLE, 0, 0);
    
    return EXIT_SUCCESS;
}

static int time_local(void)
{
    timer("STD",  MAA_RANDOM_STD,  MAA_RANDOM_UNIFORM, 1043618065, 878252412);
    timer("ALT0", MAA_RANDOM_ALT0, MAA_RANDOM_UNIFORM,  399268537,         0);
    timer("ALT1", MAA_RANDOM_ALT1, MAA_RANDOM_UNIFORM,          0,         0);
    timer("ALT2", MAA_RANDOM_ALT2, MAA_RANDOM_UNIFORM,          0,         0);
    timer("LONG", MAA_RANDOM_LONG, MAA_RANDOM_UNIFORM,          0,         0);
    
    timer("STD  SH",  MAA_RANDOM_STD,  MAA_RANDOM_SHUFFLE, 0, 0);
    timer("ALT0 SH", MAA_RANDOM_ALT0, MAA_RANDOM_SHUFFLE, 0, 0);
    timer("ALT1 SH", MAA_RANDOM_ALT1, MAA_RANDOM_SHUFFLE, 0, 0);
    timer("ALT2 SH", MAA_RANDOM_ALT2, MAA_RANDOM_SHUFFLE, 0, 0);
    timer("LONG SH", MAA_RANDOM_LONG, MAA_RANDOM_SHUFFLE, 0, 0);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    } else {
	if ((retcode = time_local()))  return retcode;
    }

    return EXIT_SUCCESS;
}
