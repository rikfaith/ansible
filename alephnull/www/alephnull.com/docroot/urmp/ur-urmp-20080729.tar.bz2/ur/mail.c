/* mail.c -- 
 * Created: Wed Jun 11 10:51:47 2003 by faith@dict.org
 * Copyright 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: mail.c,v 1.3 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"
#include <regex.h>

struct maaMailS {
    unsigned long       magic;
    
    const unsigned char *start;
    unsigned long       len;
    const unsigned char *end;

    const unsigned char *current;
    const unsigned char *next;

    const unsigned char *hpt;
    unsigned long       hlen;
    const unsigned char *bpt;
    unsigned long       blen;

    unsigned char       *header;   /* Buffer */
    unsigned long       headerlen; /* Length of buffer */
    unsigned char       *h0;       /* Null terminated */
    maaListT            h0list;    /* Listified */
};

CHECK_FUNCTION(_maaMailCheck, maaMailT, MAA_MAIL_MAGIC)

/* A version of the Boyer-Moore-Horspool text searching algorithm, as
   described in G. H. Gonnet and R. Baeza-Yates, HANDBOOK OF ALGORITHMS
   AND DATA STRUCTURES: IN PASCAL AND C (2nd ed).  Addison-Wesley
   Publishing Co., 1991.  Pages 258-9. */
static const unsigned char *maaMailScan(const unsigned char *start,
                                        const unsigned char *end,
                                        const char *pat)
{
    int                 skip[UCHAR_MAX + 1];
    int                 patlen = strlen((const char *)pat);
    int                 i, j;
    const unsigned char *p, *pt;

    for (i = 0; i <= UCHAR_MAX; i++) skip[i] = patlen;
    for (i = 0; i < patlen-1; i++)   skip[(unsigned char)pat[i]] = patlen-i-1;
    for (p = start + patlen - 1; p < end; p += skip[*p]) {
        for (j = patlen - 1, pt = p; j >= 0 && *pt == pat[j]; --j) --pt;
        if (j < 0) return pt + 1;
    }
    return NULL;
}

maaMailT maaMailCreate(const void *buffer, unsigned long len)
{
    maaMailT   mail = maaAllocZ(sizeof(*mail));

    mail->magic = MAA_MAIL_MAGIC;
    mail->start = buffer;
    mail->len   = len;
    mail->end   = mail->start + mail->len;

    return mail;
}

unsigned long maaMailDestroy(maaMailT mail)
{
    unsigned long ret;
    
    _maaMailCheck(mail);
    if (mail->header) maaFree(mail->header);
    if (mail->h0)     maaFree(mail->h0);
    if (mail->h0list) maaListDestroy(mail->h0list);
    ret = mail->magic = ~MAA_MAIL_MAGIC;
    maaFree(mail);
    return ret;
}

const void *maaMailNext(maaMailT mail, unsigned long *len)
{
    unsigned long       length;
    const unsigned char *end;
    
    _maaMailCheck(mail);

    if (!mail->current) mail->current = mail->start;
    else                mail->current = mail->next;

    if (!mail->current) return NULL;
    
    if (strncmp((char *)mail->current, "From ", 5)) { /* Is not mbox */
        mail->next = NULL;
        length     = mail->end - mail->current;
    } else {                              /* May be mbox */
        if ((end = maaMailScan(mail->current, mail->end, "\nFrom "))) {
            mail->next = end + 1;
            length     = mail->next - mail->current;
        } else {
            mail->next = NULL;
            length     = mail->end - mail->current;
        }
    }
    
    if (len) *len = length;

    if ((end = maaMailScan(mail->current,
                           mail->next ? mail->next : mail->end, "\n\n"))) {
        mail->hpt  = mail->current;
        mail->hlen = end - mail->current;
        mail->bpt  = end + 2;
        mail->blen = *len - mail->hlen - 2;
    } else {
        mail->hpt  = NULL;
        mail->hlen = 0;
        mail->bpt  = NULL;
        mail->blen = 0;
    }

    return mail->current;
}

const void *maaMailHeader(maaMailT mail, unsigned long *len, const char *re)
{
    int                 chunks = (mail->hlen
                                  + MAA_MAIL_CHUNK - 1) / MAA_MAIL_CHUNK;
    const unsigned char *s;
    unsigned char       *d, *d0, *bol, *b0;
    regex_t             preg;
    unsigned long       length   = 0;
    int                 skipping = 0;

    _maaMailCheck(mail);

    if (len) *len = 0;
    if (!mail->hpt) return NULL;
    if (!mail->header || mail->headerlen <= mail->hlen) {
        if (mail->header) maaFree(mail->header);
        if (mail->h0)     maaFree(mail->h0);
        mail->headerlen = chunks * MAA_MAIL_CHUNK - MAA_MAIL_FUDGE;
        mail->header    = maaAlloc(mail->headerlen);
        mail->h0        = maaAlloc(mail->headerlen);
    }
    if (mail->h0list) maaListDestroy(mail->h0list);
    mail->h0list        = maaListCreate();


    if (re) regcomp(&preg, re, REG_ICASE|REG_EXTENDED);

    for (s = mail->hpt, bol = d = mail->header, b0 = d0 = mail->h0;
         s < mail->hpt+mail->hlen; /**/) {
        
        if (*s == '\n' || s == mail->hpt + mail->hlen - 1) {
            *d0 = *d = '\0';
            if ((skipping && (*bol == ' ' || *bol == '\t'))
                || (re && !regexec(&preg, (const char *)bol, 0, NULL, 0))) {
                                /* d */
                skipping = 1;
                length  -= d - bol;
                d        = bol;
                d0       = b0;
                ++s;
                continue;
            } else {
                                /* d0 */
                if ((*b0 == ' ' || *b0 == '\t') && b0 > mail->h0) {
                    b0[-1] = ' ';
                    b0     = ++d0;
                } else {
                    maaListAppend(mail->h0list, b0);
                    b0     = ++d0;
                }
                                /* d */
                skipping = 0;
                bol = d  + 1;
            }
        } else
            *d0++ = *s;
        *d++  = *s++;
        ++length;
    }
    *d0 = '\0';
    
    if (re) regfree(&preg);

    if (len) *len = length;
    return mail->header;
}

maaListT maaMailHeaders(maaMailT mail)
{
    _maaMailCheck(mail);
    return mail->h0list;
}

const char *maaMailHeaderFind(maaMailT mail, const char *name, int idx)
{
    maaIteratorT iter;
    const char   *datum;
    int          len = strlen(name);

    if (idx < 0) idx = 0;
    
    _maaMailCheck(mail);
    if (!mail->h0list) return 0;
    MAA_LIST_ITERATE(mail->h0list, iter, datum)
        if (!strncasecmp(name, datum, len) && !idx--) return datum;
    return NULL;
}

const void *maaMailBody(maaMailT mail, unsigned long *len)
{
    _maaMailCheck(mail);
    if (len) *len = 0;
    if (!mail->bpt) return NULL;
    if (len) *len = mail->blen;
    return mail->bpt;
}

int maaMailParts(maaMailT mail)
{
    return 0;
}

const void *maaMailPart(maaMailT mail, int part, unsigned long *len)
{
    return NULL;
}
