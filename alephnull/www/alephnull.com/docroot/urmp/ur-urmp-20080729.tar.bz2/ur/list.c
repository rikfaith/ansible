/* list.c -- Doubly-linked list
 * Created: Mon Jul  5 13:24:11 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: list.c,v 1.10 2003-06-12 13:58:58 faith Exp $
 * 
 */

#include "maaP.h"

typedef struct maaListElementS {
    const void             *datum;
    struct maaListElementS *prev;
    struct maaListElementS *next;
} *maaListElementT;

struct maaListS {
    unsigned long   magic;
    maaListElementT head;
    maaListElementT tail;
    maaBlockT       block;
    unsigned int    depth;
};

CHECK_FUNCTION(_maaListCheck, maaListT, MAA_LIST_MAGIC)

/* Create an empty list. */
maaListT maaListCreate(void)
{
    maaListT list = maaAllocZ(sizeof(*list));

    list->magic = MAA_LIST_MAGIC;
    if (MAA_USE_BLOCK)
	list->block = maaBlockCreate(sizeof(struct maaListElementS));
    return list;
}

/* Free all allocated memory associated with list. */
unsigned long maaListDestroy(maaListT list)
{
    maaListElementT e;
    maaListElementT next;
    unsigned long   ret;

    _maaListCheck(list);
    ret = list->magic = ~MAA_LIST_MAGIC;

    if (MAA_USE_BLOCK) maaBlockDestroy(list->block);
    else {
	for (e = list->head; e; e = next) {
	    next = e->next;
	    maaFree(e);
	}
    }
    maaFree(list);
    return ret;
}

void maaListPush(maaListT list, const void *datum)
{
    maaListElementT e;

    _maaListCheck(list);

    e          = (MAA_USE_BLOCK
		  ? maaBlockAlloc(list->block)
		  : maaAlloc(sizeof(*e)));
    e->datum   = datum;
    e->prev    = NULL;
    e->next    = list->head;
    if (list->head) list->head->prev = e;
    list->head = e;
    if (!list->tail) list->tail = e; /* first element */
    ++list->depth;
}

void maaListAppend(maaListT list, const void *datum)
{
    maaListElementT e;

    _maaListCheck(list);

    e          = (MAA_USE_BLOCK
		  ? maaBlockAlloc(list->block)
		  : maaAlloc(sizeof(*e)));
    e->datum   = datum;
    e->prev    = list->tail;
    e->next    = NULL;
    if (list->tail) list->tail->next = e;
    list->tail = e;
    if (!list->head) list->head = e; /* first element */
    ++list->depth;
}

void *maaListPop(maaListT list)
{
    maaListElementT e;
    const void      *datum = NULL;

    _maaListCheck(list);
    e = list->head;
    if (e) {
	if (e->next) e->next->prev = NULL;
	list->head = e->next;
	datum      = e->datum;
	if (list->tail == e) list->tail = NULL; /* last element */
	if (MAA_USE_BLOCK) maaBlockFree(list->block, e); else maaFree(e);
	--list->depth;
    }
    return (void *)datum;	/* Discard const */
}

void *maaListTop(maaListT list)
{
    _maaListCheck(list);
    return list->head ? (void *)list->head->datum : NULL; /* Discard const */
}

void *maaListLast(maaListT list)
{
    maaListElementT e;
    const void      *datum = NULL;

    _maaListCheck(list);
    e = list->tail;
    if (e) {
	if (e->prev) e->prev->next = NULL;
	list->tail = e->prev;
	datum      = e->datum;
	if (list->head == e) list->head = NULL; /* last element */
	if (MAA_USE_BLOCK) maaBlockFree(list->block, e); else maaFree(e);
	--list->depth;
    }
    return (void *)datum;	/* Discard const */
}

void *maaListBot(maaListT list)
{
    _maaListCheck(list);
    return list->tail ? (void *)list->tail->datum : NULL; /* Discard const */
}

void *maaListNth(maaListT list, int n)
{
    maaListElementT e;
    int             i;
    
    _maaListCheck(list);
    if (n < 1)                            return NULL;
    if ((unsigned)n > maaListDepth(list)) return NULL;

    for (i = 1, e = list->head; i < n; i++, e = e->next)
	;
    return (void *)e->datum;	/* Discard const */
}

unsigned int maaListDepth(maaListT list)
{
    _maaListCheck(list);
    return list->depth;
}

void maaListMakeArgv(maaListT list, int *argc, const char ***argv)
{
    int             c;
    const char      **v;
    maaListElementT e;
    int             i;

    _maaListCheck(list);
    c = maaListDepth(list);
    v = maaAlloc((c + 1) * sizeof(*v));
    for (e = list->head, i = 0; e; e = e->next, i++) v[i] = e->datum;
    v[c]  = NULL;
    *argc = c;
    *argv = v;
}

void maaListParse(maaListT list, const char *string, const char *delim,
		  const char *quote, const char *escape)
{
    int        inquote = 0;
    const char *pt     = string;
    int        len;
    char       *buf;
    char       *last;
    
    _maaListCheck(list);
    buf = maaAlloc(strlen(string)+1);

    for (last = buf, len = 0; *pt; ++pt) {
	if (delim && !inquote && strchr(delim, *pt)) {
	    if (last != buf) maaListAppend(list, maaAtomStringN(buf, len));
	    last = buf;
	    len  = 0;
	} else if (quote && strchr(quote, *pt)) {
	    if (inquote == *pt) {
		maaListAppend(list, maaAtomStringN(buf, len));
		last    = buf;
		len     = 0;
		inquote = 0;
	    } else {
		if (!inquote) {
		    inquote = *pt;
		    if (pt[1]) {
			*last++ = *++pt;
			++len;
		    }
		} else {
		    *last++ = *pt;
		    ++len;
		}
	    }
	} else if (escape && pt[1] && strchr(escape, *pt)) {
	    *last++ = *++pt;
	    ++len;
	} else {
	    *last++ = *pt;
	    ++len;
	}
    }
    if (last != buf) maaListAppend(list, maaAtomStringN(buf, len));
    
    maaFree(buf);
}

void maaListParseString(maaListT list, const char *string)
{
    maaListParse(list, string,
		 MAA_LIST_DELIM, MAA_LIST_QUOTE, MAA_LIST_ESCAPE);
}

void maaListIteratorInit(maaListT list, maaIteratorT *iter)
{
    _maaListCheck(list);
    iter->a = list;
    iter->b = list->head;
}

int maaListIteratorNext(maaIteratorT *iter)
{
    maaListT list = iter->a;
    
    _maaListCheck(list);
    if (!iter->b) return 0;
    iter->b = ((maaListElementT)iter->b)->next;
    return iter->b != NULL;
}

void *maaListIteratorDatum(maaIteratorT *iter)
{
    maaListT list = iter->a;
    
    _maaListCheck(list);
    if (!iter->b) return NULL;
    return (void *)((maaListElementT)iter->b)->datum; /* Discard const */
}
