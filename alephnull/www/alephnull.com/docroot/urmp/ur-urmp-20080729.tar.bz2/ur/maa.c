/* maa.c -- 
 * Created: Mon Jul  5 13:08:25 1999 by faith@dict.org
 * Copyright 1999, 2000, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: maa.c,v 1.17 2003-09-12 13:15:17 faith Exp $
 * 
 */

#include "maaP.h"
#ifdef BT_PRODUCTION
#include "backtrace.h"
#endif

static const char *_maaProgramName;
static maaFlagT    _maaFlags;

void maaInit(const char *programName)
{
    _maaProgramName = maaAtomString(programName);
    if (!_maaFlags) _maaFlags = maaFlagCreate();

#ifdef BT_PRODUCTION
    bt_signal(0, programName);
#endif

#ifdef HAVE_ATEXIT
    atexit(maaShutdown);
#else
#ifdef HAVE_ON_EXIT
    on_exit(maaShutdown, NULL);
#endif
#endif
}

const char *maaProgramName(void)
{
    return _maaProgramName;
}

void maaShutdown(void)
{
    if (_maaFlags) {
	maaFlagDestroy(_maaFlags);
	_maaFlags = NULL;
    }
    maaAtomDestroy();
}

const char *maaVersion(void)
{
    char              *tmp;
    static const char *version = NULL;

    if (!version) {
	tmp = maaAlloc(128);
	sprintf(tmp, "maa %d.%d.%d (%s)",
		MAA_MAJOR, MAA_MINOR, MAA_PATCH, MAA_DATE);
	version = maaAtomString(tmp);
	maaFree(tmp);
    }
    return version;
}

int maaVersionMajor(void)
{
    return MAA_MAJOR;
}

int maaVersionMinor(void)
{
    return MAA_MINOR;
}

int maaVersionPatch(void)
{
    return MAA_PATCH;
}

const char *maaVersionDate(void)
{
    return maaAtomString(MAA_DATE);
}

void maaError(maaErrorT mask, int error,
	      const char *routine, const char *format, va_list ap)
{
    char       buf[2][256];
    int        count;
    const char *type = "unknown";

    if (mask & MAA_ERROR_TRACE)    type = "trace";
    if (mask & MAA_ERROR_WARN)     type = "warn";
    if (mask & MAA_ERROR_INFO)     type = "info";
    if (mask & MAA_ERROR_FATAL)    type = "fatal";
    if (mask & MAA_ERROR_INTERNAL) type = "internal";

    memset(buf, 0, sizeof(buf));
    
#ifndef HAVE_VSNPRINTF
				/* No vsnprintf implies no security... */
    if (strlen(routine) + strlen(format) < sizeof(buf[0]) - 100 && routine) {
	if (mask & MAA_ERROR_ERRNO)
	    sprintf(buf[0], "%s::%s (%s, errno = %d): %s",
		    _maaProgramName ? _maaProgramName : "",
		    routine ? routine : "",
		    type, error, format);
	else 
	    sprintf(buf[0], "%s::%s (%s): %s",
		    _maaProgramName ? _maaProgramName : "",
		    routine ? routine : "",
		    type, format);
    }
#else
    snprintf(buf[0], sizeof(buf[0]), "%s::%s (%s): ",
	     _maaProgramName ? _maaProgramName : "",
	     routine ? routine : "",
	     type);
#endif
    count = strlen(buf[0]);
    vsnprintf(buf[0] + count, sizeof(buf[0] - count), format, ap);
    if (mask & MAA_ERROR_ERRNO) {
#if HAVE_STRERROR
	snprintf(buf[1], sizeof(buf[1]), "    errno = %d: %s",
		 error, strerror(error));
#else
	snprintf(buf[1], sizeof(buf[1]), "     errno = %d", error);
#endif
    }

}

				/* error management */
static int _maaPrint(const char *progname, const char *routine,
                     const char *format, va_list ap)
{
    int retval = 0;
    
    fflush(stdout);
    fflush(stderr);
    if (progname) {
	if (routine)
	    retval += fprintf(stderr, "%s (%s): ", progname, routine);
	else
	    retval += fprintf(stderr, "%s: ", progname);
    } else {
	if (routine) retval += fprintf(stderr, "%s: ", routine);
    }

    retval += vfprintf(stderr, format, ap);
    maaLogErrorV(routine, format, ap);
    fflush(stderr);
    return retval;
}

void maaTrace(unsigned long flag, const char *routine, const char *format, ...)
{
    va_list ap;
    
    if (!flag || maaTraceTest(flag)) {
	va_start(ap, format);
	_maaPrint(NULL, routine, format, ap);
	va_end(ap);
    }
}

void maaWarning(const char *routine, const char *format, ...)
{
    va_list ap;
    
    va_start(ap, format);
    _maaPrint(_maaProgramName, routine, format, ap);
    va_end(ap);
}

void maaFatal(const char *routine, const char *format, ...)
{
    va_list ap;
    
    va_start(ap, format);
    _maaPrint(_maaProgramName, routine, format, ap);
    va_end(ap);
#ifdef BT_PRODUCTION
    bt_backtrace(_maaProgramName);
#endif    
    exit(EXIT_FAILURE);
}

void maaFatalAbort(const char *routine, const char *format, ...)
{
    va_list ap;
    
    va_start(ap, format);
    _maaPrint(_maaProgramName, routine, format, ap);
    va_end(ap);
                                /* Do not call bt_* here. */
    abort();
}

void maaFatalErrno(const char *routine, const char *format, ...)
{
    va_list ap;
    int     save = errno;
    
    va_start(ap, format);
    _maaPrint(_maaProgramName, routine, format, ap);
    va_end(ap);
    
#if HAVE_STRERROR
    errno = save;
    fprintf(stderr, "%s: %s\n", routine ? routine : "", strerror(save));
    errno = save;
    maaLogError(routine, "%s: %s\n", routine ? routine : "", strerror(save));
#else
    fprintf(stderr, "%s: errno = %d\n", routine ? routine : "", save);
    maaLogError(routine, "%s: errno = %d\n", routine ? routine : "", save);
#endif
   
#ifdef BT_PRODUCTION
    bt_backtrace(_maaProgramName);
#endif    
    exit(EXIT_FAILURE);
}

void maaInternal(const char *routine, const char *format, ... )
{
    va_list ap;
    
    va_start(ap, format);
    _maaPrint(_maaProgramName, routine, format, ap);
    va_end(ap);

    if (_maaProgramName) fprintf(stderr, "%s: aborting...\n", _maaProgramName);
    else                 fprintf(stderr, "aborting...\n");
    fflush(stderr);
#ifdef BT_PRODUCTION
    bt_backtrace(_maaProgramName);
#endif    
    abort();
}

int maaLogBacktrace(const char *format, ...)
{
    int     retval = 0;
    va_list ap;
    
    va_start(ap, format);
    retval += _maaPrint(NULL, NULL, format, ap);
    va_end(ap);
    return retval;
}

void maaErrorCallback(int (*f)(int severity, const char *message))
{
}

void maaLogFile(const char *filename)
{
}

void maaLogSyslog(void)
{
}

void maaLogClose(void)
{
}

void maaLogError(const char *routine, const char *format, ...)
{
}

void maaLogErrorV(const char *routine, const char *format, va_list ap)
{
}

void maaLogInfo(const char *routine, const char *format, ...)
{
}

void maaLogInfoV(const char *routine, const char *format, va_list ap)
{
}


void maaTraceRegister(unsigned long flag, const char *name)
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    maaFlagRegister(_maaFlags, flag, name);
}
    
void maaTraceSet(unsigned long flag)
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    maaFlagSet(_maaFlags, flag);
}

void maaTraceUnset(unsigned long flag)
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    maaFlagUnset(_maaFlags, flag);
}

				/* FIXME: move to a header for inlining */
int maaTraceTest(unsigned long flag)
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    return maaFlagTest(_maaFlags, flag);
}

void maaTraceSetByName(const char *name, int (*f)(const char *))
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    maaFlagSetByName(_maaFlags, name, f);
}

void maaTraceUnsetByName(const char *name, int (*f)(const char *))
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    maaFlagUnsetByName(_maaFlags, name, f);
}

int maaTraceTestByName(const char *name, int (*f)(const char *))
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    return maaFlagTestByName(_maaFlags, name, f);
}

maaListT maaTraceNames(void)
{
    if (!_maaFlags) maaFatal(__FUNCTION__, "maaInit not called\n");
    return maaFlagNames(_maaFlags);
}
