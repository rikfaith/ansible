/* option.c -- 
 * Created: Mon Jul  5 16:21:58 1999 by faith@dict.org
 * Copyright 1999, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: option.c,v 1.6 2003-06-14 12:14:33 faith Exp $
 * 
 */

#include "maaP.h"

struct maaOptionS {
    unsigned long  magic;
    
    int            argc;
    const char     **argv;
    maaOptionListT *list;
    maaListT       other;
    
    const char     *arg;
    int            argfree;
    int            ind;
    int            next_short;
    int            listfree;
};

CHECK_FUNCTION(_maaOptionCheck, maaOptionT, MAA_OPTION_MAGIC)

maaOptionT maaOptionCreate(maaOptionListT *list)
{
    maaOptionT opt = maaAllocZ(sizeof(*opt));

    opt->magic = MAA_OPTION_MAGIC;
    opt->list  = list;
    return opt;
}

void maaOptionParseArgv(maaOptionT opt, int argc, const char **argv)
{
    _maaOptionCheck(opt);

    if (opt->argfree  && opt->argv)  maaFree(opt->argv);
    if (opt->listfree && opt->other) maaListDestroy(opt->other);
    
    opt->argc       = argc;
    opt->argv       = argv;
    opt->argfree    = 0;
    
    opt->arg        = NULL;
    opt->ind        = 1;
    opt->next_short = 0;
    
    opt->other      = maaListCreate();
    opt->listfree   = 1;
}

void maaOptionParseString(maaOptionT opt, const char *string)
{
    int        argc;
    const char **argv;
    maaListT   list;
    
    _maaOptionCheck(opt);
    list = maaListCreate();
    maaListParseString(list, string);
    maaListMakeArgv(list, &argc, &argv);
    maaListDestroy(list);
    maaOptionParseArgv(opt, argc, argv);
    opt->argfree    = 1;
    opt->ind        = 0;
}

void maaOptionParseList(maaOptionT opt, maaListT list)
{
    int        argc;
    const char **argv;

    _maaOptionCheck(opt);
    maaListMakeArgv(list, &argc, &argv);
    maaOptionParseArgv(opt, argc, argv);
    opt->argfree = 1;
    opt->ind     = 0;
}

unsigned long maaOptionDestroy(maaOptionT opt)
{
    unsigned long ret;
    
    _maaOptionCheck(opt);
    ret = opt->magic = ~MAA_OPTION_MAGIC;
    if (opt->argfree  && opt->argv)  maaFree(opt->argv);
    if (opt->listfree && opt->other) maaListDestroy(opt->other);
    maaFree(opt);
    return ret;
}

static void _maaOptionGetArg(maaOptionT opt)
{
    if (opt->next_short && opt->argv[opt->ind][opt->next_short + 1])
	opt->arg = maaAtomString(&opt->argv[opt->ind][opt->next_short + 1]);
    else
	opt->arg = maaAtomString(opt->argv[++opt->ind]);
    opt->next_short = 0;
}

static int _maaOptionShort(maaOptionT opt)
{
    maaOptionListT *pt;
    
    if (!opt->next_short) opt->next_short = 1;
    
    for (pt = opt->list; pt && pt->shortname; ++pt) {
	if (pt->shortname == opt->argv[opt->ind][opt->next_short]) {
	    if (pt->type != MAA_OPTION_NONE) {
		_maaOptionGetArg(opt);
		++opt->ind;
	    } else if (!opt->argv[opt->ind][++opt->next_short]) {
		opt->next_short = 0;
		++opt->ind;
	    }
	    return pt->shortname;
	}
    }
    return '?';
}

static int _maaOptionLong(maaOptionT opt)
{
    maaOptionListT *pt;

    for (pt = opt->list; pt && pt->longname; ++pt) {
	if (!strcmp(pt->longname, &opt->argv[opt->ind][2])) {
	    if (pt->type != MAA_OPTION_NONE) _maaOptionGetArg(opt);
	    ++opt->ind;
	    return pt->shortname;
	}
    }
    return '?';
}

static void _maaOptionGetOther(maaOptionT opt)
{
    int i;

    for (i = opt->ind; i < opt->argc; i++) {
	maaListAppend(opt->other, maaAtomString(opt->argv[i]));
    }
}

int maaOptionGet(maaOptionT opt)
{
    _maaOptionCheck(opt);

    opt->arg = NULL;
    if (opt->next_short) return _maaOptionShort(opt);
    if (opt->ind >= opt->argc) {
	_maaOptionGetOther(opt);
	return EOF;
    }
    if (opt->argv[opt->ind][0] != '-'
	|| (opt->argv[opt->ind][0] && opt->argv[opt->ind][1] == '\0')) {
	_maaOptionGetOther(opt);
	return EOF; /* FIXME: try to permute */
    }
    if (opt->argv[opt->ind][1] != '-') {
	return _maaOptionShort(opt);
    }
    if (opt->argv[opt->ind][2] == '\0') {
	++opt->ind;		/* skip -- */
	_maaOptionGetOther(opt);
	return EOF;
    }
    return _maaOptionLong(opt);
}

long maaOptionInt(maaOptionT opt)
{
    _maaOptionCheck(opt);

    return opt->arg ? strtol(opt->arg, NULL, 0) : 0;
}

double maaOptionReal(maaOptionT opt)
{
    _maaOptionCheck(opt);
    return opt->arg ? strtod(opt->arg, NULL) : 0;
}

const char *maaOptionString(maaOptionT opt)
{
    _maaOptionCheck(opt);
    return opt->arg;
}

maaListT maaOptionList(maaOptionT opt)
{
    char     *buf;
    char     *pt;
    char     *prev;
    maaListT list;
    
    _maaOptionCheck(opt);
    if (!opt->arg) return NULL;

    list = maaListCreate();
    buf  = maaAlloc(strlen(opt->arg) + 1);
    strcpy(buf, opt->arg);
    for (pt = prev = buf; pt; pt++) {
	if (!*pt || *pt == ',') {
            char save = *pt;
	    *pt = '\0';
	    maaListAppend(list, maaAtomString(prev));
	    prev = pt + 1;
            *pt = save;
	}
	if (!*pt) break;
    }
    maaFree(buf);
    return list;
}

maaListT maaOptionOther(maaOptionT opt)
{
    opt->listfree = 0;
    return opt->other;
}

int maaOptionInRange(const char *range, unsigned long val)
{
    const char    *pt;
    char          *endptr;
    unsigned long v0, v1;

    if (!range) return 1;
    for (pt = range;; pt = endptr) {
        if (*pt == ',') ++pt;
        if (*pt == '-') {
            v0     = 0;
            endptr = (char *)pt;
        } else {
            v0 = strtoul(pt, &endptr, 0);
            if (pt == endptr && *endptr) {
                ++endptr;
                v0 = 0;
            }
        }
        if (*endptr == '-') {
            v1 = strtoul(endptr + 1, &endptr, 0);
            if (val >= v0 && val <= v1)            return 1;
            if (v0 > v1 && val <= v0 && val >= v1) return 1;
        } else if (val == v0) return 1;
        if (!*endptr) return 0;
    }
}
