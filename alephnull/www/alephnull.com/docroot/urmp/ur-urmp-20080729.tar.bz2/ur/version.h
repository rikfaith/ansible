#define MAA_DATE "20030614"
#define MAA_MAJOR 0
#define MAA_MINOR 1
#define MAA_PATCH 0
