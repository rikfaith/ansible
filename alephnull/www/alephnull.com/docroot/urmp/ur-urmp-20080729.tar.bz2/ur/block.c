/* block.c -- Same-size block allocator
 * Created: Sat Aug  7 18:56:30 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: block.c,v 1.5 2000-01-17 11:58:07 faith Exp $
 *
 */

#include "maaP.h"

struct maaBlockS {
    unsigned long  magic;
    size_t         size;
    maaArenaT      arena;
    void           *next;
    size_t         allocated;
    size_t         used;
    size_t         freed;
};

typedef struct maaBlockNextS {
    unsigned long  magic;
    void           *next;
} *maaBlockNextT;

CHECK_FUNCTION(_maaBlockCheck, maaBlockT, MAA_BLOCK_MAGIC)
CHECK_FUNCTION(_maaBlockNextCheck, maaBlockNextT, MAA_BLOCK_NEXT_MAGIC)

maaBlockT maaBlockCreate(size_t blocksize)
{
    maaBlockT block = maaAlloc(sizeof(*block));

    block->magic     = MAA_BLOCK_MAGIC;
    block->size      = (blocksize < sizeof(struct maaBlockNextS)
			? sizeof(struct maaBlockNextS)
			: blocksize);
    block->arena     = maaArenaCreate(0);
    block->next      = NULL;
    block->allocated = 0;
    block->used      = 0;
    block->freed     = 0;
    
    return block;
}

unsigned long maaBlockDestroy(maaBlockT block)
{
    unsigned long ret;
    
    _maaBlockCheck(block);
    maaArenaDestroy(block->arena);
    ret = block->magic = ~MAA_BLOCK_MAGIC;
    maaFree(block);
    return ret;
}

void *maaBlockAlloc(maaBlockT block)
{
    maaBlockNextT next = block->next;
    
    _maaBlockCheck(block);
    if (next) {
	_maaBlockNextCheck(next);
	block->next = next->next;
	next->magic = 0;
	next->next  = NULL;
	return next;
    }

    return maaArenaAlloc(block->arena, block->size);
}

void *maaBlockAllocZ(maaBlockT block)
{
    maaBlockNextT next;
    
    _maaBlockCheck(block);
    if ((next = block->next)) {
	_maaBlockNextCheck(next);
	block->next = next->next;
	memset(next, 0, block->size);
	return next;
    }

    return maaArenaAllocZ(block->arena, block->size);
}

void maaBlockFree(maaBlockT block, void *area)
{
    maaBlockNextT current = (maaBlockNextT)area;

    _maaBlockCheck(block);
    if (!current) maaFatal(__FUNCTION__, "Freeing NULL pointer\n");
    
    current->magic = MAA_BLOCK_NEXT_MAGIC;
    current->next  = block->next;
    block->next    = current;
}
