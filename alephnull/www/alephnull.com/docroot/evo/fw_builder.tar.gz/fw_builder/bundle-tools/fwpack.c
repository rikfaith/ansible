/*
    A small tool to generate Wyse WinTerm firmware upgrade/add-on images
    Copyright (C) 2005  Wilmer van der Gaast <wilmer@gaast.net>
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the second version of the GNU
    General Public License as published by the Free Software
    Foundation.
    
    !!! GPL EXCEPTION: Since this program includes bits of data from original
    WYSE images during the compilation progress, you're NOT allowed to
    distribute binaries! Distribute this program ONLY IN SOURCE FORM !!!
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "fwstruct.h"
#include "fwhead.h"

#ifndef BYTE_ORDER
#error "Couldn't determine byte order"
#endif

#define BUFSIZE 512

struct fwfile
{
	int fd;
	u_int32_t cs;
	u_int8_t cslen;
	union
	{
		u_int8_t byte[4];
		u_int32_t val;
	} csbuf;
};

struct fwfile *fwstart( char *fn );
int fwwrite( struct fwfile *fw, void *data, int size );
int fwpad( struct fwfile *fw, int align, off_t pad_base );
u_int32_t fwcs( struct fwfile *fw );
void fwclose( struct fwfile *fw );

int pad( off_t offset, int align, off_t pad_base );
char *basename( char *fn );
void verify_offset( int fd, off_t expect );

int main( int argc, char *argv[] )
{
	struct index *idx = NULL, *idxstart = NULL;
	struct fwfile *fw = NULL;
	u_int32_t int32;
	off_t cur, pad_base = 0;
	int fd, i;
	
	printf( "fwpack - Generate WYSE Winterm firmware bundles\n\n" );
	
	structcheck();
	
	if( argc < 3 )
	{
		fprintf( stderr, "Syntax: %s <image> <bios> [<other files> <...>]\n"
		                 "\n"
		                 "First argument is the destination file. After that, specify the files to put\n"
		                 "into the image. The first file will be used as the BIOS file, after that you\n"
		                 "can put other files you want to be in the image. The original firmware files\n"
		                 "have some flags that this tool won't create, so this tool is probably not\n"
		                 "suitable to create original WinCE firmware (or add-on) images. It's mainly\n"
		                 "meant to create Linux images.\n"
		                 "\n"
		                 "Also, a file named k will automatically be used for the hardware magic section\n"
		                 "in the headers.\n"
		                 "\n"
		                 "Don't forget to read the documentation before using this tool!\n", argv[0] );
		return( 1 );
	}
	
	printf( "Checking all files and building index" );
	fflush( stdout );
	cur = 0x59;
	for( i = 2; i < argc; i ++ )
	{
		struct fwfile *cscalc;
		char rdbuf[BUFSIZE];
		struct stat fs;
		int n;
		
		fd = open( argv[i], O_RDONLY );
		if( fd < 0 )
		{
			perror( "open" );
			return( 1 );
		}
		if( fstat( fd, &fs ) != 0 )
		{
			perror( "fstat" );
			return( 1 );
		}
		
		if( idx == NULL )
		{
			idx = idxstart = calloc( sizeof( struct index ), 1 );
		}
		else
		{
			idx->next = calloc( sizeof( struct index ), 1 );
			idx = idx->next;
		}
		idx->idx_offset = cur;
		idx->realfile = argv[i];
		
		/* Add one byte so the filename will be ASCIIZ. */
		idx->h = calloc( 1, 1 + sizeof( struct header ) + strlen( basename( argv[i] ) ) );
		idx->h->fnlen = strlen( basename( argv[i] ) );
		idx->h->hsize = idx->h->fnlen + sizeof( struct header );
		memcpy( idx->h->fn, basename( argv[i] ), idx->h->fnlen );
		
		/* BIOS gets a special flag. */
		if( i == 2 )
			idx->h->bios_flag = 0x10000;
		else
			idx->h->bios_flag = 0x20000;
		
		/* This flag is always 1 for system files, 5 for addon files. We have only system files. */
		idx->h->sys_flag[0] = 1;
		
		/* No idea what this is for, just typing something. :-) */
		idx->h->time = fs.st_mtime;
		
		/* This is a bit of a hack, but isn't that exactly what we're doing anyway? :-) */
		cscalc = fwstart( "/dev/null" );
		while( ( n = read( fd, rdbuf, BUFSIZE ) ) > 0 )
		{
			fwwrite( cscalc, rdbuf, n );
			idx->h->fsize += n;
		}
		idx->h->checksum = fwcs( cscalc );
		fwclose( cscalc );
		
		if( i == 2 && idx->h->fsize != 0x40000 )
			printf( "\nWARNING: BIOS file isn't %d bytes long!\n", 0x40000 );
		
		/* See if this is a hardware magic code? */
		if( ( strcmp( idx->h->fn, "k" ) == 0 ) && idx->h->fsize == 20 )
		{
			lseek( fd, 0, SEEK_SET );
			if( read( fd, fhead + 0x3f, 20 ) != 20 )
			{
				perror( "read" );
				return( 1 );
			}
		}
		
		cur += idx->h->hsize;
		close( fd );
		
		printf( "." );
		fflush( stdout );
	}
	printf( " Done!\n" );
	
	printf( "Building for machine type: %02x %02x %02x %02x\n",
	        fhead[0x3f], fhead[0x40], fhead[0x41], fhead[0x42] );
	
	/* Two 0-bytes to indicate the end of the index. */
	cur += 2;
	
	/* Weird padding... */
	pad_base = cur;
	
	printf( "Calculating file offsets...\n" );
	for( idx = idxstart; idx; idx = idx->next )
	{
		cur += pad( cur, 4, pad_base );
		idx->h->offset = cur;
		cur += idx->h->fsize;
	}
	
	/* Obviously, the final checksum should be padded on
	   an image-boundary again. */
	cur += pad( cur, 4, 0 );
	
	/* Add four bytes for the checksum. */
	cur += 4;
	printf( "Expected image size: %d\n", (int) cur );
	
	printf( "Now creating image headers and index... " );
	fflush( stdout );
	fw = fwstart( argv[1] );
	if( fw == NULL )
	{
		perror( "fwstart" );
		return( 1 );
	}
	
	/* Put the name of the BIOS image in the header. */
	strncpy( fhead + 0x37, basename( argv[2] ), 8 );
	
	/* The image size. */
	int32 = cvt32( cur );
	memcpy( fhead + 0x13, &int32, 4 );
	
	/* Write the image header. */
	fwwrite( fw, fhead, sizeof( fhead ) );
	
	for( idx = idxstart; idx; idx = idx->next )
	{
		/* Save this one now, we don't want to use it in swapped byte order. */
		int size = idx->h->hsize;
		
		verify_offset( fw->fd, idx->idx_offset );
		
		cvtheader( idx->h );
		fwwrite( fw, idx->h, size );
		cvtheader( idx->h );
	}
	
	/* Two 0-bytes to indicate the end of the index. */
	i = 0;
	fwwrite( fw, &i, 2 );
	
	printf( "Done!\n" );
	
	printf( "Writing the files...\n" );
	for( idx = idxstart; idx; idx = idx->next )
	{
		char rdbuf[BUFSIZE];
		int n;
		
		printf( "  %s\n", idx->h->fn );
		
		/* Since we opened this same file a few moments ago, let's assume it can't go wrong. */
		fd = open( idx->realfile, O_RDONLY );
		
		/* Try to start every file at a 4-byte boundary. */
		fwpad( fw, 4, pad_base );
		
		verify_offset( fw->fd, idx->h->offset );
		
		while( ( n = read( fd, rdbuf, BUFSIZE ) ) > 0 )
		{
			if( fwwrite( fw, rdbuf, n ) <= 0 )
			{
				perror( "fwwrite" );
				return( 1 );
			}
		}
		
		close( fd );
	}
	
	fwpad( fw, 4, 0 );
	
	int32 = fwcs( fw );
	int32 = cvt32( int32 );
	fwwrite( fw, &int32, 4 );
	
	verify_offset( fw->fd, cur );
	
	/* This is actually not very likely to go wrong... */
	if( fwcs( fw ) == 0 )
	{
		printf( "End checksum of file is 0, good!\n" );
	}
	else
	{
		fprintf( stderr, "WARNING: The file checksum is not right!\n" );
	}
	
	fwclose( fw );
	
	return( 0 );
}

struct fwfile *fwstart( char *fn )
{
	struct fwfile *fw;
	
	/* Using calloc because it gives zeroed mem. */
	fw = calloc( 1, sizeof( struct fwfile ) );
	fw->fd = open( fn, O_RDWR | O_CREAT | O_TRUNC, 0644 );
	fw->cs = 0xfffe1000;
	
	if( fw->fd < 0 )
	{
		free( fw );
		return( NULL );
	}
	
	return( fw );
}

int fwwrite( struct fwfile *fw, void *data, int size )
{
	if( write( fw->fd, data, size ) != size )
		return( -1 );
	
	/* If the checksum buffer isn't empty, try to empty it first. */
	if( fw->cslen != 0 )
	{
		if( size < ( 4 - fw->cslen ) )
		{
			memcpy( fw->csbuf.byte + fw->cslen, data, size );
			fw->cslen += size;
			return( size );
		}
		memcpy( fw->csbuf.byte + fw->cslen, data, ( 4 - fw->cslen ) );
		fw->cs -= cvt32( fw->csbuf.val );
		data += ( 4 - fw->cslen );
		size -= ( 4 - fw->cslen );
		fw->cslen = 0;
	}
	
	while( size >= 4 )
	{
		memcpy( fw->csbuf.byte, data, 4 );
		fw->cs -= cvt32( fw->csbuf.val );
		data += 4;
		size -= 4;
	}
	
	if( size > 0 )
	{
		fw->csbuf.val = 0;
		memcpy( fw->csbuf.byte, data, size );
		fw->cslen = size;
	}
	
	return( 1 );
}

int fwpad( struct fwfile *fw, int align, off_t pad_base )
{
	int padlen;
	char padding[align];
	
	padlen = pad( lseek( fw->fd, 0, SEEK_CUR ), align, pad_base );
	if( padlen == 0 )
		return( 0 );
	
	memset( padding, 0, padlen );
	
	/* Hurray for holes in files! :-) */
	if( fwwrite( fw, padding, padlen ) == padlen )
		return( padlen );
	else
		return( -1 );
}

u_int32_t fwcs( struct fwfile *fw )
{
	if( fw->cslen != 0 )
		return( fw->cs - fw->csbuf.val );
	else
		return( fw->cs );
}

void fwclose( struct fwfile *fw )
{
	close( fw->fd );
	free( fw );
}

int pad( off_t offset, int align, off_t pad_base )
{
	return( ( align - ( ( offset - pad_base ) % align ) ) % align );
}

char *basename( char *fn )
{
	char *base = fn;
	
	while( *fn )
	{
		if( fn[0] == '/' && fn[1] && fn[1] != '/' )
			base = fn + 1;
		
		fn ++;
	}
	
	return( base );
}

void verify_offset( int fd, off_t expect )
{
	off_t cur;
	
	if( ( cur = lseek( fd, 0, SEEK_CUR ) ) != expect )
	{
		fprintf( stderr, "BUG: Something went wrong! Current offset: 0x%x, expected offset: 0x%x\n",
		                 (int) cur, (int) expect );
		exit( 1 );
	}
}
