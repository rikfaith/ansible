#!/usr/bin/perl
#
# This script extracts the header bytes of an original format, needed by fwpack
# Copyright (C) 2005  Wilmer van der Gaast <wilmer@gaast.net>
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the second version of the GNU
# General Public License as published by the Free Software
# Foundation.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#

@imgs = <*.WYE *.CPQ *.BIN *.wye *.cpq *.bin>;
if( scalar( @ARGV ) >= 1 )
{
	$fn = $ARGV[0];
}
elsif( scalar( @imgs ) == 0 )
{
	print( 'Hmm, can\'t find any possible firmware bundle file. Please pass one as an' . "\n" .
	       'argument or copy it to this directory.' . "\n" );
	exit( 1 );
}
elsif( scalar( @imgs ) > 1 )
{
	print( 'Found the following firmware bundles:' . "\n" .
	       join( ' ', @imgs ) . "\n" .
	       'Which one should be used to copy the headers?' . "\n" );
	chomp( $fn = <STDIN> );
}
else
{
	$fn = $imgs[0];
}

open( IMG, '<', $fn ) or die( 'Can\'t open input file ' . $fn );
$n = sysread( IMG, $head, 0x59 );
if( substr( $head, 3, 4 ) ne 'BndL' )
{
	print( 'Couldn\'t find bundle signature, maybe this is a NetXfer image? ' );
	sysseek( IMG, 0x48200, "SEEK_SET" );
	$n = sysread( IMG, $head, 0x59 );
	if( substr( $head, 3, 4 ) eq 'BndL' )
	{
		print( 'Yes, it is.' . "\n" );
		print( 'Don\'t forget to save the NetXfer bootstrap! See README for more information.' . "\n" );
	}
	else
	{
		print( 'No...' . "\n" );
		print( STDERR 'This is not a bundle file, can\'t continue.' . "\n" );
		exit 1;
	}
}
close( IMG );

if( ord( substr( $head, 0xf, 1 ) ) == 0 )
{
	print( STDERR 'Hmm, that looks like an add-on bundle file!' . "\n" );
	exit 1;
}

## Let's just set these to something bogus, fwpack is supposed to fill them in.
substr( $head, 0x13, 4 ) = pack( 'cccc', 0xaa, 0xaa, 0xaa, 0xaa );
substr( $head, 0x37, 8 ) = pack( 'cccccccc', 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa, 0xaa );
@head = split( '', $head );

open( FWHEAD, '>', 'fwhead.h' ) or die( 'Can\'t open output file fwhead.h' );
print( FWHEAD '/* Auto-generated from ' . $fn . ' */' . "\n" );
print( FWHEAD 'u_int8_t fhead[0x59] = { ' );
for $i ( 0 .. ( scalar( @head ) - 1 ) )
{
	printf( FWHEAD '0x%02x', ord $head[$i] );
	if( $i < ( scalar( @head ) - 1 ) )
	{
		print( FWHEAD ',' );
	}
	if( ( $i % 16 ) == 15 )
	{
		print( FWHEAD "\n" . ( ' ' x 25 ) );
	}
	else
	{
		print( FWHEAD ' ' );
	}
}
print( FWHEAD '};' . "\n" );
close( FWHEAD );

print( 'fwhead.h successfully created' . "\n" );
