/*
    A small tool to read/edit Wyse WinTerm firmware upgrade/add-on images
    Copyright (C) 2006  Wilmer van der Gaast <wilmer@gaast.net>
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the second version of the GNU
    General Public License as published by the Free Software
    Foundation.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "fwstruct.h"

#define BUFSIZE 512
#define NETXFER_SIZE 0x48200

int main( int argc, char *argv[] )
{
	struct index *idx = NULL;
	char bundle_sig[4];
	int fd, netxfer;
	
	structcheck();
	
	if( argc < 3 )
	{
		fprintf( stderr, "fwextract - Read/Edit WYSE Winterm firmware bundles\n"
		                 "\n"
		                 "Syntax: %s <file> extract - Extract all files\n"
		                 "        %s <file> list - List contents\n"
		                 "        %s <file> insert <file> <slot> - Replace <slot> in archive with <file>\n",
		                 argv[0], argv[0], argv[0] );
		return 1;
	}
	
	fd = open( argv[1], O_RDONLY );
	if( fd < 0 )
	{
		perror( "open" );
		return 1;
	}
	
	lseek( fd, 3, SEEK_SET );
	if( read( fd, bundle_sig, 4 ) != 4 )
	{
		perror( "read" );
		return 1;
	}
	
	if( strncmp( bundle_sig, "BndL", 4 ) == 0 )
	{
		netxfer = 0;
	}
	else
	{
		lseek( fd, NETXFER_SIZE + 3, SEEK_SET );
		if( read( fd, bundle_sig, 4 ) != 4 )
		{
			perror( "read" );
			return 1;
		}
		
		if( strncmp( bundle_sig, "BndL", 4 ) == 0 )
		{
			printf( "This seems to be a NetXfer image, skipping the NetXfer bootstrap.\n" );
			netxfer = 1;
		}
		else
		{
			fprintf( stderr, "This doesn't look like a bundle.\n" );
			return 1;
		}
	}
	
	lseek( fd, netxfer * NETXFER_SIZE + 0x59, SEEK_SET );
	
	printf( "%-8s  %-8s  %-8s  %-6s  %-8s  %-8s  %-s\n",
	        "Offset", "Size", "Checksum", "SysFlg", "BiosFlag", "Time", "Filename" );
	
	while( 1 )
	{
		struct header *head;
		struct index *tmp;
		off_t offset;
		
		head = malloc( sizeof( struct header ) );
		
		offset = lseek( fd, 0, SEEK_CUR );
		if( read( fd, head, sizeof( struct header ) ) != sizeof( struct header ) )
		{
			perror( "read" );
			return 1;
		}
		cvtheader( head );
		
		/* End of index? */
		if( head->hsize == 0 )
			break;
		
		head = realloc( head, head->hsize + 1 );
		head->fn[head->fnlen] = 0;
		if( read( fd, head->fn, head->fnlen ) != head->fnlen )
		{
			perror( "read" );
			return 1;
		}
		
		printf( "%08x  %08x  %08x  %02x%02x%02x  %08x  %08x  %s\n",
		        head->offset, head->fsize, head->checksum, head->sys_flag[0],
		        head->sys_flag[1], head->sys_flag[2], head->bios_flag, head->time, head->fn );
		
		/* Remember that here the new file gets inserted at the
		   beginning of the list, so the whole list will be in
		   reversed order. The rest of the code might break if you
		   change this... */
		tmp = malloc( sizeof( struct index ) );
		tmp->h = head;
		tmp->next = idx;
		tmp->idx_offset = offset;
		idx = tmp;
	}
	
	if( strcmp( argv[2], "list" ) == 0 )
	{
		/* Do nothing */
	}
	else if( strcmp( argv[2], "insert" ) == 0 )
	{
#if BYTE_ORDER != BIG_ENDIAN
		struct index *tmp;
		struct stat src_info;
		unsigned int slot_cs, arch_cs, buf;
		int sfd, size;
		
		/* Warning: This code is "reasonably" dirty. :-) */
		
		if( argc < 5 )
		{
			fprintf( stderr, "Not enough arguments\n" );
			return 1;
		}
		
		if( netxfer )
		{
			fprintf( stderr, "Insert method not implemented for NetXfer images.\n" );
			return 1;
		}
		
		/* Find the slot */
		for( tmp = idx; tmp; tmp = tmp->next )
			if( strcmp( tmp->h->fn, argv[4] ) == 0 )
				break;
		
		if( tmp == NULL )
		{
			fprintf( stderr, "Slot does not exist\n" );
			return 1;
		}
		
		/* Open the file to be inserted */
		if( ( sfd = open( argv[3], O_RDONLY ) ) == -1 )
		{
			perror( "open" );
			return 1;
		}
		
		/* Check if sizes are okay */
		fstat( sfd, &src_info );
		if( tmp->h->fsize < src_info.st_size )
		{
			fprintf( stderr, "Can't insert file, slot is too small\n" );
			return 1;
		}
		
		/* To recalculate the new total-checksum, get the current one
		   and "remove" the existing file from it. */
		lseek( fd, -4, SEEK_END );
		read( fd, &arch_cs, 4 );
		
		/* Note that the checksums are per-word and these things aren't
		   necessarily word-aligned, so we have to handle this correctly. */
		lseek( fd, tmp->h->offset & ~3, SEEK_SET );
		for( size = src_info.st_size + ( tmp->h->offset & 3 ); size > 0; size -= 4 )
		{
			read( fd, &buf, 4 );
			arch_cs += buf;
		}
		
		/* Also "remove" the index entry from the checksum. */
		lseek( fd, tmp->idx_offset & ~3, SEEK_SET );
		for( size = tmp->h->fsize + ( tmp->h->fsize & 3 ); size > 0; size -= 4 )
		{
			read( fd, &buf, 4 );
			arch_cs += buf;
		}
		
		/* Oh yes, we want to write now... */
		close( fd );
		if( ( fd = open( argv[1], O_RDWR ) ) < 0 )
		{
			perror( "open" );
			return 1;
		}
		lseek( fd, tmp->h->offset, SEEK_SET );
		
		/* We're doing this in small 4-byte blocks. This is slow, but
		   it's more convenient because of the checkum calculation. */
		slot_cs = 0xFFFE1000;
		while( 1 )
		{
			unsigned int n;
			
			buf = 0;
			n = read( sfd, &buf, 4 );
			
			if( n == 0 )
				break;
			
			slot_cs -= buf;
			// arch_cs -= buf;
			write( fd, &buf, 4 );
		}
		
		/* Write the new slot checksum */
		tmp->h->checksum = slot_cs;
		tmp->h->fsize = src_info.st_size;
		lseek( fd, tmp->idx_offset, SEEK_SET );
		write( fd, tmp->h, tmp->h->fsize );
		
		/* "Add" the new contents to the checksum */
		lseek( fd, tmp->h->offset & ~3, SEEK_SET );
		for( size = src_info.st_size + ( tmp->h->offset & 3 ); size > 0; size -= 4 )
		{
			read( fd, &buf, 4 );
			arch_cs -= buf;
		}
		
		/* Don't forget the index entry, it also changed. */
		lseek( fd, tmp->idx_offset & ~3, SEEK_SET );
		for( size = tmp->h->fsize + ( tmp->h->fsize & 3 ); size > 0; size -= 4 )
		{
			read( fd, &buf, 4 );
			arch_cs -= buf;
		}
		
		/* Write the new archive checksum */
		lseek( fd, -4, SEEK_END );
		write( fd, &arch_cs, 4 );
#else
		fprintf( stderr, "Big-endian version doesn't support inserting, sorry.\n" );
#endif
	}
	else
	{
		while( idx ) /* Default action: We're extracting */
		{
			char buf[BUFSIZE];
			int len, toread, ofd;
			
			lseek( fd, netxfer * NETXFER_SIZE + idx->h->offset, SEEK_SET );
			len = idx->h->fsize;
			
			ofd = open( idx->h->fn, O_WRONLY | O_CREAT | O_EXCL, 0644 );
			if( ofd < 0 )
			{
				if( errno == EEXIST )
				{
					printf( "Warning: File already exists: %s\n", idx->h->fn );
					idx = idx->next;
					continue;
				}
				else
				{
					perror( "open" );
					return 1;
				}
			}
			
			while( len > 0 )
			{
				toread = len > BUFSIZE ? BUFSIZE : len;
				
				if( read( fd, buf, toread ) != toread )
				{
					perror( "read" );
					return 1;
				}
				
				if( write( ofd, buf, toread ) != toread )
				{
					perror( "write" );
					return 1;
				}
				
				len -= toread;
			}
			
			close( ofd );
			
			idx = idx->next;
		}
	}
	
	return 0;
}
