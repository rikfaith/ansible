/*
    A small tool to calculate Wyse WinTerm firmware image checksums
    Copyright (C) 2005  Wilmer van der Gaast <wilmer@gaast.net>
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the second version of the GNU
    General Public License as published by the Free Software
    Foundation.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

#if BYTE_ORDER == BIG_ENDIAN
#define cvt32(x) ((((x)&0xff)<<24) | (((x)&0xff00)<<8) | (((x)&0xff0000)>>8) | (((x)&0xff000000)>>24))
#else
#define cvt32(x) (x)
#endif

int main( int argc, char *argv[] )
{
	unsigned int checksum = 0xFFFE1000;
	unsigned int tmp;
	int fd;
	
	if( argc < 2 )
	{
		fprintf( stderr, "Invalid number of arguments!\n" );
		return( 1 );
	}
	
	fd = open( argv[1], O_RDONLY );
	if( fd < 0 )
	{
		perror( "open" );
		return( 1 );
	}
	
	while( read( fd, &tmp, 4 ) > 0 )
	{
		checksum -= cvt32( tmp );
		tmp = 0;
	}
	
	printf( "%08x\n", checksum );
	
	return( 0 );
}
