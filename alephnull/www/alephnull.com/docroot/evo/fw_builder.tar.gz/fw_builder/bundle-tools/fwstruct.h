/*
    Contains some structures used by fwpack and fwextract
    Copyright (C) 2005  Wilmer van der Gaast <wilmer@gaast.net>
    
    This program is free software; you can redistribute it and/or
    modify it under the terms of the second version of the GNU
    General Public License as published by the Free Software
    Foundation.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#pragma pack(1)

struct header
{
	u_int16_t hsize;		/* Confusing: hsize == header size */
	u_int8_t fnlen;
	u_int32_t bios_flag;
	u_int32_t offset;
	u_int32_t fsize;		/* file/contents size */
	u_int32_t time;
	u_int32_t checksum;
	u_int8_t sys_flag[3];
	char fn[0];
};

struct index
{
	struct header *h;
	struct index *next;
	off_t idx_offset;
	char *realfile;
};

#if BYTE_ORDER == BIG_ENDIAN
#define cvt32(x) ((((x)&0xff)<<24) | (((x)&0xff00)<<8) | (((x)&0xff0000)>>8) | (((x)&0xff000000)>>24))
#define cvt16(x) ((((x)&0xff)<< 8) | (((x)&0xff00)>>8))
#else
#define cvt32(x) (x)
#define cvt16(x) (x)
#endif

void cvtheader( struct header *h )
{
#if BYTE_ORDER == BIG_ENDIAN
	h->hsize = cvt16( h->hsize );
	h->bios_flag = cvt32( h->bios_flag );
	h->offset = cvt32( h->offset );
	h->fsize = cvt32( h->fsize );
	h->time = cvt32( h->time );
	h->checksum = cvt32( h->checksum );
#endif
}

void structcheck( void )
{
	unsigned int test = 1;
	
	if( ( *((char*)&test) == 1 && BYTE_ORDER == BIG_ENDIAN ) || ( *((char*)&test) == 0 && BYTE_ORDER == LITTLE_ENDIAN ) )
	{
		fprintf( stderr, "Program compiled for wrong byte order.\n" );
		exit( 1 );
	}
	
	if( sizeof( struct header ) != 26 )
	{
		fprintf( stderr, "sizeof(struct header) must be 26, does your compiler understand #pragma pack?\n" );
		exit( 1 );
	}
}
