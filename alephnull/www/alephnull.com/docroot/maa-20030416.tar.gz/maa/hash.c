/* hash.c -- 
 * Created: Mon Jul  5 13:21:48 1999 by faith@dict.org
 * Copyright 1999, 2000, 2002, 2003 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: hash.c,v 1.19 2003/01/02 20:06:24 faith Exp $
 *
 * Based on linear hashing from:
 *     Larson, Per-Ake.  Dynamic Hash Tables.  CACM 31(4): April 1988,
 *     pp. 446-457.
 *
 * Hash function based on:
 *     Hanson, David R. C Interfaces and Implementations: Techniques for
 *     Creating Reusable Software.  Reading, Massachusetts: Addison-Wesley,
 *     1997.  Chapter 3, pp. 39-41.
 * 
 */

#include "maaP.h"

typedef struct maaHashBucketS {
    const void            *key;
    const void            *datum;
    unsigned long         hash;
    struct maaHashBucketS *next;
} *maaHashBucketT;

typedef struct maaHashSegmentS {
               maaHashBucketT            bucket[MAA_HASH_BUCKET_COUNT];
} *maaHashSegmentT;

struct maaHashS {
    unsigned long             magic;
    maaHashHashT              hash;
    maaHashCompareT           compare;
    unsigned long             segment_count;
    unsigned long             bucket_count;
    unsigned long             bucket_limit;
    unsigned long             bucket_next;
    unsigned long             bucket_max;
    
    unsigned long             expansion_count;
    unsigned long             contraction_count;
    unsigned long             element_count;
    unsigned long             retrieval_count;
    unsigned long             hit_count;
    unsigned long             miss_count;
    maaHashSegmentT           segment[MAA_HASH_SEGMENT_COUNT];
};

static maaBlockT     _maaHashBlockBucket;
static maaBlockT     _maaHashBlockSegment;
static int           _maaHashBlockInUse;

CHECK_FUNCTION(_maaHashCheck, maaHashT, MAA_HASH_MAGIC)

static __inline__ void _maaHashCheckKey(const void *key)
{
    if (!key) maaFatal(__FUNCTION__, "Null key\n");
}

static unsigned long _maaHashHash(const void *key)
{
    static unsigned long table[256];
    static int           initialized = 0;
    const unsigned char  *pt;
    unsigned long        hash = 0;

    if (!initialized) {
	maaRandomT r;
	int        i;

	r = maaRandomCreate(MAA_RANDOM_ALT2, MAA_RANDOM_UNIFORM);
	for (i = 0; i < 256; i++) table[i] = maaRandom(r);
	maaRandomDestroy(r);
	++initialized;
    }

    for (pt = key; *pt; pt++) hash  ^= table[(unsigned char)*pt];

    return hash;
}
				/* FIXME */
static int _maaHashCompare(const void *key1, const void *key2)
{
    return strcmp(key1, key2);
}

static void _maaHashAllocSegment(maaHashT table)
{
    if (++table->segment_count >= MAA_HASH_SEGMENT_COUNT)
	maaInternal(__FUNCTION__,
		    "Segment count = %lu (> %u)\n",
		    table->segment_count,
		    MAA_HASH_SEGMENT_COUNT);

    table->segment[table->segment_count-1]
	= (_maaHashBlockSegment
	   ? maaBlockAllocZ(_maaHashBlockSegment)
	   : maaAllocZ(sizeof(*table->segment[0])));
    table->bucket_max += MAA_HASH_BUCKET_COUNT;
}

static void _maaHashFreeSegment(maaHashT table)
{
    int             i;
    maaHashBucketT  b;
    maaHashBucketT  next;
    maaHashSegmentT s;

    if (!table->segment_count)
	maaInternal(__FUNCTION__, "No more segments left\n");
    
    --table->segment_count;
    
    
    s = table->segment[table->segment_count];
    if (!s)
	maaInternal(__FUNCTION__,
		    "Segment %lu is NULL\n", table->segment_count);
		
    for (i = 0; i < MAA_HASH_BUCKET_COUNT; i++) {
	for (b = s->bucket[i]; b; b = next) {
	    next = b->next;
	    if (_maaHashBlockBucket) maaBlockFree(_maaHashBlockBucket, b);
	    else                     maaFree(b);
	}
    }
    if (_maaHashBlockSegment) maaBlockFree(_maaHashBlockSegment, s);
    else                      maaFree(s);
    
    table->segment[table->segment_count] = NULL;
    table->bucket_max -= MAA_HASH_BUCKET_COUNT;
}

maaHashT maaHashCreate(maaHashHashT hash, maaHashCompareT compare)
{
    maaHashT table = maaAllocZ(sizeof(*table));

    table->magic             = MAA_HASH_MAGIC;
    table->hash              = hash    ? hash    : _maaHashHash;
    table->compare           = compare ? compare : _maaHashCompare;
    table->segment_count     = 0;
    table->bucket_count      = MAA_HASH_MIN_BUCKETS;
    table->bucket_limit      = 2 * table->bucket_count;
    table->bucket_next       = 0;
    table->bucket_max        = 0;
    
    table->expansion_count   = 0;
    table->contraction_count = 0;
    table->element_count     = 0;
    table->retrieval_count   = 0;
    table->hit_count         = 0;
    table->miss_count        = 0;

    if (MAA_USE_BLOCK) {
	if (!_maaHashBlockBucket)
	    _maaHashBlockBucket
		= maaBlockCreate(sizeof(struct maaHashBucketS));
	if (!_maaHashBlockSegment)
	    _maaHashBlockSegment
		= maaBlockCreate(sizeof(struct maaHashSegmentS));
	++_maaHashBlockInUse;
    }

    _maaHashAllocSegment(table);
    
    return table;
}

unsigned long maaHashDestroy(maaHashT table)
{
    unsigned long i;
    unsigned long count;
    unsigned long ret;

    _maaHashCheck(table);
    
    for (i = 0, count = table->segment_count; i < count; i++) {
	_maaHashFreeSegment(table);
    }
    ret = table->magic = ~MAA_HASH_MAGIC;
    maaFree(table);
    
    if (MAA_USE_BLOCK && !--_maaHashBlockInUse) {
	if (_maaHashBlockBucket)  maaBlockDestroy(_maaHashBlockBucket);
	if (_maaHashBlockSegment) maaBlockDestroy(_maaHashBlockSegment);
	_maaHashBlockBucket  = NULL;
	_maaHashBlockSegment = NULL;
    }
    return ret;
}

static maaHashBucketT *_maaHashGetBucket(maaHashT table, unsigned long hash)
{
    unsigned long segment;
    unsigned long bucket;

    bucket   = hash & (table->bucket_limit - 1);
    if (bucket >= table->bucket_count)
	bucket = hash & (table->bucket_limit / 2 - 1);
    segment  = bucket / MAA_HASH_BUCKET_COUNT;

#if 0
    printf("%lx in %lu/%lu\n", hash, segment, bucket);
#endif
    return &table->segment[segment]->bucket[bucket & MAA_HASH_BUCKET_MASK];
}

void *maaHashLookup(maaHashT table, const void *key)
{
    maaHashBucketT  *head;
    maaHashBucketT  bucket;
    maaHashBucketT  prev = NULL;
    unsigned long   hash;

    _maaHashCheck(table);
    _maaHashCheckKey(key);

    hash = table->hash(key);
    head = _maaHashGetBucket(table, hash);

    ++table->retrieval_count;
    
    for (bucket = *head; bucket; bucket = bucket->next) {
	if (!table->compare(bucket->key, key)) {
	    if (prev) {
				/* Reorganize list */
		prev->next   = bucket->next;
		bucket->next = *head;
		*head        = bucket;
	    } else {
		++table->hit_count;
	    }
	    return (void *)bucket->datum; /* Discard const */
	}
	prev = bucket;
    }

    ++table->miss_count;
    return NULL;
}

unsigned long maaHashLookupUL(maaHashT table, const void *key)
{
    void *retval = maaHashLookup(table, key);
    return (unsigned long)retval;
}

static void _maaHashExpand(maaHashT table)
{
    unsigned long  old_segment;
    unsigned long  old_bucket;
    unsigned long  old_absolute;
    unsigned long  new_segment;
    unsigned long  new_bucket;
    unsigned long  new_absolute;
    unsigned long  absolute;
    maaHashBucketT *old_b;
    maaHashBucketT *new_b;
    maaHashBucketT b;
    maaHashBucketT next;
    maaHashBucketT prev = NULL;
    
    ++table->bucket_count;
    if (table->bucket_count > table->bucket_max) _maaHashAllocSegment(table);
    if (table->bucket_count > table->bucket_max)
	maaInternal(__FUNCTION__, "count = %lu, max = %lu\n",
		    table->bucket_count, table->bucket_max);
    
    old_segment  = table->bucket_next        / MAA_HASH_BUCKET_COUNT;
    old_bucket   = table->bucket_next        & MAA_HASH_BUCKET_MASK;
    old_absolute = old_segment * MAA_HASH_BUCKET_COUNT + old_bucket;
    old_b        = &table->segment[old_segment]->bucket[old_bucket];
    
    new_segment  = (table->bucket_count - 1) / MAA_HASH_BUCKET_COUNT;
    new_bucket   = (table->bucket_count - 1) & MAA_HASH_BUCKET_MASK;
    new_absolute = new_segment * MAA_HASH_BUCKET_COUNT + new_bucket;
    new_b        = &table->segment[new_segment]->bucket[new_bucket];

#if 0
    printf("\nExpand from %lu/%lu to %lu/%lu"
	   " (cnt = %lu, next = %lu, limit = %lu, max= %lu, ld = %.2f)\n",
	   old_segment, old_bucket,
	   new_segment, new_bucket,
	   table->bucket_count,
	   table->bucket_next,
	   table->bucket_limit,
	   table->bucket_max,
	   (double)table->element_count / table->bucket_count);
#endif
    
    for (b = *old_b; b; b = next) {
	next = b->next;
	absolute = b->hash & (table->bucket_limit - 1);
	if (absolute != old_absolute) {
#if 0
	    printf("Moving %lx from %lu/%lu to %lu/%lu (%lu)\n",
		   b->hash, old_segment, old_bucket, new_segment, new_bucket,
		   b->hash & (table->bucket_limit - 1));
#endif
	    if (absolute != new_absolute)
		maaInternal(__FUNCTION__,
			    "Mismatch (%lu, %lu)\n", absolute, new_absolute);
	    if (prev) {
		prev->next = b->next;
	    } else {
		*old_b = b->next;
	    }
	    b->next = *new_b;
	    *new_b  = b;
	} else {
	    prev = b;
	}
    }

    ++table->bucket_next;
    if (table->bucket_next >= table->bucket_limit/2) {
	table->bucket_next   = 0;
	table->bucket_limit *= 2;
    }
    
    ++table->expansion_count;
}

static void _maaHashContract(maaHashT table)
{
    unsigned long  old_segment;
    unsigned long  old_bucket;
    unsigned long  old_absolute;
    unsigned long  new_segment;
    unsigned long  new_bucket;
    unsigned long  new_absolute;
    maaHashBucketT *old_b;
    maaHashBucketT *new_b;
    maaHashBucketT b;
    maaHashBucketT next;

    if (!table->bucket_count--)
	maaInternal(__FUNCTION__, "%ld buckets\n", table->bucket_count);
    
    if (table->bucket_count > table->bucket_max)
	maaInternal(__FUNCTION__, "count = %lu, max = %lu\n",
		    table->bucket_count, table->bucket_max);
    
    if (!table->bucket_next) {
	table->bucket_limit /= 2;
	table->bucket_next   = table->bucket_limit / 2;
    }
    --table->bucket_next;
    
    old_segment  = table->bucket_count / MAA_HASH_BUCKET_COUNT;
    old_bucket   = table->bucket_count & MAA_HASH_BUCKET_MASK;
    old_absolute = old_segment * MAA_HASH_BUCKET_COUNT + old_bucket;
    old_b        = &table->segment[old_segment]->bucket[old_bucket];
    
    new_segment  = table->bucket_next  / MAA_HASH_BUCKET_COUNT;
    new_bucket   = table->bucket_next  & MAA_HASH_BUCKET_MASK;
    new_absolute = new_segment * MAA_HASH_BUCKET_COUNT + new_bucket;
    new_b        = &table->segment[new_segment]->bucket[new_bucket];

#if 0
    printf("\nContract from %lu/%lu to %lu/%lu"
	   " (cnt = %lu, next = %lu, limit = %lu, max= %lu, ld = %.2f)\n",
	   old_segment, old_bucket,
	   new_segment, new_bucket,
	   table->bucket_count,
	   table->bucket_next,
	   table->bucket_limit,
	   table->bucket_max,
	   (double)table->element_count / table->bucket_count);
#endif
    
    for (b = *old_b; b; b = next) {
#if 0
	printf("Moving %lx from %lu/%lu to %lu/%lu (%lu)\n",
	       b->hash, old_segment, old_bucket, new_segment, new_bucket,
	       b->hash & (table->bucket_limit - 1));
#endif
	next = b->next;
	b->next = *new_b;
	*new_b  = b;
    }
    *old_b = NULL;

    ++table->contraction_count;
}

int maaHashInsert(maaHashT table, const void *key, const void *datum)
{
    maaHashBucketT  *head;
    maaHashBucketT  bucket;
    maaHashBucketT  b;
    unsigned long   hash;
    int             retcode = 0;

    _maaHashCheck(table);
    _maaHashCheckKey(key);

    while ((double)table->element_count / (double)table->bucket_count
	   > MAA_HASH_BUCKET_LOAD + MAA_HASH_BUCKET_MARK)
	_maaHashExpand(table);

    hash = table->hash(key);
    head = _maaHashGetBucket(table, hash);

				/* Check for existing key */
    for (bucket = *head; bucket; bucket = bucket->next)
	if (!table->compare(bucket->key, key)) {
            bucket->datum = datum;
            retcode = 1;
        }

    if (!retcode) {
        b        = (_maaHashBlockBucket
                    ? maaBlockAlloc(_maaHashBlockBucket)
                    : maaAlloc(sizeof(*b)));
        b->key   = key;
        b->datum = datum;
        b->hash  = hash;
        b->next  = *head;
        *head    = b;
    
        ++table->element_count;
    }

    return retcode;
}

int maaHashInsertUL(maaHashT table, const void *key, unsigned long datum)
{
    return maaHashInsert(table, key, (const void *)datum);
}

int maaHashDelete(maaHashT table, const void *key)
{
    maaHashBucketT  prev = NULL;
    maaHashBucketT  *head;
    maaHashBucketT  bucket;
    unsigned long   hash;

    _maaHashCheck(table);
    _maaHashCheckKey(key);

    while ((double)table->element_count / (double)table->bucket_count
	   < MAA_HASH_BUCKET_LOAD - MAA_HASH_BUCKET_MARK
	   && table->bucket_count > MAA_HASH_MIN_BUCKETS) {
	    _maaHashContract(table);
    }
    
    hash = table->hash(key);
    head = _maaHashGetBucket(table, hash);
    
    for (bucket = *head; bucket; bucket = bucket->next) {
	if (!table->compare(bucket->key, key)) {
	    if (prev) prev->next = bucket->next;
	    else      *head = bucket->next;
	    if (_maaHashBlockBucket) maaBlockFree(_maaHashBlockBucket, bucket);
	    else                     maaFree(bucket);
	    --table->element_count;
	    return 0;
	}
	prev = bucket;
    }

    return 1;
}

unsigned long maaHashItems(maaHashT table)
{
    return table->element_count;
}

int maaHashPrintStats(maaHashT table, FILE *str, int flags)
{
    unsigned long   i, j;
    maaHashBucketT  bucket;
    unsigned long   len;
    unsigned long   bucket_use      = 0;
    unsigned long   length_max      = 0;
    unsigned long   singleton_count = 0;

    for (i = 0; i < table->segment_count; i++)
	for (j = 0; j < MAA_HASH_BUCKET_COUNT; j++) {
	    len = 0;
	    for (bucket = table->segment[i]->bucket[j];
		 bucket;
		 bucket = bucket->next) ++len;
	    
	    if (len)              ++bucket_use;
	    if (len > length_max) length_max = len;
	    if (len == 1)         ++singleton_count;
	}

    if (flags) {
	fprintf(str,
		"Sgs Bckts  BLim BNext Expan Contr Elems BUsed "
		"  Max  Sngl  Retr   Hit  Miss  Ld\n");
    }
    fprintf(str,
	    "%3lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu %5lu"
	    " %3.1f\n",
	    table->segment_count,
	    table->bucket_count,
	    table->bucket_limit,
	    table->bucket_next,
	    table->expansion_count,
	    table->contraction_count,
	    table->element_count,
	    bucket_use,
	    length_max,
	    singleton_count,
	    table->retrieval_count,
	    table->hit_count,
	    table->miss_count,
	    (double)table->element_count / (double)table->bucket_count);
    
    return 0;
}

void maaHashIteratorInit(maaHashT table, maaIteratorT *iter)
{
    _maaHashCheck(table);
    iter->a = table;
    iter->b = NULL;
    iter->c = 0;
    iter->d = 0;
    for (iter->c = 0; iter->c < table->segment_count; iter->c++) {
	for (iter->d = 0; iter->d < MAA_HASH_BUCKET_COUNT; iter->d++) {
	    if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return;
	}
    }
}

int maaHashIteratorNext(maaIteratorT *iter)
{
    maaHashT table = iter->a;
    
    _maaHashCheck(table);

    if (iter->c >= table->segment_count) return 0;
    if (iter->b) iter->b = ((maaHashBucketT)iter->b)->next;
    if (iter->b) return 1;
    for (++iter->d; iter->d < MAA_HASH_BUCKET_COUNT; iter->d++) {
	if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return 1;
    }
    for (++iter->c; iter->c < table->segment_count; iter->c++) {
	for (iter->d = 0; iter->d < MAA_HASH_BUCKET_COUNT; iter->d++) {
	    if ((iter->b = table->segment[iter->c]->bucket[iter->d])) return 1;
	}
    }
    iter->b = NULL;
    return 0;
}

void *maaHashIteratorKey(maaIteratorT *iter)
{
    maaHashT table = iter->a;
    
    _maaHashCheck(table);
    if (!iter->b) return NULL;
    return (void *)((maaHashBucketT)iter->b)->key; /* Discard const */
}

void *maaHashIteratorDatum(maaIteratorT *iter)
{
    maaHashT table = iter->a;
    
    _maaHashCheck(table);
    if (!iter->b) return NULL;
    return (void *)((maaHashBucketT)iter->b)->datum; /* Discard const */
}

unsigned long maaHashIteratorDatumUL(maaIteratorT *iter)
{
    void *retval = maaHashIteratorDatum(iter);
    return (unsigned long)retval;
}
