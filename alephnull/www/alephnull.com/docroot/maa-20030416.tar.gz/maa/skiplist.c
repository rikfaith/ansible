/* skiplist.c -- 
 * Created: Mon Jul  5 13:23:07 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: skiplist.c,v 1.5 2000/08/20 13:16:19 faith Exp $
 * 
 */

#include "maaP.h"

typedef struct maaSkipListElementS {
    const void                 *key;
    const void                 *datum;
    int                        levels;
    struct maaSkipListElementS *forward[1];
} *maaSkipListElementT;

struct maaSkipListS {
    unsigned long              magic;
    int                        level;
    unsigned int               size; /* number of data */
    maaSkipListElementT        head;
    maaSkipListCompareT        compare;
    maaRandomT                 prng;
    unsigned long              level_count[MAA_SKIPLIST_MAXLEVEL + 1];
};

CHECK_FUNCTION(_maaSkipListCheck, maaSkipListT, MAA_SKIPLIST_MAGIC)

static int _maaSkipListCompare(const void *key1, const void *key2)
{
    return strcmp(key1, key2);
}

static maaSkipListElementT _maaSkipListElementCreate(maaSkipListT list,
						     int max_level,
						     const void *key,
						     const void *datum)
{
    maaSkipListElementT e;
    
    if (max_level > MAA_SKIPLIST_MAXLEVEL)
	maaInternal(__FUNCTION__, "level %d > %d\n",
		    max_level, MAA_SKIPLIST_MAXLEVEL);

    e          = maaAllocZ(sizeof(*e) + (max_level * sizeof(e->forward[0])));
    e->key     = key;
    e->datum   = datum;
    e->levels  = max_level + 1;
    ++list->level_count[max_level];
    return e;
}

maaSkipListT maaSkipListCreate(maaSkipListCompareT compare)
{
    maaSkipListT list = maaAllocZ(sizeof(*list));

    list->magic   = MAA_SKIPLIST_MAGIC;
    list->level   = 0;
    list->size    = 0;
    list->head    = _maaSkipListElementCreate(list,
					      MAA_SKIPLIST_MAXLEVEL,
					      NULL,
					      NULL);
    list->compare = compare ? compare : _maaSkipListCompare;
    list->prng    = maaRandomCreate(MAA_RANDOM_STD, MAA_RANDOM_UNIFORM);

    return list;
}

unsigned long maaSkipListDestroy(maaSkipListT list)
{
    maaSkipListElementT e;
    maaSkipListElementT next;
    unsigned long       ret;

    _maaSkipListCheck(list);
    for (e = list->head; e; e = next) {
	next = e->forward[0];
	maaFree(e);
    }
    ret = list->magic = ~MAA_SKIPLIST_MAGIC;
    maaRandomDestroy(list->prng);
    maaFree(list);
    return ret;
}

static maaSkipListElementT _maaSkipListLocate(maaSkipListT list,
					      const void *key,
					      maaSkipListElementT *update)
{
    int                 i;
    maaSkipListElementT e, pt, prev = NULL;

    for (i = list->level, e = list->head; i >= 0; i--) {
	while ((pt = e->forward[i])
	       && pt != prev && list->compare(pt->key, key) < 0)
	    e = pt;
	prev = pt;
	if (update) update[i] = e;
    }
    return e->forward[0];
}

void *maaSkipListLookup(maaSkipListT list, const void *key)
{
    maaSkipListElementT e;
    
    _maaSkipListCheck(list);
    e = _maaSkipListLocate(list, key, NULL);
    if (e && !list->compare(e->key, key))
	return (void *)e->datum; /* Discard const */
    return NULL;
}

int maaSkipListInsert(maaSkipListT list, const void *key, const void *datum)
{
    maaSkipListElementT update[MAA_SKIPLIST_MAXLEVEL+1];
    maaSkipListElementT e;
    int                 level = 0;
    int                 i;
    
    _maaSkipListCheck(list);
    e = _maaSkipListLocate(list, key, &update[0]);
    if (e && !list->compare(e->key, key)) return 1; /* FIXME */

    while (level < MAA_SKIPLIST_MAXLEVEL && (maaRandom(list->prng) & 0x01))
	++level;
    
    if (level > list->level) {
	level         = ++list->level;
	update[level] = list->head;
    }

    e = _maaSkipListElementCreate(list, level, key, datum);

    for (i = level; i >= 0; i--) {
	e->forward[i]         = update[i]->forward[i];
	update[i]->forward[i] = e;
    }

    ++list->size;
    return 0;
}

int maaSkipListDelete(maaSkipListT list, const void *key)
{
    maaSkipListElementT update[MAA_SKIPLIST_MAXLEVEL+1];
    maaSkipListElementT e;
    int                 i;
    
    _maaSkipListCheck(list);
    e = _maaSkipListLocate(list, key, &update[0]);
    if (!e || list->compare(e->key, key)) return 1;

    for (i = 0; i <= list->level; i++)
	if (update[i]->forward[i] == e) update[i]->forward[i] = e->forward[i];

    maaFree(e);
    --list->size;
    return 0;
}

int maaSkipListPrintStats(maaSkipListT list, FILE *str, int flags)
{
    int i;

    if (flags) {
	for (i = 0; i <= MAA_SKIPLIST_MAXLEVEL; i++)
	    fprintf(str, "%5d", i);
	fprintf(str, "\n");
    }
    for (i = 0; i <= list->level; i++)
	fprintf(str, "%5lu", list->level_count[i]);
    fprintf(str, "\n");
    return 0;
}

void maaSkipListIteratorInit(maaSkipListT list, maaIteratorT *iter)
{
    _maaSkipListCheck(list);
    iter->a = list;
    iter->b = list->head->forward[0];
}

int maaSkipListIteratorNext(maaIteratorT *iter)
{
    maaSkipListT list = iter->a;

    _maaSkipListCheck(list);
    if (!iter->b) return 0;
    iter->b = ((maaSkipListElementT)iter->b)->forward[0];
    return iter->b != NULL;
}

void *maaSkipListIteratorKey(maaIteratorT *iter)
{
    maaSkipListT list = iter->a;

    _maaSkipListCheck(list);
    if (!iter->b) return NULL;
    return (void *)((maaSkipListElementT)iter->b)->key;	/* Discard const */
}

void *maaSkipListIteratorDatum(maaIteratorT *iter)
{
    maaSkipListT list = iter->a;

    _maaSkipListCheck(list);
    if (!iter->b) return NULL;
    return (void *)((maaSkipListElementT)iter->b)->datum; /* Discard const */
}
