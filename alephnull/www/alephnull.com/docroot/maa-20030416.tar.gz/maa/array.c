/* array.c -- 
 * Created: Mon Jul  5 13:20:30 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: array.c,v 1.6 1999/12/23 11:12:09 faith Exp $
 *
 * Arenas would improve speed a lot, I believe. -T
 *
 * My justification for not implementing some of the helper operations
 * as calls of the major ones is there is arguably a justifiable speed
 * gain. (I'll do some performance tests later) -T
 *
 * Note that while the user sees the stack as growing down, it really
 * grows up. That is, the top of the stack to us is depth sk->depth-1,
 * but the top of the stack to them is depth 0. -T
 *
 */

#include "maaP.h"

/* internal data structures */
typedef const void * maaStackItemT;

typedef struct maaStackInternalT {
    int depth;
    maaStackItemT *data;
} maaStackInternalT;

/* internal functions */
void maaStack_reverse(maaStackItemT *data, unsigned int i, unsigned int j);


/* "depth 0" functions ;-) */

/*
 * Create an empty stack.
 *
 * Returns: the newly allocated stack object.
 */
maaStackT maaStackCreate(void)
{
     maaStackInternalT *sk;

     sk = (maaStackInternalT *)maaAlloc(sizeof(maaStackInternalT));
     sk->depth = 0;
     sk->data = NULL;

     return (maaStackT)sk;
}

/*
 * Free all the allocated memory associated with a stack.
 *
 * Params: stack - the stack to destroy.
 */
void maaStackDestroy(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if (sk->data) maaFree(sk->data);
     maaFree(sk);
     return;
}

/*
 * Push an item onto the stack.
 *
 * Note: we don't do any real verification of the integrity of
 *       the stack here, remember that.
 *
 * Params: stack - the stack to operate on.
 *         datum - the datum to push onto stack.
 */
void maaStackPush(maaStackT stack, const void *datum)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");

     /* Note: do we want a special case for depth == 0? */
     sk->depth++;
     sk->data = (maaStackItemT *)maaRealloc((void *)sk->data,
					    sk->depth*sizeof(maaStackItemT));

     /* Invariant: sk->data != NULL,
      *            sk->data points to sk->depth*sizeof(maaStackItemT) bytes
      * 	               of memory accessable to us */
     sk->data[sk->depth-1] = (maaStackItemT)datum;

     return;
}

/*
 * Pop an item off the stack.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item formerly on the top of the stack.
 */
const void *maaStackPop(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;
     maaStackItemT ret;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     if(sk->depth == 0) maaFatal(__FUNCTION__, "Empty stack\n");

     /* Invariant: sk->data != NULL,
      *            sk->data points to sk->depth*sizeof(maaStackItemT) bytes
      * 	               of memory accessable to us */
     ret = sk->data[sk->depth-1];

     /* Note: do we want a special case for depth == 0? */
     sk->depth--;
     sk->data = (maaStackItemT *)maaRealloc((void *)sk->data,
					    sk->depth*sizeof(maaStackItemT));

     return (const void *)ret;
}

/*
 * Return the value on the top of the stack (without affecting the
 * stack). Top == most recently pushed.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item at depth 0.
 */
const void *maaStackTop(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     if(sk->depth == 0) maaFatal(__FUNCTION__, "Empty stack\n");

     /* Invariant: sk->data != NULL,
      *            sk->data points to sk->depth*sizeof(maaStackItemT) bytes
      * 	               of memory accessable to us */
     return (const void *)sk->data[sk->depth-1];
}


/*
 * Picks an item from a stack.
 *
 * Params: stack - the stack to pick from.
 *         n     - the depth of the item to pick, 0 being the top of the
 *                 stack. (most recently pushed)
 *
 * Returns: the item picked.
 */
const void *maaStackPick(maaStackT stack, unsigned int n)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     if(n > sk->depth-1) maaFatal(__FUNCTION__, "Picked too deep\n");

     /* Invariant: sk->data != NULL,
      *            sk->data points to sk->depth*sizeof(maaStackItemT) bytes
      * 	               of memory accessable to us
      *            n < sk->depth-1
      */
     return (const void *)sk->data[sk->depth-1-n];
}


/*
 * Get the depth of a stack. Note that this means the number of
 * items - calling this on a stack with one item will return 1,
 * but that item is at depth 0.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the number of items on the stack.
 */
unsigned int maaStackDepth(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     return sk->depth;
}


/*
 * Swap the top two items on the stack.
 *
 * Params: stack - the stack to operate on.
 */
void maaStackSwap(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;
     maaStackItemT tmp;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     if(sk->depth < 2) maaFatal(__FUNCTION__, "Not enough items to swap\n");

     tmp = sk->data[sk->depth-1];
     sk->data[sk->depth-1] = sk->data[sk->depth-2];
     sk->data[sk->depth-2] = tmp;

     return;
}


/*
 * Rotate the stack, "upwards" n times. That is, if you have the
 * numbers 1, 2, and 3 on the stack (with 1 being depth 0, that is,
 * the top), and you rotate the stack by one, your stack will have 2
 * on top (depth 0), 1 on the bottom (depth 2), and 3 in the middle.
 * Use a negative number to rotate "downwards".
 *
 * Params: stack - the stack to operate on.
 *         n     - the number of times to rotate.
 */
void maaStackRotate(maaStackT stack, signed int n)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");

     if(n < 0)
     {
	  n = -n;
	  if(n > sk->depth) n %= sk->depth;
	  n = sk->depth-n;
     }

     if(n > sk->depth) n %= sk->depth;

     /* This catches n being 0 both initially and mod sk->depth */
     if(n == 0) return;

     /* Invariant: 0 <= n <= sk->depth */
     maaStack_reverse(sk->data, 0, sk->depth-1);
     maaStack_reverse(sk->data, n, sk->depth-1);
     maaStack_reverse(sk->data, 0, n-1);

     return;
}


/*
 * Duplicate the item on the top of the stack.
 *
 * Params: stack - the stack to operate on.
 */
void maaStackDup(maaStackT stack)
{
     maaStackInternalT *sk = (maaStackInternalT *)stack;

     if(sk == NULL) maaFatal(__FUNCTION__, "Passed a NULL\n");
     if(sk->depth == 0) maaFatal(__FUNCTION__, "Empty stack\n");

     sk->depth++;
     sk->data = (maaStackItemT *)maaRealloc((void *)sk->data,
					    sk->depth*sizeof(maaStackItemT));

     /* Invariant: sk->data != NULL,
      *            sk->data points to sk->depth*sizeof(maaStackItemT) bytes
      * 	               of memory accessable to us */
     sk->data[sk->depth-1] = sk->data[sk->depth-2];

     return;
}


/* internal */

/* <hidden>
 * Reverse the order of set of items.
 */
void maaStack_reverse(maaStackItemT *data, unsigned int i, unsigned int j)
{
     maaStackItemT t;

     if(data == NULL) return;

     for(; i < j; i++, j--) {
	  t = data[i];
	  data[i] = data[j];
	  data[j] = t;
     }

     return;
}
