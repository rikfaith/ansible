/* test-tree.c -- 
 * Created: Sun Aug  6 10:19:28 2000 by faith@dict.org
 * Copyright 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * This program comes with ABSOLUTELY NO WARRANTY.
 *
 * $Id: test-tree.c,v 1.3 2000/12/28 20:35:54 faith Exp $
 *
 */

#define OBJECTTYPE     maaTreeT
#define OBJECTCREATE0  maaTreeCreate
#define OBJECTDESTROY  maaTreeDestroyTree

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int testlocal(void)
{
    maaTreeT      t, t2, t5;
    maaTreeT      n;
    int           pos;
    maaIteratorT  iter;
    int           retcode;
    
				/* Test with single node */
    test("L", "Inorder 1");
    t = maaTreeCreate(1);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    retcode = maaTreeIteratorNext(&iter);
    if (retcode != 1) fail("a");
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    retcode = maaTreeIteratorNext(&iter);
    if (retcode != 0) fail("b");
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra 2");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Preorder 1");
    t = maaTreeCreate(1);
    maaTreeIteratorInit(t, &iter, MAA_TREE_PREORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    retcode = maaTreeIteratorNext(&iter);
    if (retcode != 0) fail("a");
    ok(0);
    end(t);

    test("L", "Postorder 1");
    t = maaTreeCreate(1);
    maaTreeIteratorInit(t, &iter, MAA_TREE_POSTORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    retcode = maaTreeIteratorNext(&iter);
    if (retcode != 0) fail("a");
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);
    
				/* Test with two nodes */
    test("L", "Inorder 2a");
    t = maaTreeMake(1, maaTreeCreate(2), 0);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Inorder 2b (append)");
    t = maaTreeMake(1, 0);
    maaTreeAppend(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Inorder 2c (insert after)");
    t = maaTreeMake(1, 0);
    maaTreeInsertAfter(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Inorder 2d (insert last)");
    t = maaTreeMake(1, 0);
    maaTreeInsertLast(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Inorder 2e (insert last)");
    t = maaTreeMake(1, 0);
    maaTreeInsertLast(t, maaTreeCreate(2));
    maaTreeInsertLast(t, maaTreeCreate(3));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 3) fail("pre 3");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 3) fail("post 3");
    ok(0);
    maaTreePrint(t, NULL);
    end(t);

    test("L", "Preorder 2a");
    t = maaTreeMake(1, maaTreeCreate(2), 0);
    maaTreeIteratorInit(t, &iter, MAA_TREE_PREORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Preorder 2b (append)");
    t = maaTreeMake(1, 0);
    maaTreeAppend(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_PREORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Preorder 2c (insert after)");
    t = maaTreeMake(1, 0);
    maaTreeInsertAfter(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_PREORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != -1 || maaTreeId(n) != 1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != -1 || maaTreeId(n) != 2) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2a");
    t = maaTreeMake(1, maaTreeCreate(2), 0);
    maaTreeIteratorInit(t, &iter, MAA_TREE_POSTORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2b (append)");
    t = maaTreeMake(1, 0);
    maaTreeAppend(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_POSTORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

    test("L", "Postorder 2c (insert after)");
    t = maaTreeMake(1, 0);
    maaTreeInsertAfter(t, maaTreeCreate(2));
    maaTreeIteratorInit(t, &iter, MAA_TREE_POSTORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n != t || pos != 1 || maaTreeId(n) != 1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (pos != 1 || maaTreeId(n) != 2) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    end(t);

				/* Test with multiple nodes */
    test("L", "Inorder 3a");
    t = maaTreeMake(1,
		    t2 = maaTreeMake(2, maaTreeCreate(3), maaTreeCreate(4), 0),
		    t5 = maaTreeCreate(5),
		    0);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 2 || pos != -1) fail("pre 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 3 || pos != -1) fail("pre 3");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 3 || pos !=  1) fail("post 3");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 4 || pos != -1) fail("pre 4");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 4 || pos !=  1) fail("post 4");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 2 || pos !=  1) fail("post 2");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);

    test("L", "DestroyTree");
    maaTreeDestroyTree(t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);

    test("L", "Prepend");
    t2 = maaTreeMake(20, maaTreeCreate(30), maaTreeCreate(40), 0);
    maaTreePrepend(t, t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);

    test("L", "Disconnect");
    maaTreeDisconnect(t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);
    maaTreePrint(t2, NULL);

    test("L", "Append");
    maaTreeAppend(t, t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);

    test("L", "Disconnect");
    maaTreeDisconnect(t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Insert Before");
    t2 = maaTreeMake(20, maaTreeCreate(30), maaTreeCreate(40), 0);
    maaTreeInsertBefore(t5, t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Disconnect");
    maaTreeDisconnect(t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "Insert After");
    maaTreeInsertAfter(t5, t2);
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertFirst 1");
    maaTreeInsertFirst(t5, maaTreeCreate(6));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos != -1) fail("pre 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos !=  1) fail("post 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertFirst 2");
    maaTreeInsertFirst(t2, maaTreeCreate(7));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos != -1) fail("pre 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos !=  1) fail("post 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos != -1) fail("pre 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos !=  1) fail("post 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertLast 1");
    maaTreeInsertLast(t2, maaTreeCreate(8));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos != -1) fail("pre 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos !=  1) fail("post 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos != -1) fail("pre 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos !=  1) fail("post 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 8 || pos != -1) fail("pre 8");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 8 || pos !=  1) fail("post 8");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);

    test("L", "InsertLast 2");
    maaTreeInsertLast(t5, maaTreeCreate(9));
    maaTreeIteratorInit(t, &iter, MAA_TREE_INORDER);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos != -1) fail("pre 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos != -1) fail("pre 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 7 || pos !=  1) fail("post 7");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos != -1) fail("pre 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 6 || pos !=  1) fail("post 6");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos != -1) fail("pre 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 5 || pos !=  1) fail("post 5");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos != -1) fail("pre 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos != -1) fail("pre 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 30 || pos !=  1) fail("post 30");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos != -1) fail("pre 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 40 || pos !=  1) fail("post 40");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 20 || pos !=  1) fail("post 20");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 8 || pos != -1) fail("pre 8");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 8 || pos !=  1) fail("post 8");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 9 || pos != -1) fail("pre 9");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 9 || pos !=  1) fail("post 9");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (maaTreeId(n) != 1 || pos !=  1) fail("post 1");
    maaTreeIteratorNext(&iter);
    n = maaTreeIteratorDatum(&iter, &pos);
    if (n) fail("extra");
    ok(0);
    maaTreePrint(t, NULL);

    test("L", "String 1");
    if (maaTreeHasString(t)) fail("has");
    maaTreeSetString(t, "foo");
    if (!maaTreeHasString(t)) fail("not has");
    if (strcmp(maaTreeString(t), "foo")) fail(maaTreeString(t));
    ok(0);

    test("L", "Integer 1");
    if (maaTreeHasInteger(t)) fail("has");
    maaTreeSetInteger(t, 31415);
    if (!maaTreeHasInteger(t)) fail("not has");
    if (maaTreeInteger(t) != 31415) fail(0);
    ok(0);

    test("L", "String 2");
    if (!maaTreeHasString(t)) fail("not has a");
    maaTreeSetString(t, "foobar");
    if (!maaTreeHasString(t)) fail("not has b");
    if (strcmp(maaTreeString(t), "foobar")) fail(maaTreeString(t));
    ok(0);

    test("L", "Integer 2");
    if (maaTreeHasInteger(t2)) fail("has");
    maaTreeSetInteger(t2, 5);
    if (!maaTreeHasInteger(t2)) fail("not has");
    if (maaTreeInteger(t2) != 5) fail(0);
    ok(0);

    test("L", "Real");
    if (maaTreeHasReal(t5)) fail("has");
    maaTreeSetReal(t5, 3.1);
    if (!maaTreeHasReal(t5)) fail("not has");
    if (maaTreeReal(t5) != 3.1) fail(0);
    ok(0);

    test("L", "Attrib 1");
    maaTreeSetAttrib(t5, "attrib1", "val1");
    if (strcmp("val1", maaTreeAttrib(t5, "attrib1"))) fail(0);
    ok(0);

    maaTreePrint(t, NULL);
    end(t);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
