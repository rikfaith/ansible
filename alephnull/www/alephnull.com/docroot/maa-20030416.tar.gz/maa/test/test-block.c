/* test-block.c -- 
 * Created: Fri Dec 24 07:02:22 1999 by faith@acm.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-block.c,v 1.4 2000/08/20 13:16:20 faith Exp $
 * 
 */

#define OBJECTTYPE     maaBlockT
#define OBJECTCREATE64 maaBlockCreate
#define OBJECTDESTROY  maaBlockDestroy
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

static int testlocal(void)
{
    maaBlockT     a;
    void          *chunk0;
    void          *chunk1;
    char          buf[2048];
    int           i;
    
    test("L", "Allocate");
    a = maaBlockCreate(33);
    if (!a) fail("create");
    chunk0 = maaBlockAlloc(a);
    if (!chunk0) fail("chunk0");
    chunk1 = maaBlockAlloc(a);
    if (!chunk1) fail("chunk1");
    if (chunk0 == chunk1) fail("same");
    ok(0);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);
    
    test("L", "Allocate Zero-Filled");
    a = maaBlockCreate(1024);
    if (!a) fail("create");
    chunk0 = maaBlockAllocZ(a);
    if (!chunk0) fail("chunk0");
    chunk1 = maaBlockAllocZ(a);
    if (!chunk1) fail("chunk1");
    if (chunk0 == chunk1) fail("same");
    for (i = 0; i < 1024; i++) {
	if (((char *)chunk0)[i]) {
	    sprintf(buf, "chunk0 %d = 0x%02x", i,
		    ((unsigned char *)chunk0)[i]);
	    fail(buf);
	}
	if (((char *)chunk1)[i]) {
	    sprintf(buf, "chunk1 %d = 0x%02x", i,
		    ((unsigned char *)chunk1)[i]);
	    fail(buf);
	}
    }
    ok(0);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);

    test("L", "Reuse");
    a = maaBlockCreate(64);
    if (!a) fail("create");
    chunk0 = maaBlockAlloc(a);
    if (!chunk0) fail("chunk0");
    maaBlockFree(a, chunk0);
    chunk1 = maaBlockAlloc(a);
    if (!chunk1) fail("chunk1");
    /*@i1@*/ if (chunk0 != chunk1) fail("different");
    ok(0);
    maaBlockFree(a, chunk1);
    end(a);

    test("L", "Alignment 0");
    a = maaBlockCreate(0);
    chunk0 = maaBlockAlloc(a);
    chunk1 = maaBlockAlloc(a);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);
    
    test("L", "Alignment 1");
    a = maaBlockCreate(1);
    chunk0 = maaBlockAlloc(a);
    chunk1 = maaBlockAlloc(a);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);
    
    test("L", "Alignment 33");
    a = maaBlockCreate(33);
    chunk0 = maaBlockAlloc(a);
    chunk1 = maaBlockAlloc(a);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);
    
    test("L", "Alignment 2040");
    a = maaBlockCreate(2040);
    chunk0 = maaBlockAlloc(a);
    chunk1 = maaBlockAlloc(a);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    maaBlockFree(a, chunk0);
    maaBlockFree(a, chunk1);
    end(a);
    
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
