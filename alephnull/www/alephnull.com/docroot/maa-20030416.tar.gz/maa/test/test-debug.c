/* test-debug.c -- 
 * Created: Sun Jul 23 10:52:23 2000 by faith@dict.org
 * Copyright 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * $Id: test-debug.c,v 1.2 2000/08/20 13:16:20 faith Exp $
 *
 */

#define OBJECTTYPE     maaFlagT
#define OBJECTCREATEV  maaFlagCreate
#define OBJECTDESTROY  maaFlagDestroy

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define FLAG0 0x00000002
#define FLAG1 0x00000001
#define FLAG2 0x40000010
#define FLAG3 0x80000100
#define FLAG4 0xc0001000

static int testlocal(void)
{
    maaFlagT       flags;
    const char     *name;
    
    test("L", "Register/name");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    name = maaFlagName(flags, FLAG1);
    if (strcmp("one", name)) fail(name);
    ok(0);
    end(flags);

    test("L", "Not set");
    flags = maaFlagCreate();
    if (maaFlagTest(flags, FLAG1)) fail("1 set");
    if (maaFlagTest(flags, FLAG2)) fail("2 set");
    if (maaFlagTest(flags, FLAG3)) fail("3 set");
    if (maaFlagTest(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Set");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    if (maaFlagTest(flags, FLAG1)) fail("1 set");
    maaFlagSet(flags, FLAG1);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set");
    if (maaFlagTest(flags, FLAG2)) fail("2 set");
    if (maaFlagTest(flags, FLAG3)) fail("3 set");
    if (maaFlagTest(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Set 2");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagRegister(flags, FLAG2, "two");
    if (maaFlagTest(flags, FLAG1)) fail("1 set");
    maaFlagSet(flags, FLAG1);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set a");
    if (maaFlagTest(flags, FLAG2)) fail("2 set a");
    if (maaFlagTest(flags, FLAG3)) fail("3 set a");
    if (maaFlagTest(flags, FLAG4)) fail("4 set a");
    maaFlagSet(flags, FLAG2);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set b");
    if (!maaFlagTest(flags, FLAG2)) fail("2 not set b");
    if (maaFlagTest(flags, FLAG3)) fail("3 set b");
    if (maaFlagTest(flags, FLAG4)) fail("4 set b");
    ok(0);
    end(flags);

    test("L", "Set 2 by name");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagRegister(flags, FLAG2, "two");
    if (maaFlagTest(flags, FLAG1)) fail("1 set");
    maaFlagSetByName(flags, "one");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set a");
    if (maaFlagTest(flags, FLAG2)) fail("2 set a");
    if (maaFlagTest(flags, FLAG3)) fail("3 set a");
    if (maaFlagTest(flags, FLAG4)) fail("4 set a");
    maaFlagSetByName(flags, "two");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set b");
    if (!maaFlagTest(flags, FLAG2)) fail("2 not set b");
    if (maaFlagTest(flags, FLAG3)) fail("3 set b");
    if (maaFlagTest(flags, FLAG4)) fail("4 set b");
    ok(0);
    end(flags);

    test("L", "Unset");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagSet(flags, FLAG1);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set");
    maaFlagUnset(flags, FLAG1);
    if (maaFlagTest(flags, FLAG1)) fail("1 set");
    if (maaFlagTest(flags, FLAG2)) fail("2 set");
    if (maaFlagTest(flags, FLAG3)) fail("3 set");
    if (maaFlagTest(flags, FLAG4)) fail("4 set");
    ok(0);
    end(flags);

    test("L", "Unset 2");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagRegister(flags, FLAG2, "two");
    maaFlagSet(flags, FLAG1);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set");
    maaFlagUnset(flags, FLAG1);
    if (maaFlagTest(flags, FLAG1)) fail("1 set a");
    if (maaFlagTest(flags, FLAG2)) fail("2 set a");
    if (maaFlagTest(flags, FLAG3)) fail("3 set a");
    if (maaFlagTest(flags, FLAG4)) fail("4 set a");
    maaFlagSet(flags, FLAG1);
    maaFlagSet(flags, FLAG2);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set b");
    if (!maaFlagTest(flags, FLAG2)) fail("2 not set b");
    if (maaFlagTest(flags, FLAG3)) fail("3 set b");
    if (maaFlagTest(flags, FLAG4)) fail("4 set b");
    maaFlagUnset(flags, FLAG2);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set c");
    if (maaFlagTest(flags, FLAG2)) fail("2 set c");
    if (maaFlagTest(flags, FLAG3)) fail("3 set c");
    if (maaFlagTest(flags, FLAG4)) fail("4 set c");
    maaFlagUnset(flags, FLAG1);
    if (maaFlagTest(flags, FLAG1)) fail("1 set d");
    if (maaFlagTest(flags, FLAG2)) fail("2 set d");
    if (maaFlagTest(flags, FLAG3)) fail("3 set d");
    if (maaFlagTest(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);
    
    test("L", "Unset 2 alt");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagRegister(flags, FLAG0, "zero");
    maaFlagSet(flags, FLAG1);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set");
    maaFlagUnset(flags, FLAG1);
    if (maaFlagTest(flags, FLAG0)) fail("0 set a");
    if (maaFlagTest(flags, FLAG1)) fail("1 set a");
    if (maaFlagTest(flags, FLAG2)) fail("2 set a");
    if (maaFlagTest(flags, FLAG3)) fail("3 set a");
    if (maaFlagTest(flags, FLAG4)) fail("4 set a");
    maaFlagSet(flags, FLAG1);
    maaFlagSet(flags, FLAG0);
    if (!maaFlagTest(flags, FLAG0)) fail("0 not set b");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set b");
    if (maaFlagTest(flags, FLAG2)) fail("2 set b");
    if (maaFlagTest(flags, FLAG3)) fail("3 set b");
    if (maaFlagTest(flags, FLAG4)) fail("4 set b");
    maaFlagUnset(flags, FLAG0);
    if (maaFlagTest(flags, FLAG0)) fail("0 set c");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set c");
    if (maaFlagTest(flags, FLAG2)) fail("2 set c");
    if (maaFlagTest(flags, FLAG3)) fail("3 set c");
    if (maaFlagTest(flags, FLAG4)) fail("4 set c");
    maaFlagUnset(flags, FLAG1);
    if (maaFlagTest(flags, FLAG0)) fail("0 set d");
    if (maaFlagTest(flags, FLAG1)) fail("1 set d");
    if (maaFlagTest(flags, FLAG2)) fail("2 set d");
    if (maaFlagTest(flags, FLAG3)) fail("3 set d");
    if (maaFlagTest(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);
    
    test("L", "Unset 2 by name");
    flags = maaFlagCreate();
    maaFlagRegister(flags, FLAG1, "one");
    maaFlagRegister(flags, FLAG2, "two");
    maaFlagSetByName(flags, "one");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set");
    maaFlagUnsetByName(flags, "one");
    if (maaFlagTest(flags, FLAG1)) fail("1 set a");
    if (maaFlagTest(flags, FLAG2)) fail("2 set a");
    if (maaFlagTest(flags, FLAG3)) fail("3 set a");
    if (maaFlagTest(flags, FLAG4)) fail("4 set a");
    maaFlagSet(flags, FLAG1);
    maaFlagSet(flags, FLAG2);
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set b");
    if (!maaFlagTest(flags, FLAG2)) fail("2 not set b");
    if (maaFlagTest(flags, FLAG3)) fail("3 set b");
    if (maaFlagTest(flags, FLAG4)) fail("4 set b");
    maaFlagUnsetByName(flags, "two");
    if (!maaFlagTest(flags, FLAG1)) fail("1 not set c");
    if (maaFlagTest(flags, FLAG2)) fail("2 set c");
    if (maaFlagTest(flags, FLAG3)) fail("3 set c");
    if (maaFlagTest(flags, FLAG4)) fail("4 set c");
    maaFlagUnsetByName(flags, "one");
    if (maaFlagTest(flags, FLAG1)) fail("1 set d");
    if (maaFlagTest(flags, FLAG2)) fail("2 set d");
    if (maaFlagTest(flags, FLAG3)) fail("3 set d");
    if (maaFlagTest(flags, FLAG4)) fail("4 set d");
    ok(0);
    end(flags);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
