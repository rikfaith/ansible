/* test-avltree.c --
 * Created: Mon Dec 20 23:55:14 1999 by tek@wiw.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 2000 Rickard E. Faith (faith@dict.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * $Id: test-avltree.c,v 1.6 2000/08/20 13:16:20 faith Exp $
 * 
 */

#define OBJECTNAME       "maaAVLTree"
#define OBJECTTYPE       maaAVLTreeT
#define OBJECTCREATE     maaAVLTreeCreate
#define OBJECTDESTROY    maaAVLTreeDestroy
#define OBJECTINSERT     maaAVLTreeInsert
#define OBJECTLOOKUP     maaAVLTreeLookup
#define OBJECTPRINTSTATS maaAVLTreePrintStats
#define OBJECTDELETE     maaAVLTreeDelete
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#define NCASES 421

static int cmp(const void *a, const void *b) {
    if(*(int *)a > *(int *)b)
        return 1;
    else if(*(int *)a < *(int *)b)
        return -1;
    else
        return 0;
}

static int testlocal(void)
{
    OBJECTTYPE    s;
    char          buf[2048];
    int           n[NCASES];
    int           result;
    int           i, j;
    maaRandomT    r;

    for(i = 0; i < NCASES; i++) n[i] = i;

    r = maaRandomCreate(MAA_RANDOM_STD, MAA_RANDOM_UNIFORM);
	
    test("L", "Ascending insert/lookup");
    s = maaAVLTreeCreate(cmp);
    if (!s) fail("create");
    for(i = 0; i < NCASES; i++) {
        maaAVLTreeInsert(s, (const void *)&n[i], (const void *)&n[i]);
	result = *(int *)maaAVLTreeLookup(s, (const void *)&n[i]);
        if (result != n[i]) {
	    sprintf(buf, "%d %d", result, n[i]);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "Random lookup 1");
    for(i = 0; i < 2*NCASES; i++) {
        j = maaRandomRange(r, 0, NCASES-1);
	result = *(int *)maaAVLTreeLookup(s, (const void *)&n[j]);
	if (result != n[j]) {
	    sprintf(buf, "%d %d", result, n[i]);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "Ascending delete");
    for(i = 0; i < NCASES; i++) {
        maaAVLTreeDelete(s, (const void *)&i);
        if (maaAVLTreeLookup(s, (const void *)&i) != NULL) {
	    sprintf(buf, "%d", i);
	    fail(buf);
	}
    }
    ok(0);
    end(s);

    test("L", "Descending insert/lookup");
    s = maaAVLTreeCreate(cmp);
    if (!s) fail("create");
    for(i = NCASES-1; i >= 0; i--) {
        maaAVLTreeInsert(s, (const void *)&n[i], (const void *)&n[i]);
	result = *(int *)maaAVLTreeLookup(s, (const void *)&n[i]);
        if (result != n[i]) {
	    sprintf(buf, "%d %d", result, n[i]);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "Random lookup 2");
    for(i = 0; i < 2*NCASES; i++) {
        j = maaRandomRange(r, 0, NCASES-1);
	result = *(int *)maaAVLTreeLookup(s, (const void *)&n[j]);
	if (result != n[j]) {
	    sprintf(buf, "%d %d", result, n[i]);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "Descending lookup");
    for(i = NCASES-1; i >= 0; i--) {
        maaAVLTreeDelete(s, (const void *)&i);
        if (maaAVLTreeLookup(s, (const void *)&i) != NULL) {
	    sprintf(buf, "%d", i);
	    fail(buf);
	}
    }
    ok(0);
    end(s);

    maaRandomDestroy(r);

    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate()))    return retcode;
	if ((retcode = testlocal()))     return retcode;
	if ((retcode = testcontainer())) return retcode;
    } else {
	if ((retcode = timecontainer())) return retcode;
    }
    
    return EXIT_SUCCESS;
}

/* EOF test-avltree.c */
