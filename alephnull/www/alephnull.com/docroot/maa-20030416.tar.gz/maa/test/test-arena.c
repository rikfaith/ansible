/* test-arena.c -- 
 * Created: Sat Jul 10 08:14:36 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-arena.c,v 1.6 2000/08/20 13:16:20 faith Exp $
 * 
 */

#define OBJECTTYPE       maaArenaT
#define OBJECTCREATE0    maaArenaCreate
#define OBJECTDESTROY    maaArenaDestroy
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

static int testlocal(void)
{
    maaArenaT     a;
    void          *chunk0;
    void          *chunk1;
    char          buf[2048];
    int           i;
    
    test("L", "Clear empty");
    a = maaArenaCreate(0);
    if (!a) fail("create");
    maaArenaClear(a);
    ok(0);
    end(a);
    
    test("L", "Allocate");
    a = maaArenaCreate(0);
    if (!a) fail("create");
    chunk0 = maaArenaAlloc(a, 1024);
    if (!chunk0) fail("chunk0");
    chunk1 = maaArenaAlloc(a, 1024);
    if (!chunk1) fail("chunk1");
    if (chunk0 == chunk1) fail("same");
    ok(0);
    end(a);
    
    test("L", "Allocate Zero-Filled");
    a = maaArenaCreate(0);
    if (!a) fail("create");
    chunk0 = maaArenaAllocZ(a, 1024);
    if (!chunk0) fail("chunk0");
    chunk1 = maaArenaAllocZ(a, 1024);
    if (!chunk1) fail("chunk1");
    if (chunk0 == chunk1) fail("same");
    for (i = 0; i < 1024; i++) {
	sprintf(buf, "chunk0 %d", i);
	if (((char *)chunk0)[i]) fail(buf);
	sprintf(buf, "chunk1 %d", i);
	if (((char *)chunk1)[i]) fail(buf);
    }
    ok(0);
    end(a);
    
    test("L", "String Alignment");
    a = maaArenaCreate(1);
    if (!a) fail("create");
    chunk0 = maaArenaAlloc(a, 33);
    if (!chunk0) fail("chunk0");
    chunk1 = maaArenaAlloc(a, 33);
    if (!chunk1) fail("chunk1");
    if ((unsigned long)chunk0 + 33 != (unsigned long)chunk1) {
	sprintf(buf, "chunk0 0x%08lx; chunk1 0x%08lx; diff %ld\n",
		(unsigned long)chunk0,
		(unsigned long)chunk1,
		(long)chunk1 - (long)chunk0);
	fail(buf);
    }
    ok(0);
    end(a);
    
    test("L", "Clear full");
    a = maaArenaCreate(0);
    if (!a) fail("create");
    chunk0 = maaArenaAlloc(a, 1024);
    if (!chunk0)          fail("chunk0 a");
    chunk1 = maaArenaAlloc(a, 1024);
    if (!chunk1)          fail("chunk1 a");
    if (chunk0 == chunk1) fail("same a");
    maaArenaClear(a);
    chunk0 = maaArenaAlloc(a, 1024);
    if (!chunk0)          fail("chunk0 b");
    chunk1 = maaArenaAlloc(a, 1024);
    if (!chunk1)          fail("chunk1 b");
    if (chunk0 == chunk1) fail("same b");
    ok(0);
    end(a);
    
    test("L", "Alignment 0, 4");
    a = maaArenaCreate(0);
    chunk0 = maaArenaAlloc(a, 4);
    chunk1 = maaArenaAlloc(a, 4);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 0, 33");
    a = maaArenaCreate(0);
    chunk0 = maaArenaAlloc(a, 33);
    chunk1 = maaArenaAlloc(a, 33);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 1, 4");
    a = maaArenaCreate(1);
    chunk0 = maaArenaAlloc(a, 4);
    chunk1 = maaArenaAlloc(a, 4);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 1, 33");
    a = maaArenaCreate(1);
    chunk0 = maaArenaAlloc(a, 33);
    chunk1 = maaArenaAlloc(a, 33);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 33, 4");
    a = maaArenaCreate(33);
    chunk0 = maaArenaAlloc(a, 4);
    chunk1 = maaArenaAlloc(a, 4);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 33, 63");
    a = maaArenaCreate(33);
    chunk0 = maaArenaAlloc(a, 63);
    chunk1 = maaArenaAlloc(a, 63);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
    
    test("L", "Alignment 2040, 33");
    a = maaArenaCreate(2040);
    chunk0 = maaArenaAlloc(a, 33);
    chunk1 = maaArenaAlloc(a, 33);
    ok(0);
    sprintf(buf, "alignment %ld", (long)chunk1 - (long)chunk0);
    info(buf);
    end(a);
        
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate())) return retcode;
	if ((retcode = testlocal()))  return retcode;
    }

    return EXIT_SUCCESS;
}
