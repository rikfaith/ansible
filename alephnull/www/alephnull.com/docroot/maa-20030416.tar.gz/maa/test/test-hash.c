/* test-hash.c -- 
 * Created: Sat Jul 10 12:05:08 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: test-hash.c,v 1.12 2000/08/20 13:16:20 faith Exp $
 * 
 */

#define OBJECTNAME       "maaHash"
#define OBJECTTYPE       maaHashT
#define OBJECTCREATE2    maaHashCreate
#define OBJECTDESTROY    maaHashDestroy
#define OBJECTINSERT     maaHashInsert
#define OBJECTLOOKUP     maaHashLookup
#define OBJECTITERATE    MAA_HASH_ITERATE
#define OBJECTPRINTSTATS maaHashPrintStats
#define OBJECTDELETE     maaHashDelete
#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

int main(int argc, char **argv)
{
    int retcode;
    
    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testcreate()))    return retcode;
	if ((retcode = testcontainer())) return retcode;
    } else {
	if ((retcode = timecontainer())) return retcode;
    }
    
    return EXIT_SUCCESS;
}
