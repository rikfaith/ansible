/* test-base.c -- 
 * Created: Sun Aug 13 10:15:05 2000 by faith@dict.org
 * Copyright 2000 Rickard E. Faith (faith@acm.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * $Id: test-base.c,v 1.1 2000/08/20 13:16:20 faith Exp $
 *
 */

#define OBJECTINFO

#include "standard.h"
#include "maa.h"
#include "common.h"

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

static int sub(const char *name,
	       int base,
	       const char *(*encode)(unsigned long),
	       unsigned long (*decode)(const char *))
{
    const char    *r0, *r1, *pt;
    unsigned long val;
    char          buf[2048];
    unsigned long i;
    char          b[256];
    int           count;

    sprintf(buf, "%s cache 0", name);
    test("L", buf);
    r0 = encode(0);
    r1 = encode(0);
    if (r0 != r1)       fail("pointer");
    if (strcmp(r0, r1)) fail("content");
    ok(0);

    sprintf(buf, "%s cache 2600", name);
    test("L", buf);
    r0 = encode(2600);
    r1 = encode(2600);
    if (r0 != r1)       fail("pointer");
    if (strcmp(r0, r1)) fail("content");
    ok(0);

    test("L", "zero");
    r0 = encode(0);
    if (decode(r0) != 0) fail(r0);
    ok(r0);

    test("L", "one");
    r0 = encode(1);
    if (decode(r0) != 1) fail(r0);
    ok(r0);

    test("L", "base-1");
    r0 = encode(base-1);
    if (decode(r0) != base-1) fail(r0);
    ok(r0);

    test("L", "base");
    r0 = encode(base);
    if (decode(r0) != base) fail(r0);
    ok(r0);

    test("L", "base+1");
    r0 = encode(base+1);
    if (decode(r0) != base+1) fail(r0);
    ok(r0);

    test("L", "unique 1");
    for (i = 0; i < 256; i++) b[i] = 0;
    for (i = 0; i < base; i++) {
	r0 = encode(i);
	b[(unsigned char)*r0] = 1;
    }
    for (i = 0, count = 0; i < 256; i++) count += b[i];
    sprintf(buf, "%d for base%d", count, base);
    if (count != base) fail(buf);
    ok(buf);

    test("L", "unique 2");
    for (i = 0; i < 256; i++) b[i] = 0;
    for (i = 0; i < base * 10; i++) {
	r0 = encode(i);
	for (pt = r0; *pt; pt++) b[(unsigned char)*pt] = 1;
    }
    for (i = 0, count = 0; i < 256; i++) count += b[i];
    sprintf(buf, "%d for base%d", count, base);
    if (count != base) fail(buf);
    ok(buf);

    test("L", "low");
    for (i = 0x00000000UL; i < 0x0000ffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "mid");
    for (i = 0x00ff0000UL; i < 0x00ffffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    test("L", "high");
    for (i = 0xffff0000UL; i < 0xffffffffUL; i++) {
	r0 = encode(i);
	val = decode(r0);
	if (val != i) {
	    sprintf(buf, "'%s' = 0x%08lx != 0x%08lx", r0, val, i);
	    fail(buf);
	}
    }
    ok(0);

    return EXIT_SUCCESS;
}

static int tim(const char *name,
	       int base,
	       const char *(*encode)(unsigned long),
	       unsigned long (*decode)(const char *))
{
    const char    *r0 = encode(0);
    unsigned long val;
    char          buf[2048];
    unsigned long i;
    maaTimerT     t;
    maaTimevalT   tv;
    int           iters;
    int           useconds;

    test("T", "Time setup");
    if (!(t = maaTimerCreate(0))) fail("timer");
    for (iters = 1000, useconds = 0; useconds < 300000;) {
	iters *= 2;
	maaTimerStart(t);
	for (i = 0; i < iters; i++) r0 = encode(i);
	maaTimerStop(t);
	maaTimerGetElapsed(t, &tv);
	useconds = tv.wall.tv_sec * 1000000 + tv.wall.tv_usec;
    };
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);

    test("T", "Encode");
    maaTimerStart(t);
    for (i = 0; i < iters; i++) r0 = encode(i);
    maaTimerStop(t);
    maaTimerGetElapsed(t, &tv);
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [encode]", name,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    test("T", "Decode");
    maaTimerStart(t);
    for (i = 0; i < iters; i++) val = decode(r0);
    maaTimerStop(t);
    maaTimerGetElapsed(t, &tv);
    ok(0);
    sprintf(buf, "%d iters @ %ld.%06ld S",
	    iters, tv.wall.tv_sec, tv.wall.tv_usec);
    info(buf);
    sprintf(buf, ":: %20s %10.1f nS [decode]", name,
	    1000.0*(tv.wall.tv_sec * 1000000.0 + tv.wall.tv_usec)/iters);
    info(buf);

    return EXIT_SUCCESS;
}

static int testlocal(void)
{
    int r;
    
    if ((r = sub("maaBase26", 26, maaBase26Encode, maaBase26Decode))) return r;
    if ((r = sub("maaBase64", 64, maaBase64Encode, maaBase64Decode))) return r;
    if ((r = sub("maaBase85", 85, maaBase85Encode, maaBase85Decode))) return r;
    return EXIT_SUCCESS;
}

static int time_local(void)
{
    int r;
    
    if ((r = tim("maaBase26", 26, maaBase26Encode, maaBase26Decode))) return r;
    if ((r = tim("maaBase64", 64, maaBase64Encode, maaBase64Decode))) return r;
    if ((r = tim("maaBase85", 85, maaBase85Encode, maaBase85Decode))) return r;
    return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
    int retcode;

    maaInit(argv[0]);

    if (argc == 1) {
	if ((retcode = testlocal()))  return retcode;
    } else {
	if ((retcode = time_local()))  return retcode;
    }

    return EXIT_SUCCESS;
}
