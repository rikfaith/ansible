#define MAA_DATE "20021222"
#define MAA_MAJOR 0
#define MAA_MINOR 0
#define MAA_PATCH 4
