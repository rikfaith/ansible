/* atom.c -- 
 * Created: Mon Jul  5 13:31:02 1999 by faith@dict.org
 * Copyright 1999, 2000, 2001, 2002 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: atom.c,v 1.10 2002/12/23 17:05:00 faith Exp $
 * 
 */

#include "maaP.h"

static maaArenaT _maaPool;
static maaBlockT _maaBlock;
static maaHashT  _maaHash;

typedef struct maaAtomKeyS {
    const unsigned char *key;
    int                 length;
} *maaAtomKeyT;

static unsigned long _maaAtomHash(const void *key)
{
    maaAtomKeyT         k   = (maaAtomKeyT)key;
    const unsigned char *pt = k->key;
    unsigned long       h   = 0;
    int                 i;

    for (i = 0; i < k->length; i++)
	h = (h << 1) + (unsigned long)*pt++; /* FIXME */

    return h;
}

static int _maaAtomCompare(const void *key1, const void *key2)
{
    maaAtomKeyT         k1    = (maaAtomKeyT)key1;
    maaAtomKeyT         k2    = (maaAtomKeyT)key2;
    const unsigned char *p1   = k1->key;
    const unsigned char *p2   = k2->key;
    int                 i;

    if (k1->length > k2->length) return -1;
    if (k2->length > k1->length) return +1;

    for (i = 0; i < k1->length; i++, p1++, p2++) {
	if (*p1 > *p2) return -1;
	if (*p1 < *p2) return +1;
    }
    
    return 0;
}

static void _maaAtomInit(void)
{
    if (_maaPool)  maaInternal(__FUNCTION__, "Pool already exists\n");
    if (_maaBlock) maaInternal(__FUNCTION__, "Block already exists\n");
    if (_maaHash)  maaInternal(__FUNCTION__, "Hash table already exists\n");
    _maaPool  = maaArenaCreate(1);
    _maaBlock = maaBlockCreate(sizeof(struct maaAtomKeyS));
    _maaHash  = maaHashCreate(_maaAtomHash, _maaAtomCompare);
}

static const void *_maaAtomNew(const void *datum, int len, int terminate)
{
    struct maaAtomKeyS lookup_key;
    maaAtomKeyT        insert_key;
    const char         *atom;
    unsigned char      *buf;
    
    if (!_maaPool || !_maaHash || !_maaBlock) _maaAtomInit();
    if (terminate) terminate = 1;

				/* Make null terminated datum -- FIXME! */
    buf = maaAlloc(len + 1);
    memcpy(buf, datum, len);
    buf[len] = '\0';

				/* Already in table? */

    lookup_key.key    = buf;
    lookup_key.length = len + terminate;
    if ((atom = maaHashLookup(_maaHash, &lookup_key))) {
	maaFree(buf);
	return atom;
    }

				/* Not in table */
    insert_key                  = maaBlockAlloc(_maaBlock);
    insert_key->length          = len + terminate;
    insert_key->key             = maaArenaAlloc(_maaPool,
						insert_key->length);
    memcpy((char *)insert_key->key, buf, len);
    if (terminate) ((char *)insert_key->key)[len] = '\0';
    maaHashInsert(_maaHash, insert_key, insert_key->key);
    maaFree(buf);
    return insert_key->key;
}

const void *maaAtomNew(const void *datum, int len)
{
    return datum ? _maaAtomNew(datum, len, 0) : NULL;
}

const char *maaAtomString(const char *datum)
{
    return datum ? _maaAtomNew(datum, strlen(datum) + 1, 0) : NULL;
}

const char *maaAtomStringN(const char *datum, int len)
{
    return datum ? _maaAtomNew(datum, len, 1) : NULL;
}

void maaAtomDestroy(void)
{
    if (_maaPool) maaArenaDestroy(_maaPool);
    _maaPool = NULL;
    if (_maaBlock) maaBlockDestroy(_maaBlock);
    _maaBlock = NULL;
    if (_maaHash) maaHashDestroy(_maaHash);
    _maaHash = NULL;
}

