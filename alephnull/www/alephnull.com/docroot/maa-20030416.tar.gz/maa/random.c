/* random.c -- 
 * Created: Mon Jul  5 13:32:00 1999 by faith@dict.org
 * Copyright 1999, 2002 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: random.c,v 1.4 2002/12/23 17:05:00 faith Exp $
 *
 * References
 *
 * [BD76] Carter Bays and S. D. Durham. "Improving a Poor Random Number
 * Generator".  ACM Trans. Math. Softw. 2(1), March 1976, pp. 59-64.
 *
 * [Knuth98] Donald E. Knuth. The Art of Computer Programming.  Volume 2:
 * Seminumerical Algorithms.  3rd ed. Reading, Massachusetts:
 * Addison-Wesley, 1998.
 *
 * [Leva92] Joseph L. Leva.  Algorithm 712: A Normal Random Number Generator.
 * ACM Trans. Math. Softw. 18(4), December 1992, pp. 454-5.
 *
 * [LE88] Pierre L'Ecuyer. "Efficient and Portable Combined Random Number
 * Generators".  CACM 31(6), June 1988, pp. 742-774.
 *
 * [LE90] Pierre L'Ecuyer. "Random Numbers for Simulation". CACM 33(10,
 * October 1990, pp. 85-97.
 *
 * [PM88] Stephen K. Park and Keith W. Miller. "Random Number Generators:
 * Good Ones are Hard to Find". CACM 31(10), October 1988, pp. 1192-1201.
 *
 * [Sch92] Bruce Schneier. "Pseudo-Random Sequence Generator for 32-Bit
 * CPUs".  Dr. Dobb's Journal 17(2), February 1992, pp. 34, 37-38, 40.
 *
 * [PMS93] Stephen K. Park, Keith W. Miller, and Paul K. Stockmeyer.  In
 * "Technical Correspondence: Remarks on Choosing and Implementing Random
 * Number Generators". CACM 36(7), July 1993, pp. 105-110.
 * */

#include "maaP.h"

typedef struct maaRandomMlcgS {
    maaU32T       a;
    maaU32T       m;
    maaU32T       q;		/* m div a */
    maaU32T       r;		/* m mod a */
    maaU32T       seed;
} maaRandomMlcgT;

static maaRandomMlcgT _maaMlcg[] = {
				/* Reference followed by value after 10000
                                   iterations starting with seed = 1. */
    { 16807, 2147483647, 127773,  2836, 1 }, /* [PM88]  1043618065 */
    { 48271, 2147483647,  44488,  3399, 1 }, /* [PMS93]  399268537 */
    { 40014, 2147483563,  53668, 12211, 1 }, /* [LE88]             */
    { 40692, 2147483399,  52774,  3791, 1 }  /* [LE88]             */
};

struct maaRandomS {
    unsigned long      magic;
    maaRandomTypeT     type;
    maaRandomModifierT modifier;
    unsigned long      (*getrnd)(maaRandomT prng);
    unsigned long      (*base)(maaRandomT prng);
    void               (*setseed)(maaRandomT prng,
				  unsigned long seed0,
				  unsigned long seed1);

    unsigned long      max;
    maaRandomMlcgT     *m0;
    maaRandomMlcgT     *m1;

				/* Shuffle support */
    unsigned long      *shuffle;
    unsigned long      shuffle_next;
    
};

CHECK_FUNCTION(_maaRandomCheck, maaRandomT, MAA_RANDOM_MAGIC)

static __inline__ unsigned long _maaRandomMlcg(maaRandomMlcgT *s)
{
    unsigned long  hi;
    unsigned long  lo;

    hi      = s->seed / s->q;
    lo      = s->seed % s->q;
    s->seed = s->a * lo - s->r * hi;
    if (s->seed >= s->m) {
	s->seed += s->m;
	s->seed &= 0xffffffff;	/* Keep 32-bit */
    }

    return s->seed;
}

static unsigned long _maaRandomMlcgRandom(maaRandomT prng)
{
    return _maaRandomMlcg(prng->m0);
}

static void _maaRandomMlcgSeed(maaRandomT prng,
			       unsigned long seed0,
			       unsigned long seed1)
			       
{
    maaRandomMlcgT *s = prng->m0;

    s->seed = seed0 + seed1;
    if (!s->seed || s->seed >= s->m) s->seed = s->m - 1;
}

static unsigned long _maaRandomLongRandom(maaRandomT prng)
{
    unsigned long s1 = _maaRandomMlcg(prng->m0);
    unsigned long s2 = _maaRandomMlcg(prng->m1);
    unsigned long z  = s1 - s2;

    if (!z || z > prng->m0->m) {
	z += prng->m0->m - 1;
	z &= 0xffffffff;
    }
    return z;
}

static void _maaRandomLongSeed(maaRandomT prng,
			       unsigned long seed0,
			       unsigned long seed1)
			       
{
    maaRandomMlcgT *s0 = prng->m0;
    maaRandomMlcgT *s1 = prng->m1;

    s0->seed = seed0;
    if (!s0->seed || s0->seed >= s0->m) s0->seed = s0->m - 1;
    
    s1->seed = seed1;
    if (!s1->seed || s1->seed >= s1->m) s1->seed = s1->m - 1;
}

/* Algorithm from [BD76] as presented in [Knuth98, p. 33].  Knuth suggests
   making the table size equal to the byte size of the machine, and using
   the high-order byte of Y as J.  This simplifies the code.  */
static unsigned long _maaRandomShuffle(maaRandomT prng)
{
    unsigned long j = (prng->shuffle_next & 0xff000000) >> 24;

    prng->shuffle_next = prng->shuffle[j];
    prng->shuffle[j]   = (*prng->base)(prng);
    
    return prng->shuffle_next;
}
static void _maaRandomShuffleInit(maaRandomT prng)
{
    int i;

    prng->getrnd       = _maaRandomShuffle;
    prng->shuffle      = maaAlloc(256 * sizeof(*prng->shuffle));

    for (i = 0; i < 256; i++) prng->shuffle[i] = (*prng->base)(prng);
    prng->shuffle_next = (*prng->base)(prng);
}

maaRandomT maaRandomCreate(maaRandomTypeT type, maaRandomModifierT modifier)
{
    maaRandomT prng = maaAllocZ(sizeof(*prng));

    prng->magic    = MAA_RANDOM_MAGIC;
    prng->type     = type;
    prng->modifier = modifier;
    switch (type) {
    case MAA_RANDOM_STD:
	prng->m0              = &_maaMlcg[0];
	prng->max             = prng->m0->m - 1;
	prng->base            = _maaRandomMlcgRandom;
	prng->setseed         = _maaRandomMlcgSeed;
	break;
    case MAA_RANDOM_ALT0:
	prng->m0              = &_maaMlcg[1];
	prng->max             = prng->m0->m - 1;
	prng->base            = _maaRandomMlcgRandom;
	prng->setseed         = _maaRandomMlcgSeed;
	break;
    case MAA_RANDOM_ALT1:
	prng->m0              = &_maaMlcg[2];
	prng->max             = prng->m0->m - 1;
	prng->base            = _maaRandomMlcgRandom;
	prng->setseed         = _maaRandomMlcgSeed;
	break;
    case MAA_RANDOM_ALT2:
	prng->m0              = &_maaMlcg[3];
	prng->max             = prng->m0->m - 1;
	prng->base            = _maaRandomMlcgRandom;
	prng->setseed         = _maaRandomMlcgSeed;
	break;
    case MAA_RANDOM_LONG:
	prng->m0              = &_maaMlcg[2];
	prng->m1              = &_maaMlcg[3];
	prng->max             = prng->m0->m - 1;
	prng->base            = _maaRandomLongRandom;
	prng->setseed         = _maaRandomLongSeed;
	break;
    }

    if (modifier & MAA_RANDOM_SHUFFLE) _maaRandomShuffleInit(prng);
    else                               prng->getrnd = prng->base;

    return prng;
}

unsigned long maaRandomDestroy(maaRandomT prng)
{
    unsigned long ret;

    _maaRandomCheck(prng);
    ret = prng->magic = ~MAA_RANDOM_MAGIC;
    if (prng->shuffle) maaFree(prng->shuffle);
    maaFree(prng);
    return ret;
}

void maaRandomSeed(maaRandomT prng, unsigned long seed0, unsigned long seed1)
{
    _maaRandomCheck(prng);
    (*prng->setseed)(prng, seed0, seed1);
}

unsigned long maaRandom(maaRandomT prng)
{
    _maaRandomCheck(prng);
    return (*prng->getrnd)(prng);
}

unsigned long maaRandomMax(maaRandomT prng)
{
    _maaRandomCheck(prng);
    return prng->max;
}

unsigned long maaRandomRange(maaRandomT prng,
			     unsigned long min,
			     unsigned long max)
{

    _maaRandomCheck(prng);
    if (min > max) maaInternal(__FUNCTION__, "%lu > %lu\n", min, max);
    return min + (unsigned long)(maaRandomReal(prng) * (max - min + 1));
}

double maaRandomReal(maaRandomT prng)
{
    _maaRandomCheck(prng);
    return (double)prng->getrnd(prng) / ((double)prng->max + 1.0);
}
