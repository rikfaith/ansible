/* tree.c -- 
 * Created: Mon Jul 10 13:43:52 2000 by faith@dict.org
 * Copyright 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: tree.c,v 1.4 2000/12/31 21:03:31 faith Exp $
 * 
 */

#include "maaP.h"

typedef enum {
    MAA_TREE_STRING = 0x0001,
    MAA_TREE_INT    = 0x0002,
    MAA_TREE_REAL   = 0x0004
} maaTreeMaskT;

struct maaTreeS {
    unsigned long   magic;
    int             id;		/* Node id */
    int             head;	/* Non-zero if head of sibling list */
    struct maaTreeS *left;	/* Left sibling */
    struct maaTreeS *right;	/* Right sibling */
    struct maaTreeS *down;	/* Children */
    struct maaTreeS *parent;	/* Parent */
    maaTreeMaskT    attribs;	/* Attributes set */
    const char      *string;	/* Attribute */
    int             integer;	/* Attribute */
    double          real;	/* Attribute */
    maaListT        list;	/* Attribute list */
};

static maaBlockT _maaTreeBlock;

CHECK_FUNCTION(_maaTreeCheck, maaTreeT, MAA_TREE_MAGIC)

maaTreeT maaTreeCreate(int id)
{
    maaTreeT node;

    if (MAA_USE_BLOCK && !_maaTreeBlock)
	_maaTreeBlock = maaBlockCreate(sizeof(*node));

    node        = (_maaTreeBlock
		   ? maaBlockAllocZ(_maaTreeBlock)
		   : maaAllocZ(sizeof(*node)));
    
    node->magic = MAA_TREE_MAGIC;
    node->id    = id;
    node->right = node->left = node;
    node->head  = 1;

    return node;
}

maaTreeT maaTreeMake(int id, ...)
{
    va_list  ap;
    maaTreeT n;
    maaTreeT node;

    node = maaTreeCreate(id);
    va_start(ap, id);
    while ((n = va_arg(ap, maaTreeT))) {
	_maaTreeCheck(n);	/* May fail if no terminating 0 */
	if (n->parent) maaInternal(__FUNCTION__, "Node has parent\n");
	maaTreeAppend(node, n);
    }
    va_end(ap);
    
    return node;
}

unsigned long maaTreeDestroyNode(maaTreeT node)
{
    unsigned long  ret;
    
    _maaTreeCheck(node);

    if (node->down) maaInternal(__FUNCTION__,
				"Attempt to destroy linked node\n");

    if (node->parent && node->parent->down == node)
	node->parent->down = NULL;
    ret      = node->magic = ~MAA_TREE_MAGIC;
    node->id = -node->id;

    if (node->list) {
	maaIteratorT   iter;
	maaTreeAttribT pair;

	MAA_LIST_ITERATE(node->list, iter, pair) maaFree(pair);
	maaListDestroy(node->list);
    }
    
    if (_maaTreeBlock) maaBlockFree(_maaTreeBlock, node);
    else               maaFree(node);
    
    return ret;
}

unsigned long maaTreeDestroyTree(maaTreeT root)
{
    maaTreeT top;
    maaTreeT pt;
    maaTreeT old;
    
    _maaTreeCheck(root);

    top = maaTreeDisconnect(root);
    
    if (!top->down) return maaTreeDestroyNode(top); /* No children */

    for (pt = top;;) {
	if (pt->down) pt = pt->down;
	else {
	    if (!pt->right->head) {
		old = pt;
		pt  = pt->right;
		maaTreeDestroyNode(old);
	    } else {
		do {
		    old = pt;
		    if (!pt->parent)
			maaInternal(__FUNCTION__, "Parent doesn't exist\n");
		    pt = pt->parent;
		    maaTreeDestroyNode(old);
		    if (pt == top)return maaTreeDestroyNode(top);
		} while (pt->right->head);
		old = pt;
		pt  = pt->right;
		maaTreeDestroyNode(old);
	    }
	}
    }
}

/* Disconnect subtree rooted at node and return pointer to node. */

maaTreeT maaTreeDisconnect(maaTreeT node)
{
    _maaTreeCheck(node);

    if (!node) return NULL;

				/* Make sibling a proper head */
    if (node->head) {
	node->right->head = 1;

	if (node->parent) {
	    if (node->parent->down != node)
		maaInternal(__FUNCTION__,
			    "Head node is not parent's child\n");
	    if (node->right != node) node->parent->down = node->right;
	    else                     node->parent->down = NULL;
	}
    }

				/* Disconnect from siblings */
    node->right->left = node->left;
    node->left->right = node->right;
    node->right       = node->left = node;
    node->parent      = NULL;
    node->head        = 1;

    return node;
}

maaTreeT maaTreeAppend(maaTreeT parent, maaTreeT child)
{
    _maaTreeCheck(parent);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");

    if (parent->down) {		/* Parent already has children */
	child->right              = parent->down;
	child->left               = parent->down->left;
	child->head               = 0;
	parent->down->left->right = child;
	parent->down->left        = child;
    } else {			/* Parent doesn't have children */
	parent->down = child;
	child->head  = 1;
    }
    
    child->parent = parent;

    return parent;
}

maaTreeT maaTreePrepend(maaTreeT parent, maaTreeT child)
{
    _maaTreeCheck(parent);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");
    
    if (parent->down) {		/* Parent already has children */
	child->right              = parent->down;
	child->left               = parent->down->left;
	parent->down->left->right = child;
	parent->down->left        = child;
	parent->down->head        = 0;
    }
    
    parent->down  = child;
    child->head   = 1;
    child->parent = parent;

    return parent;
}

maaTreeT maaTreeInsertBefore(maaTreeT sibling, maaTreeT child)
{
    _maaTreeCheck(sibling);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");

    child->left          = sibling->left;
    child->right         = sibling;
    child->parent        = sibling->parent;
    sibling->left->right = child;
    sibling->left        = child;

    if (sibling->head) {
	sibling->head = 0;
	child->head   = 1;
	if (sibling->parent) sibling->parent->down = child;
    } else {
	child->head   = 0;
    }

    return sibling;
}

maaTreeT maaTreeInsertAfter(maaTreeT sibling, maaTreeT child)
{
    _maaTreeCheck(sibling);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");

    child->left          = sibling;
    child->right         = sibling->right;
    child->parent        = sibling->parent;
    child->head          = 0;
    sibling->right->left = child;
    sibling->right       = child;

    return sibling;
}

maaTreeT maaTreeInsertLast(maaTreeT sibling, maaTreeT child)
{
    maaTreeT point;
    
    _maaTreeCheck(sibling);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");

				/* Find last sibling */
    if (sibling->head) {
	point = sibling->left;
    } else { 
	for (point = sibling; !point->right->head; point = point->right)
	    ;
    }
    maaTreeInsertAfter(point, child);
    
    return sibling;
}

maaTreeT maaTreeInsertFirst(maaTreeT sibling, maaTreeT child)
{
    maaTreeT point;
    
    _maaTreeCheck(sibling);
    _maaTreeCheck(child);

    if (child->parent) maaInternal(__FUNCTION__, "Child has parent\n");
    if (child->right != child)
	maaInternal(__FUNCTION__, "Child has siblings\n");

				/* Find first sibling */
    for (point = sibling; !point->head; point = point->left)
	;
    maaTreeInsertBefore(point, child);
    
    return sibling;
}
	
void maaTreeSetString(maaTreeT node, const char *string)
{
    _maaTreeCheck(node);
    node->string   = string ? maaAtomString(string) : NULL;
    node->attribs |= MAA_TREE_STRING;
}

void maaTreeSetInteger(maaTreeT node, int i)
{
    _maaTreeCheck(node);
    node->integer  = i;
    node->attribs |= MAA_TREE_INT;
}

void maaTreeSetReal(maaTreeT node, double r)
{
    _maaTreeCheck(node);
    node->real     = r;
    node->attribs |= MAA_TREE_REAL;
}

void maaTreeSetAttrib(maaTreeT node, const char *name, const char *value)
{
    maaTreeAttribT pair;

    _maaTreeCheck(node);
    if (!name) return;
    pair        = maaAllocZ(sizeof(*pair));
    pair->name  = maaAtomString(name);
    pair->value = value ? maaAtomString(value) : NULL;
    if (!node->list) node->list = maaListCreate();
    maaListAppend(node->list, pair);
}

int maaTreeHasString(maaTreeT node)
{
    _maaTreeCheck(node);
    return (node->attribs & MAA_TREE_STRING) != 0;
}

int maaTreeHasInteger(maaTreeT node)
{
    _maaTreeCheck(node);
    return (node->attribs & MAA_TREE_INT) != 0;
}

int maaTreeHasReal(maaTreeT node)
{
    _maaTreeCheck(node);
    return (node->attribs & MAA_TREE_REAL) != 0;
}

int maaTreeHasAttrib(maaTreeT node)
{
    _maaTreeCheck(node);
    return (node->list != NULL);
}

int maaTreeId(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->id;
}

maaTreeT maaTreeParent(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->parent;
}

maaTreeT maaTreeChild(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->down;
}

maaTreeT maaTreeSibling(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->right != node ? node->right : NULL;
}

const char *maaTreeString(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->string;
}

int maaTreeInteger(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->integer;
}

double maaTreeReal(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->real;
}

const char *maaTreeAttrib(maaTreeT node, const char *name)
{
    maaIteratorT   iter;
    maaTreeAttribT pair;
    const char     *n;
    
    _maaTreeCheck(node);
    if (!node->list || !name) return NULL;
    n = maaAtomString(name);
    MAA_LIST_ITERATE(node->list, iter, pair) {
	if (pair->name == n) return pair->value;
    }
    return NULL;
}

maaListT maaTreeAttribList(maaTreeT node)
{
    _maaTreeCheck(node);
    return node->list;
}

void maaTreeIteratorInit(maaTreeT node, maaIteratorT *iter, maaTreeWalkT walk)
{
    _maaTreeCheck(node);
    
    iter->a = node;
    iter->b = NULL;
    iter->c = walk;
    iter->d = 0;
    iter->e = 1;
    maaTreeIteratorNext(iter);
}

int maaTreeIteratorNext(maaIteratorT *iter)
{
    maaTreeT     root = iter->a;
    maaTreeT     this = iter->b;
    maaTreeWalkT walk = iter->c;
    int          pos  = iter->d;

    if (!iter->e) return 0;	/* End of walk */
    
    for (;;) {
	if (!this) {
	    this = root, pos  = -1;
	} else {
	    if (pos == 1 && this->right == root) {
		iter->b = NULL;
		iter->e = 0;
		return 0;
	    }
	    if (pos == -1) {
		if (this->down) this = this->down, pos = -1;
		else            pos = 1;
	    } else {
		if (!this->right->head) this = this->right, pos = -1;
		else {
		    if (pos == 1) {
			if (!this->parent)
			    maaInternal(__FUNCTION__, "No parent\n");
			this = this->parent, pos = 1;
		    } else
			pos = 1;
		}
	    }
	}
	if (walk == MAA_TREE_PREORDER  && pos != -1) continue;
	if (walk == MAA_TREE_POSTORDER && pos !=  1) continue;
	iter->b = this;
	iter->d = pos;
	return 1;
    }
}

maaTreeT maaTreeIteratorDatum(maaIteratorT *iter, int *position)
{
    _maaTreeCheck(iter->a);
    if (position) *position = iter->d;
    return iter->b;
}

void maaTreePrint(maaTreeT root, FILE *stream)
{
    maaIteratorT iter;
    maaTreeT     node;
    int          pos;
    int          offset = 0;
    int          first  = 1;
    int          nodes  = 0;
    
    _maaTreeCheck(root);
    if (!stream) stream = stdout;

    MAA_TREE_ITERATE(root, iter, node, MAA_TREE_INORDER, pos) {
	nodes = 1;
	if (pos < 0) {
	    if (first) first = 0;
	    else       fprintf(stream, "\n");
	    fprintf(stream, "%*c%d", offset += 2, '(', maaTreeId(node));
	    if (maaTreeHasInteger(node))
		fprintf(stream, "/%d", maaTreeInteger(node));
	    if (maaTreeHasReal(node))
		fprintf(stream, "/%f", maaTreeReal(node));
	    if (maaTreeHasString(node))
		fprintf(stream, "/\"%s\"", maaTreeString(node));
	    if (maaTreeHasAttrib(node)) {
		maaIteratorT   iter2;
		maaTreeAttribT pair;
		maaListT       list = maaTreeAttribList(node);

		MAA_LIST_ITERATE(list, iter2, pair) {
		    fprintf(stream, " [%s=%s]", pair->name, pair->value);
		}
	    }
	} else {
	    fprintf(stream, ")");
	    offset -= 2;
	}
    }
    if (nodes) printf("\n");
}
