/* maaP.h -- Private header for maa
 * Created: Sun Jul  4 11:25:37 1999 by faith@dict.org
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: maaP.h,v 1.19 2000/08/13 11:22:51 faith Exp $
 * 
 */

#ifndef _MAAP_H_
#define _MAAP_H_

#include "standard.h"
#include "maa.h"
#include "version.h"
#include "config.h"

#define MAA_ARENA_MAGIC        0x12345678LU
#define MAA_AVLTREE_MAGIC      0x0ea1b33fLU
#define MAA_BLOCK_MAGIC        0xb10cb10cLU
#define MAA_BLOCK_NEXT_MAGIC   0xc21dc21dLU
#define MAA_FLAG_MAGIC         0xdeadbeefLU
#define MAA_HASH_MAGIC         0x0daa3456LU
#define MAA_LIST_MAGIC         0x11511151LU
#define MAA_OPTION_MAGIC       0x010f5a45LU
#define MAA_RANDOM_MAGIC       0xf33dbe3fLU
#define MAA_SKIPLIST_MAGIC     0x1234fedcLU
#define MAA_STACK_MAGIC        0x514c514cLU
#define MAA_TIMER_MAGIC        0xb3eff00dLU
#define MAA_TREE_MAGIC         0x31415926LU

#define MAA_USE_BLOCK          1	/* Use block allocator internally */

#define MAA_ARENA_CHUNK        (10*1024)

#define MAA_HASH_SEGMENT_COUNT 1024
#define MAA_HASH_BUCKET_COUNT  64
#define MAA_HASH_BUCKET_MASK   (MAA_HASH_BUCKET_COUNT - 1)
#define MAA_HASH_MIN_BUCKETS   1
#define MAA_HASH_BUCKET_LOAD   5.0
#define MAA_HASH_BUCKET_MARK   0.25

#define MAA_SKIPLIST_MAXLEVEL  15

#define CHECK_FUNCTION(name,type,magicvalue)                      \
static __inline__ void name(type object)                          \
{                                                                 \
    if (!object) maaFatal(__FUNCTION__, "Null object\n");         \
    if (object->magic != magicvalue)                              \
	maaFatal(__FUNCTION__,                                    \
		 "Bad magic (found 0x%08lx instead of 0x%08lx\n", \
		 object->magic,                                   \
		 magicvalue);                                     \
}

#ifdef DMALLOC_FUNC_CHECK
# include "dmalloc.h"
#endif

#endif
