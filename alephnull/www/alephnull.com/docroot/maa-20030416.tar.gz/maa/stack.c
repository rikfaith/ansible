/* stack.c -- Simple singly-linked stack
 * Created: Mon Jul  5 13:20:30 1999 by faith@dict.org
 * Copyright 1999 Julian E. C. Squires (tek@wiw.org)
 * Copyright 1999, 2000 Rickard E. Faith (faith@dict.org)
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *  
 * $Id: stack.c,v 1.13 2000/08/20 13:16:19 faith Exp $
 *
 * Arenas would improve speed a lot, I believe. -T
 * I agree. -R
 * Without block allocator: 3.235956 S for 421 * 10000 ops
 * With block allocator:    0.911240 S for 421 * 10000 ops
 *
 */

#include "maaP.h"

typedef struct maaStackElementS {
    const void              *datum;
    struct maaStackElementS *next;
} *maaStackElementT;

struct maaStackS {
    unsigned long    magic;
    maaStackElementT head;
    maaBlockT        block;
};

CHECK_FUNCTION(_maaStackCheck, maaStackT, MAA_STACK_MAGIC)

/*
 * Create an empty stack.
 *
 * Returns: the newly allocated stack object.
 */
maaStackT maaStackCreate(void)
{
    maaStackT stack = maaAlloc(sizeof(*stack));

    stack->magic = MAA_STACK_MAGIC;
    stack->head  = NULL;
    stack->block = NULL;
    if (MAA_USE_BLOCK)
	stack->block = maaBlockCreate(sizeof(struct maaStackElementS));
    return stack;
}

/*
 * Free all the allocated memory associated with a stack.
 *
 * Params: stack - the stack to destroy.
 */
unsigned long maaStackDestroy(maaStackT stack)
{
    maaStackElementT e;
    maaStackElementT next;
    unsigned long    ret;

    _maaStackCheck(stack);
    ret = stack->magic = ~MAA_STACK_MAGIC;
    
    if (MAA_USE_BLOCK) maaBlockDestroy(stack->block);
    else {
	for (e = stack->head; e; e = next) {
	    next = e->next;
	    maaFree(e);
	}
    }
    maaFree(stack);
    return ret;
}

/*
 * Push an item onto the stack.
 *
 * Note: we don't do any real verification of the integrity of
 *       the stack here, remember that.
 *
 * Params: stack - the stack to operate on.
 *         datum - the datum to push onto stack.
 */
void maaStackPush(maaStackT stack, const void *datum)
{
    maaStackElementT e;
    
    _maaStackCheck(stack);

    e           = (MAA_USE_BLOCK
		   ? maaBlockAlloc(stack->block)
		   : maaAlloc(sizeof(*e)));
    e->datum    = datum;
    e->next     = stack->head;
    stack->head = e;
}

/*
 * Pop an item off the stack.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item formerly on the top of the stack.
 *
 */
void *maaStackPop(maaStackT stack)
{
    maaStackElementT e;
    const void       *datum = NULL;
    
    _maaStackCheck(stack);
    e = stack->head;
    if (e) {
	stack->head = e->next;
	datum       = e->datum;
	if (MAA_USE_BLOCK) maaBlockFree(stack->block, e); else maaFree(e);
    }
    return (void *)datum;	/* Discard const */
}

/*
 * Return the value on the top of the stack (without affecting the
 * stack). Top == most recently pushed.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the item at depth 0.
 */
const void *maaStackTop(maaStackT stack)
{
    _maaStackCheck(stack);
    return stack->head ? stack->head->datum : NULL;
}

/*
 * Picks an item from a stack (without affecting the stack).
 *
 * Params: stack - the stack to pick from.
 *         n     - the depth of the item to pick, 0 being the top of the
 *                 stack (most recently pushed).
 *
 * Returns: the item picked.
 */
void *maaStackPick(maaStackT stack, unsigned int n)
{
    maaStackElementT e;
    unsigned int     i;
    
    _maaStackCheck(stack);

    for (e = stack->head, i = 0; e && i < n; e = e->next, i++);
    return e ? (void *)e->datum : NULL;	/* Discard const */
}


/*
 * Get the depth of a stack. Note that this means the number of
 * items - calling this on a stack with one item will return 1,
 * but that item is at depth 0.
 *
 * Params: stack - the stack to operate on.
 *
 * Returns: the number of items on the stack.
 */
unsigned int maaStackDepth(maaStackT stack)
{
    maaStackElementT e;
    unsigned int     i;

    _maaStackCheck(stack);

    for (e = stack->head, i = 0; e; e = e->next) ++i;
    return i;
}


/*
 * Swap the top two items on the stack.
 *
 * Params: stack - the stack to operate on.
 */
void maaStackSwap(maaStackT stack)
{
    const void *datum0;
    const void *datum1;

    _maaStackCheck(stack);

    datum0 = maaStackPop(stack);
    datum1 = maaStackPop(stack);

    if (datum0) maaStackPush(stack, datum0);
    if (datum1) maaStackPush(stack, datum1);
}

/*
 * Duplicate the item on the top of the stack.
 *
 * Params: stack - the stack to operate on.
 */
void maaStackDup(maaStackT stack)
{
    const void *datum;
    
    _maaStackCheck(stack);
    if ((datum = maaStackTop(stack))) maaStackPush(stack, datum);
}

void maaStackIteratorInit(maaStackT stack, maaIteratorT *iter)
{
    _maaStackCheck(stack);
    iter->a = stack;
    iter->b = stack->head;
}

int maaStackIteratorNext(maaIteratorT *iter)
{
    maaStackT stack = iter->a;

    _maaStackCheck(stack);
    if (!iter->b) return 0;
    iter->b = ((maaStackElementT)iter->b)->next;
    return iter->b != NULL;
}

void *maaStackIteratorDatum(maaIteratorT *iter)
{
    maaStackT stack = iter->a;

    _maaStackCheck(stack);
    if (!iter->b) return NULL;
    return (void *)((maaStackElementT)iter->b)->datum; /* Discard const */
}
