<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Sandor TIHANYI <stihanyi+dw@gmail.com>
 * @author Siaynoq Mage <siaynoqmage@gmail.com>
 * @author schilling.janos <schilling.janos@gmail.com>
 * @author Szabó Dávid <szabo.david@gyumolcstarhely.hu>
 * @author Marton Sebok <sebokmarton@gmail.com>
 */
$lang['name']                  = 'Visszajelzés a DokuWiki használatáról (sok időt vehet igénybe a betöltése)';
$lang['submit']                = 'Adatok elküldése';
$lang['autosubmit']            = 'Adatok havonkénti automatikus elküldése.';
$lang['submissionFailed']      = 'Az adatok a következő hiba miatt nem kerültek elküldésre:';
$lang['submitDirectly']        = 'Az adatokat a következő űrlap segítségével lehet elküldeni.';
$lang['autosubmitError']       = 'Az adatok a következő hiba miatt nem kerültek automatikusan elküldésre:';
$lang['lastSent']              = 'Az adatokat elküldtük.';
